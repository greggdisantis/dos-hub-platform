
import { MeasurementPoint, InputUnits } from '../types';
import { snapToSixteenth } from './measurements';

/**
 * Supported phrases:
 * "lower left 122 and three-quarter inches" -> 122.75
 * "upper right 135 and one sixteenth inches" -> 135.0625
 * "top 200 and a half inches" -> 200.5
 * "description middle screen" -> proposed description "middle screen"
 */

const KEYWORD_MAP: Record<string, MeasurementPoint> = {
  'upper left': 'upperLeft', 'ul': 'upperLeft',
  'lower left': 'lowerLeft', 'll': 'lowerLeft',
  'overall left': 'overallLeft', 'ol': 'overallLeft',
  'upper right': 'upperRight', 'ur': 'upperRight',
  'lower right': 'lowerRight', 'lr': 'lowerRight',
  'overall right': 'overallRight', 'or': 'overallRight',
  'top': 'top', 't': 'top',
  'middle': 'middle', 'mid': 'middle', 'm': 'middle',
  'bottom': 'bottom', 'b': 'bottom'
};

const NUM_WORDS: Record<string, number> = {
  'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10,
  'eleven': 11, 'twelve': 12, 'thirteen': 13, 'fourteen': 14, 'fifteen': 15, 'a': 1
};

const DENOM_WORDS: Record<string, number> = {
  'sixteenth': 16, 'sixteenths': 16,
  'eighth': 8, 'eighths': 8,
  'quarter': 4, 'quarters': 4,
  'half': 2, 'halves': 2, 'halfs': 2
};

const WORD_TO_VAL: Record<string, number> = {
  'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9,
  'ten': 10, 'eleven': 11, 'twelve': 12, 'thirteen': 13, 'fourteen': 14, 'fifteen': 15, 'sixteen': 16, 'seventeen': 17, 'eighteen': 18, 'nineteen': 19,
  'twenty': 20, 'thirty': 30, 'forty': 40, 'fifty': 50, 'sixty': 60, 'seventy': 70, 'eighty': 80, 'ninety': 90,
  'hundred': 100
};

/**
 * Parses a single whole number from words or digits. 
 * Supports "one twenty two", "one hundred twenty", "122", "one 22".
 */
function parseSingleWholeNumber(words: string[]): { value: number; consumed: number } | null {
  if (words.length === 0) return null;

  let total = 0;
  let i = 0;
  let found = false;

  while (i < words.length) {
    const word = words[i];
    let val: number | undefined;

    if (word.match(/^\d+(\.\d+)?$/)) {
      val = parseFloat(word);
    } else if (WORD_TO_VAL[word] !== undefined) {
      val = WORD_TO_VAL[word];
    } else {
      break;
    }

    // Multiplier logic: "one hundred"
    if (words[i + 1] === 'hundred') {
      total += (val * 100);
      i += 2;
      found = true;
      continue;
    }

    // Implicit multiplier: "one twenty" (val 1-9 followed by tens word 20-90)
    const nextWord = words[i + 1];
    const nextVal = nextWord ? WORD_TO_VAL[nextWord] : undefined;
    if (val >= 1 && val <= 9 && nextVal !== undefined && nextVal >= 20 && nextVal <= 90) {
      total += (val * 100);
      i++;
      found = true;
      continue;
    }

    // Word + Digit shorthand: "one 22"
    if (val >= 1 && val <= 9 && nextWord && nextWord.match(/^\d{1,2}$/)) {
      total += (val * 100);
      i++;
      found = true;
      continue;
    }

    total += val;
    i++;
    found = true;

    // Termination: stop merging if we hit a whole number > 9 or a tens-ones boundary
    if (word.match(/^\d+$/) && parseFloat(word) > 9) break;
    if (val >= 10 && val <= 99) {
      const vNext = words[i] ? WORD_TO_VAL[words[i]] : undefined;
      if (vNext !== undefined && vNext >= 1 && vNext <= 9) {
        continue; // "twenty" "two" -> loop again
      }
      break;
    }
    if (val < 10) break; // "one" then stop (next might be another part or fraction)
  }

  return found ? { value: total, consumed: i } : null;
}

/**
 * Parses a numeric value from text, handling integers, decimals, digital fractions,
 * feet+inches assembly, and spoken word fractions.
 */
function parseNumericValue(words: string[], units: InputUnits = 'IN'): { value: number; consumed: number } | null {
  if (words.length === 0) return null;

  let baseInchesValue = 0;
  let fraction = 0;
  let consumed = 0;
  let found = false;

  // 1. Try to find the whole number part(s)
  const part1 = parseSingleWholeNumber(words);
  if (part1) {
    found = true;
    consumed = part1.consumed;

    if (units === 'FT_IN') {
      // Look for compact pattern: <feet> <inches>
      const part2 = parseSingleWholeNumber(words.slice(consumed));
      if (part2) {
        baseInchesValue = (part1.value * 12) + part2.value;
        consumed += part2.consumed;
      } else {
        // Assume only feet was spoken if no second whole number exists
        baseInchesValue = part1.value * 12;
      }
    } else {
      // Inches mode: Guard against ambiguous "Number Number" sequences (likely FT_IN errors)
      const part2 = parseSingleWholeNumber(words.slice(consumed));
      if (part2) {
        // "12 2" pattern detected in Inches mode - likely a feet+inches mistake
        return null; 
      }
      baseInchesValue = part1.value;
    }
  }

  // 2. Look ahead for fraction (either digital "3/4" or spoken "three quarters")
  const nextIdx = consumed;
  if (nextIdx < words.length) {
    const nextWord = words[nextIdx];
    
    // Check digital fraction "3/4"
    if (nextWord.includes('/')) {
      const parts = nextWord.split('/');
      const n = parseInt(parts[0], 10);
      const d = parseInt(parts[1], 10);
      if (!isNaN(n) && !isNaN(d) && d !== 0) {
        fraction = n / d;
        consumed++;
        found = true;
      }
    } 
    // Check spoken fraction "three quarters"
    else if (NUM_WORDS[nextWord] !== undefined && words[nextIdx + 1] && DENOM_WORDS[words[nextIdx + 1]]) {
      fraction = NUM_WORDS[nextWord] / DENOM_WORDS[words[nextIdx + 1]];
      consumed += 2;
      found = true;
    }
    // Check shorthand spoken fraction "a half" / "quarter"
    else if (DENOM_WORDS[nextWord]) {
      fraction = 1 / DENOM_WORDS[nextWord];
      consumed++;
      found = true;
    }
  }

  if (!found) return null;
  return { value: snapToSixteenth(baseInchesValue + fraction), consumed };
}

/**
 * Specifically parses only a numeric value from a transcript for Voice Measure mode.
 * Supports spoken numbers and feet+inches assembly.
 */
export function parseSpokenValue(transcript: string, units: InputUnits = 'IN'): number | null {
  const normalized = transcript
    .toLowerCase()
    .replace(/-/g, ' ')               // Replace hyphens with spaces
    .replace(/inches?|inch/g, '')     // Remove units
    .replace(/\band\b/g, ' ')         // Remove filler "and"
    .replace(/\s+/g, ' ')             // Collapse multiple spaces
    .trim();
  
  const words = normalized.split(' ');
  const result = parseNumericValue(words, units);
  return result ? result.value : null;
}

export interface VoiceResult {
  measurements: Partial<Record<MeasurementPoint, number>>;
  specialInstructions?: string;
  numCuts?: string;
  description?: string;
}

export function parseVoiceCommands(transcript: string, units: InputUnits = 'IN'): VoiceResult {
  const result: VoiceResult = { measurements: {} };

  // 1. MANDATORY NORMALIZATION STEP
  const normalized = transcript
    .toLowerCase()
    .replace(/-/g, ' ')
    .replace(/inches?|inch/g, '')
    .replace(/\band\b/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  // 2. Handle Description (Starts with "description ")
  if (normalized.startsWith('description ')) {
    result.description = normalized.slice('description '.length).trim();
  }

  // 3. Handle Special Instructions (extract from original to preserve casing)
  const instrKeywords = ['special instructions', 'instructions', 'notes'];
  for (const kw of instrKeywords) {
    const kwIdx = transcript.toLowerCase().indexOf(kw);
    if (kwIdx !== -1) {
      result.specialInstructions = transcript.slice(kwIdx + kw.length).trim();
      break;
    }
  }

  // 4. Handle Number of Cuts
  const cutsMatch = normalized.match(/number of cuts\s+(\d+)/);
  if (cutsMatch) {
    result.numCuts = cutsMatch[1];
  }

  // 5. Handle Measurements
  const words = normalized.split(' ');
  for (let i = 0; i < words.length; i++) {
    // Check for multi-word keyword "upper left"
    const twoWordKw = words[i] + ' ' + (words[i+1] || '');
    let matchedKw: string | null = null;
    let skip = 0;

    if (KEYWORD_MAP[twoWordKw]) {
      matchedKw = twoWordKw;
      skip = 1;
    } else if (KEYWORD_MAP[words[i]]) {
      matchedKw = words[i];
      skip = 0;
    }

    if (matchedKw) {
      const mappedPoint = KEYWORD_MAP[matchedKw];
      const nextWords = words.slice(i + skip + 1);
      const parseResult = parseNumericValue(nextWords, units);

      if (parseResult) {
        result.measurements[mappedPoint] = parseResult.value;
        i += (skip + parseResult.consumed);
      } else {
        i += skip;
      }
    }
  }

  return result;
}
