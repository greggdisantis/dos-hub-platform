
import { PhotoItem } from '../types';

/**
 * Resizes and compresses an image to JPEG format.
 * Constraints: Max 1600px dimension, 0.75 quality.
 */
export async function processImage(file: File): Promise<PhotoItem> {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => {
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;
                const maxDim = 1600;

                if (width > height) {
                    if (width > maxDim) {
                        height *= maxDim / width;
                        width = maxDim;
                    }
                } else {
                    if (height > maxDim) {
                        width *= maxDim / height;
                        height = maxDim;
                    }
                }

                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                if (!ctx) return reject(new Error('Canvas context not available'));
                
                ctx.drawImage(img, 0, 0, width, height);
                const dataUrl = canvas.toDataURL('image/jpeg', 0.75);
                
                resolve({
                    id: `img-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
                    name: file.name,
                    dataUrl,
                    createdAt: new Date().toISOString()
                });
            };
            img.onerror = () => reject(new Error('Failed to load image for processing'));
            img.src = e.target?.result as string;
        };
        reader.onerror = () => reject(new Error('Failed to read file'));
        reader.readAsDataURL(file);
    });
}
