import { OrderFormState } from '../types';

export const SCREENS_SHAREPOINT_FLOW_URL = "https://default17c29834ddd548ce80f97f00ad960f.74.environment.api.powerplatform.com:443/powerautomate/automations/direct/workflows/63911e1a6af94ab9af58222f4e253869/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=esyLufNr6NbKyKO6rtdosvhLQ4Ui28OLI1sT68y2n7w";

export interface SharePointSavePayload {
  filename: string;
  pdfBase64: string;
  meta: {
    projectName: string;
    submittersName: string;
    jobNumber: string;
    address: string;
    manufacturer: string;
    mountType: string;
    totalScreens: number;
  };
}

export interface SharePointResult {
  ok: boolean;
  status: number;
  json: any;
  text: string;
}

/**
 * Sends the generated PDF to SharePoint via a Power Automate Flow.
 * Payload and behavior match the dedicated screens ordering flow requirements.
 */
export const savePdfToSharePoint = async (payload: SharePointSavePayload): Promise<SharePointResult> => {
  // Ensure base64 is clean (no data URI prefix)
  const cleanBase64 = payload.pdfBase64.includes(",")
    ? payload.pdfBase64.split(",")[1]
    : payload.pdfBase64;

  const response = await fetch(SCREENS_SHAREPOINT_FLOW_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      filename: payload.filename,
      pdfBase64: cleanBase64,
      meta: payload.meta
    })
  });

  const responseText = await response.text();
  let responseJson: any = null;
  try {
    responseJson = JSON.parse(responseText);
  } catch (e) {
    // Not JSON
  }

  // Debug logging for audit/troubleshooting
  console.log(`[SharePoint] Flow Call Status: ${response.status}`);
  console.log(`[SharePoint] Flow Response:`, responseJson || responseText);

  return {
    ok: response.ok,
    status: response.status,
    json: responseJson,
    text: responseText
  };
};