
import { OrderFormState } from '../types';

declare global {
  interface Window {
    jspdf: any;
    html2canvas: any;
  }
}

/**
 * Builds a standardized slug for filenames.
 * - removes all special characters except spaces/hyphens
 * - replaces spaces with underscores
 * - collapse multiple underscores
 */
const buildSlug = (val: string): string => {
  return val
    .trim()
    .replace(/[^a-zA-Z0-9\s-]/g, '')
    .replace(/\s+/g, '_')
    .replace(/_+/g, '_');
};

/**
 * Generates a unique, deterministic filename following the rules:
 * [ProjectName]_[JobNumber-or-NO-JOB-NUMBER]_Screen-[##]_[FileType]_[YYYY-MM-DD]_[HHMMSS].[extension]
 */
export const generateFileName = (
  formData: OrderFormState, 
  screenId: string, 
  fileType: string, 
  extension: string
): string => {
  const projectName = formData.project.name.trim();
  if (!projectName) {
    throw new Error("File could not be saved because required naming information (Project Name) is missing.");
  }

  const projectSlug = buildSlug(projectName);
  const jobNum = formData.project.jobNumber?.trim();
  const jobPart = jobNum ? buildSlug(jobNum) : "NO-JOB-NUMBER";
  
  const now = new Date();
  const datePart = now.toISOString().split('T')[0];
  const timePart = now.toTimeString().split(' ')[0].replace(/:/g, ''); // HHMMSS

  // Ensure screenId is padded for Screen-## format if it's a number
  let screenPart = screenId;
  if (!isNaN(Number(screenId))) {
    screenPart = `Screen-${String(screenId).padStart(2, '0')}`;
  }

  const fileName = `${projectSlug}_${jobPart}_${screenPart}_${fileType}_${datePart}_${timePart}.${extension}`;
  
  // Audit logging
  console.log(`[FILE_AUDIT] Generated filename: ${fileName}`);
  
  return fileName;
};

/**
 * Shared internal helper to build the jsPDF instance from a DOM element.
 * This is the single source of truth for PDF layout generation.
 */
const getPdfInstance = async (element: HTMLElement | null): Promise<any> => {
    if (!element) {
        throw new Error("PDF content element not found.");
    }

    const html2canvas = window.html2canvas;
    const { jsPDF } = window.jspdf;

    const canvas = await html2canvas(element, {
        scale: 2, 
        useCORS: true,
        windowWidth: element.scrollWidth,
        windowHeight: element.scrollHeight,
    });

    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({
        orientation: 'p',
        unit: 'mm',
        format: 'a4',
    });

    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    
    const canvasWidth = canvas.width;
    const canvasHeight = canvas.height;

    const ratio = canvasHeight / canvasWidth;
    const imgHeight = pdfWidth * ratio;

    let heightLeft = imgHeight;
    let position = 0;

    pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, imgHeight);
    heightLeft -= pageHeight;

    while (heightLeft > 0) {
        position -= pageHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, imgHeight);
        heightLeft -= pageHeight;
    }
    
    return pdf;
};

/**
 * CORE SHARED FUNCTION: Generates the PDF and returns it as a Blob.
 */
export const generatePdfBlob = async (element: HTMLElement | null): Promise<Blob> => {
    const pdf = await getPdfInstance(element);
    return pdf.output('blob');
};

/**
 * Generates the PDF and returns it as a raw base64 string (no data: prefix).
 */
export const generatePdfBase64 = async (element: HTMLElement | null): Promise<{ base64: string; fileName: string }> => {
    const pdf = await getPdfInstance(element);
    const dataUri = pdf.output('datauristring');
    const base64 = dataUri.split(',')[1];
    return { base64, fileName: '' };
};

/**
 * Generates and triggers a browser download of the PDF.
 */
export const generatePdf = async (
  element: HTMLElement | null, 
  formData: OrderFormState,
  screenId: string = "All",
  fileType: string = "Order-Package"
): Promise<void> => {
    try {
        const pdf = await getPdfInstance(element);
        const fileName = generateFileName(formData, screenId, fileType, 'pdf');
        pdf.save(fileName);
    } catch (err: any) {
        console.error("Error generating/saving PDF:", err);
        alert(err.message || "An error occurred while generating the PDF.");
        throw err;
    }
};

/**
 * Generates the PDF and returns a temporary URL for browser-native previewing.
 */
export const getPdfUrl = async (element: HTMLElement | null): Promise<string> => {
    const blob = await generatePdfBlob(element);
    return URL.createObjectURL(blob);
};
