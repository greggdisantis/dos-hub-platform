import { ScreenManufacturer } from '../types';

// Helper to find the greatest common divisor
const gcd = (a: number, b: number): number => (b === 0 ? a : gcd(b, a % b));

// Helper to create a reduced fraction string label
const reduceFraction = (numerator: number, denominator: number): string => {
  if (numerator === 0) return '0';
  const commonDivisor = gcd(numerator, denominator);
  return `${numerator / commonDivisor}/${denominator / commonDivisor}`;
};

export const FRACTION_OPTIONS = Array.from({ length: 16 }, (_, i) => ({
  value: `${i}/16`,
  label: reduceFraction(i, 16),
}));

export const MOTOR_TYPES_BY_MANUFACTURER: Record<ScreenManufacturer, string[]> = {
  [ScreenManufacturer.MAGNATRACK]: ["Gaposa", "Somfy (Simu)"],
  [ScreenManufacturer.DOS_SCREENS]: ["Alpha", "Somfy"]
};

export const REMOTE_OPTIONS_BY_MOTOR_TYPE: Record<string, string[]> = {
  "Somfy": ["1-Channel", "5-Channel", "16-Channel"],
  "Somfy (Simu)": ["1-Channel", "5-Channel", "16-Channel"],
  "Alpha": ["1-Channel", "4-Channel", "8-Channel", "16-Channel"],
  "Gaposa": ["1-Channel", "5-Channel", "16-Channel"]
};

export const INSTALL_MOUNT_OPTIONS: string[] = ["Undermount", "Face-mount"];

export const MOTOR_SIDE_OPTIONS: string[] = ["— Select —", "Left", "Right"];

export const FRAME_COLOR_COLLECTIONS_BY_MANUFACTURER: Record<ScreenManufacturer, string[]> = {
    [ScreenManufacturer.DOS_SCREENS]: ["DOS", "StruXure"],
    [ScreenManufacturer.MAGNATRACK]: ["MagnaTrack", "StruXure"]
};

export const FRAME_COLORS_BY_COLLECTION: Record<string, string[]> = {
  "DOS": ["Stark White Texture", "Stark White", "Mid-Knight Black Texture", "Mid-Knight Black", "OIl Rubbed Bronze", "Oiled Rubbed Bronze lexture", "Ash Gray", "Desert Sand", "Classic Linen Texture", "Rust", "Olive Green", "Champagne", "Glacier Blue", "Grey-Bronze", "Ash Gray Texture"],
  "MagnaTrack": ["White", "Beige", "Night Sky", "Bronze", "Dark Grey", "Ivory", "Mill Finish", "Silver Pearl"],
  "StruXure": ["StruXure White", "StruXure Black", "StruXure Gray", "StruXure Bronze", "StruXure Tan", "StruXure Adobe"]
};

// --- V3 SCREEN SELECTION CONSTANTS ---

export const SCREEN_SELECTION_RESET_STATE = {
    screenType: '', twichellSeries: '', soltisSeries: '', screenColor: '',
    vinylWindowConfig: '', vinylOrientation: '' as '', 
    windowBorderMaterialType: '', windowBorderTwichellSeries: '', windowBorderSoltisSeries: '', windowBorderColor: '',
    remoteOption: '',
    faceMountSides: '',
    reverseMeasurements: false,
};

const SCREEN_TYPE_OPTIONS_BASE = [
    { value: "Twichell Solar", label: "Twichell Solar" },
    { value: "Twichell Insect", label: "Twichell Insect" },
    { value: "Vinyl", label: "Vinyl" },
    { value: "Ferrari Soltis", label: "Ferrari Soltis" },
];
const DEFENDER_SERIES_OPTION = { value: "Defender Series", label: "Defender Series" };

export const TWICHELL_SOLAR_SERIES = ["80 Tex", "90 Tex", "95 Nano", "97 Nano", "99 Nano"];
export const FERRARI_SOLTIS_SERIES = ["VeoZip", "Proof 502"];

export const SCREEN_COLORS: Record<string, string[]> = {
    "Twichell Solar_80 Tex": ["Black","Black/Brown","Desert Sand","White","Brown","Dusk Grey","Sandstone"],
    "Twichell Solar_90 Tex": ["Black","Black/Brown","Desert Sand","White","Brown","Dusk Grey","Sandstone"],
    "Twichell Solar_95 Nano": ["Flat Black","White","Bone","Sable","Stone Texture","Shadow Texture","Espresso Texture","Granite","Tobacco","Charcoal","Desert Sand","Almond","Café","Tumbleweed"],
    "Twichell Solar_97 Nano": ["Flat Black","Granite","Espresso texture","Tobacco","Charcoal","White","Bone","Sable","Desert Sand","Almond","Café","Stone Texture","Shadow Texture","Tumbleweed Texture"],
    "Twichell Solar_99 Nano": ["Flat Black","Granite","Espresso texture","Tobacco","Charcoal"],
    "Twichell Insect": ["Black","White"],
    "Ferrari Soltis_VeoZip": ["Graphite Black","Grey Pepper","Sandalwood","Volcano","Shadow","Sea Urchin","Sea Lion","Lunar Surface","Tundra","Mistral","Macadamia","Natural","Cumulus","Edelweiss","Frost White"],
    "Ferrari Soltis_Proof 502": ["White","Boulder","Concrete","Black","Champagne","Hemp","Pepper","Lemon","Buttercup","Orange","Raspberry","Poppy","Burgundy","Porcelain Green","Tennis Green","Lagoon","Victoria Blue","Midnight Blue","Marine","Aluminum"],
    "Defender Series": ["White","White & Tan","Black & Tan","Bronze","Granite","Grey","Black"],
};

export const VINYL_WINDOW_CONFIG_OPTIONS = ["1 Window", "2 Windows", "Full Clear Vinyl w/ 6” Solid Border", "Custom Config – See special instructions"];
export const VINYL_ORIENTATION_OPTIONS = ["Horizontal", "Vertical"];

// --- V3 HELPER FUNCTIONS ---

export const getScreenTypeOptions = (manufacturer: ScreenManufacturer) => {
    const options = [...SCREEN_TYPE_OPTIONS_BASE];
    if (manufacturer === ScreenManufacturer.MAGNATRACK) {
        options.push(DEFENDER_SERIES_OPTION);
    }
    return [{ value: "", label: "— Select Type —" }, ...options];
};

export const getVinylBorderMaterialOptions = (manufacturer: ScreenManufacturer) => {
    // Same as screen types, but no "Twichell Insect" or "Vinyl"
    const options = SCREEN_TYPE_OPTIONS_BASE.filter(opt => opt.value !== "Twichell Insect" && opt.value !== "Vinyl");
    if (manufacturer === ScreenManufacturer.MAGNATRACK) {
        options.push(DEFENDER_SERIES_OPTION);
    }
    return [{ value: "", label: "— Select Material —" }, ...options];
};

export const getScreenColorOptionsV3 = (type?: string, series?: string): string[] => {
    const key = series ? `${type}_${series}` : type;
    if (!key || !SCREEN_COLORS[key]) {
        return ["— Select —"];
    }
    return ["— Select —", ...SCREEN_COLORS[key]];
};

// --- LEGACY & GENERIC HELPERS ---

export const getMotorTypeOptions = (manufacturer: ScreenManufacturer): string[] => {
  return ["— Select —", ...(MOTOR_TYPES_BY_MANUFACTURER[manufacturer] || [])];
};

export const getRemoteOptions = (motorType?: string | null): string[] => {
  if (!motorType || !REMOTE_OPTIONS_BY_MOTOR_TYPE[motorType]) {
    return [];
  }
  return REMOTE_OPTIONS_BY_MOTOR_TYPE[motorType];
};

export const getFrameColorCollectionOptions = (manufacturer: ScreenManufacturer): string[] => {
    return ["— Select —", ...FRAME_COLOR_COLLECTIONS_BY_MANUFACTURER[manufacturer]];
};

export const getFrameColorOptionsByCollection = (collection?: string): string[] => {
  if (!collection || !FRAME_COLORS_BY_COLLECTION[collection]) return ["— Select —"];
  return ["— Select —", ...FRAME_COLORS_BY_COLLECTION[collection]];
};


// Build-out thresholds in inches
export const BUILDOUT_TRIGGER_IN = 3 / 8; // 0.375
export const BUILDOUT_1X2_MAX_IN = 3 / 4; // 0.75
export const BUILDOUT_2X2_MAX_IN = 1 + 7 / 8; // 1.875

// U-Channel requirement thresholds in inches
export const UCHANNEL_THRESHOLD_MAGNATRACK = 3 / 8; // 0.375
export const UCHANNEL_THRESHOLD_DOS = 1 + 1 / 2; // 1.5

/**
 * Determines if U-Channel is needed based on the manufacturer and the difference
 * between the Top and Bottom horizontal measurements.
 */
export const isUChannelNeeded = (manufacturer: ScreenManufacturer, tBDiffInches: number): boolean => {
  if (manufacturer === ScreenManufacturer.MAGNATRACK) {
    return tBDiffInches > UCHANNEL_THRESHOLD_MAGNATRACK;
  }
  if (manufacturer === ScreenManufacturer.DOS_SCREENS) {
    return tBDiffInches > UCHANNEL_THRESHOLD_DOS;
  }
  return false;
};