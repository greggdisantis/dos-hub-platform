import { assertIsSnappedToSixteenth, isDev } from './dev';

/**
 * Helper to find the greatest common divisor for fraction reduction.
 */
const gcd = (a: number, b: number): number => (b === 0 ? a : gcd(b, a % b));

/**
 * Rounds a total inch value to the nearest 1/16th of an inch.
 */
export function snapToSixteenth(totalInches: number): number {
  if (isNaN(totalInches)) return 0;
  const result = Math.round(totalInches * 16) / 16;
  if (isDev) {
    assertIsSnappedToSixteenth(result, 'snapToSixteenth output');
  }
  return result;
}

// --- NEW CONVERSION HELPERS ---

/**
 * Builds a total inches value from feet, inches, and a 16th fraction.
 */
export function buildTotalInchesFromFtInFrac(ft: number, inch: number, frac16: number): number {
    const total = (ft * 12) + inch + (frac16 / 16);
    return snapToSixteenth(total);
}

/**
 * Builds a total inches value from total inches and a 16th fraction.
 */
export function buildTotalInchesFromInFrac(inchTotal: number, frac16: number): number {
    const total = inchTotal + (frac16 / 16);
    return snapToSixteenth(total);
}

/**
 * Splits a total inch value into its feet, inches, and 16th-fraction components.
 * Replaces the old splitToFtInFrac with a more robust name.
 */
export function parseTotalInchesToFtInFrac(totalInches: number | null): { ft: number; inch: number; frac16: number } {
  if (totalInches === null || isNaN(totalInches) || totalInches < 0) return { ft: 0, inch: 0, frac16: 0 };
  
  const snapped = snapToSixteenth(totalInches);
  let ft = Math.floor(snapped / 12);
  const remainingInches = snapped - (ft * 12);
  let inch = Math.floor(remainingInches);
  const fraction = remainingInches - inch;
  let frac16 = Math.round(fraction * 16);

  // Handle carry-over
  if (frac16 === 16) {
    inch += 1;
    frac16 = 0;
  }
  if (inch === 12) {
    ft += 1;
    inch = 0;
  }

  return { ft, inch, frac16 };
}

/**
 * Splits a total inch value into its total inches and 16th-fraction components.
 */
export function parseTotalInchesToInFrac(totalInches: number | null): { inchTotal: number; frac16: number } {
    if (totalInches === null || isNaN(totalInches) || totalInches < 0) return { inchTotal: 0, frac16: 0 };

    const snapped = snapToSixteenth(totalInches);
    let inchTotal = Math.floor(snapped);
    const fraction = snapped - inchTotal;
    let frac16 = Math.round(fraction * 16);

    // Handle carry-over
    if (frac16 === 16) {
        inchTotal += 1;
        frac16 = 0;
    }

    return { inchTotal, frac16 };
}


// --- FORMATTING HELPERS ---

/**
 * Formats a total inch value into a display string (e.g., 8' 3 7/8").
 * Fractions are reduced to their simplest form.
 */
export function formatFtInFrac(totalInches: number): string {
  if (isNaN(totalInches)) return "Invalid Measurement";
  
  const { ft, inch, frac16 } = parseTotalInchesToFtInFrac(totalInches);
  
  let result = `${ft}' ${inch}`;
  
  if (frac16 > 0) {
    const commonDivisor = gcd(frac16, 16);
    const numerator = frac16 / commonDivisor;
    const denominator = 16 / commonDivisor;
    result += ` ${numerator}/${denominator}`;
  }
  
  result += '"';
  
  return result;
}

/**
 * Formats a total inch value into a display string with inches and a reduced fraction.
 * Example: 118.4375 -> "118 7/16""
 */
export function formatInchesFrac(totalInches: number | null | undefined): string {
  if (totalInches === null || totalInches === undefined || isNaN(totalInches)) return "—";

  const { inchTotal, frac16 } = parseTotalInchesToInFrac(totalInches);

  let result = `${inchTotal}`;

  if (frac16 > 0) {
    const commonDivisor = gcd(frac16, 16);
    const numerator = frac16 / commonDivisor;
    const denominator = 16 / commonDivisor;
    result += ` ${numerator}/${denominator}`;
  }

  result += '"';

  return result;
}