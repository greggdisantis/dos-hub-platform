
// Simple check for development environment.
// In a real build process, this would be process.env.NODE_ENV !== 'production'
export const isDev = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';

/**
 * Asserts that a value is snapped to the nearest 1/16th.
 * Logs a warning to the console if the assertion fails.
 * This should only be used in development mode.
 * @param value The number to check.
 * @param context A string describing where the check is happening.
 */
export function assertIsSnappedToSixteenth(value: number, context: string = 'Unknown'): void {
  if (typeof value !== 'number' || isNaN(value)) {
    console.warn(`[Dev Assertion Failed] in ${context}: Value is not a number.`, { value });
    return;
  }
  
  const tolerance = 1e-9;
  const isSnapped = Math.abs(value * 16 - Math.round(value * 16)) < tolerance;
  
  if (!isSnapped) {
    console.warn(`[Dev Assertion Failed] in ${context}: Value is not snapped to a 1/16" increment.`, {
      value,
      multiplied: value * 16,
      rounded: Math.round(value * 16),
    });
  }
}
