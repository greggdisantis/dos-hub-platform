
import { OrderFormState, FormErrors, ScreenErrors } from '../types';

export const validateForm = (formData: OrderFormState): { isValid: boolean; errors: FormErrors } => {
    const errors: FormErrors = { globals: {}, screens: [] };
    let isValid = true;

    // Globals validation
    if (!formData.globals.manufacturer) {
        errors.globals!.manufacturer = "Manufacturer is required.";
        isValid = false;
    }

    // Per-screen validations
    for (let i = 0; i < formData.screens.length; i++) {
        const screen = formData.screens[i];
        const screenErrors: ScreenErrors = {};
        let screenHasError = false;

        // If Face-mount, # of Sides is required
        if (screen.selections.installMount === 'Face-mount' && !screen.selections.faceMountSides) {
            if (!screenErrors.selections) screenErrors.selections = {};
            screenErrors.selections.faceMountSides = `⚠️ Screen #${i + 1}: # of Sides is required for Face-mount before calculations can run.`;
            screenHasError = true;
        }

        if (screenHasError) {
            errors.screens![i] = screenErrors;
            isValid = false;
            // Return early to only show one error at a time for clarity
            return { isValid, errors };
        }
    }
    
    // Final screens check
    if (formData.screens.length === 0) {
        isValid = false;
    }

    return { isValid, errors };
};

export const findFirstErrorMessage = (errors: FormErrors): string | null => {
    if (errors.globals) {
        for (const key in errors.globals) {
            if (errors.globals[key as keyof typeof errors.globals]) {
                return errors.globals[key as keyof typeof errors.globals]!;
            }
        }
    }
    if (errors.screens) {
        for (const screenError of errors.screens) {
            if (screenError?.selections) {
                 for (const key in screenError.selections) {
                    if (screenError.selections[key as keyof typeof screenError.selections]) {
                        return screenError.selections[key as keyof typeof screenError.selections]!;
                    }
                }
            }
            if (screenError?.measurements) {
                 for (const key in screenError.measurements) {
                    if (screenError.measurements[key as keyof typeof screenError.measurements]) {
                        return screenError.measurements[key as keyof typeof screenError.measurements]!;
                    }
                }
            }
        }
    }
    return null;
};
