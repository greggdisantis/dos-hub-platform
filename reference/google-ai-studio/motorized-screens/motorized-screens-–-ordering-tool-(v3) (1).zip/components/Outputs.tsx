import React from 'react';
import { ScreenConfig, CalculationResults } from '../types';

const ReportItem: React.FC<{ label: string; value: React.ReactNode; className?: string }> = ({ label, value, className }) => (
    <div className={`flex justify-between items-baseline py-2 border-b border-gray-100 ${className}`}>
        <span className="text-sm font-medium text-gray-600">{label}:</span>
        <span className="text-sm text-gray-800 font-semibold text-right">{value || '—'}</span>
    </div>
);

const ScreenReport: React.FC<{ screen: ScreenConfig; uChannelAppliedToAll: boolean }> = ({ screen, uChannelAppliedToAll }) => {
    const { outputs, selections, numCuts } = screen;
    if (!outputs) return null;
    
    const displayMotorSide = selections.motorSide && selections.motorSide !== '— Select —' ? selections.motorSide : '—';
    
    const buildOutValue = outputs.buildOut.value;
    const buildOutRequired = buildOutValue?.needed === true;
    const buildOutType = buildOutValue?.type;
    const buildOutFlagged = buildOutType === 'FLAG';
    const buildOutDisplayType = buildOutType === '1x2' ? '1”x2”' : buildOutType === '2x2' ? '2”x2”' : buildOutType;

    return (
        <div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                 {/* Block 1 - Screen Selections */}
                 <div>
                    <h5 className="font-semibold text-gray-700 mb-2">Screen Configuration</h5>
                    <div className="p-4 bg-gray-50/70 rounded-md border">
                        <ReportItem label="Screen Type" value={selections.screenType} />
                        {selections.screenType === 'Twichell Solar' && <ReportItem label="Twichell Series" value={selections.twichellSeries} />}
                        {selections.screenType === 'Ferrari Soltis' && <ReportItem label="Soltis Series" value={selections.soltisSeries} />}
                        {selections.screenColor && <ReportItem label="Screen Color" value={selections.screenColor} />}
                        
                        {selections.screenType === 'Vinyl' && (
                            <>
                                <ReportItem label="Window Config" value={selections.vinylWindowConfig} />
                                {selections.vinylOrientation && <ReportItem label="Orientation" value={selections.vinylOrientation} />}
                                <ReportItem label="Border Material" value={selections.windowBorderMaterialType} />
                                {selections.windowBorderMaterialType === 'Twichell Solar' && <ReportItem label="Border Series" value={selections.windowBorderTwichellSeries} />}
                                {selections.windowBorderMaterialType === 'Ferrari Soltis' && <ReportItem label="Border Series" value={selections.windowBorderSoltisSeries} />}
                                <ReportItem label="Border Color" value={selections.windowBorderColor} />
                            </>
                        )}
                    </div>
                </div>

                {/* Block 2 - Other Selections */}
                 <div>
                     <h5 className="font-semibold text-gray-700 mb-2">Frame & Mount</h5>
                     <div className="p-4 bg-gray-50/70 rounded-md border">
                        <ReportItem label="Frame Collection" value={selections.frameColorCollection} />
                        <ReportItem label="Frame Color" value={selections.frameColor} />
                        <ReportItem label="Install Mount Type" value={selections.installMount} />
                        {selections.installMount === 'Face-mount' && <ReportItem label="# of Sides" value={selections.faceMountSides} />}
                        <ReportItem label="Motor Type" value={selections.motorType} />
                        <ReportItem label="Motor Side" value={displayMotorSide} />
                        <ReportItem label="Remote" value={selections.remoteOption} />
                     </div>
                </div>

                {/* Block 3 - Calculation Summary */}
                <div>
                     <h5 className="font-semibold text-gray-700 mb-2">Calculation Summary</h5>
                     <div className="p-4 bg-gray-50/70 rounded-md border">
                        {selections.reverseMeasurements && (
                            <div className="mb-3">
                                <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-100 text-indigo-800 border border-indigo-300 uppercase tracking-tight">
                                    ⚠ Reverse Measurements
                                </span>
                            </div>
                        )}
                        <ReportItem label="Upper Slope (S)" value={outputs.upperSlopeIn.displayValue} />
                        <ReportItem label="Left Height" value={outputs.leftHeightIn.displayValue} />
                        <ReportItem label="Right Height" value={outputs.rightHeightIn.displayValue} />
                        <ReportItem label="T-B Diff" value={outputs.tbDiffIn.displayValue} />
                        <ReportItem label="Track to Track" value={outputs.trackToTrackIn.displayValue} />
                        <ReportItem label="Slope Direction" value={outputs.slopeDirection.displayValue} />
                        <ReportItem label="High Side" value={outputs.highSide.displayValue} />
                        <ReportItem label="Low Side" value={outputs.lowSide.displayValue} />
                        <ReportItem label="Bias" value={outputs.bias.displayValue} />
                        <ReportItem label="U-Channel" value={outputs.uChannel.displayValue} />
                        <div className="relative">
                            <ReportItem label="Build-out" value={
                                buildOutFlagged 
                                ? <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-bold bg-amber-100 text-amber-800 border border-amber-300">FLAG</span> 
                                : outputs.buildOut.displayValue
                            } />
                            {buildOutRequired && !buildOutFlagged && (
                                <ReportItem label="Build-out Type" value={buildOutDisplayType} />
                            )}
                            {buildOutFlagged && (
                                <p className="text-[10px] text-amber-700 font-medium mt-1 leading-tight">
                                    ⚠️ Build-out flagged — confirm build-out requirement before ordering.
                                </p>
                            )}
                        </div>
                        {outputs.extendedHoodIn.displayValue !== "—" && (
                            <ReportItem label="Extended Hood" value={outputs.extendedHoodIn.displayValue} />
                        )}
                        <ReportItem label="# of Cuts" value={numCuts || '—'} />
                     </div>
                </div>
            </div>
        </div>
    );
};

const FlagsSection: React.FC<{ screens: ScreenConfig[] }> = ({ screens }) => {
    const MISMATCH_TOLERANCE_IN = 0.125; // 1/8"
    const allFlags: string[] = [];

    screens.forEach((screen, idx) => {
        const screenNum = idx + 1;
        const { measurements, outputs } = screen;
        const { upperLeft: ul, lowerLeft: ll, overallLeft: ol, upperRight: ur, lowerRight: lr, overallRight: or } = measurements;

        // Left Consistency Flags
        if ((ul !== null && ll !== null && ol !== null) && Math.abs((ul + ll) - ol) > MISMATCH_TOLERANCE_IN) {
            allFlags.push(`Screen #${screenNum}: Left side check mismatch — UL + LL must match OL within 1/8".`);
        }

        // Right Consistency Flags
        if ((ur !== null && lr !== null && or !== null) && Math.abs((ur + lr) - or) > MISMATCH_TOLERANCE_IN) {
            allFlags.push(`Screen #${screenNum}: Right side check mismatch — UR + LR must match OR within 1/8".`);
        }

        // NEW BUILD-OUT FLAGS (Driven by S > 1.75)
        const sValue = outputs?.upperSlopeIn.value ?? 0;
        if (sValue > 1.75) {
            allFlags.push(`Screen #${screenNum}: NOTICE: Build-out Material Exceeded Threshold`);
            allFlags.push(`Screen #${screenNum}: NOTICE: SLOPE EXCEEDS 1-3/4”`);
        } else if (outputs?.buildOut.value?.needed === true) {
            // Only add default build-out flag if slope isn't blocking
            allFlags.push(`Screen #${screenNum}: Build-out required/detected.`);
        }
    });

    if (allFlags.length === 0) return null;

    return (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 shadow-sm mb-8 animate-in fade-in duration-300">
            <h4 className="text-sm font-bold text-amber-900 uppercase tracking-wide mb-3 flex items-center">
                <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
                Flags & Warnings
            </h4>
            <ul className="space-y-1.5">
                {allFlags.map((flag, i) => (
                    <li key={i} className="text-sm text-amber-800 flex items-start">
                        <span className="mr-2 mt-1.5 w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0"></span>
                        {flag}
                    </li>
                ))}
            </ul>
        </div>
    );
};

interface Props {
    results: CalculationResults;
    isCalculating: boolean;
    error: string | null;
}

const Outputs: React.FC<Props> = ({ results, isCalculating, error }) => {
    if (error || !results || results.screens.length === 0) {
        return null;
    }

    if (isCalculating) {
        return (
            <div className="p-6 bg-white rounded-lg shadow">
                 <h3 className="text-lg font-semibold text-gray-700 border-b pb-3 mb-4">Outputs</h3>
                 <div className="text-center py-8">
                    <p className="text-gray-500">Calculating...</p>
                 </div>
            </div>
        );
    }
    
    return (
        <div className="p-6 bg-white rounded-lg shadow space-y-8">
             <h3 className="text-lg font-semibold text-gray-700 border-b pb-3 uppercase tracking-wider text-xs font-bold text-gray-500">Output Summary</h3>
             
             <FlagsSection screens={results.screens} />

             {results.screens.map((screen, index) => (
                <div key={screen.id} className="border-t border-gray-100 pt-6 first:border-t-0 first:pt-0">
                    <h4 className="font-bold text-gray-800 mb-4 flex items-center">
                        <span className="bg-indigo-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded mr-2">SCREEN #{index + 1}</span>
                        <span className="font-medium text-gray-600 truncate">{screen.description || 'No Description'}</span>
                    </h4>
                    <ScreenReport screen={screen} uChannelAppliedToAll={results.uChannelAppliedToAll} />
                </div>
             ))}
        </div>
    );
};

export default Outputs;