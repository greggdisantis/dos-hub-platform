
import React from 'react';
import { GlobalSelections, ScreenManufacturer, FormErrors, InputUnits } from '../types';
import { getMotorTypeOptions } from '../utils/constants';
import DetailedScreenSelections from './DetailedScreenSelections';

interface Props {
  globals: GlobalSelections;
  onChange: (field: keyof GlobalSelections, value: any) => void;
  errors?: FormErrors['globals'];
  anyUChannelRequired: boolean;
}

const GlobalSelectionsComponent: React.FC<Props> = ({ globals, onChange, errors, anyUChannelRequired }) => {
  const totalScreensOptions = Array.from({ length: 20 }, (_, i) => i + 1);
  const motorTypeOptions = getMotorTypeOptions(globals.manufacturer);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 items-end">
        <div>
          <label htmlFor="manufacturer" className="block text-sm font-medium text-gray-600">
            Screen Manufacturer
          </label>
          <select
            id="manufacturer"
            value={globals.manufacturer}
            onChange={(e) => onChange('manufacturer', e.target.value as ScreenManufacturer)}
            className={`mt-1 block w-full pl-3 pr-10 py-2 text-base border focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md bg-blue-100 text-black [*:option]:text-black ${
                errors?.manufacturer ? 'border-red-500' : 'border-gray-300'
            }`}
          >
            <option>{ScreenManufacturer.DOS_SCREENS}</option>
            <option>{ScreenManufacturer.MAGNATRACK}</option>
          </select>
          {errors?.manufacturer && <p className="mt-1 text-xs text-red-600">{errors.manufacturer}</p>}
        </div>
        <div>
          <label htmlFor="totalScreens" className="block text-sm font-medium text-gray-600">
            Total # of Screens
          </label>
          <select
            id="totalScreens"
            value={globals.totalScreens}
            onChange={(e) => onChange('totalScreens', parseInt(e.target.value, 10))}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md bg-blue-100 text-black [*:option]:text-black"
          >
            {totalScreensOptions.map(num => (
              <option key={num} value={num}>{num}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="inputUnits" className="block text-sm font-medium text-gray-600">
            Input Units
          </label>
          <select
            id="inputUnits"
            value={globals.inputUnits}
            onChange={(e) => onChange('inputUnits', e.target.value as InputUnits)}
            className="mt-1 block w-full pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md bg-blue-100 text-black [*:option]:text-black"
          >
            <option value="FT_IN">Feet + Inches + 1/16"</option>
            <option value="IN">Inches + 1/16"</option>
          </select>
        </div>
         <div>
          <label htmlFor="motorType" className="block text-sm font-medium text-gray-600">Motor Type (Global)</label>
          <select id="motorType" value={globals.motorType} onChange={e => onChange('motorType', e.target.value)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md bg-blue-100 text-black [*:option]:text-black">
            {motorTypeOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
          </select>
        </div>
      </div>

      {anyUChannelRequired && (
        <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-md">
            <div className="flex items-center justify-start space-x-4">
                <span className="text-sm font-medium text-yellow-800">U-Channel Required on at least one screen. Apply U-Channel to ALL screens for consistency?</span>
                <div className="flex items-center space-x-2">
                    <button type="button" onClick={() => onChange('applyUChannelToAll', true)} className={`px-4 py-1 text-sm font-medium rounded-md ${globals.applyUChannelToAll ? 'bg-yellow-500 text-white shadow-sm' : 'bg-white text-yellow-800 border border-yellow-300'}`}>Yes</button>
                    <button type="button" onClick={() => onChange('applyUChannelToAll', false)} className={`px-4 py-1 text-sm font-medium rounded-md ${!globals.applyUChannelToAll ? 'bg-yellow-500 text-white shadow-sm' : 'bg-white text-yellow-800 border border-yellow-300'}`}>No</button>
                </div>
            </div>
        </div>
      )}

      <div className="pt-6 border-t border-gray-200">
        <div className="flex items-center space-x-4 mb-4">
          <span className="text-sm font-medium text-gray-600">All Screen Material & Frame Colors the Same?</span>
          <div className="flex items-center space-x-2">
            <button type="button" onClick={() => onChange('allSame', true)} className={`px-4 py-2 text-sm font-medium rounded-md ${globals.allSame ? 'bg-indigo-600 text-white shadow-sm' : 'bg-white text-gray-700 border border-gray-300'}`}>Yes</button>
            <button type="button" onClick={() => onChange('allSame', false)} className={`px-4 py-2 text-sm font-medium rounded-md ${!globals.allSame ? 'bg-indigo-600 text-white shadow-sm' : 'bg-white text-gray-700 border border-gray-300'}`}>No</button>
          </div>
        </div>

        {globals.allSame && (
          <div>
              <DetailedScreenSelections 
                  selections={globals} 
                  onChange={(field, value) => onChange(field as keyof GlobalSelections, value)} 
                  manufacturer={globals.manufacturer}
                  errors={errors}
              />
          </div>
        )}
      </div>
    </div>
  );
};

export default GlobalSelectionsComponent;
