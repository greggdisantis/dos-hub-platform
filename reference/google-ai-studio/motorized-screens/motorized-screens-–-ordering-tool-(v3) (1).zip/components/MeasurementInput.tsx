import React, { useState, useEffect } from 'react';
import { FieldError, InputUnits, MeasurementValue } from '../types';
import { FRACTION_OPTIONS } from '../utils/constants';
import { 
    parseTotalInchesToFtInFrac, 
    parseTotalInchesToInFrac,
    buildTotalInchesFromFtInFrac,
    buildTotalInchesFromInFrac,
} from '../utils/measurements';

interface Props {
  label: string;
  totalInches: MeasurementValue;
  onChange: (totalInches: MeasurementValue) => void;
  idPrefix: string;
  error?: FieldError;
  inputUnits: InputUnits;
}

const MeasurementInput: React.FC<Props> = ({ label, totalInches, onChange, idPrefix, error, inputUnits }) => {
  // Local state for display purposes, using strings to allow empty inputs
  const [displayValues, setDisplayValues] = useState({ ft: '', inch: '', inchTotal: '', frac16: 0 });

  // Update display state when the authoritative totalInches prop changes
  useEffect(() => {
    if (totalInches === null) {
      setDisplayValues({ ft: '', inch: '', inchTotal: '', frac16: 0 });
      return;
    }

    if (inputUnits === 'FT_IN') {
        const { ft, inch, frac16 } = parseTotalInchesToFtInFrac(totalInches);
        setDisplayValues(prev => ({ ...prev, ft: String(ft), inch: String(inch), frac16 }));
    } else { // 'IN'
        const { inchTotal, frac16 } = parseTotalInchesToInFrac(totalInches);
        setDisplayValues(prev => ({ ...prev, inchTotal: String(inchTotal), frac16 }));
    }
  }, [totalInches, inputUnits]);
  
  const handleDisplayChange = (part: keyof typeof displayValues, value: string | number) => {
    const newDisplay = { ...displayValues, [part]: value };
    setDisplayValues(newDisplay); // Update UI immediately

    // Determine if all relevant numeric fields are empty
    const isEmpty = inputUnits === 'FT_IN' 
        ? (newDisplay.ft === '' && newDisplay.inch === '') 
        : (newDisplay.inchTotal === '');

    if (isEmpty) {
        onChange(null);
        return;
    }

    // Calculate new totalInches and propagate up
    let newTotalInches = 0;
    if (inputUnits === 'FT_IN') {
        const ft = parseInt(newDisplay.ft, 10) || 0;
        let inch = parseInt(newDisplay.inch, 10) || 0;
        if (inch > 11) inch = 11; // Clamp inches
        const frac16 = Number(newDisplay.frac16);
        newTotalInches = buildTotalInchesFromFtInFrac(ft, inch, frac16);
    } else { // 'IN'
        const inchTotal = parseInt(newDisplay.inchTotal, 10) || 0;
        const frac16 = Number(newDisplay.frac16);
        newTotalInches = buildTotalInchesFromInFrac(inchTotal, frac16);
    }
    onChange(newTotalInches);
  };
  
  const errorClass = 'border-red-500 focus:ring-red-500 focus:border-red-500';
  const baseClass = 'w-full px-2 py-1.5 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm placeholder-[#B0B0B0]';

  return (
    <div>
      <label htmlFor={`${idPrefix}-feet`} className="block text-sm font-medium text-gray-600 mb-1">{label}</label>
      <div className={`grid gap-2 ${inputUnits === 'FT_IN' ? 'grid-cols-3' : 'grid-cols-2'}`}>
        {inputUnits === 'FT_IN' && (
          <input
            type="number"
            id={`${idPrefix}-feet`}
            value={displayValues.ft}
            onChange={(e) => handleDisplayChange('ft', e.target.value)}
            onBlur={(e) => {
                const val = e.target.value;
                handleDisplayChange('ft', val === '' ? '' : Math.max(0, parseInt(val, 10) || 0));
            }}
            placeholder="Enter value here"
            aria-label={`${label} feet`}
            className={`${baseClass} ${error ? errorClass : ''}`}
            min="0"
          />
        )}
        <input
          type="number"
          id={`${idPrefix}-inches`}
          value={inputUnits === 'FT_IN' ? displayValues.inch : displayValues.inchTotal}
          onChange={(e) => handleDisplayChange(inputUnits === 'FT_IN' ? 'inch' : 'inchTotal', e.target.value)}
          onBlur={(e) => {
            const val = e.target.value;
            if (val === '') {
                handleDisplayChange(inputUnits === 'FT_IN' ? 'inch' : 'inchTotal', '');
                return;
            }
            let parsed = Math.max(0, parseInt(val, 10) || 0);
            if (inputUnits === 'FT_IN' && parsed > 11) parsed = 11;
            handleDisplayChange(inputUnits === 'FT_IN' ? 'inch' : 'inchTotal', parsed);
          }}
          placeholder="Enter value here"
          aria-label={`${label} inches`}
          className={`${baseClass} ${error ? errorClass : ''}`}
          min="0"
          max={inputUnits === 'FT_IN' ? "11" : undefined}
        />
        <select
          id={`${idPrefix}-fraction`}
          value={`${displayValues.frac16}/16`}
          onChange={(e) => handleDisplayChange('frac16', e.target.value.split('/')[0])}
          aria-label={`${label} fraction`}
          className={`w-full pl-2 pr-7 py-1.5 text-base border focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md bg-blue-100 text-black [*:option]:text-black ${error ? errorClass : 'border-gray-300'}`}
        >
          {FRACTION_OPTIONS.map(opt => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>
      </div>
       {error && <p className="mt-1 text-xs text-red-600">{error}</p>}
    </div>
  );
};

export default MeasurementInput;