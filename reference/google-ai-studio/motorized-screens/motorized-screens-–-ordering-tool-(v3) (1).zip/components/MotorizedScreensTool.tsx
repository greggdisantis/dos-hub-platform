
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { OrderFormState, ScreenConfig, ScreenManufacturer, ScreenMeasurements, FormErrors, ScreenSelections, ScreenOutputs, CalculationResults, CalculatedValue, BuildOutType, GlobalApplicableSelections, MeasurementPoint, AttachmentItem, SavedProject } from '../types';
import ProjectHeader from './ProjectHeader';
import GlobalSelections from './GlobalSelections';
import ScreenItem from './ScreenItem';
import ActionsRow from './ActionsRow';
import Outputs from './Outputs';
import { formatInchesFrac, snapToSixteenth } from '../utils/measurements';
import { generatePdf, generatePdfBlob, getPdfUrl, generatePdfBase64, generateFileName } from '../utils/pdfGenerator';
import { savePdfToSharePoint, SharePointSavePayload } from '../utils/sharepoint';
import { getFrameColorOptionsByCollection, getMotorTypeOptions, SCREEN_SELECTION_RESET_STATE, BUILDOUT_TRIGGER_IN, BUILDOUT_1X2_MAX_IN, BUILDOUT_2X2_MAX_IN, isUChannelNeeded, getScreenTypeOptions, INSTALL_MOUNT_OPTIONS, getRemoteOptions, FRAME_COLOR_COLLECTIONS_BY_MANUFACTURER } from '../utils/constants';
import PdfContent from './PdfContent';
import PreviewModal from './PreviewModal';
import { validateForm, findFirstErrorMessage } from '../utils/validation';
import { isDev } from '../utils/dev';
import QaChecklist from './QaChecklist';
import { getAuth } from "firebase/auth";

const SAVE_SERVICE_URL = "https://dos-save-service-1089575066430.us-east1.run.app";
const DEFAULT_TOOL_KEY = "motorized_screens_v3";
const MISMATCH_TOLERANCE_IN = 0.125; // 1/8"

function getReturnUrlFromQuery() {
  const params = new URLSearchParams(window.location.search);
  const ru = params.get("returnUrl");
  return ru ? decodeURIComponent(ru) : null;
}

async function fetchWithFreshAuth(url: string, options: RequestInit = {}) {
  const auth = getAuth();
  const user = auth.currentUser;

  if (!user) {
    throw new Error("User not signed in.");
  }

  const headers = new Headers(options.headers || {});

  // 1) Always start with a forced refresh token
  const token = await user.getIdToken(true);
  headers.set("Authorization", `Bearer ${token}`);

  // 2) Ensure JSON header for POST/PUT when body exists
  const method = (options.method || "GET").toUpperCase();
  if ((method === "POST" || method === "PUT") && options.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  // 3) First attempt
  let resp = await fetch(url, { ...options, headers });

  // 4) If 401, force refresh again and retry once
  if (resp.status === 401) {
    const freshToken = await user.getIdToken(true);
    headers.set("Authorization", `Bearer ${freshToken}`);
    resp = await fetch(url, { ...options, headers });
  }

  return resp;
}

const initialScreenMeasurements: ScreenMeasurements = {
  upperLeft: null, lowerLeft: null, overallLeft: null,
  upperRight: null, lowerRight: null, overallRight: null,
  top: null, middle: null, bottom: null,
};

const initialGlobalApplicableSelections: GlobalApplicableSelections = {
    motorType: '',
    frameColorCollection: '',
    frameColor: '',
    reverseMeasurements: false,
    ...SCREEN_SELECTION_RESET_STATE,
};

const initialScreenSelections: ScreenSelections = {
    ...initialGlobalApplicableSelections,
    installMount: 'Undermount',
    remoteOption: '',
    faceMountSides: '',
    motorSide: '',
};

const createMissingValue = <T,>(missingReason: string): CalculatedValue<T> => {
  const trimmedReason = (missingReason || "").trim();
  return {
    value: null,
    missing: trimmedReason,
    displayValue: trimmedReason ? `— (missing: ${trimmedReason})` : `— (unable to compute)`,
  };
};

const getInches = (measurements: ScreenMeasurements, key: MeasurementPoint): number | null => {
    if (!measurements) return null;
    const val = measurements[key];
    return (typeof val === 'number' && val > 0) ? val : null;
};

const runCalculations = (currentFormData: OrderFormState): { updatedScreens: ScreenConfig[], anyUChannelRequired: boolean } => {
    const { manufacturer, applyUChannelToAll, allSame } = currentFormData.globals;
    let anyUChannelRequiredGlobal = false;

    const processedScreens: ScreenConfig[] = currentFormData.screens.map((screen) => {
        const measurements = screen.measurements;
        const selections = screen.selections;
        const rev = selections.reverseMeasurements;

        const rawUl = getInches(measurements, 'upperLeft');
        const rawLl = getInches(measurements, 'lowerLeft');
        const rawOl = getInches(measurements, 'overallLeft');
        const rawUr = getInches(measurements, 'upperRight');
        const rawLr = getInches(measurements, 'lowerRight');
        const rawOr = getInches(measurements, 'overallRight');

        const ul = rev ? rawUr : rawUl;
        const ur = rev ? rawUl : rawUr;
        const ll = rev ? rawLr : rawLl;
        const lr = rev ? rawLl : rawLr;
        const ol = rev ? rawOr : rawOl;
        const or = rev ? rawOl : rawOr;

        const t = getInches(measurements, 'top');
        const m = getInches(measurements, 'middle');
        const b = getInches(measurements, 'bottom');

        const slopeMissing = (ul === null || ur === null) ? 'UL, UR' : '';
        const leftHeightMissing = (ol === null || ul === null || ur === null) ? 'OL, UL, UR' : '';
        const rightHeightMissing = (or === null || ul === null || ur === null) ? 'OR, UL, UR' : '';
        const horizMissing = (t === null || b === null) ? 'T, B' : '';

        let sRaw = 0;
        let upperSlopeIn: CalculatedValue<number>;
        let slopeDirection: CalculatedValue<'Left' | 'Right' | 'Level'>;
        let highSide: CalculatedValue<'Left' | 'Right' | 'Level'>;
        let lowSide: CalculatedValue<'Left' | 'Right' | 'Level'>;

        if (ul !== null && ur !== null) {
            sRaw = snapToSixteenth(Math.abs(ur - ul));
            upperSlopeIn = { value: sRaw, displayValue: formatInchesFrac(sRaw) };
            if (ul > ur) {
                // High Side = Left, Low Side = Right -> Left to Right
                slopeDirection = { value: 'Left', displayValue: 'Left to Right' };
                highSide = { value: 'Left', displayValue: 'Left' };
                lowSide = { value: 'Right', displayValue: 'Right' };
            } else if (ur > ul) {
                // High Side = Right, Low Side = Left -> Right to Left
                slopeDirection = { value: 'Right', displayValue: 'Right to Left' };
                highSide = { value: 'Right', displayValue: 'Right' };
                lowSide = { value: 'Left', displayValue: 'Left' };
            } else {
                slopeDirection = { value: 'Level', displayValue: 'Level' };
                highSide = { value: 'Level', displayValue: 'Level' };
                lowSide = { value: 'Level', displayValue: 'Level' };
            }
        } else {
            upperSlopeIn = createMissingValue(slopeMissing);
            slopeDirection = createMissingValue(slopeMissing);
            highSide = createMissingValue(slopeMissing);
            lowSide = createMissingValue(slopeMissing);
        }

        let leftHeightIn: CalculatedValue<number>;
        if (ol !== null && ul !== null && ur !== null) {
            let lh = ol;
            if (sRaw === 0) {
                lh = ol;
            } else if (ul > ur) { // High Side == "Left"
                lh = ol - sRaw;
            } else { // High Side == "Right"
                lh = ol;
            }
            lh = snapToSixteenth(Math.max(0, lh));
            leftHeightIn = { value: lh, displayValue: formatInchesFrac(lh) };
        } else {
            leftHeightIn = createMissingValue(leftHeightMissing);
        }

        let rightHeightIn: CalculatedValue<number>;
        if (or !== null && ul !== null && ur !== null) {
            let rh = or;
            if (sRaw === 0) {
                rh = or;
            } else if (ur > ul) { // High Side == "Right"
                rh = or - sRaw;
            } else { // High Side == "Left"
                rh = or;
            }
            rh = snapToSixteenth(Math.max(0, rh));
            rightHeightIn = { value: rh, displayValue: formatInchesFrac(rh) };
        } else {
            rightHeightIn = createMissingValue(rightHeightMissing);
        }

        let tbDiffIn: CalculatedValue<number>;
        let uChannel: CalculatedValue<{ needed: boolean; applied: boolean }>;
        if (t !== null && b !== null) {
            const diff = snapToSixteenth(Math.abs(t - b));
            tbDiffIn = { value: diff, displayValue: formatInchesFrac(diff) };
            const needed = isUChannelNeeded(manufacturer, diff);
            if (needed) anyUChannelRequiredGlobal = true;
            uChannel = { 
                value: { needed, applied: needed }, 
                displayValue: needed ? 'Yes' : 'No' 
            };
        } else {
            tbDiffIn = createMissingValue(horizMissing);
            uChannel = createMissingValue(horizMissing);
        }

        // NEW BUILD-OUT RULES based on S (sRaw)
        let buildOut: CalculatedValue<{ needed: boolean; type: BuildOutType }>;
        if (ul !== null && ur !== null) {
            const S_in = sRaw;
            let needed = false;
            let type: BuildOutType = 'None';
            let displayVal = 'No';

            if (S_in >= 0.4375 && S_in <= 0.75) {
                needed = true;
                type = '1x2';
                displayVal = 'Required';
            } else if (S_in >= 0.8125 && S_in <= 1.75) {
                needed = true;
                type = '2x2';
                displayVal = 'Required';
            } else if (S_in > 1.75) {
                needed = true;
                type = 'FLAG';
                displayVal = 'FLAG';
            }

            buildOut = { value: { needed, type }, displayValue: displayVal };
        } else {
            buildOut = createMissingValue(slopeMissing);
        }

        let trackToTrackIn: CalculatedValue<number>;
        const uChannelNeededForTT = uChannel.value?.needed ?? false;
        if (uChannelNeededForTT) {
            if (t !== null && m !== null && b !== null) {
                const A = t - 0.125;
                const B1 = m;
                const C = b;
                const minVal = Math.min(A, B1, C);
                const tt = snapToSixteenth(minVal - 1.0);
                trackToTrackIn = { value: tt, displayValue: formatInchesFrac(tt) };
            } else {
                trackToTrackIn = createMissingValue('T, M, B');
            }
        } else {
            if (t !== null) {
                const tt = snapToSixteenth(t - 0.125);
                trackToTrackIn = { value: tt, displayValue: formatInchesFrac(tt) };
            } else {
                trackToTrackIn = createMissingValue('Top (T)');
            }
        }

        let extendedHoodIn: CalculatedValue<number>;
        const uChannelNeeded = uChannel.value?.needed || false;

        // NEW HIGHEST PRIORITY OVERRIDE: DOS Screens + Undermount
        if (manufacturer === ScreenManufacturer.DOS_SCREENS && selections.installMount === 'Undermount') {
            extendedHoodIn = { value: null, displayValue: "—" };
        }
        // NEW OVERRIDE: Undermount + MagnaTrack + U-Channel Needed
        else if (selections.installMount === 'Undermount' && manufacturer === ScreenManufacturer.MAGNATRACK && uChannelNeeded) {
            if (t !== null) {
                const eh = snapToSixteenth(t - 0.125);
                extendedHoodIn = { value: eh, displayValue: formatInchesFrac(eh) };
            } else {
                extendedHoodIn = createMissingValue('Top (T)');
            }
        } 
        // EXISTING OVERRIDE: Undermount + No U-Channel Needed (Suppression)
        else if (selections.installMount === 'Undermount' && !uChannelNeeded) {
            extendedHoodIn = { value: null, displayValue: "—" };
        } 
        // DEFAULT LOGIC: (requires M)
        else if (m !== null) {
            const eh = snapToSixteenth(m + 4.5);
            extendedHoodIn = { value: eh, displayValue: formatInchesFrac(eh) };
        } else {
            extendedHoodIn = createMissingValue('Middle (M)');
        }

        let bias: CalculatedValue<{ value: number }>;
        if (ul !== null && ur !== null) {
            const bVal = snapToSixteenth(sRaw / 2);
            bias = { value: { value: bVal }, displayValue: formatInchesFrac(bVal) };
        } else {
            bias = createMissingValue(slopeMissing);
        }

        const outputs: ScreenOutputs = {
            orderableWidthIn: m || 0,
            orderableHeightIn: Math.max(leftHeightIn.value || 0, rightHeightIn.value || 0),
            upperSlopeIn,
            leftHeightIn,
            rightHeightIn,
            slopeDirection,
            highSide,
            lowSide,
            trackToTrackIn,
            tbDiffIn,
            uChannel,
            buildOut,
            bias,
            extendedHoodIn,
            leftSideMismatch: (rawUl !== null && rawOl !== null && rawLl !== null) ? Math.abs((rawUl + rawLl) - rawOl) > MISMATCH_TOLERANCE_IN : false,
            rightSideMismatch: (rawUr !== null && rawOr !== null && rawLr !== null) ? Math.abs((rawUr + rawOr) - rawOr) > MISMATCH_TOLERANCE_IN : false,
        };

        return { ...screen, outputs };
    });

    const updatedScreens = processedScreens.map(screen => {
        if (applyUChannelToAll && anyUChannelRequiredGlobal && screen.outputs) {
            const prev = screen.outputs.uChannel.value;
            return {
                ...screen,
                outputs: {
                    ...screen.outputs,
                    uChannel: {
                        value: { needed: prev?.needed || false, applied: true },
                        displayValue: `Yes (Global Apply)`
                    }
                }
            };
        }
        return screen;
    });

    return { updatedScreens, anyUChannelRequired: anyUChannelRequiredGlobal };
};

const MotorizedScreensTool: React.FC = () => {
    const [formData, setFormData] = useState<OrderFormState>({
        project: { name: '', submitterName: '', date: new Date().toISOString().split('T')[0], address: '', jobNumber: '' },
        globals: {
            manufacturer: ScreenManufacturer.DOS_SCREENS,
            totalScreens: 1,
            allSame: true,
            applyUChannelToAll: false,
            inputUnits: 'IN',
            ...initialGlobalApplicableSelections
        },
        screens: [{
            id: 's-1',
            description: '',
            specialInstructions: '',
            uChannelNotes: '',
            buildOutColor: '',
            buildOutNotes: '',
            numCuts: '',
            selections: { ...initialScreenSelections },
            measurements: { ...initialScreenMeasurements },
            outputs: null,
            measurementPhotos: [],
            generalPhotos: [],
            attachments: [],
        }]
    });

    const [results, setResults] = useState<CalculationResults>(null);
    const [errors, setErrors] = useState<FormErrors>({});
    const [showValidation, setShowValidation] = useState(false);
    const [isCalculating, setIsCalculating] = useState(false);
    const [isExporting, setIsExporting] = useState(false);
    const [isSavingToSharePoint, setIsSavingToSharePoint] = useState(false);
    const [sharePointStatus, setSharePointStatus] = useState<{ 
        type: 'success' | 'error' | null; 
        message: string | null;
        folderPath?: string | null;
        webUrl?: string | null;
    }>({ type: null, message: null });
    
    const [previewUrl, setPreviewUrl] = useState<string | null>(null);
    const [previewTitle, setPreviewTitle] = useState<string>("PDF Preview");
    const [isGeneratingPreview, setIsGeneratingPreview] = useState(false);
    const [previewTargetIndex, setPreviewTargetIndex] = useState<number | null>(null);
    
    // Save/Load Service State
    const [dosToken, setDosToken] = useState<string | null>(null);
    const [toolKey, setToolKey] = useState<string>(DEFAULT_TOOL_KEY);
    const [savedProjects, setSavedProjects] = useState<SavedProject[]>([]);
    const [selectedProjectId, setSelectedProjectId] = useState<string>('');
    const [currentProjectId, setCurrentProjectId] = useState<string | null>(null);
    const [isSaveLoading, setIsSaveLoading] = useState(false);
    const [saveError, setSaveError] = useState<string | null>(null);
    const [saveSuccess, setSaveSuccess] = useState<string | null>(null);

    const pdfRef = useRef<HTMLDivElement>(null);
    const singleScreenPdfRef = useRef<HTMLDivElement>(null);
    const headerRef = useRef<any>(null);

    useEffect(() => {
        const params = new URLSearchParams(window.location.search);
        const token = params.get('dosToken');
        const tk = params.get('toolKey') || DEFAULT_TOOL_KEY;
        setToolKey(tk);
        if (token) {
            setDosToken(token);
            fetchSavedProjects(token, tk);
        }
    }, []);

    const fetchSavedProjects = async (token: string, tk: string) => {
        setIsSaveLoading(true);
        setSaveError(null);
        try {
            const resp = await fetch(`${SAVE_SERVICE_URL}/api/projects?toolKey=${tk}`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!resp.ok) throw new Error("Failed to fetch projects");
            const data = await resp.json();
            setSavedProjects(data);
        } catch (err: any) {
            setSaveError("Error fetching saved projects.");
        } finally {
            setIsSaveLoading(false);
        }
    };

    const handleLoadProject = async () => {
        if (!selectedProjectId || !dosToken) return;
        setIsSaveLoading(true);
        setSaveError(null);
        try {
            const resp = await fetch(`${SAVE_SERVICE_URL}/api/projects/${selectedProjectId}`, {
                headers: { 'Authorization': `Bearer ${dosToken}` }
            });
            if (!resp.ok) throw new Error("Failed to load project details");
            const projectData: SavedProject = await resp.json();
            
            if (projectData.payload?.inputs) {
                setFormData(projectData.payload.inputs);
                setCurrentProjectId(projectData.id);
                setSaveSuccess(`Loaded project: ${projectData.projectName}`);
                setTimeout(() => setSaveSuccess(null), 3000);
            }
        } catch (err: any) {
            setSaveError("Error loading project.");
        } finally {
            setIsSaveLoading(false);
        }
    };

    const generatePayload = () => {
        const flags: string[] = [];
        formData.screens.forEach((screen, idx) => {
            const { measurements, outputs } = screen;
            const { upperLeft: ul, lowerLeft: ll, overallLeft: ol, upperRight: ur, lowerRight: lr, overallRight: or } = measurements;
            const sValue = outputs?.upperSlopeIn.value ?? 0;
            
            if ((ul !== null && ll !== null && ol !== null) && Math.abs((ul + ll) - ol) > MISMATCH_TOLERANCE_IN) flags.push(`S#${idx+1} Left Mismatch`);
            if ((ur !== null && lr !== null && or !== null) && Math.abs((ur + lr) - or) > MISMATCH_TOLERANCE_IN) flags.push(`S#${idx+1} Right Mismatch`);
            
            if (sValue > 1.75) {
                flags.push(`S#${idx+1} NOTICE: Build-out Material Exceeded Threshold`);
                flags.push(`S#${idx+1} NOTICE: SLOPE EXCEEDS 1-3/4”`);
            } else if (outputs?.buildOut.value?.needed) {
                flags.push(`S#${idx+1} Build-out Required`);
            }
        });

        return {
            version: DEFAULT_TOOL_KEY,
            toolKey: toolKey,
            inputs: formData,
            output: results,
            flags: flags
        };
    };

    const handleSaveNew = async () => {
        if (!dosToken) return;
        if (!formData.project.name.trim()) {
            setSaveError("Project Name is required to save.");
            return;
        }

        setIsSaveLoading(true);
        setSaveError(null);
        try {
            const payload = generatePayload();
            const resp = await fetch(`${SAVE_SERVICE_URL}/api/projects`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${dosToken}`
                },
                body: JSON.stringify({
                    toolKey: toolKey,
                    projectName: formData.project.name,
                    payload
                })
            });
            if (!resp.ok) throw new Error("Failed to save project");
            const result = await resp.json();
            setCurrentProjectId(result.id);
            setSaveSuccess("New project saved successfully!");
            fetchSavedProjects(dosToken, toolKey);
            setTimeout(() => setSaveSuccess(null), 3000);
        } catch (err: any) {
            setSaveError("Error saving project.");
        } finally {
            setIsSaveLoading(false);
        }
    };

    const handleUpdateProject = async () => {
        if (!dosToken || !currentProjectId) return;
        if (!formData.project.name.trim()) {
            setSaveError("Project Name is required.");
            return;
        }

        setIsSaveLoading(true);
        setSaveError(null);
        try {
            const payload = generatePayload();
            const resp = await fetch(`${SAVE_SERVICE_URL}/api/projects/${currentProjectId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${dosToken}`
                },
                body: JSON.stringify({
                    projectName: formData.project.name,
                    payload
                })
            });
            if (!resp.ok) throw new Error("Failed to update project");
            setSaveSuccess("Project updated successfully!");
            fetchSavedProjects(dosToken, toolKey);
            setTimeout(() => setSaveSuccess(null), 3000);
        } catch (err: any) {
            setSaveError("Error updating project.");
        } finally {
            setIsSaveLoading(false);
        }
    };

    useEffect(() => {
        if (previewTargetIndex !== null) {
            const generate = async () => {
                setIsGeneratingPreview(true);
                try {
                    await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
                    
                    if (singleScreenPdfRef.current) {
                        const url = await getPdfUrl(singleScreenPdfRef.current);
                        setPreviewUrl(url);
                        setPreviewTitle(`Preview: Screen #${previewTargetIndex + 1} of ${formData.globals.totalScreens}`);
                    } else {
                        throw new Error("Preview container not mounted in time.");
                    }
                } catch (err: any) {
                    console.error("Single screen preview failed:", err);
                    alert("Failed to generate screen preview.");
                } finally {
                    setIsGeneratingPreview(false);
                    setPreviewTargetIndex(null);
                }
            };
            generate();
        }
    }, [previewTargetIndex, formData.globals.totalScreens]);

    useEffect(() => {
        setFormData(prev => {
            const count = prev.globals.totalScreens;
            if (prev.screens.length === count) return prev;
            
            const newScreens = [...prev.screens];
            if (newScreens.length < count) {
                for (let i = newScreens.length; i < count; i++) {
                    newScreens.push({
                        id: `s-${Date.now()}-${i}`,
                        description: '',
                        specialInstructions: '',
                        uChannelNotes: '',
                        buildOutColor: '',
                        buildOutNotes: '',
                        numCuts: '',
                        selections: { ...initialScreenSelections },
                        measurements: { ...initialScreenMeasurements },
                        outputs: null,
                        measurementPhotos: [],
                        generalPhotos: [],
                        attachments: [],
                    });
                }
            } else {
                newScreens.splice(count);
            }
            return { ...prev, screens: newScreens };
        });
    }, [formData.globals.totalScreens]);

    useEffect(() => {
        setIsCalculating(true);
        const timer = setTimeout(() => {
            const { updatedScreens, anyUChannelRequired } = runCalculations(formData);
            setResults({
                screens: updatedScreens,
                anyUChannelRequired,
                uChannelAppliedToAll: formData.globals.applyUChannelToAll
            });
            setIsCalculating(false);
        }, 300);
        return () => clearTimeout(timer);
    }, [formData]);

    const handleProjectChange = (field: keyof typeof formData.project, value: string) => {
        setFormData(prev => ({ ...prev, project: { ...prev.project, [field]: value } }));
    };

    const handleGlobalChange = (field: keyof typeof formData.globals, value: any) => {
        setFormData(prev => {
            const newGlobals = { ...prev.globals, [field]: value } as any;
            if (field === 'manufacturer') {
                newGlobals.motorType = '';
                newGlobals.frameColorCollection = '';
                newGlobals.frameColor = '';
            }
            const newScreens = prev.screens.map(s => {
                // Type safety: ensure field exists in global applicable selections before dynamic update
                if (newGlobals.allSame && field in initialGlobalApplicableSelections) {
                    return { ...s, selections: { ...s.selections, [field as keyof ScreenSelections]: value } as ScreenSelections };
                }
                return s;
            });
            return { ...prev, globals: newGlobals as typeof prev.globals, screens: newScreens };
        });
    };

    const handleScreenChange = (index: number, field: string, value: any) => {
        setFormData(prev => {
            const newScreens = [...prev.screens];
            const screen = { ...newScreens[index] };

            if (field.startsWith('measurements.')) {
                const point = field.split('.')[1] as MeasurementPoint;
                screen.measurements = { ...screen.measurements, [point]: value };
            } else if (field.startsWith('selections.')) {
                const subField = field.split('.')[1] as keyof ScreenSelections;
                screen.selections = { ...screen.selections, [subField]: value } as ScreenSelections;
            } else {
                (screen as any)[field] = value;
            }

            newScreens[index] = screen;
            return { ...prev, screens: newScreens };
        });
    };

    const handleExport = async () => {
        const { isValid, errors: validationErrors } = validateForm(formData);
        if (!isValid) {
            setErrors(validationErrors);
            const msg = findFirstErrorMessage(validationErrors);
            alert(msg || "Please correct the errors before exporting.");
            return;
        }

        setErrors({});
        setIsExporting(true);
        try {
            await generatePdf(pdfRef.current, formData);
        } catch (e) {
            console.error(e);
        } finally {
            setIsExporting(false);
        }
    };

    const handlePreviewAll = async () => {
        const { isValid, errors: validationErrors } = validateForm(formData);
        if (!isValid) {
            setErrors(validationErrors);
            const msg = findFirstErrorMessage(validationErrors);
            alert(msg || "Please correct the errors before previewing.");
            return;
        }

        setErrors({});
        setIsGeneratingPreview(true);
        try {
            await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
            const url = await getPdfUrl(pdfRef.current);
            setPreviewUrl(url);
            setPreviewTitle("Preview: Full Order Package");
        } catch (err) {
            console.error(err);
        } finally {
            setIsGeneratingPreview(false);
        }
    };

    const handleSaveToSharePoint = async () => {
        // DO add comment above each fix
        // Fix: Ensure projectName, jobNumber, and submitterName are strings before proceeding
        const projectName: string = formData.project.name?.trim() || "";
        const submitterName: string = formData.project.submitterName?.trim() || "";
        const jobNumber: string = formData.project.jobNumber?.trim() || "";
        
        // We calculate if we can save
        const isProjectValid = !!projectName;
        const isSubmitterValid = submitterName.length >= 2;
        const isJobValid = !!jobNumber;

        if (!isProjectValid || !isSubmitterValid || !isJobValid) {
            setShowValidation(true);
            
            // Scroll or focus to first missing field
            if (!isProjectValid) {
                headerRef.current?.focusName();
            } else if (!isSubmitterValid) {
                headerRef.current?.focusSubmitter();
                setSharePointStatus({ 
                    type: 'error', 
                    message: 'Cannot save: Submitter’s Name is required.' 
                });
            } else if (!isJobValid) {
                headerRef.current?.focusJob();
            }
            return;
        }

        // Defend against mismatches
        const hasBlockingMismatch = results?.screens.some(s => s.outputs?.leftSideMismatch || s.outputs?.rightSideMismatch) || false;
        if (hasBlockingMismatch) {
            setSharePointStatus({ 
                type: 'error', 
                message: 'Cannot save: Left and/or Right side dimensions must match Overall within 1/8".' 
            });
            return;
        }

        // NEW BUILD-OUT THRESHOLD GUARD
        const slopeExceedsThreshold = results?.screens.some(s => (s.outputs?.upperSlopeIn.value ?? 0) > 1.75) || false;
        if (slopeExceedsThreshold) {
            setSharePointStatus({ 
                type: 'error', 
                message: 'Cannot save: Upper Slope (S) exceeds 1-3/4". Adjust measurements/build-out approach before saving.' 
            });
            return;
        }

        const { isValid, errors: validationErrors } = validateForm(formData);
        if (!isValid) {
            setErrors(validationErrors);
            const msg = findFirstErrorMessage(validationErrors);
            alert(msg || "Please correct the errors before saving.");
            return;
        }

        setErrors({});
        setIsSavingToSharePoint(true);
        setSharePointStatus({ type: null, message: null });
        
        try {
            await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
            
            const { base64 } = await generatePdfBase64(pdfRef.current);
            
            // FILENAME FORMAT: ProjectName_JobNumber_YYYYMMDD.pdf
            const cleanProjectName = projectName.replace(/[^a-zA-Z0-9]/g, '');
            const cleanJobNumber = (jobNumber || "").replace(/[^a-zA-Z0-9]/g, '');
            const dateStr = new Date().toISOString().split('T')[0].replace(/-/g, '');
            const filename = `${cleanProjectName}_${cleanJobNumber}_${dateStr}.pdf`;

            // Calculate installMountType: Mixed if values differ
            const mounts = formData.screens.map(s => s.selections.installMount);
            const uniqueMounts = Array.from(new Set(mounts));
            const mountType = uniqueMounts.length > 1 ? "Mixed" : (uniqueMounts[0] || "Undermount");

            // Build exact payload structure for dedicated screens flow
            const payload: SharePointSavePayload = {
                filename,
                pdfBase64: base64,
                meta: {
                    projectName: formData.project.name,
                    submittersName: submitterName,
                    jobNumber: formData.project.jobNumber || "NO-JOB-NUMBER",
                    address: formData.project.address,
                    manufacturer: formData.globals.manufacturer as string,
                    mountType: mountType,
                    totalScreens: Number(formData.globals.totalScreens)
                }
            };

            // DO add comment above each fix
            // Fix: Cast result to any to avoid unknown type errors when accessing dynamic properties from the SharePoint flow response
            const result: any = await savePdfToSharePoint(payload);
            const resultJson: any = result.json;
            const isActuallyOk: boolean = result.ok && (resultJson?.ok !== false);

            if (isActuallyOk) {
                // DO add comment above each fix
                // Fix: Safely extract folderPath and webUrl, ensuring they are cast to string | null as expected by setSharePointStatus
                const fPath: string | null = typeof resultJson?.folderPath === 'string' ? (resultJson.folderPath as string) : null;
                const wUrl: string | null = typeof resultJson?.webUrl === 'string' ? (resultJson.webUrl as string) : null;
                setSharePointStatus({ 
                    type: 'success', 
                    message: `Saved to SharePoint: ${filename}`,
                    folderPath: fPath,
                    webUrl: wUrl
                });
                setTimeout(() => setSharePointStatus({ type: null, message: null }), 12000);
            } else {
                // DO add comment above each fix
                // Fix: Ensure all error message components are explicitly stringified to prevent unknown type assignment errors
                const jsonMsg: string = resultJson?.message ? String(resultJson.message) : "";
                const resultText: string = result.text ? String(result.text) : "";
                const resultStatus: string = result.status ? String(result.status) : "";
                const errorMsg: string = jsonMsg || resultText || `Flow failed: ${resultStatus}`;

                setSharePointStatus({ 
                    type: 'error', 
                    message: `SharePoint upload failed: ${errorMsg}` 
                });
            }
        } catch (err: any) {
            // DO add comment above each fix
            // Fix: Changed err from unknown to any and safely extract message to resolve "Type 'unknown' is not assignable to type 'string'" error
            console.error("SharePoint Save Failed Exception:", err);
            const msg: string = err?.message || String(err);
            setSharePointStatus({ 
                type: 'error', 
                message: `SharePoint upload failed: ${msg}` 
            });
        } finally {
            setIsSavingToSharePoint(false);
        }
    };

    const handlePreviewSingleScreen = (index: number) => {
        const { isValid, errors: validationErrors } = validateForm(formData);
        if (!isValid) {
            setErrors(validationErrors);
            const msg = findFirstErrorMessage(validationErrors);
            alert(msg || "Please correct the errors before previewing.");
            return;
        }

        setErrors({});
        setPreviewTargetIndex(index);
    };

    // Calculate if Save button should look enabled
    const hasBlockingMismatch = results?.screens.some(s => s.outputs?.leftSideMismatch || s.outputs?.rightSideMismatch) || false;
    const slopeExceedsThreshold = results?.screens.some(s => (s.outputs?.upperSlopeIn.value ?? 0) > 1.75) || false;
    const canSaveToSharePoint = !!formData.project.name?.trim() && !!formData.project.jobNumber?.trim() && (formData.project.submitterName?.trim().length || 0) >= 2 && !hasBlockingMismatch && !slopeExceedsThreshold;

    return (
        <div className="max-w-7xl mx-auto space-y-8 pb-24">
            {!dosToken && (
                <div className="bg-amber-50 border-l-4 border-amber-400 p-4 rounded shadow-sm flex items-center">
                    <svg className="h-5 w-5 text-amber-400 mr-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    <span className="text-amber-800 font-medium text-sm">Open this tool from DOS Hub to enable Save/Load.</span>
                </div>
            )}

            <div className={`bg-white p-6 rounded-lg shadow space-y-6 ${!dosToken ? 'opacity-50 grayscale pointer-events-none' : ''}`}>
                <div className="flex justify-between items-center border-b pb-3">
                    <h3 className="text-lg font-semibold text-gray-700">Saved Projects</h3>
                    <div className="flex space-x-3">
                        {currentProjectId && (
                            <span className="text-xs bg-indigo-100 text-indigo-700 px-2 py-1 rounded-full self-center">
                                Loaded Project: <span className="font-bold">{formData.project.name}</span>
                            </span>
                        )}
                        <button 
                            onClick={() => dosToken && fetchSavedProjects(dosToken, toolKey)}
                            className="text-xs font-bold text-indigo-600 hover:text-indigo-800 uppercase tracking-tight"
                        >
                            Refresh My Projects
                        </button>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 items-end">
                    <div>
                        <label className="block text-sm font-medium text-gray-600 mb-1">My Saved Projects</label>
                        <select 
                            value={selectedProjectId}
                            onChange={(e) => setSelectedProjectId(e.target.value)}
                            className="block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                        >
                            <option value="">— Select a Project —</option>
                            {savedProjects.map(p => (
                                <option key={p.id} value={p.id}>
                                    {p.projectName} ({new Date(p.updatedAt).toLocaleDateString()})
                                </option>
                            ))}
                        </select>
                    </div>
                    
                    <div className="flex space-x-2">
                        <button 
                            onClick={handleLoadProject}
                            disabled={!selectedProjectId || isSaveLoading}
                            className="flex-1 px-4 py-2 bg-indigo-50 text-indigo-700 font-bold text-sm rounded border border-indigo-200 hover:bg-indigo-100 disabled:opacity-50 transition-colors shadow-sm"
                        >
                            Load Selected
                        </button>
                    </div>

                    <div className="flex space-x-2">
                        <button 
                            onClick={handleSaveNew}
                            disabled={isSaveLoading || !formData.project.name}
                            className="flex-1 px-4 py-2 bg-indigo-600 text-white font-bold text-sm rounded hover:bg-indigo-700 disabled:opacity-50 transition-colors shadow-sm"
                        >
                            Save New Project
                        </button>
                        <button 
                            onClick={handleUpdateProject}
                            disabled={isSaveLoading || !currentProjectId}
                            className="flex-1 px-4 py-2 bg-white border border-indigo-600 text-indigo-700 font-bold text-sm rounded hover:bg-indigo-50 disabled:opacity-30 transition-colors shadow-sm"
                        >
                            Update Project
                        </button>
                    </div>
                </div>

                {(saveError || saveSuccess) && (
                    <div className={`text-xs font-semibold p-2 rounded border ${saveError ? 'bg-red-50 text-red-700 border-red-200' : 'bg-green-50 text-green-700 border-green-200'}`}>
                        {saveError || saveSuccess}
                    </div>
                )}
            </div>

            <div className="bg-white p-6 rounded-lg shadow space-y-6">
                <h3 className="text-lg font-semibold text-gray-700 border-b pb-3">Project Info</h3>
                <ProjectHeader 
                    ref={headerRef} 
                    project={formData.project} 
                    onChange={handleProjectChange} 
                    showValidation={showValidation}
                />
            </div>

            <div className="bg-white p-6 rounded-lg shadow space-y-6">
                <h3 className="text-lg font-semibold text-gray-700 border-b pb-3">Global Selections</h3>
                <GlobalSelections 
                    globals={formData.globals} 
                    onChange={handleGlobalChange} 
                    errors={errors.globals} 
                    anyUChannelRequired={results?.anyUChannelRequired || false}
                />
            </div>

            <div className="space-y-6">
                <h3 className="text-xl font-bold text-gray-800 px-2">Screens Configuration</h3>
                {formData.screens.map((screen, idx) => (
                    <ScreenItem 
                        key={screen.id}
                        screenNumber={idx + 1}
                        screenData={screen}
                        isAllSame={formData.globals.allSame}
                        manufacturer={formData.globals.manufacturer}
                        inputUnits={formData.globals.inputUnits}
                        globalMotorType={formData.globals.motorType}
                        anyUChannelRequired={results?.anyUChannelRequired || false}
                        uChannelAppliedToAll={formData.globals.applyUChannelToAll}
                        onChange={(field, value) => handleScreenChange(idx, field, value)}
                        onPreview={() => handlePreviewSingleScreen(idx)}
                        errors={errors.screens?.[idx]}
                    />
                ))}
            </div>

            <Outputs results={results} isCalculating={isCalculating} error={null} />

            <ActionsRow 
                onExport={handleExport} 
                onSaveToSharePoint={handleSaveToSharePoint}
                onPreviewAll={handlePreviewAll}
                isExporting={isExporting} 
                isSavingToSharePoint={isSavingToSharePoint}
                isPreviewingAll={isGeneratingPreview && previewTargetIndex === null}
                isCalculating={isCalculating} 
                error={findFirstErrorMessage(errors)} 
                sharePointStatus={sharePointStatus}
                isSharePointGated={!canSaveToSharePoint}
            />

            {isDev && results && <QaChecklist formData={formData} results={results} />}

            <div style={{ position: 'absolute', left: '-9999px', top: '-9999px', pointerEvents: 'none' }}>
                <PdfContent ref={pdfRef} formData={formData} results={results} anyUChannelRequired={results?.anyUChannelRequired || false} />
            </div>

            {previewTargetIndex !== null && (
                <div style={{ position: 'absolute', left: '-9999px', top: '-9999px', pointerEvents: 'none' }}>
                    <PdfContent 
                        ref={singleScreenPdfRef} 
                        formData={formData} 
                        results={results}
                        anyUChannelRequired={results?.anyUChannelRequired || false} 
                        onlyShowIndex={previewTargetIndex}
                    />
                </div>
            )}

            <PreviewModal 
                isOpen={!!previewUrl} 
                url={previewUrl} 
                title={previewTitle} 
                onClose={() => setPreviewUrl(null)} 
            />

            {isGeneratingPreview && (
                <div className="fixed inset-0 z-[110] flex items-center justify-center bg-white/50 backdrop-blur-[2px]">
                    <div className="bg-white p-8 rounded-lg shadow-2xl border border-gray-200 flex flex-col items-center">
                        <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mb-4"></div>
                        <p className="text-indigo-900 font-bold text-lg">Preparing PDF Preview...</p>
                        <p className="text-gray-500 text-sm mt-1">Rendering layout for capture.</p>
                    </div>
                </div>
            )}
        </div>
    );
};

export default MotorizedScreensTool;
