
import React from 'react';
import { OrderFormState, CalculationResults } from '../types';
import { getScreenTypeOptions } from '../utils/constants';

interface Props {
  formData: OrderFormState;
  results: CalculationResults;
}

const CheckItem: React.FC<{ title: string; passed: boolean }> = ({ title, passed }) => (
  <li className="flex items-center text-xs">
    <span className={`mr-2 ${passed ? 'text-green-500' : 'text-red-500'}`}>
      {passed ? '✓' : '✗'}
    </span>
    {title}
  </li>
);

const QaChecklist: React.FC<Props> = ({ formData, results }) => {
  const [isOpen, setIsOpen] = React.useState(false);

  // Check 1: Defender series is conditional
  const screenTypeOptions = getScreenTypeOptions(formData.globals.manufacturer);
  const defenderCheckPassed = formData.globals.manufacturer === 'MagnaTrack' 
    ? screenTypeOptions.some(o => o.value === 'Defender Series')
    : !screenTypeOptions.some(o => o.value === 'Defender Series');

  // Check 2: Outputs display inches with fractions
  const calculatedScreens = results?.screens || [];
  const outputs = calculatedScreens.flatMap(s => s.outputs ? [s.outputs.leftHeightIn.displayValue] : []);
  const outputFormattingCheck = outputs.length > 0 ? outputs.every(out => typeof out === 'string' && out.includes('"') && !out.includes("'") && !out.match(/\d\.\d/)) : true;

  // Check 3: Calculation has run at least once
  const calculateProducesResultsCheck = !!results && results.screens.some(s => s.outputs !== null);

  return (
    <div className="fixed bottom-4 right-4 z-50 max-w-sm w-full bg-white shadow-lg rounded-lg border border-gray-300">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full text-left p-2 font-bold text-sm bg-gray-100 hover:bg-gray-200 rounded-t-lg"
      >
        V3 QA Checklist (Dev Only) {isOpen ? '[-]' : '[+]'}
      </button>
      {isOpen && (
        <div className="p-2 text-gray-700">
          <ul className="space-y-1">
            <CheckItem title="Defender series is conditional" passed={defenderCheckPassed} />
            <CheckItem title="Outputs are inches/frac" passed={outputFormattingCheck} />
            <CheckItem title="Calculation has produced results" passed={calculateProducesResultsCheck} />
          </ul>
        </div>
      )}
    </div>
  );
};

export default QaChecklist;
