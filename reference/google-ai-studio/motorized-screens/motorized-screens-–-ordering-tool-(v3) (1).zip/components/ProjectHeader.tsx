import React, { forwardRef } from 'react';
import { ProjectInfo } from '../types';

interface Props {
  project: ProjectInfo;
  onChange: (field: keyof ProjectInfo, value: string) => void;
  showValidation?: boolean;
}

const ProjectHeader = forwardRef<HTMLDivElement, Props>(({ project, onChange, showValidation }, ref) => {
  const nameInputRef = React.useRef<HTMLInputElement>(null);
  const submitterInputRef = React.useRef<HTMLInputElement>(null);
  const jobInputRef = React.useRef<HTMLInputElement>(null);

  // Expose focus methods via ref if needed, or rely on IDs
  React.useImperativeHandle(ref, () => ({
    focusName: () => nameInputRef.current?.focus(),
    focusSubmitter: () => submitterInputRef.current?.focus(),
    focusJob: () => jobInputRef.current?.focus(),
  }) as any);

  const nameError = showValidation && !project.name?.trim();
  const submitterError = showValidation && (!project.submitterName || project.submitterName.trim().length < 2);
  const jobError = showValidation && !project.jobNumber?.trim();

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
      {/* Left Column: Identification */}
      <div className="space-y-6">
        <div>
          <label htmlFor="projectName" className="block text-sm font-medium text-gray-600">
            Project Name *
          </label>
          <input
            type="text"
            id="projectName"
            ref={nameInputRef}
            value={project.name ?? ''}
            onChange={(e) => onChange('name', e.target.value)}
            className={`mt-1 block w-full px-3 py-2 bg-white border ${nameError ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-indigo-500'} rounded-md shadow-sm focus:outline-none focus:border-indigo-500 sm:text-sm`}
          />
          {nameError && (
            <p className="mt-1 text-xs text-red-600 font-medium">Project Name is required.</p>
          )}
        </div>
        <div>
          <label htmlFor="jobNumber" className="block text-sm font-medium text-gray-600">
            Job Number *
          </label>
          <input
            type="text"
            id="jobNumber"
            ref={jobInputRef}
            value={project.jobNumber ?? ''}
            onChange={(e) => onChange('jobNumber', e.target.value)}
            placeholder="Required for saving"
            className={`mt-1 block w-full px-3 py-2 bg-white border ${jobError ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-indigo-500'} rounded-md shadow-sm focus:outline-none focus:border-indigo-500 sm:text-sm`}
          />
          {jobError && (
            <p className="mt-1 text-xs text-red-600 font-medium">Job Number is required.</p>
          )}
        </div>
        <div>
          <label htmlFor="submitterName" className="block text-sm font-medium text-gray-600">
            Submitter’s Name *
          </label>
          <input
            type="text"
            id="submitterName"
            ref={submitterInputRef}
            value={project.submitterName ?? ''}
            onChange={(e) => onChange('submitterName', e.target.value)}
            className={`mt-1 block w-full px-3 py-2 bg-white border ${submitterError ? 'border-red-500 focus:ring-red-500' : 'border-gray-300 focus:ring-indigo-500'} rounded-md shadow-sm focus:outline-none focus:border-indigo-500 sm:text-sm`}
          />
          {submitterError && (
            <p className="mt-1 text-xs text-red-600 font-medium">Submitter’s Name is required.</p>
          )}
        </div>
      </div>

      {/* Right Column: Logistics */}
      <div className="space-y-6">
        <div>
          <label htmlFor="date" className="block text-sm font-medium text-gray-600">
            Date
          </label>
          <input
            type="date"
            id="date"
            value={project.date ?? ''}
            onChange={(e) => onChange('date', e.target.value)}
            className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          />
        </div>
        <div>
          <label htmlFor="address" className="block text-sm font-medium text-gray-600">
            Address
          </label>
          <input
            type="text"
            id="address"
            value={project.address ?? ''}
            onChange={(e) => onChange('address', e.target.value)}
            className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          />
        </div>
      </div>
    </div>
  );
});

export default ProjectHeader;