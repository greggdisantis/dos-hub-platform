import React, { useState, useRef, useEffect, useCallback } from 'react';
import { ScreenConfig, MeasurementPoint, ScreenErrors, ScreenSelections, ScreenManufacturer, InputUnits, MeasurementValue, PhotoItem, AttachmentItem } from '../types';
import Measurements from './Measurements';
import DetailedScreenSelections from './DetailedScreenSelections';
import { getRemoteOptions, INSTALL_MOUNT_OPTIONS, MOTOR_SIDE_OPTIONS } from '../utils/constants';
import { parseVoiceCommands, parseSpokenValue, VoiceResult } from '../utils/voiceParser';
import { formatInchesFrac } from '../utils/measurements';
import { processImage } from '../utils/imageProcessor';

/**
 * Singleton recognition tracker to ensure only one component (main or field-specific)
 * listens at a time.
 */
let activeRecognitionInstance: any = null;

const VOICE_MEASURE_POINTS = [
  { value: 'upperLeft', label: 'Upper Left (UL)' },
  { value: 'lowerLeft', label: 'Lower Left (LL)' },
  { value: 'overallLeft', label: 'Overall Left (OL)' },
  { value: 'upperRight', label: 'Upper Right (UR)' },
  { value: 'lowerRight', label: 'Lower Right (LR)' },
  { value: 'overallRight', label: 'Overall Right (OR)' },
  { value: 'top', label: 'Top (T)' },
  { value: 'middle', label: 'Middle (M)' },
  { value: 'bottom', label: 'Bottom (B)' },
];

const PhotoBucket: React.FC<{ 
    label: string; 
    photos: PhotoItem[]; 
    onUpload: (files: FileList) => void; 
    onRemove: (id: string) => void; 
}> = ({ label, photos, onUpload, onRemove }) => {
    return (
        <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-700">{label}</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
                {photos.map(p => (
                    <div key={p.id} className="relative group aspect-square bg-gray-200 rounded border overflow-hidden shadow-sm">
                        <img 
                            src={p.dataUrl} 
                            alt={p.name} 
                            className="w-full h-full object-cover cursor-pointer hover:opacity-90" 
                            onClick={() => window.open(p.dataUrl, '_blank')}
                            title="Click to enlarge"
                        />
                        <button 
                            type="button"
                            onClick={(e) => { e.stopPropagation(); onRemove(p.id); }}
                            className="absolute top-1 right-1 bg-red-600 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-md hover:bg-red-700"
                        >
                            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </div>
                ))}
                {(photos.length < 10) && (
                    <label className="aspect-square flex flex-col items-center justify-center border-2 border-dashed border-gray-300 rounded hover:border-indigo-400 cursor-pointer bg-white transition-all hover:bg-gray-50">
                        <svg className="w-6 h-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" />
                        </svg>
                        <span className="text-[10px] text-gray-500 mt-1 uppercase font-bold tracking-tighter">Add Photo/PDF</span>
                        <input 
                            type="file" 
                            className="hidden" 
                            accept="image/*,application/pdf" 
                            multiple 
                            onChange={e => {
                                if (e.target.files) {
                                    onUpload(e.target.files);
                                    e.target.value = ''; // Reset input to allow re-upload of same file
                                }
                            }} 
                        />
                    </label>
                )}
            </div>
            {photos.length === 0 && <p className="text-[10px] text-gray-400 italic">No photos uploaded.</p>}
        </div>
    );
};

const AttachmentList: React.FC<{ 
  attachments: AttachmentItem[]; 
  onRemove: (id: string) => void; 
}> = ({ attachments, onRemove }) => {
  return (
    <div className="space-y-2 mt-4 pt-4 border-t border-gray-100">
      <label className="block text-sm font-medium text-gray-700">Attachments (PDFs)</label>
      <div className="space-y-1">
        {attachments.map(att => (
          <div key={att.id} className="flex items-center justify-between p-2 bg-indigo-50/50 rounded-md border border-indigo-100">
            <div className="flex items-center space-x-2 truncate">
              <svg className="w-4 h-4 text-indigo-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.707 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
              </svg>
              <span className="text-xs text-indigo-900 font-medium truncate">{att.name} {att.category === 'measurement' ? '(Measurement)' : '(General)'}</span>
            </div>
            <button 
              type="button"
              onClick={() => onRemove(att.id)}
              className="p-1 text-red-500 hover:text-red-700 transition-colors"
              title="Remove Attachment"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        ))}
        {attachments.length === 0 && (
          <p className="text-[10px] text-gray-400 italic">No PDF attachments uploaded.</p>
        )}
      </div>
    </div>
  );
};

/**
 * A helper component for field-specific voice input.
 * Shows a "Voice" button next to the label and a review row below the input.
 */
interface FieldVoiceWrapperProps {
  label: string;
  htmlFor: string;
  onApply: (text: string) => void;
  children: React.ReactNode;
}

const FieldVoiceWrapper: React.FC<FieldVoiceWrapperProps> = ({ label, htmlFor, onApply, children }) => {
  const [isListening, setIsListening] = useState(false);
  const [transcriptVal, setTranscriptVal] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);

  const initRecognition = () => {
    if (recognitionRef.current) return recognitionRef.current;
    
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return null;

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      setIsListening(true);
      setTranscriptVal(null);
      setErrorMsg(null);
    };

    recognition.onresult = (event: any) => {
      let interim = '';
      let final = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) final += event.results[i][0].transcript;
        else interim += event.results[i][0].transcript;
      }
      setTranscriptVal(final || interim);
    };

    recognition.onerror = (event: any) => {
      console.error('Field Voice Recognition Error:', event.error);
      if (event.error === 'not-allowed') {
        setErrorMsg('Microphone access denied. You can enable it in browser settings.');
      }
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
      if (activeRecognitionInstance === recognition) {
        activeRecognitionInstance = null;
      }
    };

    recognitionRef.current = recognition;
    return recognition;
  };

  const toggle = () => {
    const recognition = initRecognition();
    if (!recognition) return;

    if (isListening) {
      recognition.stop();
    } else {
      if (activeRecognitionInstance && activeRecognitionInstance !== recognition) {
        activeRecognitionInstance.stop();
      }
      activeRecognitionInstance = recognition;
      recognition.start();
    }
  };

  useEffect(() => {
    return () => {
      if (recognitionRef.current) recognitionRef.current.stop();
    };
  }, []);

  const isSupported = !!((window as any).SpeechRecognition || (window as any).webkit_speech_recognition);

  return (
    <div className="space-y-1">
      <div className="flex justify-between items-center">
        <label htmlFor={htmlFor} className="block text-sm font-medium text-gray-600">
          {label}
        </label>
        {isSupported && (
          <button
            type="button"
            onClick={toggle}
            className={`inline-flex items-center px-2 py-0.5 text-[10px] font-bold rounded shadow-sm transition-colors border ${
              isListening 
                ? 'bg-red-500 text-white border-red-600 animate-pulse' 
                : 'bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100'
            }`}
          >
            <svg className="w-2.5 h-2.5 mr-1" fill="currentColor" viewBox="0 0 20 20">
               <path d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8a1 1 0 10-2 0A5 5 0 015 8a1 1 0 00-2 0 7.001 7.001 0 006 6.93V17H6a1 1 0 100 2h8a1 1 0 100-2h-3v-2.07z" />
            </svg>
            {isListening ? 'Listening…' : '🎙 Voice'}
          </button>
        )}
      </div>
      {children}
      {errorMsg && (
        <div className="p-2 bg-red-50 border border-red-100 rounded text-[10px] text-red-600 font-medium animate-in fade-in slide-in-from-top-1">
          {errorMsg}
        </div>
      )}
      {!isListening && transcriptVal && (
        <div className="flex items-center justify-between p-2 bg-indigo-50 border border-indigo-100 rounded text-[11px] shadow-sm">
          <span className="text-gray-700 italic flex-1 truncate mr-3">"{transcriptVal}"</span>
          <div className="flex space-x-1.5 shrink-0">
            <button
              onClick={() => { onApply(transcriptVal); setTranscriptVal(null); }}
              className="px-2 py-0.5 bg-indigo-600 text-white rounded font-bold hover:bg-indigo-700 transition-colors"
            >
              Apply
            </button>
            <button
              onClick={() => setTranscriptVal(null)}
              className="px-2 py-0.5 bg-white border border-indigo-200 text-indigo-600 rounded font-medium hover:bg-indigo-100"
            >
              Discard
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

interface Props {
  screenNumber: number;
  screenData: ScreenConfig;
  isAllSame: boolean;
  manufacturer: ScreenManufacturer;
  inputUnits: InputUnits;
  globalMotorType: string;
  anyUChannelRequired: boolean;
  uChannelAppliedToAll: boolean;
  onChange: (field: keyof ScreenConfig | `selections.${keyof ScreenSelections}` | `measurements.${MeasurementPoint}`, value: any) => void;
  onPreview: () => void;
  errors?: ScreenErrors;
}

const ScreenItem: React.FC<Props> = ({ screenNumber, screenData, isAllSame, manufacturer, inputUnits, globalMotorType, anyUChannelRequired, uChannelAppliedToAll, onChange, onPreview, errors }) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [proposedResults, setProposedResults] = useState<VoiceResult | null>(null);
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);

  // States for "Voice Measure" field-specific flow
  const [showVoiceMeasureControls, setShowVoiceMeasureControls] = useState(false);
  const [voiceMeasurePoint, setVoiceMeasurePoint] = useState<string>('');
  const [isVoiceMeasureListening, setIsVoiceMeasureListening] = useState(false);
  const [voiceMeasureTranscript, setVoiceMeasureTranscript] = useState('');
  const [voiceMeasureProposedValue, setVoiceMeasureProposedValue] = useState<number | null>(null);
  const voiceMeasureRecognitionRef = useRef<any>(null);

  const initMainRecognition = () => {
    if (recognitionRef.current) return recognitionRef.current;
    
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return null;

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      setIsListening(true);
      setVoiceError(null);
      setProposedResults(null);
    };

    recognition.onresult = (event: any) => {
      let interimTranscript = '';
      let finalTranscript = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) finalTranscript += event.results[i][0].transcript;
        else interimTranscript += event.results[i][0].transcript;
      }
      const combined = finalTranscript || interimTranscript;
      setTranscript(combined);
      const parsed = parseVoiceCommands(combined, inputUnits);
      setProposedResults(parsed);
    };

    recognition.onerror = (event: any) => {
      console.error('Speech recognition error', event.error);
      if (event.error === 'not-allowed') {
        setVoiceError('Microphone access denied. You can enable it in browser settings.');
      } else {
        setVoiceError('Voice entry error. Try again.');
      }
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
      if (activeRecognitionInstance === recognition) {
        activeRecognitionInstance = null;
      }
    };

    recognitionRef.current = recognition;
    return recognition;
  };

  const initMeasureRecognition = () => {
    if (voiceMeasureRecognitionRef.current) return voiceMeasureRecognitionRef.current;
    
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return null;

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      setIsVoiceMeasureListening(true);
      setVoiceMeasureTranscript('');
      setVoiceMeasureProposedValue(null);
      setVoiceError(null);
    };

    recognition.onresult = (event: any) => {
      let interim = '';
      let final = '';
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) final += event.results[i][0].transcript;
        else interim += event.results[i][0].transcript;
      }
      const combined = final || interim;
      setVoiceMeasureTranscript(combined);
      const parsed = parseSpokenValue(combined, inputUnits);
      setVoiceMeasureProposedValue(parsed);
    };

    recognition.onerror = (event: any) => {
      console.error('Measure Voice Recognition Error:', event.error);
      if (event.error === 'not-allowed') {
        setVoiceError('Microphone access denied. You can enable it in browser settings.');
      }
      setIsVoiceMeasureListening(false);
    };

    recognition.onend = () => setIsVoiceMeasureListening(false);
    voiceMeasureRecognitionRef.current = recognition;
    return recognition;
  };

  const handleMeasurementChange = (
    point: MeasurementPoint,
    totalInches: MeasurementValue
  ) => {
    onChange(`measurements.${point}`, totalInches);
  };

  const handleSelectionChange = (field: keyof ScreenSelections, value: any) => {
    onChange(`selections.${field}`, value);
  };

  const handleUpload = async (files: FileList, targetCategory: 'measurement' | 'general') => {
    const fileArray = Array.from(files);
    const images = fileArray.filter(f => f.type.startsWith('image/'));
    const pdfs = fileArray.filter(f => f.type === 'application/pdf');

    if (images.length > 0) {
      const processedImages = await Promise.all(images.map(processImage));
      const field = targetCategory === 'measurement' ? 'measurementPhotos' : 'generalPhotos';
      const existing = (screenData[field] || []) as PhotoItem[];
      onChange(field, [...existing, ...processedImages].slice(0, 10));
    }

    if (pdfs.length > 0) {
      const processedPdfs = await Promise.all(pdfs.map(async f => {
        return new Promise<AttachmentItem>((resolve) => {
          const reader = new FileReader();
          reader.onload = (e) => {
            resolve({
              id: `att-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
              name: f.name,
              mimeType: 'application/pdf',
              dataUrl: e.target?.result as string,
              category: targetCategory,
              createdAt: new Date().toISOString()
            });
          };
          reader.readAsDataURL(f);
        });
      }));
      const existing = screenData.attachments || [];
      const newAttachments = [...existing, ...processedPdfs].slice(0, 10);
      onChange('attachments', newAttachments);
    }
  };

  const effectiveMotorType = isAllSame ? globalMotorType : screenData.selections.motorType;
  const remoteOptions = getRemoteOptions(effectiveMotorType);
  const isRemoteDisabled = !effectiveMotorType || remoteOptions.length === 0;

  const uChannelIsNeeded = screenData.outputs?.uChannel.value?.needed === true;
  const showUChannelNotes = uChannelIsNeeded || (anyUChannelRequired && uChannelAppliedToAll);
  const buildOutIsNeeded = screenData.outputs?.buildOut.value?.needed === true;

  const toggleListening = useCallback(() => {
    const recognition = initMainRecognition();
    if (!recognition) return;

    if (isListening) {
      recognition.stop();
    } else {
      if (activeRecognitionInstance && activeRecognitionInstance !== recognition) {
        activeRecognitionInstance.stop();
      }
      activeRecognitionInstance = recognition;
      setTranscript('');
      setProposedResults(null);
      recognition.start();
    }
  }, [isListening, inputUnits]);

  const toggleVoiceMeasureListening = useCallback(() => {
    const recognition = initMeasureRecognition();
    if (!recognition) return;

    if (isVoiceMeasureListening) {
      recognition.stop();
    } else {
      if (activeRecognitionInstance && activeRecognitionInstance !== recognition) {
        activeRecognitionInstance.stop();
      }
      activeRecognitionInstance = recognition;
      recognition.start();
    }
  }, [isVoiceMeasureListening, inputUnits]);

  useEffect(() => {
    return () => {
      if (recognitionRef.current) recognitionRef.current.stop();
      if (voiceMeasureRecognitionRef.current) voiceMeasureRecognitionRef.current.stop();
    };
  }, []);

  const handleApplyVoice = () => {
    if (!proposedResults) return;
    Object.entries(proposedResults.measurements).forEach(([point, val]) => {
      if (val !== undefined) onChange(`measurements.${point as MeasurementPoint}`, val as number);
    });
    if (proposedResults.description) onChange('description', proposedResults.description);
    if (proposedResults.specialInstructions) {
      const current = screenData.specialInstructions || '';
      onChange('specialInstructions', current ? `${current}\n${proposedResults.specialInstructions}` : proposedResults.specialInstructions);
    }
    if (proposedResults.numCuts) onChange('numCuts', proposedResults.numCuts);
    setProposedResults(null);
    setTranscript('');
  };

  const handleApplyVoiceMeasure = () => {
    if (voiceMeasurePoint && voiceMeasureProposedValue !== null) {
      onChange(`measurements.${voiceMeasurePoint as MeasurementPoint}`, voiceMeasureProposedValue);
      setVoiceMeasureTranscript('');
      setVoiceMeasureProposedValue(null);
    }
  };

  const handleDiscardVoice = () => {
    setProposedResults(null);
    setTranscript('');
  };

  const isSpeechSupported = !!((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition);

  const getPointLabel = (p: string) => {
    const labels: Record<string, string> = {
      upperLeft: 'Upper Left (UL)', lowerLeft: 'Lower Left (LL)', overallLeft: 'Overall Left (OL)',
      upperRight: 'Upper Right (UR)', lowerRight: 'Lower Right (LR)', overallRight: 'Overall Right (OR)',
      top: 'Top (T)', middle: 'Middle (M)', bottom: 'Bottom (B)'
    };
    return labels[p] || p;
  };

  const hasProposals = proposedResults && (
    Object.keys(proposedResults.measurements).length > 0 || 
    proposedResults.description ||
    proposedResults.specialInstructions || 
    proposedResults.numCuts
  );

  return (
    <div className="border border-gray-200 p-4 rounded-lg bg-gray-50/50">
      <div className="flex justify-between items-center mb-4">
        <div className="flex items-center space-x-3">
            <h4 className="font-semibold text-gray-800 uppercase tracking-wide">SCREEN #{screenNumber}</h4>
            <button
                type="button"
                onClick={onPreview}
                className="px-2 py-1 text-[10px] font-bold text-indigo-700 bg-indigo-50 border border-indigo-200 rounded hover:bg-indigo-100 transition-colors shadow-sm"
            >
                Preview Screen PDF
            </button>
        </div>
        <div className="flex items-center space-x-3">
          {isSpeechSupported ? (
             <div className="flex flex-col items-end">
                <button
                  type="button"
                  onClick={toggleListening}
                  className={`inline-flex items-center px-3 py-1 text-xs font-semibold rounded-md transition-colors shadow-sm ${
                    isListening 
                      ? 'bg-red-500 text-white animate-pulse' 
                      : 'bg-indigo-600 text-white hover:bg-indigo-700'
                  }`}
                >
                  <svg className="w-3 h-3 mr-1.5" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8a1 1 0 10-2 0A5 5 0 015 8a1 1 0 00-2 0 7.001 7.001 0 006 6.93V17H6a1 1 0 100 2h8a1 1 0 100-2h-3v-2.07z" clipRule="evenodd" />
                  </svg>
                  {isListening ? 'Listening… (Tap to stop)' : 'Voice Entry'}
                </button>
             </div>
          ) : (
            <span className="text-[10px] text-gray-400 italic">Voice entry not supported in this browser.</span>
          )}
        </div>
      </div>

      {transcript && (
        <div className="mb-4 p-2 bg-white border border-indigo-100 rounded text-[11px] text-gray-600 italic">
          <span className="font-bold text-indigo-800 not-italic mr-1">Transcript:</span>
          "{transcript}"
        </div>
      )}

      {!isListening && transcript && (
        <div className="mb-4 p-4 bg-indigo-50 border border-indigo-200 rounded-lg shadow-sm">
          <h5 className="text-xs font-bold text-indigo-900 uppercase mb-3 flex items-center">
            <svg className="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
            </svg>
            Review Proposed Updates
          </h5>
          
          {hasProposals ? (
            <div className="space-y-2 mb-4">
              {proposedResults!.description && (
                <div className="flex justify-between text-xs border-b border-indigo-100 pb-1">
                  <span className="text-gray-600 font-medium">Description:</span>
                  <span className="text-indigo-900 font-bold italic">"{proposedResults!.description}"</span>
                </div>
              )}
              {Object.entries(proposedResults!.measurements).map(([point, val]) => (
                <div key={point} className="flex justify-between text-xs border-b border-indigo-100 pb-1">
                  <span className="text-gray-600 font-medium">{getPointLabel(point)}:</span>
                  <span className="text-indigo-900 font-bold">{formatInchesFrac(val as number)}</span>
                </div>
              ))}
              {proposedResults!.numCuts && (
                <div className="flex justify-between text-xs border-b border-indigo-100 pb-1">
                  <span className="text-gray-600 font-medium"># of Cuts:</span>
                  <span className="text-indigo-900 font-bold">{proposedResults!.numCuts}</span>
                </div>
              )}
              {proposedResults!.specialInstructions && (
                <div className="text-xs pt-1">
                  <span className="text-gray-600 font-medium block">Special Instructions (Append):</span>
                  <span className="text-indigo-800 italic">"{proposedResults!.specialInstructions}"</span>
                </div>
              )}
            </div>
          ) : (
            <p className="text-xs text-indigo-700 mb-4 italic">No measurements detected. Please try again or speak clearly, e.g., "Top 200 inches, special instructions see notes."</p>
          )}

          <div className="flex space-x-2">
            <button
              type="button"
              onClick={handleApplyVoice}
              disabled={!hasProposals}
              className="flex-1 px-3 py-1.5 bg-indigo-600 text-white text-xs font-bold rounded hover:bg-indigo-700 disabled:bg-indigo-300 transition-colors shadow-sm"
            >
              Apply to Screen #{screenNumber}
            </button>
            <button
              type="button"
              onClick={handleDiscardVoice}
              className="px-3 py-1.5 bg-white border border-indigo-300 text-indigo-700 text-xs font-bold rounded hover:bg-indigo-50 transition-colors"
            >
              Discard
            </button>
          </div>
        </div>
      )}

      {voiceError && (
        <div className="mb-4 text-[10px] text-red-500 font-semibold bg-red-50 border border-red-100 p-2 rounded animate-in fade-in duration-200">
          ⚠️ {voiceError}
        </div>
      )}

      <div className="space-y-4">
        <div>
          <label htmlFor={`screenDesc-${screenNumber}`} className="block text-sm font-medium text-gray-600">
            Description
          </label>
          <input
            type="text"
            id={`screenDesc-${screenNumber}`}
            value={screenData.description ?? ''}
            onChange={(e) => onChange('description', e.target.value)}
            placeholder="e.g. Middle Screen, Left Screen"
            className="mt-1 block w-full max-w-md px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          />
        </div>

        {!isAllSame && (
          <div className="pt-4 border-t border-gray-200">
            <h5 className="text-sm font-semibold text-gray-700 mb-2">Per-Screen Selections</h5>
             <DetailedScreenSelections
                selections={screenData.selections}
                onChange={handleSelectionChange}
                manufacturer={manufacturer}
                errors={errors?.selections}
            />
          </div>
        )}

        <div className="pt-4 border-t border-gray-200 grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <div>
                <label htmlFor={`installMount-${screenNumber}`} className="block text-sm font-medium text-gray-600">
                  Install Mount Type
                </label>
                <select
                  id={`installMount-${screenNumber}`}
                  value={screenData.selections.installMount || 'Undermount'}
                  onChange={(e) => onChange('selections.installMount', e.target.value)}
                  className={`mt-1 block w-full max-w-xs pl-3 pr-10 py-2 text-base border focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md bg-blue-100 text-black [*:option]:text-black ${errors?.selections?.installMount ? 'border-red-500' : 'border-gray-300'}`}
                >
                  {INSTALL_MOUNT_OPTIONS.map(opt => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
                {errors?.selections?.installMount && <p className="mt-1 text-xs text-red-600">{errors.selections.installMount}</p>}
              </div>
              {screenData.selections.installMount === 'Face-mount' && (
                <div>
                  <label htmlFor={`faceMountSides-${screenNumber}`} className="block text-sm font-medium text-gray-600">
                    # of Sides
                  </label>
                  <select
                    id={`faceMountSides-${screenNumber}`}
                    value={screenData.selections.faceMountSides || ''}
                    onChange={(e) => onChange('selections.faceMountSides', e.target.value)}
                    className={`mt-1 block w-full max-w-xs pl-3 pr-10 py-2 text-base border focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md bg-blue-100 text-black [*:option]:text-black ${errors?.selections?.faceMountSides ? 'border-red-500' : 'border-gray-300'}`}
                  >
                    <option value="">— Select Sides —</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                  </select>
                  {errors?.selections?.faceMountSides && <p className="mt-1 text-xs text-red-600">{errors.selections.faceMountSides}</p>}
                </div>
              )}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor={`motorSide-${screenNumber}`} className="block text-sm font-medium text-gray-600">
                  Motor Side
                </label>
                <select
                  id={`motorSide-${screenNumber}`}
                  value={screenData.selections.motorSide || ''}
                  onChange={(e) => onChange('selections.motorSide', e.target.value)}
                  className="mt-1 block w-full max-w-xs pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md bg-blue-100 text-black [*:option]:text-black"
                >
                  {MOTOR_SIDE_OPTIONS.map(opt => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor={`remote-${screenNumber}`} className="block text-sm font-medium text-gray-600">
                  Remote
                </label>
                <select
                  id={`remote-${screenNumber}`}
                  value={screenData.selections.remoteOption || ''}
                  onChange={(e) => onChange('selections.remoteOption', e.target.value)}
                  disabled={isRemoteDisabled}
                  className="mt-1 block w-full max-w-xs pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md bg-blue-100 text-black [*:option]:text-black disabled:bg-gray-200 disabled:text-gray-500 disabled:cursor-not-allowed"
                >
                  <option value="">{isRemoteDisabled ? 'Select motor type first' : '— Select Remote —'}</option>
                  {remoteOptions.map(opt => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>
            </div>
        </div>

        <div className="pt-4 border-t border-gray-200">
          <div className="flex justify-between items-center mb-2">
            <h5 className="text-sm font-semibold text-gray-700">Measurements</h5>
            {isSpeechSupported && (
               <button
                 type="button"
                 onClick={() => setShowVoiceMeasureControls(!showVoiceMeasureControls)}
                 className={`inline-flex items-center px-2 py-1 text-[10px] font-bold rounded shadow-sm transition-colors border ${
                   showVoiceMeasureControls 
                    ? 'bg-indigo-600 text-white border-indigo-700' 
                    : 'bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100'
                 }`}
               >
                 🎙 Voice Measure
               </button>
            )}
          </div>

          {showVoiceMeasureControls && (
            <div className="mb-4 p-3 bg-indigo-50 border border-indigo-200 rounded-lg shadow-sm space-y-3">
               <div className="flex items-center space-x-3">
                  <select 
                    value={voiceMeasurePoint} 
                    onChange={e => setVoiceMeasurePoint(e.target.value)}
                    className="text-xs border border-indigo-300 rounded px-2 py-1 bg-white text-indigo-900 focus:ring-indigo-500"
                  >
                    <option value="">— Select Point —</option>
                    {VOICE_MEASURE_POINTS.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                  </select>

                  <button
                    type="button"
                    disabled={!voiceMeasurePoint}
                    onClick={toggleVoiceMeasureListening}
                    className={`px-3 py-1 text-xs font-bold rounded transition-colors shadow-sm ${
                       isVoiceMeasureListening 
                         ? 'bg-red-500 text-white animate-pulse' 
                         : 'bg-indigo-600 text-white hover:bg-indigo-700 disabled:bg-gray-300 disabled:cursor-not-allowed'
                    }`}
                  >
                    {isVoiceMeasureListening ? 'Stop Listening' : 'Start Listening'}
                  </button>
               </div>

               {voiceMeasureTranscript && (
                 <div className="p-2 bg-white border border-indigo-100 rounded text-[11px] text-gray-600 italic">
                    <span className="font-bold text-indigo-800 not-italic mr-1">Transcript:</span>
                    "{voiceMeasureTranscript}"
                 </div>
               )}

               {!isVoiceMeasureListening && voiceMeasureTranscript && (
                  <div className="flex items-center justify-between p-2 bg-white border border-indigo-200 rounded shadow-inner">
                     <div className="text-xs">
                        <span className="text-gray-500 mr-2">Parsed Value:</span>
                        <span className="font-bold text-indigo-900 text-sm">
                           {voiceMeasureProposedValue !== null ? formatInchesFrac(voiceMeasureProposedValue) : 'Invalid Value'}
                        </span>
                     </div>
                     <div className="flex space-x-2">
                        <button
                          type="button"
                          onClick={handleApplyVoiceMeasure}
                          disabled={voiceMeasureProposedValue === null}
                          className="px-3 py-1 bg-indigo-600 text-white text-[10px] font-bold rounded hover:bg-indigo-700 disabled:bg-indigo-300 transition-colors"
                        >
                          Apply
                        </button>
                        <button
                          type="button"
                          onClick={() => { setVoiceMeasureTranscript(''); setVoiceMeasureProposedValue(null); }}
                          className="px-3 py-1 bg-white border border-indigo-300 text-indigo-700 text-[10px] font-bold rounded hover:bg-indigo-50 transition-colors"
                        >
                          Discard
                        </button>
                     </div>
                  </div>
               )}
            </div>
          )}

          <Measurements
            measurements={screenData.measurements}
            onMeasurementChange={handleMeasurementChange}
            screenNumber={screenNumber}
            errors={errors?.measurements}
            inputUnits={inputUnits}
            reverseMeasurements={screenData.selections.reverseMeasurements}
            onReverseChange={(val) => onChange('selections.reverseMeasurements', val)}
          />
        </div>

        {screenData.outputs && (screenData.outputs.leftSideMismatch || screenData.outputs.rightSideMismatch) && (
          <div className="mt-4 space-y-2">
            {screenData.outputs.leftSideMismatch && (
              <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 p-3 rounded-r-md" role="alert">
                <p className="font-bold text-sm">⚠️ Left Side Measurement Mismatch</p>
                <p className="text-xs mt-1">Upper Left and Lower Left do not add up to Overall Left.</p>
              </div>
            )}
            {screenData.outputs.rightSideMismatch && (
              <div className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 p-3 rounded-r-md" role="alert">
                <p className="font-bold text-sm">⚠️ Right Side Measurement Mismatch</p>
                <p className="text-xs mt-1">Upper Right and Lower Right do not add up to Overall Right.</p>
              </div>
            )}
          </div>
        )}

        {showUChannelNotes && (
           <FieldVoiceWrapper
              label="U-Channel Notes"
              htmlFor={`u-channel-notes-${screenNumber}`}
              onApply={(text) => {
                const current = screenData.uChannelNotes || '';
                onChange('uChannelNotes', current ? `${current}\n${text}` : text);
              }}
           >
              <textarea
                id={`u-channel-notes-${screenNumber}`}
                value={screenData.uChannelNotes ?? ''}
                onChange={(e) => onChange('uChannelNotes', e.target.value)}
                placeholder="e.g., U-channel to be cut on site..."
                className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                rows={2}
              />
           </FieldVoiceWrapper>
        )}

        {buildOutIsNeeded && (
          <div className="space-y-4">
            <FieldVoiceWrapper
              label="Build Out Color"
              htmlFor={`build-out-color-${screenNumber}`}
              onApply={(text) => onChange('buildOutColor', text)}
            >
              <input
                type="text"
                id={`build-out-color-${screenNumber}`}
                value={screenData.buildOutColor ?? ''}
                onChange={(e) => onChange('buildOutColor', e.target.value)}
                placeholder="e.g., Match frame color"
                className="mt-1 block w-full max-md px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              />
            </FieldVoiceWrapper>
            
            <FieldVoiceWrapper
              label="Build Out Notes"
              htmlFor={`build-out-notes-${screenNumber}`}
              onApply={(text) => {
                const current = screenData.buildOutNotes || '';
                onChange('buildOutNotes', current ? `${current}\n${text}` : text);
              }}
            >
              <textarea
                id={`build-out-notes-${screenNumber}`}
                value={screenData.buildOutNotes ?? ''}
                onChange={(e) => onChange('buildOutNotes', e.target.value)}
                placeholder="e.g., Build-out material to be supplied by installer..."
                className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                rows={2}
              />
           </FieldVoiceWrapper>
          </div>
        )}

        <div>
          <label htmlFor={`num-cuts-${screenNumber}`} className="block text-sm font-medium text-gray-600">
            # of Cuts
          </label>
          <input
            type="number"
            id={`num-cuts-${screenNumber}`}
            value={screenData.numCuts ?? ''}
            onChange={(e) => onChange('numCuts', e.target.value)}
            placeholder="e.g., 2"
            className="mt-1 block w-full max-w-[120px] px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            min="0"
          />
        </div>

        <div>
          <label htmlFor={`screen-special-instructions-${screenNumber}`} className="block text-sm font-medium text-gray-600">
            Special Instructions
          </label>
          <textarea
            id={`screen-special-instructions-${screenNumber}`}
            value={screenData.specialInstructions ?? ''}
            onChange={(e) => onChange('specialInstructions', e.target.value)}
            placeholder="Type any special notes for this screen…"
            className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            rows={3}
          />
        </div>

        <div className="pt-6 border-t border-gray-200">
          <h5 className="text-base font-bold text-gray-800 mb-4 uppercase tracking-tight flex items-center">
              <svg className="w-5 h-5 mr-2 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              Screen #{screenNumber} Photos & Attachments
          </h5>
          <div className="grid grid-cols-1 gap-6 bg-gray-50/50 p-4 rounded-lg border border-gray-200">
            <PhotoBucket
                label="Measurement Photos (Max 10)"
                photos={screenData.measurementPhotos || []}
                onUpload={async (files) => handleUpload(files, 'measurement')}
                onRemove={(id) => {
                    const filtered = (screenData.measurementPhotos || []).filter(p => p.id !== id);
                    onChange('measurementPhotos', filtered);
                }}
            />
            <PhotoBucket
                label="General Screen Area Photos (Max 10)"
                photos={screenData.generalPhotos || []}
                onUpload={async (files) => handleUpload(files, 'general')}
                onRemove={(id) => {
                    const filtered = (screenData.generalPhotos || []).filter(p => p.id !== id);
                    onChange('generalPhotos', filtered);
                }}
            />
            <AttachmentList 
              attachments={screenData.attachments || []} 
              onRemove={(id) => {
                const filtered = (screenData.attachments || []).filter(a => a.id !== id);
                onChange('attachments', filtered);
              }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScreenItem;