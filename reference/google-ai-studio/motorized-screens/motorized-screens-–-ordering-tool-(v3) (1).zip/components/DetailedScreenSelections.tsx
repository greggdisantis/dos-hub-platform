
import React from 'react';
import { GlobalSelections, ScreenSelections, ScreenManufacturer, FieldError } from '../types';
import { 
    getScreenTypeOptions,
    TWICHELL_SOLAR_SERIES,
    FERRARI_SOLTIS_SERIES,
    getScreenColorOptionsV3,
    VINYL_WINDOW_CONFIG_OPTIONS,
    VINYL_ORIENTATION_OPTIONS,
    getVinylBorderMaterialOptions,
    getFrameColorCollectionOptions,
    getFrameColorOptionsByCollection
} from '../utils/constants';

interface Props {
  selections: GlobalSelections | ScreenSelections;
  onChange: (field: keyof (GlobalSelections & ScreenSelections), value: any) => void;
  manufacturer: ScreenManufacturer;
  errors?: Partial<Record<keyof ScreenSelections, FieldError>>;
}

const DetailedScreenSelections: React.FC<Props> = ({ selections, onChange, manufacturer, errors }) => {
    const screenTypeOptions = getScreenTypeOptions(manufacturer);
    
    const { screenType, twichellSeries, soltisSeries, vinylWindowConfig, windowBorderMaterialType, windowBorderTwichellSeries, windowBorderSoltisSeries } = selections;

    const mainColorOptions = getScreenColorOptionsV3(screenType, twichellSeries || soltisSeries);
    const borderColorOptions = getScreenColorOptionsV3(windowBorderMaterialType, windowBorderTwichellSeries || windowBorderSoltisSeries);
    const borderMaterialOptions = getVinylBorderMaterialOptions(manufacturer);
    const frameColorCollectionOptions = getFrameColorCollectionOptions(manufacturer);
    const frameColorOptions = getFrameColorOptionsByCollection(selections.frameColorCollection);

    const showOrientation = vinylWindowConfig === '1 Window' || vinylWindowConfig === '2 Windows';

    const baseSelectClass = "mt-1 block w-full pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md bg-blue-100 text-black [*:option]:text-black";

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-4 items-start">
            
            {/* --- COLUMN 1: Screen Material --- */}
            <div className="space-y-4">
                <h3 className="text-sm font-semibold text-gray-800 border-b pb-2">Screen Material</h3>
                <div>
                    <label className="block text-sm font-medium text-gray-600">Screen Type</label>
                    <select value={screenType || ''} onChange={e => onChange('screenType', e.target.value)} className={baseSelectClass}>
                        {screenTypeOptions.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                    </select>
                </div>

                {screenType === 'Twichell Solar' && (
                     <div>
                        <label className="block text-sm font-medium text-gray-600">Twichell Series</label>
                        <select value={twichellSeries || ''} onChange={e => onChange('twichellSeries', e.target.value)} className={baseSelectClass}>
                           <option value="">— Select Series —</option>
                           {TWICHELL_SOLAR_SERIES.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                        </select>
                    </div>
                )}
                {screenType === 'Ferrari Soltis' && (
                     <div>
                        <label className="block text-sm font-medium text-gray-600">Soltis Series</label>
                        <select value={soltisSeries || ''} onChange={e => onChange('soltisSeries', e.target.value)} className={baseSelectClass}>
                            <option value="">— Select Series —</option>
                            {FERRARI_SOLTIS_SERIES.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                        </select>
                    </div>
                )}
                {screenType !== 'Vinyl' && (
                    <div>
                        <label className="block text-sm font-medium text-gray-600">Screen Color</label>
                        <select value={selections.screenColor || ''} onChange={e => onChange('screenColor', e.target.value)} className={baseSelectClass} disabled={mainColorOptions.length <= 1}>
                            {mainColorOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                        </select>
                    </div>
                )}
            </div>
            
            {/* --- COLUMN 2: Vinyl & Frame --- */}
            <div className="space-y-4">
                 <h3 className="text-sm font-semibold text-gray-800 border-b pb-2">Frame</h3>
                <div>
                    <label className="block text-sm font-medium text-gray-600">Frame Color Collection</label>
                    <select value={selections.frameColorCollection || ''} onChange={e => onChange('frameColorCollection', e.target.value)} className={baseSelectClass}>
                        {frameColorCollectionOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                    </select>
                </div>
                <div>
                    <label className="block text-sm font-medium text-gray-600">Frame Color</label>
                    <select value={selections.frameColor || ''} onChange={e => onChange('frameColor', e.target.value)} className={baseSelectClass} disabled={frameColorOptions.length <= 1}>
                        {frameColorOptions.map(color => <option key={color} value={color}>{color}</option>)}
                    </select>
                </div>
            </div>

            {/* --- COLUMN 3: Vinyl Details --- */}
            {screenType === 'Vinyl' && (
                <div className="space-y-4">
                    <h3 className="text-sm font-semibold text-gray-800 border-b pb-2">Vinyl Configuration</h3>
                    <div>
                        <label className="block text-sm font-medium text-gray-600">Window Config</label>
                        <select value={vinylWindowConfig || ''} onChange={e => onChange('vinylWindowConfig', e.target.value)} className={baseSelectClass}>
                            <option value="">— Select Config —</option>
                            {VINYL_WINDOW_CONFIG_OPTIONS.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                        </select>
                    </div>
                     {showOrientation && (
                        <div>
                            <label className="block text-sm font-medium text-gray-600">Orientation</label>
                            <select value={selections.vinylOrientation || ''} onChange={e => onChange('vinylOrientation', e.target.value as 'Horizontal' | 'Vertical')} className={baseSelectClass}>
                                <option value="">— Select —</option>
                                {VINYL_ORIENTATION_OPTIONS.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                            </select>
                        </div>
                     )}
                     <div>
                        <label className="block text-sm font-medium text-gray-600">Window Border Material</label>
                        <select value={windowBorderMaterialType || ''} onChange={e => onChange('windowBorderMaterialType', e.target.value)} className={baseSelectClass}>
                            {borderMaterialOptions.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                        </select>
                     </div>
                     {windowBorderMaterialType === 'Twichell Solar' && (
                        <div>
                           <label className="block text-sm font-medium text-gray-600">Border Twichell Series</label>
                           <select value={windowBorderTwichellSeries || ''} onChange={e => onChange('windowBorderTwichellSeries', e.target.value)} className={baseSelectClass}>
                              <option value="">— Select Series —</option>
                              {TWICHELL_SOLAR_SERIES.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                           </select>
                       </div>
                    )}
                     {windowBorderMaterialType === 'Ferrari Soltis' && (
                        <div>
                           <label className="block text-sm font-medium text-gray-600">Border Soltis Series</label>
                           <select value={windowBorderSoltisSeries || ''} onChange={e => onChange('windowBorderSoltisSeries', e.target.value)} className={baseSelectClass}>
                               <option value="">— Select Series —</option>
                               {FERRARI_SOLTIS_SERIES.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                           </select>
                       </div>
                    )}
                     <div>
                        <label className="block text-sm font-medium text-gray-600">Window Border Color</label>
                        <select value={selections.windowBorderColor || ''} onChange={e => onChange('windowBorderColor', e.target.value)} className={baseSelectClass} disabled={borderColorOptions.length <= 1}>
                            {borderColorOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                        </select>
                    </div>
                </div>
            )}
        </div>
    );
};

export default DetailedScreenSelections;
