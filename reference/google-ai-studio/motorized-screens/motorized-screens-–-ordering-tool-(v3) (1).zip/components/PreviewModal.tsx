
import React, { useEffect } from 'react';

interface Props {
  isOpen: boolean;
  url: string | null;
  title: string;
  onClose: () => void;
}

const PreviewModal: React.FC<Props> = ({ isOpen, url, title, onClose }) => {
  // Clean up the URL when the modal closes or component unmounts
  useEffect(() => {
    return () => {
      if (url) {
        URL.revokeObjectURL(url);
      }
    };
  }, [url]);

  if (!isOpen || !url) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-lg shadow-2xl w-full max-w-5xl h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gray-50">
          <h3 className="text-lg font-bold text-gray-800">{title}</h3>
          <button 
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-200 rounded-full transition-colors"
            title="Close Preview"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Viewer */}
        <div className="flex-1 bg-gray-200 relative">
          <iframe 
            src={url} 
            className="w-full h-full border-none"
            title="PDF Preview Viewer"
          />
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-200 flex justify-end bg-gray-50">
          <button 
            onClick={onClose}
            className="px-8 py-2 bg-white border border-gray-300 text-gray-700 font-bold rounded-md hover:bg-gray-100 transition-colors shadow-sm"
          >
            Close Viewer
          </button>
        </div>
      </div>
    </div>
  );
};

export default PreviewModal;
