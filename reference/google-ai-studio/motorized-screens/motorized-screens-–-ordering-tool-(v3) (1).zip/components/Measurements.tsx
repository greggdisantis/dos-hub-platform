import React, { useState, useEffect, useRef } from 'react';
import { MeasurementPoint, ScreenMeasurements, ScreenErrors, InputUnits, MeasurementValue } from '../types';
import MeasurementInput from './MeasurementInput';

interface Props {
  measurements: ScreenMeasurements;
  onMeasurementChange: (point: MeasurementPoint, totalInches: MeasurementValue) => void;
  screenNumber: number;
  errors?: ScreenErrors['measurements'];
  inputUnits: InputUnits;
  reverseMeasurements: boolean;
  onReverseChange: (val: boolean) => void;
}

const MISMATCH_TOLERANCE_IN = 0.125; // 1/8"

const Alert: React.FC<{ icon: string; text: string; type: 'warning' | 'info' }> = ({ icon, text, type }) => {
  const bgColor = type === 'warning' ? 'bg-amber-50 border-amber-200' : 'bg-blue-50 border-blue-200';
  const textColor = type === 'warning' ? 'text-amber-800' : 'text-blue-800';
  
  return (
    <div className={`flex items-start space-x-2 p-2 border rounded mt-2 ${bgColor} ${textColor} animate-in fade-in slide-in-from-top-1 duration-200`}>
      <span className="text-sm shrink-0 leading-none mt-0.5">{icon}</span>
      <span className="text-[11px] leading-tight font-medium">{text}</span>
    </div>
  );
};

const Measurements: React.FC<Props> = ({ measurements, onMeasurementChange, screenNumber, errors, inputUnits, reverseMeasurements, onReverseChange }) => {
  const { upperLeft: ul, lowerLeft: ll, overallLeft: ol, upperRight: ur, lowerRight: lr, overallRight: or, top: t, middle: m, bottom: b } = measurements;

  const [showExplainer, setShowExplainer] = useState(false);
  const explainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (explainerRef.current && !explainerRef.current.contains(event.target as Node)) {
        setShowExplainer(false);
      }
    };
    if (showExplainer) {
      document.addEventListener('click', handleClickOutside);
    }
    return () => {
      document.removeEventListener('click', handleClickOutside);
    };
  }, [showExplainer]);

  // Left Column Check
  const showLeftMismatch = (ul !== null && ll !== null && ol !== null) && Math.abs((ul + ll) - ol) > MISMATCH_TOLERANCE_IN;

  // Right Column Check
  const showRightMismatch = (ur !== null && lr !== null && or !== null) && Math.abs((ur + lr) - or) > MISMATCH_TOLERANCE_IN;

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-4 mb-4 bg-white p-3 rounded-md border border-gray-200 shadow-sm overflow-hidden">
        <div className="relative flex items-center shrink-0" ref={explainerRef}>
          <span className="text-sm font-bold text-gray-700">Reverse measurements?</span>
          <button 
            type="button"
            onClick={(e) => { e.stopPropagation(); setShowExplainer(!showExplainer); }}
            className="ml-1.5 flex items-center justify-center w-4 h-4 rounded-full bg-gray-200 text-gray-600 text-[10px] font-bold hover:bg-gray-300 transition-colors focus:outline-none"
            title="What is this?"
          >
            ?
          </button>
          {showExplainer && (
            <div className="absolute left-0 top-full mt-2 w-64 p-3 bg-white border border-gray-200 rounded-md shadow-xl z-50 animate-in fade-in zoom-in-95 duration-200">
               <p className="text-xs text-gray-700 font-medium leading-relaxed">
                 Select this option ONLY if you want the Left and Right side measurements to be reversed.
               </p>
            </div>
          )}
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          <button 
            type="button" 
            onClick={() => onReverseChange(true)} 
            className={`px-4 py-1 text-xs font-bold rounded-md transition-all ${reverseMeasurements ? 'bg-indigo-600 text-white shadow-sm' : 'bg-gray-100 text-gray-600 border border-gray-300 hover:bg-gray-200'}`}
          >
            Yes
          </button>
          <button 
            type="button" 
            onClick={() => onReverseChange(false)} 
            className={`px-4 py-1 text-xs font-bold rounded-md transition-all ${!reverseMeasurements ? 'bg-indigo-600 text-white shadow-sm' : 'bg-gray-100 text-gray-600 border border-gray-300 hover:bg-gray-200'}`}
          >
            No
          </button>
        </div>

        {reverseMeasurements ? (
          <div className="flex-1 flex items-center animate-in fade-in slide-in-from-left-1 duration-300">
            <span className="inline-flex items-center px-2.5 py-1 rounded bg-indigo-50 text-indigo-700 border border-indigo-200 text-[10px] font-bold uppercase tracking-tight whitespace-nowrap">
              ⚠ Reverse measurements active
            </span>
          </div>
        ) : (
          <p className="text-[10px] text-gray-400 italic font-medium hidden sm:block truncate">
            If active, Left and Right values are swapped for all calculations.
          </p>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* LEFT Column */}
        <div className="p-4 bg-gray-100 border border-gray-200 rounded-md flex flex-col">
          <h6 className="font-bold text-center text-gray-800 uppercase text-xs tracking-wider">Left Side</h6>
          {reverseMeasurements && (
            <p className="text-[10px] text-indigo-600 font-bold text-center mb-2 uppercase animate-in fade-in duration-300">Reverse measurements active</p>
          )}
          <div className="space-y-4 flex-grow">
            <MeasurementInput
              label="Upper Left (UL)"
              idPrefix={`s${screenNumber}-ul`}
              totalInches={measurements.upperLeft}
              onChange={(totalInches) => onMeasurementChange('upperLeft', totalInches)}
              error={errors?.upperLeft}
              inputUnits={inputUnits}
            />
            <MeasurementInput
              label="Lower Left (LL)"
              idPrefix={`s${screenNumber}-ll`}
              totalInches={measurements.lowerLeft}
              onChange={(totalInches) => onMeasurementChange('lowerLeft', totalInches)}
              error={errors?.lowerLeft}
              inputUnits={inputUnits}
            />
            <MeasurementInput
              label="Overall Left (OL)"
              idPrefix={`s${screenNumber}-ol`}
              totalInches={measurements.overallLeft}
              onChange={(totalInches) => onMeasurementChange('overallLeft', totalInches)}
              error={errors?.overallLeft}
              inputUnits={inputUnits}
            />
          </div>
          {showLeftMismatch && (
            <Alert 
              icon="⚠️" 
              text={'Left side check: Upper Left (UL) + Lower Left (LL) must equal Overall Left (OL) within 1/8". Please verify.'} 
              type="warning" 
            />
          )}
        </div>

        {/* RIGHT Column */}
        <div className="p-4 bg-gray-100 border border-gray-200 rounded-md flex flex-col">
          <h6 className="font-bold text-center text-gray-800 uppercase text-xs tracking-wider">Right Side</h6>
          {reverseMeasurements && (
            <p className="text-[10px] text-indigo-600 font-bold text-center mb-2 uppercase animate-in fade-in duration-300">Reverse measurements active</p>
          )}
          <div className="space-y-4 flex-grow">
            <MeasurementInput
              label="Upper Right (UR)"
              idPrefix={`s${screenNumber}-ur`}
              totalInches={measurements.upperRight}
              onChange={(totalInches) => onMeasurementChange('upperRight', totalInches)}
              error={errors?.upperRight}
              inputUnits={inputUnits}
            />
            <MeasurementInput
              label="Lower Right (LR)"
              idPrefix={`s${screenNumber}-lr`}
              totalInches={measurements.lowerRight}
              onChange={(totalInches) => onMeasurementChange('lowerRight', totalInches)}
              error={errors?.lowerRight}
              inputUnits={inputUnits}
            />
            <MeasurementInput
              label="Overall Right (OR)"
              idPrefix={`s${screenNumber}-or`}
              totalInches={measurements.overallRight}
              onChange={(totalInches) => onMeasurementChange('overallRight', totalInches)}
              error={errors?.overallRight}
              inputUnits={inputUnits}
            />
          </div>
          {showRightMismatch && (
            <Alert 
              icon="⚠️" 
              text={'Right side check: Upper Right (UR) + Lower Right (LR) must equal Overall Right (OR) within 1/8". Please verify.'} 
              type="warning" 
            />
          )}
        </div>

        {/* HORIZONTAL Column */}
        <div className="p-4 bg-gray-100 border border-gray-200 rounded-md flex flex-col">
          <h6 className="font-bold text-center text-gray-800 uppercase text-xs tracking-wider">Horizontal</h6>
          <div className="space-y-4 flex-grow">
            <MeasurementInput
              label="Top (T)"
              idPrefix={`s${screenNumber}-t`}
              totalInches={measurements.top}
              onChange={(totalInches) => onMeasurementChange('top', totalInches)}
              error={errors?.top}
              inputUnits={inputUnits}
            />
            <MeasurementInput
              label="Middle (M)"
              idPrefix={`s${screenNumber}-m`}
              totalInches={measurements.middle}
              onChange={(totalInches) => onMeasurementChange('middle', totalInches)}
              error={errors?.middle}
              inputUnits={inputUnits}
            />
            <MeasurementInput
              label="Bottom (B)"
              idPrefix={`s${screenNumber}-b`}
              totalInches={measurements.bottom}
              onChange={(totalInches) => onMeasurementChange('bottom', totalInches)}
              error={errors?.bottom}
              inputUnits={inputUnits}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Measurements;