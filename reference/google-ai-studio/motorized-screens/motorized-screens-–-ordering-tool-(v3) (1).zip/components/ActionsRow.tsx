import React from 'react';

interface Props {
  onExport: () => void;
  onSaveToSharePoint: () => void;
  onPreviewAll: () => void;
  isExporting: boolean;
  isSavingToSharePoint: boolean;
  isPreviewingAll: boolean;
  isCalculating: boolean;
  error: string | null;
  sharePointStatus: { 
    type: 'success' | 'error' | null; 
    message: string | null;
    folderPath?: string | null;
    webUrl?: string | null;
  };
  isSharePointGated?: boolean;
}

const StatusDisplay: React.FC<{ 
    isCalculating: boolean; 
    error: string | null;
    isSavingToSharePoint: boolean;
    sharePointStatus: Props['sharePointStatus'];
    isPreviewingAll: boolean;
}> = ({ isCalculating, error, isSavingToSharePoint, sharePointStatus, isPreviewingAll }) => {
  if (error) {
    return (
      <p className="text-sm text-red-600 font-medium" role="alert">
        {error}
      </p>
    );
  }
  
  if (sharePointStatus.type === 'success') {
      return (
        <div className="flex flex-col space-y-0.5">
          <p className="text-sm text-green-600 font-semibold animate-pulse">✓ {sharePointStatus.message}</p>
          {sharePointStatus.folderPath && (
            <p className="text-[10px] text-gray-500 truncate max-w-[200px] sm:max-w-xs italic" title={sharePointStatus.folderPath}>
              Path: {sharePointStatus.folderPath}
            </p>
          )}
          {sharePointStatus.webUrl && (
            <a 
              href={sharePointStatus.webUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-[10px] text-indigo-600 hover:underline font-bold flex items-center"
            >
              Open in SharePoint 
              <svg className="w-2.5 h-2.5 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
              </svg>
            </a>
          )}
        </div>
      );
  }
  
  if (sharePointStatus.type === 'error') {
      return <p className="text-sm text-red-600 font-semibold">✗ {sharePointStatus.message}</p>;
  }

  if (isCalculating) {
    return (
      <p className="text-sm text-indigo-600 animate-pulse">
        Auto-calculating...
      </p>
    );
  }

  if (isSavingToSharePoint) {
      return <p className="text-sm text-indigo-600 font-medium animate-pulse">Uploading to SharePoint...</p>;
  }

  if (isPreviewingAll) {
      return <p className="text-sm text-indigo-600 font-medium animate-pulse">Generating Preview...</p>;
  }

  return <p className="text-sm text-gray-500">Ready</p>;
};


const ActionsRow: React.FC<Props> = ({ 
    onExport, 
    onSaveToSharePoint,
    onPreviewAll,
    isExporting, 
    isSavingToSharePoint,
    isPreviewingAll,
    isCalculating, 
    error,
    sharePointStatus,
    isSharePointGated
}) => {
  const isBusy = isExporting || isSavingToSharePoint || isPreviewingAll || isCalculating || !!error;

  return (
    <div className="p-6 bg-white rounded-lg shadow sticky bottom-0 border-t border-gray-200 z-10">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <div className="flex-grow w-full sm:w-auto">
          <StatusDisplay 
            isCalculating={isCalculating} 
            error={error} 
            isSavingToSharePoint={isSavingToSharePoint}
            isPreviewingAll={isPreviewingAll}
            sharePointStatus={sharePointStatus}
          />
        </div>
        <div className="flex-shrink-0 flex items-center flex-wrap justify-center sm:justify-end gap-x-4 gap-y-2">
          <button
            type="button"
            onClick={onPreviewAll}
            disabled={isBusy}
            className="px-4 py-2 text-sm font-semibold text-indigo-700 bg-white border border-indigo-200 rounded-md hover:bg-indigo-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm inline-flex items-center"
          >
            {isPreviewingAll ? 'Previewing...' : 'Preview All Pages'}
          </button>

          <button
            type="button"
            onClick={onSaveToSharePoint}
            disabled={isSavingToSharePoint}
            className={`px-4 py-2 text-sm font-semibold text-white bg-indigo-600 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-gray-300 disabled:text-gray-500 disabled:cursor-not-allowed transition-all shadow-sm inline-flex items-center ${isSharePointGated && !isSavingToSharePoint ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            {isSavingToSharePoint ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Saving...
              </>
            ) : 'Save to SharePoint'}
          </button>
          
          <button
            type="button"
            onClick={onExport}
            disabled={isBusy}
            className="px-6 py-2 text-sm font-semibold text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400 disabled:bg-gray-100 disabled:text-gray-400 disabled:cursor-not-allowed transition-colors shadow-sm"
          >
            {isExporting ? 'Exporting...' : 'Export to PDF'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ActionsRow;