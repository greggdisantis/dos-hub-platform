import React from 'react';
import { OrderFormState, ScreenConfig, ScreenMeasurements, PhotoItem, AttachmentItem, CalculationResults } from '../types';
import { formatInchesFrac } from '../utils/measurements';

interface Props {
  formData: OrderFormState;
  results: CalculationResults;
  anyUChannelRequired: boolean;
  onlyShowIndex?: number;
}

const DetailItem: React.FC<{ 
    label: string; 
    value?: React.ReactNode; 
    fullWidth?: boolean;
    labelFontSize?: string;
    valueFontSize?: string;
    padding?: string;
}> = ({ label, value, fullWidth = false, labelFontSize = '10px', valueFontSize = '10px', padding = '4px 0' }) => {
    const styles: { [key: string]: React.CSSProperties } = {
        item: {
            display: 'flex',
            flexDirection: 'column',
            padding: padding,
            gridColumn: fullWidth ? '1 / -1' : undefined,
            borderBottom: '0.5px solid #e5e7eb',
        },
        label: {
            fontSize: labelFontSize,
            color: '#4b5563',
            marginBottom: '1px',
            lineHeight: 1.15,
        },
        value: {
            fontSize: valueFontSize,
            fontWeight: '500',
            minHeight: '1em',
            lineHeight: 1.15,
        },
        preWrap: {
            whiteSpace: 'pre-wrap',
            wordBreak: 'break-word',
            fontSize: valueFontSize,
        }
    };
    
    const displayValue = value === null || value === undefined || value === '' ? '—' : value;

    return (
        <div style={styles.item}>
            <span style={styles.label}>{label}</span>
            <span style={styles.value}>
                {typeof displayValue === 'string' && (displayValue as string).includes('\n') ? 
                    <span style={styles.preWrap}>{displayValue}</span> 
                    : displayValue
                }
            </span>
        </div>
    );
};

// Internal Header component to ensure consistent Job Number logic across all page types
const PdfHeaderGroup: React.FC<{ formData: OrderFormState; screenIndex: number }> = ({ formData, screenIndex }) => {
    const styles: { [key: string]: React.CSSProperties } = {
        overviewGrid: { 
            display: 'grid', 
            gridTemplateColumns: 'repeat(3, 1fr)', 
            gap: '0px 18px', 
            marginBottom: '4mm', 
            paddingBottom: '3mm', 
            borderBottom: '1.5px solid #374151' 
        },
        nestedCol: {
            display: 'flex',
            flexDirection: 'column'
        }
    };

    return (
        <div style={styles.overviewGrid}>
            <div style={styles.nestedCol}>
                <DetailItem label="Project Name" value={formData.project.name} />
                <DetailItem label="Submitter" value={formData.project.submitterName} />
                {formData.project.jobNumber && (
                    <DetailItem label="Job Number" value={formData.project.jobNumber} />
                )}
            </div>
            <DetailItem label="Date" value={formData.project.date} />
            <DetailItem label="Address" value={formData.project.address} />
            
            <DetailItem label="Screen Manufacturer" value={formData.globals.manufacturer} />
            <DetailItem label="Total # of Screens" value={formData.globals.totalScreens} />
            <DetailItem label="Screen #" value={`${screenIndex + 1} of ${formData.globals.totalScreens}`} />
            
            <DetailItem 
                label="Description" 
                value={formData.screens[screenIndex]?.description} 
                fullWidth={true} 
            />
        </div>
    );
};

const Section: React.FC<{ 
    title: string; 
    children: React.ReactNode; 
    columns?: number;
}> = ({ title, children, columns = 2 }) => {
    const styles: { [key: string]: React.CSSProperties } = {
        section: {
            marginBottom: '6px',
        },
        title: {
            fontSize: '12px',
            fontWeight: 'bold',
            marginBottom: '3px',
            paddingBottom: '2px',
            borderBottom: '1px solid #9ca3af',
            color: '#111827',
        },
        grid: {
            display: 'grid',
            gridTemplateColumns: `repeat(${columns}, 1fr)`,
            gap: '0px 24px',
        }
    };

    return (
        <section style={styles.section}>
            <div style={styles.title}>{title}</div>
            <div style={styles.grid}>{children}</div>
        </section>
    );
};

const ScreenPage: React.FC<{ screen: ScreenConfig; formData: OrderFormState; screenIndex: number }> = ({ screen, formData, screenIndex }) => {
    const { selections, outputs, measurements } = screen;
    const uChannelRequired = outputs?.uChannel.value?.needed;
    
    const buildOutValue = outputs?.buildOut.value;
    const buildOutRequired = buildOutValue?.needed === true;
    const buildOutType = buildOutValue?.type;
    const buildOutFlagged = buildOutType === 'FLAG';
    const buildOutDisplayType = buildOutType === '1x2' ? '1”x2”' : buildOutType === '2x2' ? '2”x2”' : buildOutType;

    const styles: { [key: string]: React.CSSProperties } = {
        pageWrapper: {
            width: '210mm',
            minHeight: '297mm',
            padding: '10mm',
            boxSizing: 'border-box',
            backgroundColor: '#ffffff',
            fontFamily: 'Helvetica, Arial, sans-serif',
            color: '#1f2937',
            display: 'flex',
            flexDirection: 'column',
            pageBreakAfter: 'always',
            pageBreakInside: 'avoid',
            overflow: 'visible',
        },
        pageHeader: { textAlign: 'center', marginBottom: '5mm' },
        headerTitle: { fontSize: '14pt', fontWeight: 'bold' },
        headerSubtitle: { fontSize: '12pt', color: '#4b5563' },
        mainContent: {
            flex: '1 1 auto',
        },
        bottomContent: {
            paddingTop: '4px',
            breakInside: 'avoid',
            pageBreakInside: 'avoid',
        },
        compactSection: {
            borderTop: '1px solid #9ca3af',
            paddingTop: '3px'
        },
        compactTitle: {
            fontSize: '11px',
            fontWeight: 'bold',
            color: '#111827',
            marginBottom: '3px',
        },
        compactGrid: {
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '0 24px',
        },
        compactSubTitle: {
            fontSize: '10px',
            fontWeight: 'bold',
            color: '#374151',
            marginBottom: '2px',
        },
        compactInnerGrid: {
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '0 12px'
        }
    };
    
    return (
        <div style={styles.pageWrapper}>
            <div style={styles.mainContent}>
                <header style={styles.pageHeader}>
                    <div style={styles.headerTitle}>Distinctive Outdoor Structures</div>
                    <div style={styles.headerSubtitle}>Motorized Screen Form</div>
                </header>

                <PdfHeaderGroup formData={formData} screenIndex={screenIndex} />

                {/* MAIN CONTENT */}
                <div>
                    <Section title="SECTION 1 — SCREEN & FRAME CONFIG">
                        <DetailItem label="Screen Type" value={selections.screenType} />
                        <DetailItem label="Frame Color Collection" value={selections.frameColorCollection} />
                        <DetailItem label="Series" value={selections.twichellSeries || selections.soltisSeries} />
                        <DetailItem label="Frame Color" value={selections.frameColor} />
                        <DetailItem label="Screen Color" value={selections.screenColor} />
                        {selections.screenType === 'Vinyl' && (
                            <>
                               <DetailItem label="Vinyl Window Config" value={selections.vinylWindowConfig} />
                               <DetailItem label="Window Orientation" value={selections.vinylOrientation} />
                               <DetailItem label="Window Border Material" value={selections.windowBorderMaterialType} />
                               <DetailItem label="Border Series" value={selections.windowBorderTwichellSeries || selections.windowBorderSoltisSeries} />
                               <DetailItem label="Window Border Color" value={selections.windowBorderColor} />
                            </>
                        )}
                    </Section>
                    
                    <Section title="SECTION 2 — MOTOR CONFIG">
                        <DetailItem label="Motor Type" value={selections.motorType} />
                        <DetailItem label="Remote" value={selections.remoteOption} />
                        <DetailItem label="Motor Side" value={selections.motorSide} />
                        <DetailItem label="Install Mount Type" value={selections.installMount} />
                        {selections.installMount === 'Face-mount' && <DetailItem label="# of Sides" value={selections.faceMountSides} />}
                    </Section>

                    <Section title="SECTION 3 — ORDER MEASUREMENTS">
                        <DetailItem label="Left Height" value={outputs?.leftHeightIn.displayValue} />
                        <DetailItem label="Right Height" value={outputs?.rightHeightIn.displayValue} />
                        <DetailItem label="Track to Track" value={outputs?.trackToTrackIn.displayValue} />
                        {outputs?.extendedHoodIn.displayValue !== "—" && (
                            <DetailItem label="Extended Hood" value={outputs?.extendedHoodIn.displayValue} />
                        )}
                    </Section>

                    <Section title="SECTION 4 — MATERIALS">
                        <DetailItem label="U-Channel Required?" value={uChannelRequired === undefined ? '—' : uChannelRequired ? 'Yes' : 'No'} />
                        <DetailItem label="U-Channel Notes" value={screen.uChannelNotes} />
                        <DetailItem label="Build-Out Required?" value={buildOutRequired === undefined ? '—' : buildOutFlagged ? 'FLAG' : buildOutRequired ? 'Yes' : 'No'} />
                        <DetailItem label="Build-Out Type" value={buildOutFlagged ? '—' : buildOutDisplayType} />
                        <DetailItem label="Build Out Color" value={screen.buildOutColor} />
                        <DetailItem label="Build Out Notes" value={screen.buildOutNotes} />
                    </Section>

                    <Section title="SECTION 5 — MISC" columns={1}>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 3fr', gap: '0 24px' }}>
                            <DetailItem label="Number of Cuts" value={screen.numCuts} />
                            <DetailItem label="Special Instructions" value={screen.specialInstructions} />
                        </div>
                    </Section>
                </div>
            </div>
            
            {/* BOTTOM COMPACT CONTENT */}
            <div style={styles.bottomContent}>
                <section style={styles.compactSection}>
                    <div style={styles.compactTitle}>RAW MEASUREMENTS + CALC SUMMARY</div>
                    <div style={styles.compactGrid}>
                        {/* Column 1: Raw Measurements */}
                        <div>
                            <h4 style={styles.compactSubTitle}>RAW MEASUREMENTS (INPUTS)</h4>
                            <div style={styles.compactInnerGrid}>
                                <div> {/* Vertical */}
                                    <DetailItem label="UL" value={formatInchesFrac(measurements.upperLeft)} labelFontSize="9.5px" valueFontSize="9.5px" padding="2px 0"/>
                                    <DetailItem label="LL" value={formatInchesFrac(measurements.lowerLeft)} labelFontSize="9.5px" valueFontSize="9.5px" padding="2px 0"/>
                                    <DetailItem label="OL" value={formatInchesFrac(measurements.overallLeft)} labelFontSize="9.5px" valueFontSize="9.5px" padding="2px 0"/>
                                    <DetailItem label="UR" value={formatInchesFrac(measurements.upperRight)} labelFontSize="9.5px" valueFontSize="9.5px" padding="2px 0"/>
                                    <DetailItem label="LR" value={formatInchesFrac(measurements.lowerRight)} labelFontSize="9.5px" valueFontSize="9.5px" padding="2px 0"/>
                                    <DetailItem label="OR" value={formatInchesFrac(measurements.overallRight)} labelFontSize="9.5px" valueFontSize="9.5px" padding="2px 0"/>
                                </div>
                                <div> {/* Horizontal */}
                                    <DetailItem label="T" value={formatInchesFrac(measurements.top)} labelFontSize="9.5px" valueFontSize="9.5px" padding="2px 0"/>
                                    <DetailItem label="M" value={formatInchesFrac(measurements.middle)} labelFontSize="9.5px" valueFontSize="9.5px" padding="2px 0"/>
                                    <DetailItem label="B" value={formatInchesFrac(measurements.bottom)} labelFontSize="9.5px" valueFontSize="9.5px" padding="2px 0"/>
                                </div>
                            </div>
                        </div>
                        {/* Column 2: Calc Summary */}
                        <div>
                            <h4 style={styles.compactSubTitle}>CALC SUMMARY (CALCULATED)</h4>
                            {selections.reverseMeasurements && (
                                <div style={{ fontSize: '9px', fontWeight: 'bold', border: '0.5px solid #000', padding: '1px 3px', marginBottom: '3px', display: 'inline-block' }}>
                                    ⚠ REVERSE MEASUREMENTS ACTIVE
                                </div>
                            )}
                            <DetailItem label="Upper Slope (S)" value={outputs?.upperSlopeIn.displayValue} labelFontSize="9.5px" valueFontSize="9.5px" padding="2px 0"/>
                            <DetailItem label="Slope Direction" value={outputs?.slopeDirection.displayValue} labelFontSize="9.5px" valueFontSize="9.5px" padding="2px 0"/>
                            <DetailItem label="High Side / Low Side" value={`${outputs?.highSide.displayValue} / ${outputs?.lowSide.displayValue}`} labelFontSize="9.5px" valueFontSize="9.5px" padding="2px 0"/>
                            <DetailItem label="T-B Diff" value={outputs?.tbDiffIn.displayValue} labelFontSize="9.5px" valueFontSize="9.5px" padding="2px 0"/>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    );
};

const PhotoPages: React.FC<{ screen: ScreenConfig; formData: OrderFormState; screenIndex: number }> = ({ screen, formData, screenIndex }) => {
    const measurementPhotos = screen.measurementPhotos || [];
    const generalPhotos = screen.generalPhotos || [];

    if (measurementPhotos.length === 0 && generalPhotos.length === 0) return null;

    const styles: { [key: string]: React.CSSProperties } = {
        pageWrapper: {
            width: '210mm',
            minHeight: '297mm',
            padding: '10mm',
            boxSizing: 'border-box',
            backgroundColor: '#ffffff',
            fontFamily: 'Helvetica, Arial, sans-serif',
            color: '#1f2937',
            display: 'flex',
            flexDirection: 'column',
            pageBreakAfter: 'always',
            pageBreakInside: 'avoid',
            overflow: 'visible',
        },
        pageHeader: { textAlign: 'center', marginBottom: '5mm' },
        headerTitle: { fontSize: '14pt', fontWeight: 'bold' },
        headerSubtitle: { fontSize: '12pt', color: '#4b5563' },
        sectionTitle: {
            fontSize: '12px',
            fontWeight: 'bold',
            marginTop: '8px',
            marginBottom: '6px',
            paddingBottom: '2px',
            borderBottom: '1px solid #9ca3af',
            color: '#111827',
            textTransform: 'uppercase'
        },
        photoGrid: {
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '15px',
            marginBottom: '10px'
        },
        photoContainer: {
            border: '0.5px solid #e5e7eb',
            borderRadius: '4px',
            overflow: 'hidden',
            aspectRatio: '4/3',
            backgroundColor: '#f9fafb',
            display: 'center',
            alignItems: 'center',
            justifyContent: 'center',
            padding: '4px'
        },
        photo: {
            maxWidth: '100%',
            maxHeight: '100%',
            objectFit: 'contain'
        },
        footer: {
            marginTop: 'auto',
            fontSize: '9px',
            color: '#9ca3af',
            textAlign: 'right',
            fontStyle: 'italic'
        }
    };

    const photosPerPage = 6;

    const renderCategoryPages = (photos: PhotoItem[], label: string) => {
        const pagesCount = Math.ceil(photos.length / photosPerPage) || 1;
        const pagesArr = [];
        for (let i = 0; i < pagesCount; i++) {
            const chunk = photos.slice(i * photosPerPage, (i + 1) * photosPerPage);
            pagesArr.push({ chunk, label, pageNum: i + 1, totalPages: pagesCount });
        }
        return pagesArr;
    };

    const allPageData = [
        ...renderCategoryPages(measurementPhotos, "Measurement Photos"),
        ...renderCategoryPages(generalPhotos, "General Screen Area Photos")
    ];

    return (
        <>
            {allPageData.map((pageData, pIdx) => (
                <div key={pIdx} style={styles.pageWrapper}>
                    <header style={styles.pageHeader}>
                        <div style={styles.headerTitle}>Distinctive Outdoor Structures</div>
                        <div style={styles.headerSubtitle}>Motorized Screen Form – Supplement</div>
                    </header>

                    <PdfHeaderGroup formData={formData} screenIndex={screenIndex} />

                    <div style={styles.sectionTitle}>
                        {pageData.label} 
                        {pageData.totalPages > 1 ? ` (Part ${pageData.pageNum} of ${pageData.totalPages})` : ''}
                    </div>
                    
                    <div style={styles.photoGrid}>
                        {pageData.chunk.length > 0 ? (
                            pageData.chunk.map((p, i) => (
                                <div key={p.id} style={styles.photoContainer}>
                                    <img src={p.dataUrl} style={styles.photo} alt={p.name} />
                                </div>
                            ))
                        ) : (
                            <div style={{ gridColumn: '1 / -1', padding: '20px 0', textAlign: 'center' }}>
                                <p style={{ fontSize: '11px', color: '#6b7280', fontStyle: 'italic' }}>No photos provided.</p>
                            </div>
                        )}
                    </div>

                    <div style={styles.footer}>
                        Screen #{screenIndex + 1} Photo Supplement — Page {pIdx + 1} of {allPageData.length}
                    </div>
                </div>
            ))}
        </>
    );
};

const AttachmentPages: React.FC<{ 
    screen: ScreenConfig; 
    formData: OrderFormState; 
    screenIndex: number; 
    isLastScreen?: boolean;
}> = ({ screen, formData, screenIndex, isLastScreen }) => {
    const attachments = screen.attachments || [];

    const styles: { [key: string]: React.CSSProperties } = {
        pageWrapper: {
            width: '210mm',
            minHeight: '297mm',
            padding: '10mm',
            boxSizing: 'border-box',
            backgroundColor: '#ffffff',
            fontFamily: 'Helvetica, Arial, sans-serif',
            color: '#1f2937',
            display: 'flex',
            flexDirection: 'column',
            pageBreakAfter: isLastScreen ? 'auto' : 'always',
            pageBreakInside: 'avoid',
            overflow: 'visible',
        },
        pageHeader: { textAlign: 'center', marginBottom: '5mm' },
        headerTitle: { fontSize: '14pt', fontWeight: 'bold' },
        headerSubtitle: { fontSize: '12pt', color: '#4b5563' },
        sectionTitle: {
            fontSize: '12px',
            fontWeight: 'bold',
            marginTop: '8px',
            marginBottom: '12px',
            paddingBottom: '2px',
            borderBottom: '1px solid #9ca3af',
            color: '#111827',
            textTransform: 'uppercase'
        },
        list: {
            listStyleType: 'decimal',
            paddingLeft: '20px',
            marginTop: '10px'
        },
        listItem: {
            marginBottom: '8px',
            fontSize: '11px',
            color: '#374151'
        },
        footer: {
            marginTop: 'auto',
            fontSize: '9px',
            color: '#9ca3af',
            textAlign: 'right',
            fontStyle: 'italic'
        }
    };

    return (
        <div style={styles.pageWrapper}>
            <header style={styles.pageHeader}>
                <div style={styles.headerTitle}>Distinctive Outdoor Structures</div>
                <div style={styles.headerSubtitle}>Motorized Screen Form – Attachments</div>
            </header>

            <PdfHeaderGroup formData={formData} screenIndex={screenIndex} />

            <div style={styles.sectionTitle}>PDF Attachments</div>
            
            {attachments.length > 0 ? (
                <>
                  <p style={{ fontSize: '11px', color: '#4b5563', marginBottom: '10px' }}>
                    Total Attachments: <strong>{attachments.length}</strong>
                  </p>
                  <ol style={styles.list}>
                    {attachments.map((att, idx) => (
                      <li key={att.id} style={styles.listItem}>
                        {att.name}
                      </li>
                    ))}
                  </ol>
                </>
            ) : (
                <div style={{ padding: '20px 0', textAlign: 'center' }}>
                    <p style={{ fontSize: '11px', color: '#6b7280', fontStyle: 'italic' }}>No PDF attachments provided for this screen.</p>
                </div>
            )}

            <div style={styles.footer}>
                Screen #{screenIndex + 1} Attachment Summary
            </div>
        </div>
    );
};

const PdfContent = React.forwardRef<HTMLDivElement, Props>(({ formData, results, onlyShowIndex, anyUChannelRequired }, ref) => {
  const sourceScreens = results?.screens || formData.screens;

  const screensToRender = onlyShowIndex !== undefined && onlyShowIndex >= 0 && onlyShowIndex < sourceScreens.length
    ? [sourceScreens[onlyShowIndex]] 
    : sourceScreens;

  return (
    <div ref={ref}>
      {screensToRender.map((screen, index) => {
        const screenIndex = onlyShowIndex !== undefined ? onlyShowIndex : index;
        const isLastScreen = index === screensToRender.length - 1;
        return (
          <React.Fragment key={screen.id}>
            <ScreenPage 
                screen={screen} 
                formData={formData} 
                screenIndex={screenIndex} 
            />
            <PhotoPages 
                screen={screen} 
                formData={formData} 
                screenIndex={screenIndex} 
            />
            <AttachmentPages
                screen={screen}
                formData={formData}
                screenIndex={screenIndex}
                isLastScreen={isLastScreen}
            />
          </React.Fragment>
        );
      })}
    </div>
  );
});

export default PdfContent;