
import React from 'react';
import MotorizedScreensTool from './components/MotorizedScreensTool';

const App: React.FC = () => {
  const handleGoToMain = () => {
    window.location.href = "https://dos-hub-259879581437.us-west1.run.app";
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <header className="bg-white shadow-md">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-gray-900">DOS Internal Resources</h1>
          <button
            onClick={handleGoToMain}
            aria-label="Return to Main Page"
            className="inline-flex items-center px-4 py-2 border border-indigo-200 text-sm font-semibold rounded-md text-indigo-700 bg-indigo-50 hover:bg-indigo-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-colors shadow-sm"
          >
            <svg 
              className="w-4 h-4 mr-2" 
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            Main Page
          </button>
        </div>
      </header>
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* The tool provides ordering configuration for motorized screens. */}
        <MotorizedScreensTool />
      </main>
      <footer className="text-center py-4 text-gray-500 text-sm">
        <p>&copy; {new Date().getFullYear()} Distinctive Outdoor Structures. Internal Use Only.</p>
      </footer>
    </div>
  );
};

export default App;
