export interface ProjectInfo {
  name: string;
  submitterName: string;
  date: string;
  address: string;
  jobNumber?: string;
}

export enum ScreenManufacturer {
  DOS_SCREENS = 'DOS Screens',
  MAGNATRACK = 'MagnaTrack',
}

export type InputUnits = 'FT_IN' | 'IN';

export interface PhotoItem {
  id: string;
  name: string;
  dataUrl: string; // base64 encoded jpeg
  createdAt?: string;
}

export interface AttachmentItem {
  id: string;
  name: string;
  mimeType: string;
  dataUrl: string; // base64
  category?: 'measurement' | 'general';
  createdAt?: string;
}

export interface GlobalApplicableSelections {
  // V3 Screen Selection Model
  screenType: string;
  twichellSeries?: string;
  soltisSeries?: string;
  screenColor?: string;
  
  // V3 Vinyl Configuration
  vinylWindowConfig?: string;
  vinylOrientation?: 'Horizontal' | 'Vertical' | '';
  windowBorderMaterialType?: string;
  windowBorderTwichellSeries?: string;
  windowBorderSoltisSeries?: string;
  windowBorderColor?: string;

  // Other selections that can be global or per-screen
  frameColorCollection?: string;
  frameColor?: string;
  motorType: string;
  reverseMeasurements: boolean;
}

export interface ScreenSelections extends GlobalApplicableSelections {
  installMount: string;
  faceMountSides?: string;
  remoteOption?: string;
  motorSide?: string;
}

export interface GlobalSelections extends GlobalApplicableSelections {
  manufacturer: ScreenManufacturer;
  totalScreens: number;
  allSame: boolean;
  applyUChannelToAll: boolean;
  inputUnits: InputUnits;
}

export type MeasurementValue = number | null;

export type MeasurementPoint =
  | 'upperLeft'
  | 'lowerLeft'
  | 'overallLeft'
  | 'upperRight'
  | 'lowerRight'
  | 'overallRight'
  | 'top'
  | 'middle'
  | 'bottom';

export type ScreenMeasurements = Record<MeasurementPoint, MeasurementValue>;

// Represents a calculated value that might be missing due to dependencies.
export type CalculatedValue<T> = {
  value: T | null;
  displayValue: string;
  missing?: string; // e.g., "UL, UR"
};

export type BuildOutType = 'None' | '1x2' | '2x2' | 'FLAG';

export interface ScreenOutputs {
  // Raw orderable dimensions (internal use)
  orderableWidthIn: number;
  orderableHeightIn: number;
  
  // 1. Upper Slope (S)
  upperSlopeIn: CalculatedValue<number>;
  // 2. Left Height
  leftHeightIn: CalculatedValue<number>;
  // 3. Right Height
  rightHeightIn: CalculatedValue<number>;
  // 4. Slope Direction
  slopeDirection: CalculatedValue<'Left' | 'Right' | 'Level'>;
  // 5. High Side
  highSide: CalculatedValue<'Left' | 'Right' | 'Level'>;
  // 6. Low Side
  lowSide: CalculatedValue<'Left' | 'Right' | 'Level'>;
  // 7. Track to Track
  trackToTrackIn: CalculatedValue<number>;
  // 8. T-B Diff
  tbDiffIn: CalculatedValue<number>;
  // 9. U-Channel
  uChannel: CalculatedValue<{ needed: boolean; applied: boolean }>;
  // 10. Build-out
  buildOut: CalculatedValue<{ needed: boolean; type: BuildOutType; flagMessage?: string }>;
  // 11. Bias
  bias: CalculatedValue<{ value: number; notice?: string }>;

  // Additional dependent calculations
  extendedHoodIn: CalculatedValue<number>;

  // Side measurement mismatch notices (internal use for UI warnings)
  leftSideMismatch: boolean;
  rightSideMismatch: boolean;
}

export interface ScreenConfig {
  id: string; // Unique ID for React key prop
  description: string;
  specialInstructions: string;
  uChannelNotes: string;
  buildOutColor: string;
  buildOutNotes: string;
  numCuts: string;
  selections: ScreenSelections;
  measurements: ScreenMeasurements;
  outputs: ScreenOutputs | null;
  measurementPhotos: PhotoItem[];
  generalPhotos: PhotoItem[];
  attachments: AttachmentItem[];
}

export interface OrderFormState {
  project: ProjectInfo;
  globals: GlobalSelections;
  screens: ScreenConfig[];
}

// Validation
export type FieldError = string | undefined;
export type ScreenErrors = {
  measurements?: { [key in MeasurementPoint]?: FieldError };
  selections?: Partial<Record<keyof ScreenSelections, FieldError>>;
};
export type FormErrors = {
  globals?: Partial<Record<keyof GlobalSelections, FieldError>>;
  screens?: ScreenErrors[];
};

export type CalculationResults = {
  screens: ScreenConfig[];
  anyUChannelRequired: boolean;
  uChannelAppliedToAll: boolean;
} | null;

export interface SavedProject {
  id: string;
  projectName: string;
  updatedAt: string;
  payload?: {
    version: string;
    toolKey: string;
    inputs: OrderFormState;
    output: CalculationResults;
    flags: string[];
  };
}