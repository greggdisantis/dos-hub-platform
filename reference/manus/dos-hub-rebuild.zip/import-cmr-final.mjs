#!/usr/bin/env node
/**
 * CMR Import - Final Implementation
 * 
 * Imports 11 real historical CMR records using EXACT approved field mapping.
 * - Uses idempotent logic to prevent duplicates
 * - Preserves consultant attribution as visible field
 * - Maps confidence correctly (currentConfidencePct + originalPcPct)
 * - Maps estimatedContractValue to estimatedValue
 * - Sets all records to "submitted" status
 */

import mysql from 'mysql2/promise';
import fs from 'fs';
import { URL } from 'url';

// Load JSON data
const jsonData = JSON.parse(fs.readFileSync('/tmp/cmr_data.json', 'utf8'));

// Parse DATABASE_URL
const databaseUrl = process.env.DATABASE_URL || '';
let connectionConfig = {};

if (databaseUrl) {
  try {
    const url = new URL(databaseUrl);
    connectionConfig = {
      host: url.hostname,
      user: url.username,
      password: url.password,
      database: url.pathname.slice(1),
      port: url.port || 3306,
      ssl: {},
    };
  } catch (e) {
    console.error('Failed to parse DATABASE_URL:', e.message);
    process.exit(1);
  }
} else {
  connectionConfig = {
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'dos_hub',
  };
}

const DEFAULT_USER_ID = 1;

console.log(`\n📋 CMR IMPORT - FINAL IMPLEMENTATION`);
console.log(`   Total records to import: ${jsonData.reports.length}`);
console.log(`   Using EXACT approved field mapping\n`);

// Helper functions
function transformLeadSource(source) {
  if (!source || source === '—') return null;
  return JSON.stringify([source]);
}

function transformProjectTypes(types) {
  if (!types || types.length === 0) return null;
  if (Array.isArray(types)) return JSON.stringify(types);
  return JSON.stringify([types]);
}

function transformArray(value) {
  if (!value || value === '—') return null;
  if (Array.isArray(value)) return JSON.stringify(value);
  // Split by comma and trim
  const arr = value.split(',').map(v => v.trim());
  return JSON.stringify(arr);
}

function transformBoolean(value) {
  if (typeof value === 'boolean') return value ? 1 : 0;
  if (value === 'Yes' || value === 'yes' || value === true) return 1;
  if (value === 'No' || value === 'no' || value === false) return 0;
  return 0;
}

function transformCloseTimeline(timeline) {
  if (!timeline || timeline === '—') return null;
  if (timeline === '0-30 days') return '0-30';
  if (timeline === '31-60 days') return '31-60';
  if (timeline === '61-90 days') return '61-90';
  if (timeline === '90+ days' || timeline === '90plus') return '90plus';
  return timeline;
}

function transformDealStatus(status) {
  if (!status) return null;
  // Replace all underscores with hyphens
  return status.replace(/_/g, '-');
}

function transformEnum(value, enumType) {
  if (!value || value === '—') return null;
  
  if (enumType === 'clientResponse') {
    if (value === 'Strong Alignment') return 'strong-alignment';
    if (value === 'Neutral') return 'neutral';
    if (value === 'Price Focused') return 'price-focused';
    if (value === 'Comparing Online') return 'comparing-online';
  }
  
  if (enumType === 'financingReaction') {
    if (value === 'Interested') return 'interested';
    if (value === 'Needs Follow-Up') return 'needs-follow-up';
    if (value === 'Declined') return 'declined';
  }
  
  return value.toLowerCase().replace(' ', '-');
}

function safeNull(value) {
  if (!value || value === '—') return null;
  return value;
}

async function importRecords() {
  let connection;
  try {
    connection = await mysql.createConnection(connectionConfig);

    console.log('✅ Connected to database\n');

    let importedCount = 0;
    let skippedCount = 0;
    const importedIds = [];
    const errors = [];

    for (const record of jsonData.reports) {
      try {
        // Idempotent check: use clientName + appointmentDate as unique key
        const [existing] = await connection.query(
          'SELECT id FROM cmr_reports WHERE clientName = ? AND appointmentDate = ?',
          [record.clientName, record.appointmentDate]
        );

        if (existing.length > 0) {
          console.log(`⏭️  SKIP: "${record.clientName}" (${record.appointmentDate}) - already exists`);
          skippedCount++;
          continue;
        }

        // EXACT FIELD MAPPING as approved
        const importRecord = {
          userId: DEFAULT_USER_ID,
          
          // Direct mappings
          clientName: record.clientName,
          consultantName: record.consultantName, // PRESERVE as visible field
          appointmentDate: record.appointmentDate,
          appointmentType: record.appointmentType?.toLowerCase().replace(' ', '-') || null,
          clientType: record.clientType?.toLowerCase() || null,
          address: safeNull(record.address),
          
          // Array transformations
          leadSources: transformLeadSource(record.leadSource),
          projectTypes: transformProjectTypes(record.projectTypes),
          
          // Deal status
          dealStatus: transformDealStatus(record.dealStatus),
          outcome: record.outcome?.toLowerCase() || 'open',
          
          // CRITICAL: Confidence handling per approved mapping
          // purchaseConfidencePct -> currentConfidencePct
          // purchaseConfidencePct -> originalPcPct (locked)
          currentConfidencePct: record.purchaseConfidencePct || null,
          originalPcPct: record.purchaseConfidencePct || null,
          
          // CRITICAL: Estimated value handling per approved mapping
          // estimatedContractValue -> estimatedValue
          estimatedValue: record.estimatedContractValue || null,
          
          // Follow-up dates (preserve historical dates)
          followUpDate: safeNull(record.followUpDate),
          nextFollowUpDate: safeNull(record.nextFollowUpDate),
          
          // Close timeline
          closeTimeline: transformCloseTimeline(record.estimatedCloseTimeline),
          
          // Decision and motivation
          decisionMakers: safeNull(record.decisionMakersInvolved),
          mainMotivation: safeNull(record.mainMotivation),
          mainHesitation: safeNull(record.mainHesitation),
          
          // PC notes
          pcNotes: safeNull(record.pcNotes),
          
          // Financing
          financingDiscussed: transformBoolean(record.financingDiscussed),
          financingReaction: transformEnum(record.financingReaction, 'financingReaction'),
          
          // Value and objections
          valueCommunicated: transformArray(record.valueCommunicated),
          clientResponse: transformEnum(record.clientResponse, 'clientResponse'),
          objections: transformArray(record.objections),
          objectionNotes: safeNull(record.objectionsNotes),
          
          // Next actions
          nextActions: transformArray(record.nextActions),
          
          // Status fields
          status: 'submitted',
          approvedStatus: 'submitted',
          
          // Timestamps
          meetingDate: new Date(),
          lastUpdatedAt: new Date(),
        };

        // Build INSERT query
        const columns = [
          'userId', 'clientName', 'consultantName', 'appointmentDate', 'appointmentType',
          'clientType', 'address', 'leadSources', 'projectTypes', 'dealStatus', 'outcome',
          'currentConfidencePct', 'originalPcPct', 'estimatedValue', 'followUpDate',
          'nextFollowUpDate', 'closeTimeline', 'decisionMakers', 'mainMotivation',
          'mainHesitation', 'pcNotes', 'financingDiscussed', 'financingReaction',
          'valueCommunicated', 'clientResponse', 'objections', 'objectionNotes',
          'nextActions', 'status', 'approvedStatus', 'meetingDate', 'lastUpdatedAt'
        ];

        const values = [
          importRecord.userId, importRecord.clientName, importRecord.consultantName,
          importRecord.appointmentDate, importRecord.appointmentType,
          importRecord.clientType, importRecord.address, importRecord.leadSources,
          importRecord.projectTypes, importRecord.dealStatus, importRecord.outcome,
          importRecord.currentConfidencePct, importRecord.originalPcPct,
          importRecord.estimatedValue, importRecord.followUpDate,
          importRecord.nextFollowUpDate, importRecord.closeTimeline,
          importRecord.decisionMakers, importRecord.mainMotivation,
          importRecord.mainHesitation, importRecord.pcNotes, importRecord.financingDiscussed,
          importRecord.financingReaction, importRecord.valueCommunicated,
          importRecord.clientResponse, importRecord.objections, importRecord.objectionNotes,
          importRecord.nextActions, importRecord.status, importRecord.approvedStatus,
          importRecord.meetingDate, importRecord.lastUpdatedAt
        ];

        const placeholders = columns.map(() => '?').join(', ');
        const query = `INSERT INTO cmr_reports (${columns.join(', ')}) VALUES (${placeholders})`;

        const [result] = await connection.query(query, values);

        console.log(`✅ IMPORT: "${record.clientName}" (${record.appointmentDate}) - ID: ${result.insertId}`);
        console.log(`   Consultant: ${record.consultantName} | PC: ${record.purchaseConfidencePct}% | Est Value: $${record.estimatedContractValue || 'N/A'}`);
        
        importedCount++;
        importedIds.push(result.insertId);

      } catch (err) {
        const errorMsg = `❌ ERROR importing "${record.clientName}": ${err.message}`;
        console.log(errorMsg);
        errors.push(errorMsg);
      }
    }

    console.log(`\n📊 IMPORT SUMMARY:`);
    console.log(`   ✅ Imported: ${importedCount}`);
    console.log(`   ⏭️  Skipped (duplicates): ${skippedCount}`);
    console.log(`   ❌ Errors: ${errors.length}`);
    console.log(`   📍 New IDs: ${importedIds.join(', ')}`);

    if (errors.length > 0) {
      console.log(`\n⚠️  Errors encountered:`);
      errors.forEach(err => console.log(`   ${err}`));
    }

    // Verify import
    const [allRecords] = await connection.query('SELECT COUNT(*) as count FROM cmr_reports');
    console.log(`\n📈 Total CMR records in database: ${allRecords[0].count}`);

    // Verify confidence fields
    const [confidenceCheck] = await connection.query(
      'SELECT COUNT(*) as count FROM cmr_reports WHERE currentConfidencePct IS NOT NULL AND originalPcPct IS NOT NULL'
    );
    console.log(`✅ Records with confidence fields populated: ${confidenceCheck[0].count}`);

    // Verify estimated value
    const [valueCheck] = await connection.query(
      'SELECT COUNT(*) as count FROM cmr_reports WHERE estimatedValue IS NOT NULL'
    );
    console.log(`✅ Records with estimatedValue populated: ${valueCheck[0].count}`);

    return { importedCount, skippedCount, errors, importedIds };

  } catch (err) {
    console.error('❌ Fatal error:', err.message);
    console.error('Stack:', err.stack);
    process.exit(1);
  } finally {
    if (connection) await connection.end();
  }
}

// Run import
importRecords().then(() => {
  console.log('\n✅ Import complete!\n');
  process.exit(0);
}).catch(err => {
  console.error('❌ Import failed:', err);
  process.exit(1);
});
