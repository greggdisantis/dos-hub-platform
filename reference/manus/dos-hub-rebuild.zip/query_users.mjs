import { drizzle } from "drizzle-orm/mysql2";
import { users } from "./drizzle/schema.ts";

const db = drizzle(process.env.DATABASE_URL);

async function listUsers() {
  try {
    const allUsers = await db.select().from(users);
    console.log("=== CURRENT USERS IN NEW SYSTEM ===\n");
    console.log(JSON.stringify(allUsers, null, 2));
    console.log(`\nTotal users: ${allUsers.length}`);
  } catch (error) {
    console.error("Error querying users:", error);
  }
}

listUsers();
