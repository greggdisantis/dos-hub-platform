import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, LogOut, Menu, X } from "lucide-react";
import { useLocation } from "wouter";
import { useState } from "react";

interface ModuleLink {
  label: string;
  path: string;
  icon: string;
  roles: string[];
}

const MODULE_LINKS: ModuleLink[] = [
  { label: "CMR Reports", path: "/dashboard/cmr", icon: "📋", roles: ["member", "manager", "admin", "super-admin"] },
  { label: "Screen Measurements", path: "/screen-measurements", icon: "📐", roles: ["member", "manager", "admin", "super-admin"] },
  { label: "Material Checklist", path: "/dashboard/materials", icon: "📦", roles: ["member", "manager", "admin", "super-admin"] },
  { label: "Receipt Capture", path: "/dashboard/receipts", icon: "🧾", roles: ["member", "manager", "admin", "super-admin"] },
  { label: "AquaClean Receipts", path: "/dashboard/aquaclean", icon: "💧", roles: ["member", "manager", "admin", "super-admin"] },
  { label: "Preconstruction", path: "/dashboard/precon", icon: "✓", roles: ["member", "manager", "admin", "super-admin"] },
  { label: "User Management", path: "/dashboard/users", icon: "👥", roles: ["admin", "super-admin"] },
  { label: "Approvals", path: "/admin/approval", icon: "✅", roles: ["super-admin"] },
];

export default function Dashboard() {
  const { user, loading, logout } = useAuth();
  const [, setLocation] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const fullName = `${user.firstName} ${user.lastName}`;
  const userRole = user.role;

  // Filter modules based on user role
  const availableModules = MODULE_LINKS.filter((module) =>
    module.roles.includes(userRole)
  );

  const handleLogout = async () => {
    await logout();
    setLocation("/login");
  };

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      <aside
        className={`${
          sidebarOpen ? "w-64" : "w-20"
        } bg-card border-r border-border transition-all duration-300 flex flex-col`}
      >
        {/* Logo */}
        <div className="p-4 border-b border-border flex items-center justify-between">
          {sidebarOpen && <h1 className="text-lg font-bold">DOS Hub</h1>}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-1 hover:bg-accent rounded transition-colors"
          >
            {sidebarOpen ? (
              <X className="w-5 h-5" />
            ) : (
              <Menu className="w-5 h-5" />
            )}
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
          {availableModules.map((module) => (
            <button
              key={module.path}
              onClick={() => setLocation(module.path)}
              className="w-full flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-accent transition-colors text-left text-sm"
              title={module.label}
            >
              <span className="text-lg flex-shrink-0">{module.icon}</span>
              {sidebarOpen && <span className="truncate">{module.label}</span>}
            </button>
          ))}
        </nav>

        {/* User Profile */}
        <div className="p-4 border-t border-border space-y-3">
          <div className={`flex items-center gap-3 ${!sidebarOpen && "justify-center"}`}>
            <div className="w-10 h-10 rounded-full bg-accent flex items-center justify-center flex-shrink-0 font-semibold">
              {user.firstName?.charAt(0).toUpperCase()}
            </div>
            {sidebarOpen && (
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium truncate">{fullName}</p>
                <p className="text-xs text-muted-foreground capitalize truncate">
                  {userRole}
                </p>
              </div>
            )}
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={handleLogout}
            className="w-full"
          >
            {sidebarOpen ? (
              <>
                <LogOut className="w-4 h-4 mr-2" />
                Sign out
              </>
            ) : (
              <LogOut className="w-4 h-4" />
            )}
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Top Header */}
        <header className="bg-card border-b border-border px-6 py-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">Dashboard</h2>
            <div className="text-sm text-muted-foreground">
              Welcome, {fullName}
            </div>
          </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 p-6 overflow-auto">
          <div className="space-y-6">
            {/* Status Card */}
            {user.approved === 0 && (
              <Card className="p-6 border-amber-200 bg-amber-50">
                <p className="text-sm text-amber-900">
                  ⚠️ Your account is pending admin approval. You will gain full access once approved.
                </p>
              </Card>
            )}

            {/* Role-Specific Welcome */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold mb-2">
                {getRoleWelcomeMessage(userRole)}
              </h3>
              <p className="text-muted-foreground text-sm">
                {getRoleDescription(userRole)}
              </p>
            </Card>

            {/* Quick Access Grid */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Quick Access</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {availableModules.map((module) => (
                  <Card
                    key={module.path}
                    className="p-6 cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => setLocation(module.path)}
                  >
                    <div className="flex items-start gap-4">
                      <span className="text-3xl">{module.icon}</span>
                      <div className="flex-1">
                        <h4 className="font-semibold text-sm mb-1">
                          {module.label}
                        </h4>
                        <p className="text-xs text-muted-foreground">
                          {getModuleDescription(module.label)}
                        </p>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>

            {/* Admin Section */}
            {["admin", "super-admin"].includes(userRole) && (
              <div>
                <h3 className="text-lg font-semibold mb-4">Administration</h3>
                <Card className="p-6">
                  <div className="space-y-3">
                    <div>
                      <h4 className="font-semibold text-sm mb-1">User Management</h4>
                      <p className="text-xs text-muted-foreground mb-3">
                        Manage user accounts, roles, and approvals
                      </p>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setLocation("/admin/approval")}
                      >
                        View Pending Approvals
                      </Button>
                    </div>
                  </div>
                </Card>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}

function getRoleWelcomeMessage(role: string): string {
  const messages: Record<string, string> = {
    member: "Welcome to DOS Hub",
    manager: "Welcome, Manager",
    admin: "Welcome, Administrator",
    "super-admin": "Welcome, Super Administrator",
    pending: "Account Pending Approval",
    guest: "Welcome, Guest",
  };
  return messages[role] || "Welcome to DOS Hub";
}

function getRoleDescription(role: string): string {
  const descriptions: Record<string, string> = {
    member: "Access to core project management tools and reporting features.",
    manager: "Full access to project management, team coordination, and reporting.",
    admin: "Administrative access to user management and system configuration.",
    "super-admin": "Complete system access with full control over all features and users.",
    pending: "Your account is awaiting admin approval to access DOS Hub.",
    guest: "Limited access to view-only features.",
  };
  return descriptions[role] || "Access DOS Hub features based on your role.";
}

function getModuleDescription(label: string): string {
  const descriptions: Record<string, string> = {
    "CMR Reports": "Create and manage client meeting reports",
    "Screen Measurements": "Record on-site screen measurements",
    "Material Checklist": "Track project materials and deliveries",
    "Receipt Capture": "Upload and categorize expense receipts",
    "AquaClean Receipts": "Manage AquaClean-specific receipts",
    Preconstruction: "Track preconstruction checklists",
    "User Management": "Manage user accounts and permissions",
    Approvals: "Review and approve pending users",
  };
  return descriptions[label] || "Access this module";
}
