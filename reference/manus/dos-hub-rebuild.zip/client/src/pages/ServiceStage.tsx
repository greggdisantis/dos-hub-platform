import { StageOverview } from "./StageOverview";

export default function ServiceStage() {
  return (
    <StageOverview
      stage="service"
      title="Service"
      description="Post-installation service and maintenance. Track service requests, repairs, and receipts."
    />
  );
}
