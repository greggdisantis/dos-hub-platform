/**
 * DOS: Receipt Capture — Main Hub Page
 * Route: /dashboard/receipts
 *
 * Shows role-appropriate navigation cards:
 * - All users: Submit Receipt, My Receipts
 * - Finance roles: Finance Inbox, Finance In Progress, Archive, Analytics
 */
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { ModulePageHeader } from "@/components/ModulePageHeader";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import {
  Upload,
  FileText,
  Inbox,
  Clock,
  Archive,
  BarChart3,
} from "lucide-react";

const FINANCE_ROLES = ["admin", "super-admin", "manager", "finance"];

function isFinance(role?: string) {
  return role ? FINANCE_ROLES.includes(role) : false;
}

interface NavCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  path: string;
  badge?: string | number;
  badgeVariant?: "default" | "secondary" | "destructive" | "outline";
}

function NavCard({ icon, title, description, path, badge, badgeVariant = "secondary" }: NavCardProps) {
  const [, setLocation] = useLocation();
  return (
    <Card
      className="cursor-pointer hover:shadow-md transition-shadow border-border/60 hover:border-primary/40"
      onClick={() => setLocation(path)}
    >
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10 text-primary">{icon}</div>
            <CardTitle className="text-base">{title}</CardTitle>
          </div>
          {badge !== undefined && (
            <Badge variant={badgeVariant}>{badge}</Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <CardDescription>{description}</CardDescription>
      </CardContent>
    </Card>
  );
}

export function ReceiptCapture() {
  const { user } = useAuth();
  const finance = isFinance(user?.role);

  // Fetch counts for badges
  const { data: myReceipts } = trpc.receipts.list.useQuery({ limit: 200 }, { enabled: !!user });
  const { data: financeInbox } = trpc.receipts.financeList.useQuery(undefined, { enabled: finance });
  const { data: financeInProgress } = trpc.receipts.financeInProgress.useQuery(undefined, { enabled: finance });

  const myDraftCount = myReceipts?.filter((r) => r.status === "draft").length ?? 0;
  const mySubmittedCount = myReceipts?.filter((r) => r.status === "submitted").length ?? 0;
  const inboxCount = financeInbox?.length ?? 0;
  const inProgressCount = financeInProgress?.length ?? 0;

  return (
    <div className="flex flex-col gap-6">
      <ModulePageHeader title="Receipt Capture" />

      {/* User section */}
      <div>
        <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">
          My Receipts
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <NavCard
            icon={<Upload className="h-5 w-5" />}
            title="Submit Receipt"
            description="Upload and submit a new receipt for finance processing."
            path="/dashboard/receipts/new"
            badge={myDraftCount > 0 ? `${myDraftCount} draft` : undefined}
            badgeVariant="outline"
          />
          <NavCard
            icon={<FileText className="h-5 w-5" />}
            title="My Receipts"
            description="View and manage all receipts you have submitted."
            path="/dashboard/receipts/mine"
            badge={mySubmittedCount > 0 ? mySubmittedCount : undefined}
          />
        </div>
      </div>

      {/* Finance section */}
      {finance && (
        <div>
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">
            Finance
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <NavCard
              icon={<Inbox className="h-5 w-5" />}
              title="Finance Inbox"
              description="Receipts submitted by staff awaiting entry into accounting."
              path="/dashboard/receipts/finance-inbox"
              badge={inboxCount > 0 ? inboxCount : undefined}
              badgeVariant="destructive"
            />
            <NavCard
              icon={<Clock className="h-5 w-5" />}
              title="Finance In Progress"
              description="Receipts currently being entered into the accounting system."
              path="/dashboard/receipts/finance-in-progress"
              badge={inProgressCount > 0 ? inProgressCount : undefined}
            />
            <NavCard
              icon={<Archive className="h-5 w-5" />}
              title="Archive"
              description="Search completed and voided receipts."
              path="/dashboard/receipts/archive"
            />
            <NavCard
              icon={<BarChart3 className="h-5 w-5" />}
              title="Analytics"
              description="Receipt submission trends, totals, and processing metrics."
              path="/dashboard/receipts/analytics"
            />
          </div>
        </div>
      )}
    </div>
  );
}
