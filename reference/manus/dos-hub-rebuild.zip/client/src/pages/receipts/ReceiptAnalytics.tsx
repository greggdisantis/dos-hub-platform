/**
 * DOS: Receipt Capture — Analytics
 * Route: /dashboard/receipts/analytics
 * Finance roles only.
 */
import { useState, useMemo } from "react";
import { trpc } from "@/lib/trpc";
import { ModulePageHeader } from "@/components/ModulePageHeader";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, DollarSign, FileText, Clock } from "lucide-react";

function formatCurrency(val: number) {
  return `$${val.toFixed(2)}`;
}

function StatCard({ icon, label, value, sub }: { icon: React.ReactNode; label: string; value: string; sub?: string }) {
  return (
    <Card>
      <CardContent className="pt-5 flex items-start gap-4">
        <div className="p-2 rounded-lg bg-primary/10 text-primary shrink-0">{icon}</div>
        <div>
          <p className="text-sm text-muted-foreground">{label}</p>
          <p className="text-2xl font-bold">{value}</p>
          {sub && <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>}
        </div>
      </CardContent>
    </Card>
  );
}

// Default: last 30 days
function defaultDateRange() {
  const to = new Date();
  const from = new Date();
  from.setDate(from.getDate() - 30);
  return {
    from: from.toISOString().split("T")[0],
    to: to.toISOString().split("T")[0],
  };
}

export function ReceiptAnalytics() {
  const defaults = useMemo(() => defaultDateRange(), []);
  const [dateFrom, setDateFrom] = useState(defaults.from);
  const [dateTo, setDateTo] = useState(defaults.to);
  const [queryInput, setQueryInput] = useState({ dateFrom: defaults.from, dateTo: defaults.to });

  const { data, isLoading } = trpc.receipts.analytics.useQuery({
    dateFrom: queryInput.dateFrom,
    dateTo: queryInput.dateTo,
  });

  const handleApply = () => setQueryInput({ dateFrom, dateTo });

  // Derived counts from byStatus
  const totalPending = data
    ? (data.byStatus["submitted"]?.count ?? 0) + (data.byStatus["entered"]?.count ?? 0)
    : 0;
  const totalComplete = data?.byStatus["complete"]?.count ?? 0;

  return (
    <div className="flex flex-col gap-6">
      <ModulePageHeader
        title="Receipt Analytics"
        backTo="/dashboard/receipts"
        backLabel="Back to Receipt Capture"
      />

      {/* Date range filter */}
      <Card>
        <CardContent className="pt-5 flex flex-wrap items-end gap-4">
          <div className="flex flex-col gap-1.5">
            <Label>From</Label>
            <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="w-40" />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label>To</Label>
            <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="w-40" />
          </div>
          <Button onClick={handleApply}>Apply</Button>
        </CardContent>
      </Card>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-28 rounded-lg" />)}
        </div>
      ) : !data ? (
        <p className="text-sm text-muted-foreground">No data available for the selected period.</p>
      ) : (
        <>
          {/* KPI cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard
              icon={<FileText className="h-5 w-5" />}
              label="Total Receipts"
              value={String(data.totalCount)}
              sub="In selected period"
            />
            <StatCard
              icon={<DollarSign className="h-5 w-5" />}
              label="Total Amount"
              value={formatCurrency(data.totalAmount)}
              sub="Sum of all receipts"
            />
            <StatCard
              icon={<TrendingUp className="h-5 w-5" />}
              label="Completed"
              value={String(totalComplete)}
              sub="Entered and marked complete"
            />
            <StatCard
              icon={<Clock className="h-5 w-5" />}
              label="Pending Entry"
              value={String(totalPending)}
              sub="Submitted or in progress"
            />
          </div>

          {/* By type breakdown */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Breakdown by Type</CardTitle>
            </CardHeader>
            <CardContent>
              {Object.keys(data.byType).length === 0 ? (
                <p className="text-sm text-muted-foreground">No data.</p>
              ) : (
                <div className="flex flex-col gap-3">
                  {Object.entries(data.byType).map(([type, stats]) => (
                    <div key={type} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">
                          {type === "job_related" ? "Job Related" : type === "overhead" ? "Overhead" : "Unclassified"}
                        </Badge>
                        <span className="text-sm text-muted-foreground">{stats.count} receipts</span>
                      </div>
                      <span className="text-sm font-medium">{formatCurrency(stats.amount)}</span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* By status breakdown */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Breakdown by Status</CardTitle>
            </CardHeader>
            <CardContent>
              {Object.keys(data.byStatus).length === 0 ? (
                <p className="text-sm text-muted-foreground">No data.</p>
              ) : (
                <div className="flex flex-col gap-3">
                  {Object.entries(data.byStatus).map(([status, stats]) => (
                    <div key={status} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Badge variant={status === "voided" ? "destructive" : status === "complete" ? "default" : "secondary"}>
                          {status}
                        </Badge>
                        <span className="text-sm text-muted-foreground">{stats.count} receipts</span>
                      </div>
                      <span className="text-sm font-medium">{formatCurrency(stats.amount)}</span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* By overhead category */}
          {Object.keys(data.byOverheadCategory).length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Overhead by Category</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col gap-3">
                  {Object.entries(data.byOverheadCategory).map(([cat, stats]) => (
                    <div key={cat} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{cat}</Badge>
                        <span className="text-sm text-muted-foreground">{stats.count} receipts</span>
                      </div>
                      <span className="text-sm font-medium">{formatCurrency(stats.amount)}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}
