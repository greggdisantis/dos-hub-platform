/**
 * DOS: Receipt Capture — Submit New Receipt
 * Route: /dashboard/receipts/new
 *
 * Flow:
 *   1. Upload image (drag-drop or file picker)
 *   2. AI analysis triggers automatically after upload — auto-fills all fields
 *   3. User reviews / edits fields (all fields remain editable)
 *   4. Save as draft or submit directly to finance inbox
 *
 * NOTE: handleFileSelect and runAnalysis are plain async functions (NOT wrapped in
 * useCallback) to avoid stale-closure bugs with tRPC mutation references. The
 * isParsingRef guard prevents duplicate parse calls.
 */
import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { ModulePageHeader } from "@/components/ModulePageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Spinner } from "@/components/ui/spinner";
import { Plus, Trash2, ImageIcon, AlertTriangle, CheckCircle2 } from "lucide-react";

// Approved DOS overhead categories — must match server/routers/receipts.ts
export const OVERHEAD_CATEGORIES = [
  "Fuel",
  "Office Supplies",
  "Tools",
  "Vehicle Maintenance",
  "Parking",
  "Meals",
  "Travel",
  "Lodging",
  "Shipping",
  "Software",
  "Marketing",
  "Training",
  "Safety",
  "Shop Supplies",
  "Utilities",
  "Equipment Rental",
  "Miscellaneous",
] as const;

interface LineItem {
  description: string;
  amount: string;
}

type ParseStatus = "idle" | "analyzing" | "success" | "partial" | "failed";

export function ReceiptNew() {
  const [, setLocation] = useLocation();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Guard: prevent duplicate parse calls
  const isParsingRef = useRef(false);

  // Upload state
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [draftId, setDraftId] = useState<number | null>(null);

  // AI parse state
  const [parseStatus, setParseStatus] = useState<ParseStatus>("idle");
  const [parseWarning, setParseWarning] = useState<string | null>(null);

  // Form state — all start empty (no hardcoded defaults)
  const [vendorName, setVendorName] = useState("");
  const [receiptDate, setReceiptDate] = useState("");
  const [subtotal, setSubtotal] = useState("");
  const [tax, setTax] = useState("");
  const [total, setTotal] = useState("");
  const [description, setDescription] = useState("");
  const [notes, setNotes] = useState("");
  const [receiptType, setReceiptType] = useState<"job_related" | "overhead" | "">("");
  const [overheadCategory, setOverheadCategory] = useState("");
  const [jobName, setJobName] = useState("");
  const [poNumber, setPoNumber] = useState("");
  const [lineItems, setLineItems] = useState<LineItem[]>([]);

  const utils = trpc.useUtils();

  // tRPC mutations — referenced directly in handlers (no useCallback) to avoid stale closures
  const uploadImageMutation = trpc.receipts.uploadImage.useMutation();
  const createDraftMutation = trpc.receipts.createDraft.useMutation();
  const analyzeMutation = trpc.receipts.analyze.useMutation();
  const saveMutation = trpc.receipts.save.useMutation();
  const submitMutation = trpc.receipts.submit.useMutation();

  // ---------------------------------------------------------------------------
  // AI analysis — called directly after upload, NOT via useCallback
  // ---------------------------------------------------------------------------
  async function runAnalysis(draftReceiptId: number) {
    if (isParsingRef.current) return; // prevent duplicate calls
    isParsingRef.current = true;
    setParseStatus("analyzing");
    setParseWarning(null);
    try {
      const result = await analyzeMutation.mutateAsync({ receiptId: draftReceiptId });

      // Populate all fields from AI result — only set if value is non-null/non-empty
      if (result.vendorName) setVendorName(result.vendorName);
      if (result.receiptDate) setReceiptDate(result.receiptDate);
      if (result.subtotal) setSubtotal(result.subtotal);
      if (result.tax) setTax(result.tax);
      if (result.total) setTotal(result.total);
      if (result.receiptType) setReceiptType(result.receiptType as "job_related" | "overhead");
      if (result.overheadCategory) setOverheadCategory(result.overheadCategory);
      if (result.description) setDescription(result.description);
      if (result.notes) setNotes(result.notes);
      if (result.lineItems?.length) {
        setLineItems(
          result.lineItems.map((li: any) => ({
            description: li.description ?? "",
            amount: li.amount ?? "",
          }))
        );
      }

      // Determine parse quality
      const confidence = result.confidence ?? "low";
      const missingCritical = !result.vendorName || !result.total;

      if (confidence === "low" || missingCritical) {
        setParseStatus("partial");
        setParseWarning(
          "We couldn't fully read this receipt. Please review and complete any missing fields."
        );
      } else {
        setParseStatus("success");
        setParseWarning(null);
      }
    } catch (err: any) {
      setParseStatus("failed");
      setParseWarning(
        "We couldn't fully read this receipt. Please review and complete any missing fields."
      );
      toast.error("AI analysis failed — please fill in the fields manually.");
    } finally {
      isParsingRef.current = false;
    }
  }

  // ---------------------------------------------------------------------------
  // File selection handler — upload then auto-trigger AI
  // ---------------------------------------------------------------------------
  async function handleFileSelect(file: File) {
    if (!file.type.startsWith("image/")) {
      toast.error("Please select an image file (JPG, PNG, HEIC, etc.)");
      return;
    }
    if (file.size > 16 * 1024 * 1024) {
      toast.error("Image must be under 16 MB");
      return;
    }

    // Show preview immediately
    setImagePreview(URL.createObjectURL(file));

    // Reset all form fields and parse state for the new image
    setVendorName("");
    setReceiptDate("");
    setSubtotal("");
    setTax("");
    setTotal("");
    setDescription("");
    setNotes("");
    setReceiptType("");
    setOverheadCategory("");
    setJobName("");
    setPoNumber("");
    setLineItems([]);
    setParseStatus("idle");
    setParseWarning(null);
    isParsingRef.current = false;

    setUploading(true);
    try {
      const base64 = await fileToBase64(file);

      // Step 1: Upload image to S3
      const uploadResult = await uploadImageMutation.mutateAsync({
        filename: file.name,
        contentType: file.type,
        base64Data: base64,
      });

      // Step 2: Create draft receipt record
      const draft = await createDraftMutation.mutateAsync({
        originalImageKey: uploadResult.key,
      });
      setDraftId(draft.id);

      // Step 3: Automatically trigger AI analysis — no button click required
      setUploading(false);
      await runAnalysis(draft.id);
    } catch (err: any) {
      toast.error(err?.message ?? "Upload failed — please try again.");
      setParseStatus("failed");
      setUploading(false);
    }
  }

  // ---------------------------------------------------------------------------
  // Drag-and-drop handler
  // ---------------------------------------------------------------------------
  function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file) handleFileSelect(file);
  }

  // ---------------------------------------------------------------------------
  // Save draft
  // ---------------------------------------------------------------------------
  async function handleSaveDraft() {
    if (!draftId) {
      toast.error("Please upload an image first");
      return;
    }
    try {
      await saveMutation.mutateAsync(buildSavePayload());
      toast.success("Draft saved");
    } catch (err: any) {
      toast.error(err?.message ?? "Save failed");
    }
  }

  // ---------------------------------------------------------------------------
  // Submit to finance
  // ---------------------------------------------------------------------------
  async function handleSubmit() {
    if (!draftId) {
      toast.error("Please upload an image first");
      return;
    }
    if (!total) {
      toast.error("Please enter the receipt total before submitting");
      return;
    }
    try {
      await saveMutation.mutateAsync(buildSavePayload());
      await submitMutation.mutateAsync({ id: draftId });
      utils.receipts.list.invalidate();
      toast.success("Receipt submitted to finance inbox");
      setLocation("/dashboard/receipts/mine");
    } catch (err: any) {
      toast.error(err?.message ?? "Submit failed");
    }
  }

  function buildSavePayload() {
    return {
      id: draftId!,
      vendorName: vendorName || undefined,
      receiptDate: receiptDate || undefined,
      subtotal: subtotal || undefined,
      tax: tax || undefined,
      total: total || undefined,
      description: description || undefined,
      notes: notes || undefined,
      receiptType: (receiptType as any) || undefined,
      overheadCategory: overheadCategory || undefined,
      jobName: jobName || undefined,
      poNumber: poNumber || undefined,
      lineItems: lineItems.map((li, i) => ({ ...li, sortOrder: i })),
    };
  }

  // ---------------------------------------------------------------------------
  // Line item helpers
  // ---------------------------------------------------------------------------
  const addLineItem = () => setLineItems((prev) => [...prev, { description: "", amount: "" }]);
  const removeLineItem = (i: number) =>
    setLineItems((prev) => prev.filter((_, idx) => idx !== i));
  const updateLineItem = (i: number, field: keyof LineItem, value: string) =>
    setLineItems((prev) => prev.map((li, idx) => (idx === i ? { ...li, [field]: value } : li)));

  // ---------------------------------------------------------------------------
  // Derived state
  // ---------------------------------------------------------------------------
  const isAnalyzing = parseStatus === "analyzing";
  const isBusy =
    uploading || isAnalyzing || saveMutation.isPending || submitMutation.isPending;

  // ---------------------------------------------------------------------------
  // Render
  // ---------------------------------------------------------------------------
  return (
    <div className="flex flex-col gap-6">
      <ModulePageHeader
        title="Submit Receipt"
        backTo="/dashboard/receipts"
        backLabel="Back to Receipt Capture"
      >
        <Button variant="outline" onClick={handleSaveDraft} disabled={isBusy || !draftId}>
          Save Draft
        </Button>
        <Button onClick={handleSubmit} disabled={isBusy || !draftId}>
          {submitMutation.isPending ? <Spinner className="h-4 w-4 mr-2" /> : null}
          Submit to Finance
        </Button>
      </ModulePageHeader>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* ------------------------------------------------------------------ */}
        {/* Image upload panel                                                  */}
        {/* ------------------------------------------------------------------ */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Receipt Image</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            {imagePreview ? (
              <div className="relative">
                <img
                  src={imagePreview}
                  alt="Receipt preview"
                  className="w-full max-h-80 object-contain rounded-lg border"
                />
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-2 w-full"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploading || isAnalyzing}
                >
                  Replace Image
                </Button>
              </div>
            ) : (
              <div
                className="border-2 border-dashed border-border rounded-lg p-10 flex flex-col items-center gap-3 cursor-pointer hover:border-primary/50 transition-colors"
                onClick={() => fileInputRef.current?.click()}
                onDrop={handleDrop}
                onDragOver={(e) => e.preventDefault()}
              >
                {uploading ? (
                  <Spinner className="h-8 w-8 text-muted-foreground" />
                ) : (
                  <ImageIcon className="h-10 w-10 text-muted-foreground" />
                )}
                <p className="text-sm text-muted-foreground text-center">
                  {uploading
                    ? "Uploading…"
                    : "Drag & drop or click to select a receipt image"}
                </p>
                <p className="text-xs text-muted-foreground">JPG, PNG, HEIC — max 16 MB</p>
              </div>
            )}

            {/* Hidden file input — used by both the drop zone and Replace Image button */}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleFileSelect(file);
                // Reset so the same file can be re-selected after replace
                e.target.value = "";
              }}
            />

            {/* AI parse status banners */}
            {isAnalyzing && (
              <div className="flex items-center gap-2 p-3 bg-muted rounded-md text-sm text-muted-foreground">
                <Spinner className="h-4 w-4 shrink-0" />
                <span>Analyzing receipt with AI — fields will auto-fill shortly…</span>
              </div>
            )}
            {parseStatus === "success" && (
              <div className="flex items-center gap-2 p-3 bg-green-50 border border-green-200 rounded-md text-sm text-green-800 dark:bg-green-950/30 dark:border-green-800 dark:text-green-300">
                <CheckCircle2 className="h-4 w-4 shrink-0" />
                <span>Fields auto-filled from receipt. Review and edit as needed.</span>
              </div>
            )}
            {(parseStatus === "partial" || parseStatus === "failed") && parseWarning && (
              <div className="flex items-start gap-2 p-3 bg-amber-50 border border-amber-200 rounded-md text-sm text-amber-800 dark:bg-amber-950/30 dark:border-amber-800 dark:text-amber-300">
                <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
                <span>{parseWarning}</span>
              </div>
            )}
          </CardContent>
        </Card>

        {/* ------------------------------------------------------------------ */}
        {/* Form fields panel                                                   */}
        {/* ------------------------------------------------------------------ */}
        <div className="flex flex-col gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Receipt Details</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col gap-4">
              {/* Vendor + Date */}
              <div className="grid grid-cols-2 gap-4">
                <div className="flex flex-col gap-1.5">
                  <Label>Vendor Name</Label>
                  <Input
                    value={vendorName}
                    onChange={(e) => setVendorName(e.target.value)}
                    placeholder="Vendor name"
                    disabled={isAnalyzing}
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label>Receipt Date</Label>
                  <Input
                    type="date"
                    value={receiptDate}
                    onChange={(e) => setReceiptDate(e.target.value)}
                    disabled={isAnalyzing}
                  />
                </div>
              </div>

              {/* Amounts */}
              <div className="grid grid-cols-3 gap-4">
                <div className="flex flex-col gap-1.5">
                  <Label>Subtotal</Label>
                  <Input
                    value={subtotal}
                    onChange={(e) => setSubtotal(e.target.value)}
                    placeholder="0.00"
                    disabled={isAnalyzing}
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label>Tax</Label>
                  <Input
                    value={tax}
                    onChange={(e) => setTax(e.target.value)}
                    placeholder="0.00"
                    disabled={isAnalyzing}
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label>Total *</Label>
                  <Input
                    value={total}
                    onChange={(e) => setTotal(e.target.value)}
                    placeholder="0.00"
                    disabled={isAnalyzing}
                  />
                </div>
              </div>

              {/* Receipt Type */}
              <div className="flex flex-col gap-1.5">
                <Label>Receipt Type</Label>
                <Select
                  value={receiptType}
                  onValueChange={(v) => {
                    setReceiptType(v as any);
                    if (v !== "overhead") setOverheadCategory("");
                  }}
                  disabled={isAnalyzing}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="job_related">Job Related</SelectItem>
                    <SelectItem value="overhead">Overhead</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Overhead Category — controlled dropdown, only shown when type = overhead */}
              {receiptType === "overhead" && (
                <div className="flex flex-col gap-1.5">
                  <Label>Overhead Category</Label>
                  <Select
                    value={overheadCategory}
                    onValueChange={setOverheadCategory}
                    disabled={isAnalyzing}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select overhead category" />
                    </SelectTrigger>
                    <SelectContent>
                      {OVERHEAD_CATEGORIES.map((cat) => (
                        <SelectItem key={cat} value={cat}>
                          {cat}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {/* Job fields — only shown when type = job_related */}
              {receiptType === "job_related" && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1.5">
                    <Label>Job Name</Label>
                    <Input
                      value={jobName}
                      onChange={(e) => setJobName(e.target.value)}
                      placeholder="Job name"
                      disabled={isAnalyzing}
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <Label>PO Number</Label>
                    <Input
                      value={poNumber}
                      onChange={(e) => setPoNumber(e.target.value)}
                      placeholder="PO-XXXX"
                      disabled={isAnalyzing}
                    />
                  </div>
                </div>
              )}

              {/* Description */}
              <div className="flex flex-col gap-1.5">
                <Label>Description</Label>
                <Input
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Brief description of purchase"
                  disabled={isAnalyzing}
                />
              </div>

              {/* Notes */}
              <div className="flex flex-col gap-1.5">
                <Label>Notes</Label>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Any additional notes"
                  rows={2}
                  disabled={isAnalyzing}
                />
              </div>
            </CardContent>
          </Card>

          {/* Line items */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">Line Items</CardTitle>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={addLineItem}
                  disabled={isAnalyzing}
                >
                  <Plus className="h-4 w-4 mr-1" /> Add
                </Button>
              </div>
            </CardHeader>
            <CardContent className="flex flex-col gap-2">
              {lineItems.length === 0 && (
                <p className="text-sm text-muted-foreground">
                  {isAnalyzing
                    ? "Extracting line items…"
                    : "No line items. AI analysis will populate these automatically, or add them manually."}
                </p>
              )}
              {lineItems.map((li, i) => (
                <div key={i} className="flex gap-2 items-center">
                  <Input
                    className="flex-1"
                    placeholder="Description"
                    value={li.description}
                    onChange={(e) => updateLineItem(i, "description", e.target.value)}
                    disabled={isAnalyzing}
                  />
                  <Input
                    className="w-24"
                    placeholder="Amount"
                    value={li.amount}
                    onChange={(e) => updateLineItem(i, "amount", e.target.value)}
                    disabled={isAnalyzing}
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => removeLineItem(i)}
                    disabled={isAnalyzing}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Convert a File to a base64 string (without the data URL prefix). */
function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result.split(",")[1]);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
