/**
 * DOS: Receipt Capture — My Receipts
 * Route: /dashboard/receipts/mine
 */
import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { ModulePageHeader } from "@/components/ModulePageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Search } from "lucide-react";

const STATUS_COLORS: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
  draft: "outline",
  submitted: "secondary",
  entered: "default",
  complete: "default",
  voided: "destructive",
};

function formatDate(val: any) {
  if (!val) return "—";
  try {
    return new Date(val).toLocaleDateString();
  } catch {
    return String(val);
  }
}

function formatCurrency(val: any) {
  if (!val) return "—";
  const n = parseFloat(val);
  if (isNaN(n)) return val;
  return `$${n.toFixed(2)}`;
}

export function MyReceipts() {
  const [, setLocation] = useLocation();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");

  const { data: receipts, isLoading } = trpc.receipts.list.useQuery({
    search: search || undefined,
    status: statusFilter !== "all" ? statusFilter : undefined,
    receiptType: typeFilter !== "all" ? typeFilter : undefined,
    limit: 100,
  });

  return (
    <div className="flex flex-col gap-6">
      <ModulePageHeader
        title="My Receipts"
        backTo="/dashboard/receipts"
        backLabel="Back to Receipt Capture"
      >
        <Button onClick={() => setLocation("/dashboard/receipts/new")}>
          <Plus className="h-4 w-4 mr-2" /> New Receipt
        </Button>
      </ModulePageHeader>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            className="pl-9"
            placeholder="Search vendor, description…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="submitted">Submitted</SelectItem>
            <SelectItem value="entered">Entered</SelectItem>
            <SelectItem value="complete">Complete</SelectItem>
            <SelectItem value="voided">Voided</SelectItem>
          </SelectContent>
        </Select>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-44">
            <SelectValue placeholder="Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="job_related">Job Related</SelectItem>
            <SelectItem value="overhead">Overhead</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* List */}
      {isLoading ? (
        <div className="flex flex-col gap-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-20 w-full rounded-lg" />
          ))}
        </div>
      ) : !receipts?.length ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            No receipts found.{" "}
            <button
              className="underline text-primary"
              onClick={() => setLocation("/dashboard/receipts/new")}
            >
              Submit your first receipt
            </button>
          </CardContent>
        </Card>
      ) : (
        <div className="flex flex-col gap-2">
          {receipts.map((r) => (
            <Card
              key={r.id}
              className="cursor-pointer hover:shadow-sm transition-shadow"
              onClick={() => setLocation(`/dashboard/receipts/${r.id}`)}
            >
              <CardContent className="py-4 flex items-center justify-between gap-4">
                <div className="flex flex-col gap-1 min-w-0">
                  <p className="font-medium truncate">{r.vendorName ?? "Unnamed Vendor"}</p>
                  <p className="text-sm text-muted-foreground">
                    {formatDate(r.receiptDate)}
                    {r.receiptType ? ` · ${r.receiptType === "job_related" ? "Job Related" : "Overhead"}` : ""}
                    {r.jobName ? ` · ${r.jobName}` : ""}
                  </p>
                </div>
                <div className="flex items-center gap-4 shrink-0">
                  <span className="text-sm font-medium">{formatCurrency(r.total)}</span>
                  <Badge variant={STATUS_COLORS[r.status ?? "draft"] ?? "outline"}>
                    {r.status ?? "draft"}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
