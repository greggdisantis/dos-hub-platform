/**
 * DOS: Receipt Capture — Finance In Progress
 * Route: /dashboard/receipts/finance-in-progress
 * Finance roles only.
 */
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { ModulePageHeader } from "@/components/ModulePageHeader";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

function formatDate(val: any) {
  if (!val) return "—";
  try { return new Date(val).toLocaleDateString(); } catch { return String(val); }
}
function formatCurrency(val: any) {
  if (!val) return "—";
  const n = parseFloat(val);
  return isNaN(n) ? val : `$${n.toFixed(2)}`;
}

export function FinanceInProgress() {
  const [, setLocation] = useLocation();
  const { data: receipts, isLoading } = trpc.receipts.financeInProgress.useQuery();

  return (
    <div className="flex flex-col gap-6">
      <ModulePageHeader
        title="Finance In Progress"
        backTo="/dashboard/receipts"
        backLabel="Back to Receipt Capture"
      />

      <div className="flex items-center gap-2">
        <Badge>{receipts?.length ?? 0} in progress</Badge>
        <span className="text-sm text-muted-foreground">Receipts currently being entered</span>
      </div>

      {isLoading ? (
        <div className="flex flex-col gap-3">
          {[1, 2, 3].map((i) => <Skeleton key={i} className="h-20 w-full rounded-lg" />)}
        </div>
      ) : !receipts?.length ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            No receipts currently in progress.
          </CardContent>
        </Card>
      ) : (
        <div className="flex flex-col gap-2">
          {receipts.map((r) => (
            <Card
              key={r.id}
              className="cursor-pointer hover:shadow-sm transition-shadow"
              onClick={() => setLocation(`/dashboard/receipts/${r.id}`)}
            >
              <CardContent className="py-4 flex items-center justify-between gap-4">
                <div className="flex flex-col gap-1 min-w-0">
                  <p className="font-medium truncate">{r.vendorName ?? "Unnamed Vendor"}</p>
                  <p className="text-sm text-muted-foreground">
                    {formatDate(r.receiptDate)}
                    {r.receiptType ? ` · ${r.receiptType === "job_related" ? "Job Related" : "Overhead"}` : ""}
                    {r.jobName ? ` · ${r.jobName}` : ""}
                  </p>
                  {r.financeNote && (
                    <p className="text-xs text-muted-foreground italic">Note: {r.financeNote}</p>
                  )}
                </div>
                <div className="flex items-center gap-4 shrink-0">
                  <span className="text-sm font-medium">{formatCurrency(r.total)}</span>
                  <Badge>entered</Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
