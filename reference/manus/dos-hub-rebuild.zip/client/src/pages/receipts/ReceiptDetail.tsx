/**
 * DOS: Receipt Capture — Receipt Detail / Edit
 * Route: /dashboard/receipts/:id
 *
 * Shows full receipt details.
 * - Submitter: can edit drafts, view status
 * - Finance: can mark entered, complete, void, add finance notes
 */
import { useState } from "react";
import { useRoute, useLocation } from "wouter";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { ModulePageHeader } from "@/components/ModulePageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Spinner } from "@/components/ui/spinner";
import { FileDown, CheckCircle, XCircle, ArrowRight } from "lucide-react";

const FINANCE_ROLES = ["admin", "super-admin", "manager", "finance"];
function isFinance(role?: string) {
  return role ? FINANCE_ROLES.includes(role) : false;
}

const STATUS_COLORS: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
  draft: "outline",
  submitted: "secondary",
  entered: "default",
  complete: "default",
  voided: "destructive",
};

function formatDate(val: any) {
  if (!val) return "—";
  try { return new Date(val).toLocaleDateString(); } catch { return String(val); }
}
function formatCurrency(val: any) {
  if (!val) return "—";
  const n = parseFloat(val);
  return isNaN(n) ? val : `$${n.toFixed(2)}`;
}

export function ReceiptDetail() {
  const [, params] = useRoute("/dashboard/receipts/:id");
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const finance = isFinance(user?.role);
  const receiptId = parseInt(params?.id ?? "0");

  const { data: receipt, isLoading, refetch } = trpc.receipts.getById.useQuery(
    { id: receiptId },
    { enabled: !!receiptId }
  );

  const [financeNote, setFinanceNote] = useState("");
  const [voidReason, setVoidReason] = useState("");

  const utils = trpc.useUtils();

  const markEnteredMutation = trpc.receipts.markEntered.useMutation({
    onSuccess: () => { toast.success("Marked as entered"); refetch(); utils.receipts.financeList.invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const markCompleteMutation = trpc.receipts.markComplete.useMutation({
    onSuccess: () => { toast.success("Marked as complete"); refetch(); utils.receipts.financeInProgress.invalidate(); },
    onError: (e) => toast.error(e.message),
  });
  const voidMutation = trpc.receipts.void.useMutation({
    onSuccess: () => { toast.success("Receipt voided"); refetch(); },
    onError: (e) => toast.error(e.message),
  });
  const exportMutation = trpc.receipts.exportPdf.useMutation({
    onSuccess: (result: { base64: string }) => {
      const link = document.createElement("a");
      link.href = `data:application/pdf;base64,${result.base64}`;
      link.download = `receipt-${receiptId}.pdf`;
      link.click();
      toast.success("PDF downloaded");
    },
    onError: (e) => toast.error(e.message),
  });

  if (isLoading) {
    return (
      <div className="flex flex-col gap-6">
        <Skeleton className="h-16 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!receipt) {
    return (
      <div className="flex flex-col gap-6">
        <ModulePageHeader title="Receipt Not Found" backTo="/dashboard/receipts/mine" backLabel="Back to My Receipts" />
        <p className="text-muted-foreground">This receipt does not exist or you do not have access.</p>
      </div>
    );
  }

  const canEdit = receipt.status === "draft" && receipt.submittedByUserId === user?.id;
  const canMarkEntered = finance && receipt.status === "submitted";
  const canMarkComplete = finance && receipt.status === "entered";
  const canVoid = finance && ["submitted", "entered"].includes(receipt.status ?? "");

  // Determine back destination based on status and role
  const backTo = finance && receipt.status === "submitted"
    ? "/dashboard/receipts/finance-inbox"
    : finance && receipt.status === "entered"
    ? "/dashboard/receipts/finance-in-progress"
    : "/dashboard/receipts/mine";
  const backLabel = finance && receipt.status === "submitted"
    ? "Back to Finance Inbox"
    : finance && receipt.status === "entered"
    ? "Back to Finance In Progress"
    : "Back to My Receipts";

  return (
    <div className="flex flex-col gap-6">
      <ModulePageHeader title={`Receipt #${receipt.id}`} backTo={backTo} backLabel={backLabel}>
        {/* Finance actions */}
        {canMarkEntered && (
          <Button
            variant="outline"
            onClick={() => markEnteredMutation.mutate({ id: receiptId, financeNote: financeNote || undefined })}
            disabled={markEnteredMutation.isPending}
          >
            {markEnteredMutation.isPending ? <Spinner className="h-4 w-4 mr-2" /> : <ArrowRight className="h-4 w-4 mr-2" />}
            Mark Entered
          </Button>
        )}
        {canMarkComplete && (
          <Button
            onClick={() => markCompleteMutation.mutate({ id: receiptId })}
            disabled={markCompleteMutation.isPending}
          >
            {markCompleteMutation.isPending ? <Spinner className="h-4 w-4 mr-2" /> : <CheckCircle className="h-4 w-4 mr-2" />}
            Mark Complete
          </Button>
        )}
        {canVoid && (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" size="sm">
                <XCircle className="h-4 w-4 mr-2" /> Void
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Void this receipt?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. The receipt will be marked as voided.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <div className="flex flex-col gap-1.5 py-2">
                <Label>Reason (optional)</Label>
                <Textarea value={voidReason} onChange={(e) => setVoidReason(e.target.value)} rows={2} placeholder="Reason for voiding…" />
              </div>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => voidMutation.mutate({ id: receiptId, reason: voidReason || undefined })}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                >
                  Void Receipt
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
        <Button
          variant="outline"
          onClick={() => exportMutation.mutate({ id: receiptId })}
          disabled={exportMutation.isPending}
        >
          {exportMutation.isPending ? <Spinner className="h-4 w-4 mr-2" /> : <FileDown className="h-4 w-4 mr-2" />}
          Export PDF
        </Button>
      </ModulePageHeader>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Receipt image */}
        {receipt.imageUrl && (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Receipt Image</CardTitle>
            </CardHeader>
            <CardContent>
              <img
                src={receipt.imageUrl}
                alt="Receipt"
                className="w-full max-h-96 object-contain rounded-lg border"
              />
            </CardContent>
          </Card>
        )}

        {/* Details */}
        <div className="flex flex-col gap-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">Details</CardTitle>
                <Badge variant={STATUS_COLORS[receipt.status ?? "draft"] ?? "outline"}>
                  {receipt.status ?? "draft"}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="flex flex-col gap-3">
              <Row label="Vendor" value={receipt.vendorName ?? "—"} />
              <Row label="Date" value={formatDate(receipt.receiptDate)} />
              <Row label="Subtotal" value={formatCurrency(receipt.subtotal)} />
              <Row label="Tax" value={formatCurrency(receipt.tax)} />
              <Row label="Total" value={formatCurrency(receipt.total)} bold />
              <Separator />
              <Row label="Type" value={receipt.receiptType === "job_related" ? "Job Related" : receipt.receiptType === "overhead" ? "Overhead" : "—"} />
              {receipt.receiptType === "overhead" && receipt.overheadCategory && (
                <Row label="Category" value={receipt.overheadCategory} />
              )}
              {receipt.receiptType === "job_related" && receipt.jobName && (
                <Row label="Job" value={receipt.jobName} />
              )}
              {receipt.poNumber && <Row label="PO #" value={receipt.poNumber} />}
              {receipt.description && <Row label="Description" value={receipt.description} />}
              {receipt.notes && <Row label="Notes" value={receipt.notes} />}
              <Separator />
              <Row label="Submitted" value={formatDate(receipt.submittedAt)} />
              {receipt.financeNote && <Row label="Finance Note" value={receipt.financeNote} />}
              {receipt.voidReason && <Row label="Void Reason" value={receipt.voidReason} />}
            </CardContent>
          </Card>

          {/* Finance note input for "Mark Entered" action */}
          {canMarkEntered && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Finance Note (optional)</CardTitle>
              </CardHeader>
              <CardContent>
                <Textarea
                  value={financeNote}
                  onChange={(e) => setFinanceNote(e.target.value)}
                  placeholder="Add a note when marking as entered…"
                  rows={2}
                />
              </CardContent>
            </Card>
          )}

          {/* Line items */}
          {receipt.lineItems && receipt.lineItems.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Line Items</CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col gap-2">
                {receipt.lineItems.map((li: any, i: number) => (
                  <div key={i} className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{li.description}</span>
                    <span className="font-medium">{li.amount}</span>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className="flex justify-between text-sm">
      <span className="text-muted-foreground">{label}</span>
      <span className={bold ? "font-semibold" : ""}>{value}</span>
    </div>
  );
}
