/**
 * DOS: Receipt Capture — Finance Inbox
 * Route: /dashboard/receipts/finance-inbox
 * Finance roles only.
 */
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { ModulePageHeader } from "@/components/ModulePageHeader";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

function formatDate(val: any) {
  if (!val) return "—";
  try { return new Date(val).toLocaleDateString(); } catch { return String(val); }
}
function formatCurrency(val: any) {
  if (!val) return "—";
  const n = parseFloat(val);
  return isNaN(n) ? val : `$${n.toFixed(2)}`;
}

export function FinanceInbox() {
  const [, setLocation] = useLocation();
  const { data: receipts, isLoading } = trpc.receipts.financeList.useQuery();

  return (
    <div className="flex flex-col gap-6">
      <ModulePageHeader
        title="Finance Inbox"
        backTo="/dashboard/receipts"
        backLabel="Back to Receipt Capture"
      />

      <div className="flex items-center gap-2">
        <Badge variant="secondary">{receipts?.length ?? 0} pending</Badge>
        <span className="text-sm text-muted-foreground">Receipts submitted and awaiting entry</span>
      </div>

      {isLoading ? (
        <div className="flex flex-col gap-3">
          {[1, 2, 3].map((i) => <Skeleton key={i} className="h-20 w-full rounded-lg" />)}
        </div>
      ) : !receipts?.length ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            Finance inbox is empty. No receipts awaiting entry.
          </CardContent>
        </Card>
      ) : (
        <div className="flex flex-col gap-2">
          {receipts.map((r) => (
            <Card
              key={r.id}
              className="cursor-pointer hover:shadow-sm transition-shadow"
              onClick={() => setLocation(`/dashboard/receipts/${r.id}`)}
            >
              <CardContent className="py-4 flex items-center justify-between gap-4">
                <div className="flex flex-col gap-1 min-w-0">
                  <p className="font-medium truncate">{r.vendorName ?? "Unnamed Vendor"}</p>
                  <p className="text-sm text-muted-foreground">
                    {formatDate(r.receiptDate)}
                    {r.receiptType ? ` · ${r.receiptType === "job_related" ? "Job Related" : "Overhead"}` : ""}
                    {r.jobName ? ` · ${r.jobName}` : ""}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Submitted by user #{r.submittedByUserId}
                    {r.submittedAt ? ` on ${formatDate(r.submittedAt)}` : ""}
                  </p>
                </div>
                <div className="flex items-center gap-4 shrink-0">
                  <span className="text-sm font-medium">{formatCurrency(r.total)}</span>
                  <Badge variant="secondary">submitted</Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
