/**
 * DOS: Receipt Capture — Archive Search
 * Route: /dashboard/receipts/archive
 * Finance roles only.
 */
import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { ModulePageHeader } from "@/components/ModulePageHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Search } from "lucide-react";

const STATUS_COLORS: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
  complete: "default",
  voided: "destructive",
};

function formatDate(val: any) {
  if (!val) return "—";
  try { return new Date(val).toLocaleDateString(); } catch { return String(val); }
}
function formatCurrency(val: any) {
  if (!val) return "—";
  const n = parseFloat(val);
  return isNaN(n) ? val : `$${n.toFixed(2)}`;
}

export function ReceiptArchive() {
  const [, setLocation] = useLocation();
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const { data: receipts, isLoading } = trpc.receipts.archive.useQuery(
    {
      search: search || undefined,
      receiptType: typeFilter !== "all" ? typeFilter : undefined,
      dateFrom: dateFrom || undefined,
      dateTo: dateTo || undefined,
      limit: 100,
    },
    { enabled: submitted }
  );

  const handleSearch = () => setSubmitted(true);

  return (
    <div className="flex flex-col gap-6">
      <ModulePageHeader
        title="Archive"
        backTo="/dashboard/receipts"
        backLabel="Back to Receipt Capture"
      />

      {/* Search filters */}
      <Card>
        <CardContent className="pt-5 flex flex-col gap-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="flex flex-col gap-1.5">
              <Label>Search</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  className="pl-9"
                  placeholder="Vendor, description…"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                />
              </div>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>Type</Label>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="job_related">Job Related</SelectItem>
                  <SelectItem value="overhead">Overhead</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>Date From</Label>
              <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>Date To</Label>
              <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
            </div>
          </div>
          <Button onClick={handleSearch} className="self-start">
            <Search className="h-4 w-4 mr-2" /> Search Archive
          </Button>
        </CardContent>
      </Card>

      {/* Results */}
      {!submitted ? (
        <p className="text-sm text-muted-foreground">Enter search criteria above and click Search Archive.</p>
      ) : isLoading ? (
        <div className="flex flex-col gap-3">
          {[1, 2, 3].map((i) => <Skeleton key={i} className="h-20 w-full rounded-lg" />)}
        </div>
      ) : !receipts?.length ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            No archived receipts found matching your criteria.
          </CardContent>
        </Card>
      ) : (
        <div className="flex flex-col gap-2">
          <p className="text-sm text-muted-foreground">{receipts.length} result{receipts.length !== 1 ? "s" : ""}</p>
          {receipts.map((r) => (
            <Card
              key={r.id}
              className="cursor-pointer hover:shadow-sm transition-shadow"
              onClick={() => setLocation(`/dashboard/receipts/${r.id}`)}
            >
              <CardContent className="py-4 flex items-center justify-between gap-4">
                <div className="flex flex-col gap-1 min-w-0">
                  <p className="font-medium truncate">{r.vendorName ?? "Unnamed Vendor"}</p>
                  <p className="text-sm text-muted-foreground">
                    {formatDate(r.receiptDate)}
                    {r.receiptType ? ` · ${r.receiptType === "job_related" ? "Job Related" : "Overhead"}` : ""}
                    {r.jobName ? ` · ${r.jobName}` : ""}
                  </p>
                </div>
                <div className="flex items-center gap-4 shrink-0">
                  <span className="text-sm font-medium">{formatCurrency(r.total)}</span>
                  <Badge variant={STATUS_COLORS[r.status ?? "complete"] ?? "outline"}>
                    {r.status}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
