import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Loader2, CheckCircle, XCircle } from "lucide-react";
import { useLocation } from "wouter";
import { useState } from "react";
import { toast } from "sonner";

export default function AdminApproval() {
  const { user, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const [actionInProgress, setActionInProgress] = useState<number | null>(null);

  // Fetch pending users
  const { data: pendingUsers, isLoading, refetch } = trpc.admin.getPendingUsers.useQuery(undefined, {
    enabled: user?.role === "super-admin",
    retry: false,
  });

  // Mutations
  const approveMutation = trpc.admin.approveUser.useMutation();
  const rejectMutation = trpc.admin.rejectUser.useMutation();

  // Check authorization
  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Not authenticated</p>
          <Button onClick={() => setLocation("/login")}>Sign in</Button>
        </div>
      </div>
    );
  }

  if (user.role !== "super-admin") {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <p className="text-red-600 font-semibold mb-4">Access Denied</p>
          <p className="text-muted-foreground mb-4">Only super-admins can access this page.</p>
          <Button onClick={() => setLocation("/")} variant="outline">
            Go Home
          </Button>
        </div>
      </div>
    );
  }

  const handleApprove = async (userId: number) => {
    setActionInProgress(userId);
    try {
      await approveMutation.mutateAsync({ userId });
      toast.success("User approved");
      refetch();
    } catch (error) {
      toast.error("Failed to approve user");
      console.error(error);
    } finally {
      setActionInProgress(null);
    }
  };

  const handleReject = async (userId: number) => {
    setActionInProgress(userId);
    try {
      await rejectMutation.mutateAsync({ userId });
      toast.success("User rejected");
      refetch();
    } catch (error) {
      toast.error("Failed to reject user");
      console.error(error);
    } finally {
      setActionInProgress(null);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <h1 className="text-2xl font-bold tracking-tight">Admin Approval</h1>
          <Button
            variant="outline"
            onClick={() => setLocation("/")}
          >
            Back to Home
          </Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="space-y-6">
          <div className="bg-card border border-border rounded-lg p-6">
            <h2 className="text-lg font-semibold mb-2">Pending User Approvals</h2>
            <p className="text-sm text-muted-foreground">
              Review and approve new user signups. Only approved users can access the system.
            </p>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
            </div>
          ) : !pendingUsers || pendingUsers.length === 0 ? (
            <Card className="p-8 text-center">
              <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <p className="text-muted-foreground">No pending users to approve</p>
            </Card>
          ) : (
            <div className="space-y-4">
              {pendingUsers.map((user) => (
                <Card key={user.id} className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg font-semibold">{user.firstName} {user.lastName}</h3>
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                          Pending
                        </span>
                      </div>
                      <dl className="space-y-1 text-sm">
                        <div>
                          <dt className="text-muted-foreground">Email</dt>
                          <dd className="font-medium">{user.email}</dd>
                        </div>
                        <div>
                          <dt className="text-muted-foreground">Requested Role</dt>
                          <dd className="font-medium capitalize">{user.role}</dd>
                        </div>
                        <div>
                          <dt className="text-muted-foreground">Signup Date</dt>
                          <dd className="font-medium">
                            {new Date(user.createdAt).toLocaleDateString()}
                          </dd>
                        </div>
                      </dl>
                    </div>

                    <div className="flex gap-3 ml-4">
                      <Button
                        onClick={() => handleApprove(user.id)}
                        disabled={actionInProgress === user.id}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        {actionInProgress === user.id ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <>
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Approve
                          </>
                        )}
                      </Button>
                      <Button
                        onClick={() => handleReject(user.id)}
                        disabled={actionInProgress === user.id}
                        variant="destructive"
                      >
                        {actionInProgress === user.id ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <>
                            <XCircle className="w-4 h-4 mr-2" />
                            Reject
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
