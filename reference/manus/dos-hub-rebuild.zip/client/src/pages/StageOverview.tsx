import { useAuth } from "@/_core/hooks/useAuth";
import { Breadcrumb } from "@/components/Breadcrumb";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Plus } from "lucide-react";
import { useLocation } from "wouter";

interface StageOverviewProps {
  stage: "sales" | "engineering" | "production" | "install" | "service" | "admin";
  title: string;
  description: string;
}

export function StageOverview({ stage, title, description }: StageOverviewProps) {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  // Mock data - will be replaced with actual API calls
  const mockProjects = [
    {
      id: 1,
      name: "Acme Corp - Office Screens",
      clientName: "Acme Corporation",
      status: "in-progress",
      lastUpdated: "2 hours ago",
    },
    {
      id: 2,
      name: "Tech Startup - Partition System",
      clientName: "Tech Startup Inc",
      status: "pending",
      lastUpdated: "1 day ago",
    },
    {
      id: 3,
      name: "Enterprise Solutions - Full Build",
      clientName: "Enterprise Solutions",
      status: "completed",
      lastUpdated: "3 days ago",
    },
  ];

  const stageStats = {
    sales: { active: 8, pending: 3, total: 15 },
    engineering: { active: 5, pending: 2, total: 12 },
    production: { active: 4, pending: 1, total: 10 },
    install: { active: 3, pending: 0, total: 8 },
    service: { active: 2, pending: 1, total: 6 },
    admin: { users: 12, pending: 2, roles: 6 },
  };

  const stats = stageStats[stage as keyof typeof stageStats];

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <Breadcrumb items={[{ label: title }]} />

        {/* Header */}
        <div className="flex justify-between items-start mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">{title}</h1>
            <p className="text-muted-foreground">{description}</p>
          </div>
          {stage !== "admin" && (
            <Button onClick={() => setLocation(`/project/new?stage=${stage}`)}>
              <Plus className="w-4 h-4 mr-2" />
              New Project
            </Button>
          )}
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          {Object.entries(stats).map(([key, value]) => (
            <Card key={key} className="p-4">
              <div className="text-sm text-muted-foreground capitalize">{key}</div>
              <div className="text-2xl font-bold">{value}</div>
            </Card>
          ))}
        </div>

        {/* Search and Filter */}
        <div className="flex gap-4 mb-6">
          <Input
            placeholder="Search projects..."
            className="flex-1"
          />
        </div>

        {/* Project List */}
        <div className="space-y-3">
          {mockProjects.map((project) => (
            <Card
              key={project.id}
              className="p-4 cursor-pointer hover:bg-accent transition-colors"
              onClick={() => setLocation(`/project/${project.id}`)}
            >
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-semibold">{project.name}</h3>
                  <p className="text-sm text-muted-foreground">{project.clientName}</p>
                </div>
                <div className="text-right">
                  <div className={`text-sm font-medium ${
                    project.status === "completed" ? "text-green-600" :
                    project.status === "in-progress" ? "text-blue-600" :
                    "text-yellow-600"
                  }`}>
                    {project.status}
                  </div>
                  <p className="text-xs text-muted-foreground">{project.lastUpdated}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
