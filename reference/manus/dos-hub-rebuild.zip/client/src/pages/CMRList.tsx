import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Loader2, Plus, Eye, Edit2, Trash2, Pencil, MessageSquarePlus,
  DollarSign, TrendingUp, BarChart2, Download, Printer, ChevronDown, FileDown
} from "lucide-react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { useState, useMemo } from "react";
import { toast } from "sonner";
import { ModuleViewToggle } from "@/components/ModuleViewToggle";
import { ModulePageHeader } from "@/components/ModulePageHeader";
import CMRAnalytics from "./CMRAnalytics";

// ─── Helpers ────────────────────────────────────────────────────────────────

function formatDate(dateValue: any): string {
  if (!dateValue) return "—";
  if (typeof dateValue === "string" && dateValue.match(/^\d{4}-\d{2}-\d{2}$/)) {
    const [year, month, day] = dateValue.split("-").map(Number);
    return new Date(year, month - 1, day).toLocaleDateString();
  }
  return new Date(dateValue).toLocaleDateString();
}

function formatCurrency(value: any): string {
  if (!value && value !== 0) return "—";
  const num = typeof value === "string" ? parseFloat(value) : value;
  if (isNaN(num)) return "—";
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(num);
}

function getStatusBadge(status: string) {
  if (status === "approved") return "bg-green-100 text-green-800";
  if (status === "submitted") return "bg-blue-100 text-blue-800";
  return "bg-gray-100 text-gray-800";
}

function getLatestNote(updateNotes: any): { note: string; createdAt: string; createdBy: string } | null {
  if (!updateNotes) return null;
  try {
    const notes = typeof updateNotes === "string" ? JSON.parse(updateNotes) : updateNotes;
    if (Array.isArray(notes) && notes.length > 0) return notes[0];
  } catch { /* empty */ }
  return null;
}

// ─── Inline Quick Edit Popover ───────────────────────────────────────────────

function QuickEditPopover({ report, onSaved }: { report: any; onSaved: () => void }) {
  const [open, setOpen] = useState(false);
  const [estValue, setEstValue] = useState(report.estimatedValue ? String(parseFloat(report.estimatedValue)) : "");
  const [confidence, setConfidence] = useState(report.currentConfidencePct !== null && report.currentConfidencePct !== undefined ? String(report.currentConfidencePct) : "");

  const quickEditMutation = trpc.cmr.quickEdit.useMutation({
    onSuccess: () => {
      toast.success("Updated successfully");
      setOpen(false);
      onSaved();
    },
    onError: () => toast.error("Failed to save changes"),
  });

  const handleSave = () => {
    const updates: { reportId: number; estimatedValue?: number; currentConfidencePct?: number } = { reportId: report.id };
    if (estValue !== "") updates.estimatedValue = parseFloat(estValue);
    if (confidence !== "") updates.currentConfidencePct = parseInt(confidence, 10);
    quickEditMutation.mutate(updates);
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" title="Quick Edit" aria-label="Quick Edit">
          <Pencil className="w-4 h-4" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-72 p-4 space-y-3" align="end">
        <p className="font-semibold text-sm">Quick Edit — {report.clientName}</p>
        <div className="space-y-1">
          <label className="text-xs text-muted-foreground">Estimated Value ($)</label>
          <Input
            type="number"
            placeholder="e.g. 12500"
            value={estValue}
            onChange={(e) => setEstValue(e.target.value)}
          />
        </div>
        <div className="space-y-1">
          <label className="text-xs text-muted-foreground">Current Confidence % (0–100)</label>
          <Input
            type="number"
            min={0}
            max={100}
            placeholder="e.g. 75"
            value={confidence}
            onChange={(e) => setConfidence(e.target.value)}
          />
          <p className="text-xs text-muted-foreground">
            Original PC %: <strong>{report.originalPcPct ?? "—"}%</strong> (locked)
          </p>
        </div>
        <div className="flex gap-2 pt-1">
          <Button size="sm" className="flex-1" onClick={handleSave} disabled={quickEditMutation.isPending}>
            {quickEditMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Save"}
          </Button>
          <Button size="sm" variant="outline" className="flex-1" onClick={() => setOpen(false)}>
            Cancel
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}

// ─── Add Note Popover ────────────────────────────────────────────────────────

function AddNotePopover({ report, onSaved }: { report: any; onSaved: () => void }) {
  const [open, setOpen] = useState(false);
  const [noteText, setNoteText] = useState("");

  const addNoteMutation = trpc.cmr.addUpdateNote.useMutation({
    onSuccess: () => {
      toast.success("Note added");
      setNoteText("");
      setOpen(false);
      onSaved();
    },
    onError: () => toast.error("Failed to add note"),
  });

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" title="Add Update" aria-label="Add Update">
          <MessageSquarePlus className="w-4 h-4" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-4 space-y-3" align="end">
        <p className="font-semibold text-sm">Add Update Note — {report.clientName}</p>
        <Textarea
          placeholder="Enter update note..."
          value={noteText}
          onChange={(e) => setNoteText(e.target.value)}
          rows={3}
        />
        <div className="flex gap-2">
          <Button size="sm" className="flex-1" onClick={() => addNoteMutation.mutate({ reportId: report.id, note: noteText })} disabled={!noteText.trim() || addNoteMutation.isPending}>
            {addNoteMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Add Note"}
          </Button>
          <Button size="sm" variant="outline" className="flex-1" onClick={() => setOpen(false)}>
            Cancel
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}

// ─── Export Helpers ──────────────────────────────────────────────────────────

function exportToCSV(reports: any[], userMap: Record<number, string>) {
  const headers = [
    "ID", "Client Name", "Consultant", "Appointment Date", "Appointment Type",
    "Deal Status", "Status", "PC %", "Original PC %", "Current PC %",
    "Estimated Value", "Closed Amount", "Outcome", "Appointment Result",
    "Lead Sources", "Project Types", "Close Timeline", "Created At"
  ];

  const rows = reports.map((r: any) => [
    r.id,
    r.clientName || "",
    r.consultantName || userMap[r.userId] || "",
    formatDate(r.appointmentDate),
    r.appointmentType || "",
    r.dealStatus || "",
    r.status || "",
    r.purchaseConfidencePct ?? "",
    r.originalPcPct ?? "",
    r.currentConfidencePct ?? "",
    r.estimatedValue ? parseFloat(r.estimatedValue) : "",
    r.closedAmount ? parseFloat(r.closedAmount) : "",
    r.outcome || "",
    r.appointmentResult || "",
    Array.isArray(r.leadSources) ? r.leadSources.join("; ") : (r.leadSources || ""),
    Array.isArray(r.projectTypes) ? r.projectTypes.join("; ") : (r.projectTypes || ""),
    r.closeTimeline || "",
    r.createdAt ? new Date(r.createdAt).toLocaleDateString() : "",
  ]);

  const csvContent = [headers, ...rows]
    .map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(","))
    .join("\n");

  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `CMR_Export_${new Date().toISOString().slice(0, 10)}.csv`;
  link.click();
  URL.revokeObjectURL(url);
  toast.success("CSV exported successfully");
}

function handlePrint() {
  window.print();
}

// ─── Main Component ──────────────────────────────────────────────────────────

export default function CMRList() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<"list" | "analytics">("list");
  const [view, setView] = useState<"my" | "all">("my");
  const [statusFilter, setStatusFilter] = useState<"draft" | "submitted" | "approved" | undefined>(undefined);
  const [userFilter, setUserFilter] = useState<number | undefined>(undefined);
  const [projectFilter, setProjectFilter] = useState<number | undefined>(undefined);

  const canSeeAll = user && ["super-admin", "admin", "manager"].includes(user.role);

  const { data: allUsers = [] } = trpc.user.list.useQuery();
  const { data: allProjects = [] } = trpc.project.list.useQuery();

  const { data: reports, isLoading, refetch } = trpc.cmr.listAll.useQuery({
    status: statusFilter,
    userId: view === "my" ? user?.id : userFilter,
    projectId: projectFilter,
  });

  const deleteMutation = trpc.cmr.delete.useMutation();

  const userMap = useMemo(() => {
    const map: Record<number, string> = {};
    allUsers.forEach((u: any) => {
      map[u.id] = `${u.firstName} ${u.lastName}`.trim() || u.email;
    });
    return map;
  }, [allUsers]);

  const projectMap = useMemo(() => {
    const map: Record<number, string> = {};
    allProjects.forEach((p: any) => {
      const label = p.clientName || p.address || p.projectStage || `Project #${p.id}`;
      map[p.id] = label;
    });
    return map;
  }, [allProjects]);

  const exportPdfMutation = trpc.cmrExport.exportPdf.useMutation({
    onSuccess: (data) => {
      // Decode base64 and trigger browser download
      const bytes = Uint8Array.from(atob(data.pdfBase64), (c) => c.charCodeAt(0));
      const blob = new Blob([bytes], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = data.filename;
      link.click();
      URL.revokeObjectURL(url);
      toast.success("PDF exported successfully");
    },
    onError: () => toast.error("Failed to export PDF"),
  });

  const handleExportPdf = (reportId: number) => {
    exportPdfMutation.mutate({ reportId });
  };

  const handlePrintReport = (reportId: number) => {
    // Use the same Puppeteer PDF export path — no browser print dialog
    exportPdfMutation.mutate({ reportId });
  };

  const handleDelete = async (reportId: number) => {
    if (!confirm("Are you sure you want to delete this CMR?")) return;
    try {
      await deleteMutation.mutateAsync({ reportId });
      toast.success("CMR deleted successfully");
      refetch();
    } catch {
      toast.error("Failed to delete CMR");
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <ModulePageHeader title="Client Meeting Reports">
        {activeTab === "list" && (
          <>
            <Button variant="outline" size="sm" onClick={handlePrint} className="gap-1">
              <Printer className="w-4 h-4" />
              Print
            </Button>
            <Button variant="outline" size="sm" onClick={() => exportToCSV(reports || [], userMap)} className="gap-1">
              <Download className="w-4 h-4" />
              Export CSV
            </Button>
          </>
        )}
        <Button onClick={() => setLocation("/dashboard/cmr/create")} size="default" className="gap-2 font-semibold shadow-sm px-5">
          <Plus className="w-4 h-4" />
          New Report
        </Button>
      </ModulePageHeader>

      {/* Tabs */}
      <div className="flex border-b">
        <button
          className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${activeTab === "list" ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}
          onClick={() => setActiveTab("list")}
        >
          Reports List
        </button>
        <button
          className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors flex items-center gap-1 ${activeTab === "analytics" ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}
          onClick={() => setActiveTab("analytics")}
        >
          <BarChart2 className="w-4 h-4" />
          Analytics
        </button>
      </div>

      {/* Analytics Tab */}
      {activeTab === "analytics" && (
        <CMRAnalytics reports={reports || []} allUsers={allUsers} isLoading={isLoading} />
      )}

      {/* List Tab */}
      {activeTab === "list" && (
        <>
          {/* View Toggle and Filters */}
          <div className="space-y-4">
            <ModuleViewToggle onViewChange={setView} canSeeAll={canSeeAll || false} />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Select value={statusFilter || "all-statuses"} onValueChange={(val) => setStatusFilter(val === "all-statuses" ? undefined : (val as any))}>
                <SelectTrigger><SelectValue placeholder="Filter by status" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-statuses">All Statuses</SelectItem>
                  <SelectItem value="draft">Draft</SelectItem>
                  <SelectItem value="submitted">Submitted</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                </SelectContent>
              </Select>

              {view === "all" && (
                <Select value={userFilter?.toString() || "all-users"} onValueChange={(val) => setUserFilter(val === "all-users" ? undefined : parseInt(val))}>
                  <SelectTrigger><SelectValue placeholder="Filter by user" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all-users">All Users</SelectItem>
                    {allUsers.map((u: any) => (
                      <SelectItem key={u.id} value={u.id.toString()}>
                        {`${u.firstName} ${u.lastName}`.trim() || u.email}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}

              <Select value={projectFilter?.toString() || "all-projects"} onValueChange={(val) => setProjectFilter(val === "all-projects" ? undefined : parseInt(val))}>
                <SelectTrigger><SelectValue placeholder="Filter by project" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-projects">All Projects</SelectItem>
                  {allProjects.map((p: any) => {
                    const label = p.clientName || p.address || p.projectStage || `Project #${p.id}`;
                    return <SelectItem key={p.id} value={p.id.toString()}>{label}</SelectItem>;
                  })}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* CMR Cards */}
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
            </div>
          ) : !reports || reports.length === 0 ? (
            <Card className="p-8 text-center text-muted-foreground">
              No CMRs found. {view === "my" ? "Create one to get started!" : ""}
            </Card>
          ) : (
            <div className="space-y-2 print:space-y-4">
              {reports.map((report: any) => {
                const latestNote = getLatestNote(report.updateNotes);
                const displayConfidence = report.currentConfidencePct ?? report.purchaseConfidencePct;

                return (
                  <Card key={report.id} className="p-4 hover:shadow-md transition-shadow print:shadow-none print:border">
                    <div className="flex items-start justify-between gap-4">
                      {/* Main info */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3 flex-wrap">
                          <h3 className="font-semibold text-base">{report.clientName}</h3>
                          <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${getStatusBadge(report.status)}`}>
                            {report.status}
                          </span>
                          {report.dealStatus && (
                            <span className="text-xs px-2 py-0.5 rounded-full bg-purple-100 text-purple-800">
                              {report.dealStatus}
                            </span>
                          )}
                        </div>

                        {/* Consultant + Project */}
                        <div className="text-sm text-muted-foreground mt-1">
                          <span>{report.consultantName || userMap[report.userId] || `User #${report.userId}`}</span>
                          {report.projectId && projectMap[report.projectId] && (
                            <span> • {projectMap[report.projectId]}</span>
                          )}
                        </div>

                        {/* Key fields row */}
                        <div className="text-sm text-muted-foreground mt-2 flex flex-wrap gap-4">
                          {report.appointmentDate && (
                            <span>📅 {formatDate(report.appointmentDate)}</span>
                          )}
                          {report.appointmentType && (
                            <span>🏠 {report.appointmentType}</span>
                          )}
                          {displayConfidence !== null && displayConfidence !== undefined && (
                            <span className="flex items-center gap-1">
                              <TrendingUp className="w-3 h-3" />
                              PC: {displayConfidence}%
                              {report.originalPcPct !== null && report.originalPcPct !== undefined && report.originalPcPct !== displayConfidence && (
                                <span className="text-xs text-muted-foreground">(orig: {report.originalPcPct}%)</span>
                              )}
                            </span>
                          )}
                          {report.estimatedValue && (
                            <span className="flex items-center gap-1 font-medium text-emerald-700">
                              <DollarSign className="w-3 h-3" />
                              {formatCurrency(report.estimatedValue)}
                            </span>
                          )}
                          {report.nextFollowUpDate && (
                            <span>Follow-up: {formatDate(report.nextFollowUpDate)}</span>
                          )}
                        </div>

                        {/* Latest update note preview */}
                        {latestNote && (
                          <div className="mt-2 text-xs bg-amber-50 border border-amber-200 rounded px-2 py-1 text-amber-800 max-w-lg">
                            <span className="font-medium">Latest note</span> ({new Date(latestNote.createdAt).toLocaleDateString()}):&nbsp;
                            <span className="italic">{latestNote.note.length > 100 ? latestNote.note.slice(0, 100) + "…" : latestNote.note}</span>
                          </div>
                        )}
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-1 print:hidden">
                        <Button variant="ghost" size="sm" onClick={() => setLocation(`/dashboard/cmr/${report.id}`)} title="View Report" aria-label="View Report">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => setLocation(`/dashboard/cmr/${report.id}/edit`)} title="Edit Report" aria-label="Edit Report">
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <QuickEditPopover report={report} onSaved={refetch} />
                        <AddNotePopover report={report} onSaved={refetch} />
                        <Button variant="ghost" size="sm" onClick={() => handlePrintReport(report.id)} title="Print Report" aria-label="Print Report">
                          <Printer className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleExportPdf(report.id)}
                          title="Export PDF"
                          aria-label="Export PDF"
                          disabled={exportPdfMutation.isPending && exportPdfMutation.variables?.reportId === report.id}
                        >
                          {exportPdfMutation.isPending && exportPdfMutation.variables?.reportId === report.id
                            ? <Loader2 className="w-4 h-4 animate-spin" />
                            : <FileDown className="w-4 h-4" />}
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => handleDelete(report.id)} title="Delete Report" aria-label="Delete Report">
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </>
      )}
    </div>
  );
}
