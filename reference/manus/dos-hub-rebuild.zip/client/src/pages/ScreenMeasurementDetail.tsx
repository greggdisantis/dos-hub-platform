import { useState, useCallback, useRef } from "react";
import { useLocation, useParams } from "wouter";
import DashboardLayout from "@/components/DashboardLayout";
import { FractionInput, formatInchesFrac } from "@/components/FractionInput";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import {
  ArrowLeft,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  Camera,
  AlertTriangle,
  AlertCircle,
  Info,
  ChevronDown,
  ChevronUp,
  FileText,
  Loader2,
} from "lucide-react";
import { cn } from "@/lib/utils";

// ─── Types ────────────────────────────────────────────────────────────────────

interface CalcFlag {
  code: string;
  severity: "info" | "warning" | "error";
  message: string;
}

interface Line {
  id: number;
  headerId: number;
  screenLabel: string | null;
  sortOrder: number | null;
  ul: string | null;
  ll: string | null;
  ol: string | null;
  ur: string | null;
  lr: string | null;
  orMeasurement: string | null;
  t: string | null;
  m: string | null;
  b: string | null;
  reverseMeasurements: number;
  motorSide: string | null;
  remoteType: string | null;
  numberOfCuts: number | null;
  powerConnectionType: string | null;
  powerConnectionOtherText: string | null;
  upperSlope: string | null;
  slopeDirection: string | null;
  leftHeight: string | null;
  rightHeight: string | null;
  tbDiff: string | null;
  uChannelNeeded: number;
  uChannelReason: string | null;
  buildOutRequired: number;
  buildOutType: string | null;
  trackToTrack: string | null;
  extendedHood: number;
  extendedHoodValue?: string | null;
  bias: string | null;
  orderableWidth: string | null;
  orderableHeight: string | null;
  leftSideMismatch: number;
  rightSideMismatch: number;
  calculationFlagsJson: CalcFlag[] | null;
  notes: string | null;
  attachments?: { id: number; fileId: string; caption: string | null; photoType: string | null; url?: string }[];
}

interface MeasForm {
  ul: number | null;
  ll: number | null;
  ol: number | null;
  ur: number | null;
  lr: number | null;
  orMeasurement: number | null;
  t: number | null;
  m: number | null;
  b: number | null;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function toNum(v: string | null | undefined): number | null {
  if (v == null || v === "") return null;
  const n = parseFloat(v);
  return isNaN(n) ? null : n;
}

function fmtFrac(v: string | null | undefined): string {
  return formatInchesFrac(toNum(v));
}

const MOTOR_SIDE_OPTIONS = [
  { value: "left", label: "Left" },
  { value: "right", label: "Right" },
];

const POWER_CONNECTION_OPTIONS = [
  { value: "plugged", label: "Plugged" },
  { value: "hardwired", label: "Hardwired" },
  { value: "other", label: "Other" },
];

// ─── CalcFlagBadge ────────────────────────────────────────────────────────────

function CalcFlagBadge({ flag }: { flag: CalcFlag }) {
  const Icon =
    flag.severity === "error" ? AlertCircle : flag.severity === "warning" ? AlertTriangle : Info;
  const cls =
    flag.severity === "error"
      ? "bg-red-50 border-red-200 text-red-700"
      : flag.severity === "warning"
      ? "bg-yellow-50 border-yellow-200 text-yellow-700"
      : "bg-blue-50 border-blue-200 text-blue-700";
  return (
    <div className={cn("flex items-start gap-2 px-3 py-2 rounded-md border text-xs", cls)}>
      <Icon className="w-3.5 h-3.5 mt-0.5 shrink-0" />
      <div>
        <span className="font-mono font-bold mr-1">[{flag.code}]</span>
        {flag.message}
      </div>
    </div>
  );
}

// ─── CalcResultsSection ───────────────────────────────────────────────────────

function CalcResultsSection({ line }: { line: Line }) {
  const flags = line.calculationFlagsJson ?? [];
  const hasCalc = line.orderableWidth != null || line.orderableHeight != null;

  if (!hasCalc && flags.length === 0) {
    return (
      <div className="text-xs text-muted-foreground italic px-1">
        No calculation results yet. Save measurements to calculate.
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {flags.length > 0 && (
        <div className="space-y-1.5">
          {flags.map((f, i) => (
            <CalcFlagBadge key={i} flag={f} />
          ))}
        </div>
      )}
      {hasCalc && (
        <div className="space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-primary/5 border border-primary/20 rounded-md p-3 text-center">
              <div className="text-xs text-muted-foreground mb-1">Orderable Width</div>
              <div className="text-lg font-bold font-mono">{fmtFrac(line.orderableWidth)}</div>
            </div>
            <div className="bg-primary/5 border border-primary/20 rounded-md p-3 text-center">
              <div className="text-xs text-muted-foreground mb-1">Orderable Height</div>
              <div className="text-lg font-bold font-mono">{fmtFrac(line.orderableHeight)}</div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-x-4 gap-y-1">
            {[
              { label: "Upper Slope (S)", value: fmtFrac(line.upperSlope) },
              { label: "Slope Direction", value: line.slopeDirection ?? "—" },
              { label: "Left Height", value: fmtFrac(line.leftHeight) },
              { label: "Right Height", value: fmtFrac(line.rightHeight) },
              { label: "Track to Track", value: fmtFrac(line.trackToTrack) },
              { label: "T–B Diff", value: fmtFrac(line.tbDiff) },
              { label: "Bias", value: fmtFrac(line.bias) },
              { label: "U-Channel", value: line.uChannelNeeded ? "Yes" : "No" },
              { label: "Build-Out", value: line.buildOutRequired ? (line.buildOutType ?? "Yes") : "No" },
              { label: "Extended Hood", value: line.extendedHood ? fmtFrac(line.extendedHoodValue) : "No" },
            ].map(({ label, value }) => (
              <div key={label} className="flex justify-between items-center py-0.5 border-b border-dashed border-border last:border-0 text-xs">
                <span className="text-muted-foreground">{label}</span>
                <span className="font-mono font-medium">{value}</span>
              </div>
            ))}
          </div>
          {(line.leftSideMismatch || line.rightSideMismatch) && (
            <div className="space-y-1">
              {!!line.leftSideMismatch && (
                <div className="flex items-center gap-1.5 text-xs text-yellow-700 bg-yellow-50 border border-yellow-200 rounded px-2 py-1">
                  <AlertTriangle className="w-3 h-3" />
                  Left side mismatch: UL + LL ≠ OL
                </div>
              )}
              {!!line.rightSideMismatch && (
                <div className="flex items-center gap-1.5 text-xs text-yellow-700 bg-yellow-50 border border-yellow-200 rounded px-2 py-1">
                  <AlertTriangle className="w-3 h-3" />
                  Right side mismatch: UR + LR ≠ OR
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── PhotoSection ─────────────────────────────────────────────────────────────

function PhotoSection({ line, canEdit }: { line: Line; canEdit: boolean }) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const utils = trpc.useUtils();

  const { data: photos, isLoading: photosLoading } = trpc.screens.getLineAttachmentUrls.useQuery(
    { lineId: line.id },
    { enabled: line.id > 0 }
  );

  const uploadMutation = trpc.screens.uploadLinePhoto.useMutation({
    onError: (err) => toast.error("Upload failed: " + err.message),
  });

  const addAttachmentMutation = trpc.screens.addLineAttachment.useMutation({
    onSuccess: () => {
      utils.screens.getLineAttachmentUrls.invalidate({ lineId: line.id });
      toast.success("Photo added");
    },
    onError: (err) => toast.error("Failed to save attachment: " + err.message),
  });

  const removeMutation = trpc.screens.removeLineAttachment.useMutation({
    onSuccess: () => {
      utils.screens.getLineAttachmentUrls.invalidate({ lineId: line.id });
      toast.success("Photo removed");
    },
    onError: (err) => toast.error("Failed to remove: " + err.message),
  });

  const handleFileChange = useCallback(
    async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      if (file.size > 16 * 1024 * 1024) {
        toast.error("File too large (max 16 MB)");
        return;
      }
      const reader = new FileReader();
      reader.onload = async () => {
        const base64 = (reader.result as string).split(",")[1];
        const result = await uploadMutation.mutateAsync({
          lineId: line.id,
          filename: file.name,
          contentType: file.type,
          base64Data: base64,
        });
        await addAttachmentMutation.mutateAsync({
          lineId: line.id,
          fileId: result.key,
          caption: null,
          photoType: "measurement",
          sortOrder: (photos?.length ?? 0) + 1,
        });
      };
      reader.readAsDataURL(file);
      e.target.value = "";
    },
    [line.id, uploadMutation, addAttachmentMutation, photos]
  );

  const isUploading = uploadMutation.isPending || addAttachmentMutation.isPending;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-semibold">Measurement Photos</h4>
        {canEdit && (
          <>
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={isUploading}
              onClick={() => fileInputRef.current?.click()}
            >
              {isUploading ? (
                <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
              ) : (
                <Camera className="w-3.5 h-3.5 mr-1.5" />
              )}
              Add Photo
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileChange}
            />
          </>
        )}
      </div>
      {photosLoading ? (
        <div className="text-xs text-muted-foreground">Loading photos...</div>
      ) : !photos || photos.length === 0 ? (
        <div className="text-xs text-muted-foreground italic">No photos attached.</div>
      ) : (
        <div className="grid grid-cols-3 gap-2">
          {photos.map((photo) => (
            <div key={photo.id} className="relative group rounded-md overflow-hidden border bg-muted aspect-square">
              <img
                src={photo.url}
                alt={photo.caption ?? "Measurement photo"}
                className="w-full h-full object-cover"
              />
              {canEdit && (
                <button
                  type="button"
                  onClick={() => removeMutation.mutate({ id: photo.id })}
                  className="absolute top-1 right-1 bg-black/60 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── LineCard ─────────────────────────────────────────────────────────────────

interface LineCardProps {
  line: Line;
  index: number;
  canEdit: boolean;
  remoteTypeOptions: { code: string; name: string }[];
  onSave: (lineId: number | undefined, data: Partial<Line> & { meas: MeasForm }) => Promise<void>;
  onDelete: (lineId: number) => void;
}

function LineCard({ line, index, canEdit, remoteTypeOptions, onSave, onDelete }: LineCardProps) {
  const [expanded, setExpanded] = useState(true);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);

  const [screenLabel, setScreenLabel] = useState(line.screenLabel ?? "");
  const [motorSide, setMotorSide] = useState(line.motorSide ?? "");
  const [remoteType, setRemoteType] = useState(line.remoteType ?? "");
  const [reverseMeasurements, setReverseMeasurements] = useState(!!line.reverseMeasurements);
  const [numberOfCuts, setNumberOfCuts] = useState(
    line.numberOfCuts != null ? String(line.numberOfCuts) : ""
  );
  const [powerConnectionType, setPowerConnectionType] = useState(line.powerConnectionType ?? "");
  const [powerConnectionOtherText, setPowerConnectionOtherText] = useState(
    line.powerConnectionOtherText ?? ""
  );
  const [notes, setNotes] = useState(line.notes ?? "");
  const [meas, setMeas] = useState<MeasForm>({
    ul: toNum(line.ul),
    ll: toNum(line.ll),
    ol: toNum(line.ol),
    ur: toNum(line.ur),
    lr: toNum(line.lr),
    orMeasurement: toNum(line.orMeasurement),
    t: toNum(line.t),
    m: toNum(line.m),
    b: toNum(line.b),
  });

  const handleEdit = () => {
    setScreenLabel(line.screenLabel ?? "");
    setMotorSide(line.motorSide ?? "");
    setRemoteType(line.remoteType ?? "");
    setReverseMeasurements(!!line.reverseMeasurements);
    setNumberOfCuts(line.numberOfCuts != null ? String(line.numberOfCuts) : "");
    setPowerConnectionType(line.powerConnectionType ?? "");
    setPowerConnectionOtherText(line.powerConnectionOtherText ?? "");
    setNotes(line.notes ?? "");
    setMeas({
      ul: toNum(line.ul),
      ll: toNum(line.ll),
      ol: toNum(line.ol),
      ur: toNum(line.ur),
      lr: toNum(line.lr),
      orMeasurement: toNum(line.orMeasurement),
      t: toNum(line.t),
      m: toNum(line.m),
      b: toNum(line.b),
    });
    setEditing(true);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await onSave(line.id, {
        screenLabel: screenLabel || null,
        motorSide: motorSide || null,
        remoteType: remoteType || null,
        reverseMeasurements: reverseMeasurements ? 1 : 0,
        numberOfCuts: numberOfCuts ? parseInt(numberOfCuts, 10) : null,
        powerConnectionType: (powerConnectionType as any) || null,
        powerConnectionOtherText: powerConnectionOtherText || null,
        notes: notes || null,
        meas,
      });
      setEditing(false);
    } finally {
      setSaving(false);
    }
  };

  const flags = line.calculationFlagsJson ?? [];
  const hasWarnings = flags.some((f) => f.severity === "warning" || f.severity === "error");
  const setMeasField = (field: keyof MeasForm) => (val: number | null) =>
    setMeas((prev) => ({ ...prev, [field]: val }));

  return (
    <div className="border rounded-lg overflow-hidden bg-card">
      {/* Card header */}
      <div
        className="flex items-center justify-between px-4 py-3 bg-muted/40 cursor-pointer select-none"
        onClick={() => setExpanded((v) => !v)}
      >
        <div className="flex items-center gap-3">
          <span className="text-sm font-bold text-muted-foreground w-6 text-center">
            {index + 1}
          </span>
          <span className="font-semibold text-sm">
            {line.screenLabel || `Screen ${index + 1}`}
          </span>
          {hasWarnings && (
            <span className="inline-flex items-center gap-1 text-xs text-yellow-700 bg-yellow-50 border border-yellow-200 rounded-full px-2 py-0.5">
              <AlertTriangle className="w-3 h-3" />
              {flags.filter((f) => f.severity === "warning" || f.severity === "error").length} warning
              {flags.filter((f) => f.severity === "warning" || f.severity === "error").length !== 1 ? "s" : ""}
            </span>
          )}
          {line.orderableWidth && line.orderableHeight && (
            <span className="text-xs text-muted-foreground font-mono">
              {fmtFrac(line.orderableWidth)} × {fmtFrac(line.orderableHeight)}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
          {canEdit && !editing && (
            <>
              <Button variant="ghost" size="sm" onClick={handleEdit}>
                <Edit2 className="w-3.5 h-3.5" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="text-destructive hover:text-destructive"
                onClick={() => onDelete(line.id)}
              >
                <Trash2 className="w-3.5 h-3.5" />
              </Button>
            </>
          )}
          {expanded ? (
            <ChevronUp className="w-4 h-4 text-muted-foreground" />
          ) : (
            <ChevronDown className="w-4 h-4 text-muted-foreground" />
          )}
        </div>
      </div>

      {expanded && (
        <div className="p-4 space-y-5">
          {editing ? (
            <div className="space-y-5">
              {/* Description */}
              <div>
                <label className="text-xs font-semibold text-muted-foreground block mb-1">
                  Screen Description / Label
                </label>
                <Input
                  value={screenLabel}
                  onChange={(e) => setScreenLabel(e.target.value)}
                  placeholder="e.g. Screen 1 – Living Room Left"
                />
              </div>

              {/* Motor Side | Remote | Cuts */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-semibold text-muted-foreground block mb-1">
                    Motor Side
                  </label>
                  <Select
                    value={motorSide || "__none__"}
                    onValueChange={(v) => setMotorSide(v === "__none__" ? "" : v)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__none__">— None —</SelectItem>
                      {MOTOR_SIDE_OPTIONS.map((o) => (
                        <SelectItem key={o.value} value={o.value}>
                          {o.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-muted-foreground block mb-1">
                    Remote (per-screen)
                  </label>
                  <Select
                    value={remoteType || "__none__"}
                    onValueChange={(v) => setRemoteType(v === "__none__" ? "" : v)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__none__">— None —</SelectItem>
                      {remoteTypeOptions.map((o) => (
                        <SelectItem key={o.code} value={o.code}>
                          {o.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-muted-foreground block mb-1">
                    # of Cuts
                  </label>
                  <Input
                    type="number"
                    min={0}
                    value={numberOfCuts}
                    onChange={(e) => setNumberOfCuts(e.target.value)}
                    placeholder="0"
                  />
                </div>
              </div>

              {/* Measurements */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-sm font-semibold">Measurements</h4>
                </div>

                {/* Reverse toggle */}
                <div className="mb-4 flex items-center gap-3">
                  <span className="text-xs font-semibold text-muted-foreground">
                    Reverse measurements?
                  </span>
                  <div className="flex rounded-md border overflow-hidden">
                    <button
                      type="button"
                      className={cn(
                        "px-3 py-1 text-xs font-medium transition-colors",
                        reverseMeasurements
                          ? "bg-primary text-primary-foreground"
                          : "bg-background text-muted-foreground hover:bg-muted"
                      )}
                      onClick={() => setReverseMeasurements(true)}
                    >
                      Yes
                    </button>
                    <button
                      type="button"
                      className={cn(
                        "px-3 py-1 text-xs font-medium transition-colors",
                        !reverseMeasurements
                          ? "bg-primary text-primary-foreground"
                          : "bg-background text-muted-foreground hover:bg-muted"
                      )}
                      onClick={() => setReverseMeasurements(false)}
                    >
                      No
                    </button>
                  </div>
                  {reverseMeasurements && (
                    <span className="text-xs text-amber-600 italic">
                      Measurements will be mirrored left↔right during calculation.
                    </span>
                  )}
                </div>

                {/* Left / Right columns */}
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <div className="text-xs font-bold text-muted-foreground mb-2 uppercase tracking-wide">
                      Left Side
                    </div>
                    <div className="space-y-3">
                      <FractionInput label="Upper Left" shortLabel="UL" value={meas.ul} onChange={setMeasField("ul")} required />
                      <FractionInput label="Lower Left" shortLabel="LL" value={meas.ll} onChange={setMeasField("ll")} />
                      <FractionInput label="Overall Left" shortLabel="OL" value={meas.ol} onChange={setMeasField("ol")} />
                    </div>
                  </div>
                  <div>
                    <div className="text-xs font-bold text-muted-foreground mb-2 uppercase tracking-wide">
                      Right Side
                    </div>
                    <div className="space-y-3">
                      <FractionInput label="Upper Right" shortLabel="UR" value={meas.ur} onChange={setMeasField("ur")} required />
                      <FractionInput label="Lower Right" shortLabel="LR" value={meas.lr} onChange={setMeasField("lr")} />
                      <FractionInput label="Overall Right" shortLabel="OR" value={meas.orMeasurement} onChange={setMeasField("orMeasurement")} />
                    </div>
                  </div>
                </div>

                {/* Horizontal row */}
                <div>
                  <div className="text-xs font-bold text-muted-foreground mb-2 uppercase tracking-wide">
                    Horizontal (Width)
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <FractionInput label="Top" shortLabel="T" value={meas.t} onChange={setMeasField("t")} required />
                    <FractionInput label="Middle" shortLabel="M" value={meas.m} onChange={setMeasField("m")} />
                    <FractionInput label="Bottom" shortLabel="B" value={meas.b} onChange={setMeasField("b")} />
                  </div>
                </div>
              </div>

              {/* Power Connection */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-muted-foreground block mb-1">
                    Power Connection
                  </label>
                  <Select
                    value={powerConnectionType || "__none__"}
                    onValueChange={(v) => setPowerConnectionType(v === "__none__" ? "" : v)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__none__">— None —</SelectItem>
                      {POWER_CONNECTION_OPTIONS.map((o) => (
                        <SelectItem key={o.value} value={o.value}>
                          {o.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                {powerConnectionType === "other" && (
                  <div>
                    <label className="text-xs font-semibold text-muted-foreground block mb-1">
                      Power Connection Notes
                    </label>
                    <Input
                      value={powerConnectionOtherText}
                      onChange={(e) => setPowerConnectionOtherText(e.target.value)}
                      placeholder="Describe power connection..."
                    />
                  </div>
                )}
              </div>

              {/* Special Instructions */}
              <div>
                <label className="text-xs font-semibold text-muted-foreground block mb-1">
                  Special Instructions
                </label>
                <Textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Any special notes for this screen..."
                  rows={3}
                />
              </div>

              {/* Save / Cancel */}
              <div className="flex gap-2 pt-1">
                <Button onClick={handleSave} disabled={saving} size="sm">
                  {saving ? (
                    <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
                  ) : (
                    <Check className="w-3.5 h-3.5 mr-1.5" />
                  )}
                  Save Screen
                </Button>
                <Button variant="outline" size="sm" onClick={() => setEditing(false)} disabled={saving}>
                  <X className="w-3.5 h-3.5 mr-1.5" />
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            // ── READ-ONLY VIEW ─────────────────────────────────────────────
            <div className="space-y-5">
              {/* Summary row */}
              <div className="grid grid-cols-4 gap-3 text-sm">
                <div>
                  <div className="text-xs text-muted-foreground mb-0.5">Motor Side</div>
                  <div className="font-medium capitalize">{line.motorSide ?? "—"}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground mb-0.5">Remote</div>
                  <div className="font-medium">{line.remoteType ?? "—"}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground mb-0.5"># of Cuts</div>
                  <div className="font-medium">{line.numberOfCuts ?? "—"}</div>
                </div>
                <div>
                  <div className="text-xs text-muted-foreground mb-0.5">Reverse Meas.</div>
                  <div className="font-medium">{line.reverseMeasurements ? "Yes" : "No"}</div>
                </div>
              </div>

              {/* Measurement grid */}
              <div>
                <h4 className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-2">
                  Measurements
                </h4>
                <div className="grid grid-cols-2 gap-4 mb-3">
                  <div className="border rounded-md p-3">
                    <div className="text-xs font-bold text-muted-foreground mb-2">Left Side</div>
                    {[
                      { label: "Upper Left (UL)", val: line.ul },
                      { label: "Lower Left (LL)", val: line.ll },
                      { label: "Overall Left (OL)", val: line.ol },
                    ].map(({ label, val }) => (
                      <div key={label} className="flex justify-between py-0.5 text-sm">
                        <span className="text-muted-foreground">{label}</span>
                        <span className="font-mono font-medium">{fmtFrac(val)}</span>
                      </div>
                    ))}
                  </div>
                  <div className="border rounded-md p-3">
                    <div className="text-xs font-bold text-muted-foreground mb-2">Right Side</div>
                    {[
                      { label: "Upper Right (UR)", val: line.ur },
                      { label: "Lower Right (LR)", val: line.lr },
                      { label: "Overall Right (OR)", val: line.orMeasurement },
                    ].map(({ label, val }) => (
                      <div key={label} className="flex justify-between py-0.5 text-sm">
                        <span className="text-muted-foreground">{label}</span>
                        <span className="font-mono font-medium">{fmtFrac(val)}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="border rounded-md p-3">
                  <div className="text-xs font-bold text-muted-foreground mb-2">Horizontal (Width)</div>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { label: "Top (T)", val: line.t },
                      { label: "Middle (M)", val: line.m },
                      { label: "Bottom (B)", val: line.b },
                    ].map(({ label, val }) => (
                      <div key={label} className="text-center">
                        <div className="text-xs text-muted-foreground">{label}</div>
                        <div className="font-mono font-medium text-sm">{fmtFrac(val)}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Power connection */}
              {line.powerConnectionType && (
                <div>
                  <div className="text-xs text-muted-foreground mb-0.5">Power Connection</div>
                  <div className="text-sm font-medium capitalize">
                    {line.powerConnectionType}
                    {line.powerConnectionType === "other" && line.powerConnectionOtherText
                      ? ` — ${line.powerConnectionOtherText}`
                      : ""}
                  </div>
                </div>
              )}

              {/* Notes */}
              {line.notes && (
                <div>
                  <div className="text-xs text-muted-foreground mb-0.5">Special Instructions</div>
                  <div className="text-sm whitespace-pre-wrap">{line.notes}</div>
                </div>
              )}

              {/* Calc results */}
              <div>
                <h4 className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-2">
                  Calculated Results
                </h4>
                <CalcResultsSection line={line} />
              </div>

              {/* Photos */}
              <PhotoSection line={line} canEdit={canEdit} />
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Header Settings Card ─────────────────────────────────────────────────────

interface Header {
  id: number;
  recordNumber: string | null;
  status: string;
  manufacturerCode: string | null;
  motorType: string | null;
  remoteType: string | null;
  installMount: string | null;
  faceMountSides: string | null;
  applyUChannelToAll: number | null;
  calculationProfileCode: string | null;
  calculationVersion: number | null;
  measurementDate: string | null;
  siteNotes: string | null;
  ownerId: number;
  createdAt: Date | null;
  updatedAt: Date | null;
}

function HeaderSettingsCard({
  header,
  canEdit,
  onSaved,
}: {
  header: Header;
  canEdit: boolean;
  onSaved: () => void;
}) {
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);

  const { data: manufacturers } = trpc.screens.getManufacturers.useQuery();
  const { data: motorTypes } = trpc.screens.getMotorTypes.useQuery({
    manufacturerCode: header.manufacturerCode ?? undefined,
  });
  const { data: remoteTypes } = trpc.screens.getRemoteTypes.useQuery({
    manufacturerCode: header.manufacturerCode ?? undefined,
  });
  const { data: installMounts } = trpc.screens.getInstallMounts.useQuery();

  const [form, setForm] = useState({
    manufacturerCode: header.manufacturerCode ?? "",
    motorType: header.motorType ?? "",
    remoteType: header.remoteType ?? "",
    installMount: header.installMount ?? "",
    applyUChannelToAll: !!header.applyUChannelToAll,
    measurementDate: header.measurementDate
      ? new Date(header.measurementDate).toISOString().split("T")[0]
      : "",
    siteNotes: header.siteNotes ?? "",
  });

  const updateMutation = trpc.screens.update.useMutation({
    onSuccess: () => {
      setEditing(false);
      onSaved();
      toast.success("Settings saved");
    },
    onError: (err) => toast.error("Save failed: " + err.message),
  });

  const handleSave = async () => {
    setSaving(true);
    try {
      await updateMutation.mutateAsync({
        id: header.id,
        manufacturerCode: form.manufacturerCode || null,
        motorType: form.motorType || null,
        remoteType: form.remoteType || null,
        installMount: (form.installMount as any) || null,
        applyUChannelToAll: form.applyUChannelToAll,
        measurementDate: form.measurementDate || null,
        siteNotes: form.siteNotes || null,
      });
    } finally {
      setSaving(false);
    }
  };

  const STATUS_COLORS: Record<string, string> = {
    draft: "bg-gray-100 text-gray-700",
    submitted: "bg-blue-50 text-blue-700",
    approved: "bg-green-50 text-green-700",
    closed: "bg-slate-100 text-slate-600",
    cancelled: "bg-red-50 text-red-600",
    archived: "bg-yellow-50 text-yellow-700",
  };

  return (
    <div className="border rounded-lg bg-card">
      <div className="flex items-center justify-between px-4 py-3 border-b bg-muted/40">
        <div className="flex items-center gap-3">
          <h2 className="font-semibold text-sm">Job Settings</h2>
          <span
            className={cn(
              "text-xs px-2 py-0.5 rounded-full font-medium",
              STATUS_COLORS[header.status] ?? "bg-gray-100 text-gray-700"
            )}
          >
            {header.status.charAt(0).toUpperCase() + header.status.slice(1)}
          </span>
        </div>
        {canEdit && !editing && (
          <Button variant="ghost" size="sm" onClick={() => setEditing(true)}>
            <Edit2 className="w-3.5 h-3.5 mr-1.5" />
            Edit
          </Button>
        )}
      </div>
      <div className="p-4">
        {editing ? (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-muted-foreground block mb-1">
                  Manufacturer
                </label>
                <Select
                  value={form.manufacturerCode || "__none__"}
                  onValueChange={(v) =>
                    setForm((f) => ({
                      ...f,
                      manufacturerCode: v === "__none__" ? "" : v,
                      motorType: "",
                      remoteType: "",
                    }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none__">— None —</SelectItem>
                    {manufacturers?.map((m) => (
                      <SelectItem key={m.code} value={m.code}>
                        {m.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs font-semibold text-muted-foreground block mb-1">
                  Motor Type
                </label>
                <Select
                  value={form.motorType || "__none__"}
                  onValueChange={(v) =>
                    setForm((f) => ({ ...f, motorType: v === "__none__" ? "" : v }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none__">— None —</SelectItem>
                    {motorTypes?.map((m) => (
                      <SelectItem key={m.code} value={m.code}>
                        {m.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs font-semibold text-muted-foreground block mb-1">
                  Remote Type (default)
                </label>
                <Select
                  value={form.remoteType || "__none__"}
                  onValueChange={(v) =>
                    setForm((f) => ({ ...f, remoteType: v === "__none__" ? "" : v }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none__">— None —</SelectItem>
                    {remoteTypes?.map((r) => (
                      <SelectItem key={r.code} value={r.code}>
                        {r.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs font-semibold text-muted-foreground block mb-1">
                  Install Mount
                </label>
                <Select
                  value={form.installMount || "__none__"}
                  onValueChange={(v) =>
                    setForm((f) => ({ ...f, installMount: v === "__none__" ? "" : v }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__none__">— None —</SelectItem>
                    {installMounts?.map((m) => (
                      <SelectItem key={m.code} value={m.code}>
                        {m.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs font-semibold text-muted-foreground block mb-1">
                  Measurement Date
                </label>
                <Input
                  type="date"
                  value={form.measurementDate}
                  onChange={(e) => setForm((f) => ({ ...f, measurementDate: e.target.value }))}
                />
              </div>
              <div className="flex items-center gap-2 pt-5">
                <input
                  type="checkbox"
                  id="applyUChannel"
                  checked={form.applyUChannelToAll}
                  onChange={(e) =>
                    setForm((f) => ({ ...f, applyUChannelToAll: e.target.checked }))
                  }
                  className="rounded"
                />
                <label htmlFor="applyUChannel" className="text-sm">
                  Apply U-Channel to all screens
                </label>
              </div>
            </div>
            <div>
              <label className="text-xs font-semibold text-muted-foreground block mb-1">
                Site Notes
              </label>
              <Textarea
                value={form.siteNotes}
                onChange={(e) => setForm((f) => ({ ...f, siteNotes: e.target.value }))}
                placeholder="Job site notes..."
                rows={3}
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleSave} disabled={saving} size="sm">
                {saving ? (
                  <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
                ) : (
                  <Check className="w-3.5 h-3.5 mr-1.5" />
                )}
                Save Settings
              </Button>
              <Button variant="outline" size="sm" onClick={() => setEditing(false)} disabled={saving}>
                Cancel
              </Button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-x-6 gap-y-3 text-sm">
            {[
              { label: "Manufacturer", value: header.manufacturerCode ?? "—" },
              { label: "Motor Type", value: header.motorType ?? "—" },
              { label: "Remote Type", value: header.remoteType ?? "—" },
              { label: "Install Mount", value: header.installMount ?? "—" },
              {
                label: "Measurement Date",
                value: header.measurementDate
                  ? new Date(header.measurementDate).toLocaleDateString()
                  : "—",
              },
              {
                label: "U-Channel (all)",
                value: header.applyUChannelToAll ? "Yes" : "No",
              },
              {
                label: "Calc Profile",
                value: header.calculationProfileCode
                  ? `${header.calculationProfileCode}${header.calculationVersion ? ` v${header.calculationVersion}` : ""}`
                  : "—",
              },
            ].map(({ label, value }) => (
              <div key={label}>
                <div className="text-xs text-muted-foreground mb-0.5">{label}</div>
                <div className="font-medium">{value}</div>
              </div>
            ))}
            {header.siteNotes && (
              <div className="col-span-3">
                <div className="text-xs text-muted-foreground mb-0.5">Site Notes</div>
                <div className="whitespace-pre-wrap">{header.siteNotes}</div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function ScreenMeasurementDetail() {
  const params = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const recordId = parseInt(params.id ?? "0", 10);
  const utils = trpc.useUtils();

  const { data, isLoading, error } = trpc.screens.get.useQuery(
    { id: recordId },
    { enabled: recordId > 0 }
  );

  const { data: remoteTypes } = trpc.screens.getRemoteTypes.useQuery({
    manufacturerCode: data?.header.manufacturerCode ?? undefined,
  });

  const addLineMutation = trpc.screens.upsertLine.useMutation({
    onSuccess: () => {
      utils.screens.get.invalidate({ id: recordId });
      toast.success("Screen added");
    },
    onError: (err: any) => toast.error("Failed to add screen: " + err.message),
  });

  const upsertLineMutation = trpc.screens.upsertLine.useMutation({
    onSuccess: () => {
      utils.screens.get.invalidate({ id: recordId });
    },
    onError: (err) => toast.error("Save failed: " + err.message),
  });

  const deleteLineMutation = trpc.screens.deleteLine.useMutation({
    onSuccess: () => {
      utils.screens.get.invalidate({ id: recordId });
      toast.success("Screen removed");
    },
    onError: (err) => toast.error("Delete failed: " + err.message),
  });

  const transitionMutation = trpc.screens.transition.useMutation({
    onSuccess: () => {
      utils.screens.get.invalidate({ id: recordId });
      toast.success("Status updated");
    },
    onError: (err) => toast.error("Transition failed: " + err.message),
  });

  const exportPdfMutation = trpc.screens.exportPdf.useMutation({
    onSuccess: (result: any) => {
      const link = document.createElement("a");
      link.href = `data:application/pdf;base64,${result.pdf}`;
      link.download = `screen-measurements-${data?.header.recordNumber ?? recordId}.pdf`;
      link.click();
      toast.success("PDF downloaded");
    },
    onError: (err) => toast.error("PDF export failed: " + err.message),
  });

  const handleSaveLine = useCallback(
    async (lineId: number | undefined, payload: Partial<Line> & { meas: MeasForm }) => {
      const { meas, ...rest } = payload;
      await upsertLineMutation.mutateAsync({
        id: lineId,
        headerId: recordId,
        screenLabel: rest.screenLabel ?? null,
        motorSide: rest.motorSide ?? null,
        remoteType: rest.remoteType ?? null,
        reverseMeasurements:
          rest.reverseMeasurements === 1 || (rest.reverseMeasurements as any) === true,
        numberOfCuts: rest.numberOfCuts ?? null,
        powerConnectionType: (rest.powerConnectionType as any) ?? null,
        powerConnectionOtherText: rest.powerConnectionOtherText ?? null,
        notes: rest.notes ?? null,
        ul: meas.ul,
        ll: meas.ll,
        ol: meas.ol,
        ur: meas.ur,
        lr: meas.lr,
        orMeasurement: meas.orMeasurement,
        t: meas.t,
        m: meas.m,
        b: meas.b,
      });
    },
    [recordId, upsertLineMutation]
  );

  const handleDeleteLine = useCallback(
    (lineId: number) => {
      if (!confirm("Remove this screen?")) return;
      deleteLineMutation.mutate({ id: lineId });
    },
    [deleteLineMutation]
  );

  if (isLoading) {
    return (
      <DashboardLayout>
        <div className="flex items-center justify-center min-h-[60vh]">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </div>
      </DashboardLayout>
    );
  }

  if (error || !data) {
    return (
      <DashboardLayout>
        <div className="p-6 max-w-4xl mx-auto">
          <div className="text-center py-12">
            <p className="text-muted-foreground mb-4">
              {error?.message ?? "Record not found."}
            </p>
            <Button variant="outline" onClick={() => navigate("/screen-measurements")}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Records
            </Button>
          </div>
        </div>
      </DashboardLayout>
    );
  }

  const { header, lines } = data;
  const canEdit = header.status === "draft" || header.status === "submitted";

  const totalWarnings = (lines as Line[]).reduce(
    (sum, l) =>
      sum +
      (l.calculationFlagsJson?.filter(
        (f) => f.severity === "warning" || f.severity === "error"
      ).length ?? 0),
    0
  );

  return (
    <DashboardLayout>
      <div className="p-6 max-w-4xl mx-auto space-y-6">
        {/* Page header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => navigate("/screen-measurements")}>
              <ArrowLeft className="w-4 h-4 mr-1" />
              Back
            </Button>
            <div>
              <h1 className="text-xl font-bold">
                {header.recordNumber ?? `Record #${header.id}`}
              </h1>
              <p className="text-xs text-muted-foreground">
                {lines.length} screen{lines.length !== 1 ? "s" : ""}
                {totalWarnings > 0 && (
                  <span className="ml-2 text-yellow-600">
                    · {totalWarnings} warning{totalWarnings !== 1 ? "s" : ""}
                  </span>
                )}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {header.status === "draft" && (
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  transitionMutation.mutate({ id: header.id, to: "submitted" })
                }
                disabled={transitionMutation.isPending}
              >
                Submit for Review
              </Button>
            )}
            {header.status === "submitted" && (
              <Button
                variant="outline"
                size="sm"
                onClick={() =>
                  transitionMutation.mutate({ id: header.id, to: "approved" })
                }
                disabled={transitionMutation.isPending}
              >
                Approve
              </Button>
            )}
            <Button
              variant="outline"
              size="sm"
              onClick={() => exportPdfMutation.mutate({ id: header.id })}
              disabled={exportPdfMutation.isPending}
            >
              {exportPdfMutation.isPending ? (
                <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
              ) : (
                <FileText className="w-3.5 h-3.5 mr-1.5" />
              )}
              Export PDF
            </Button>
          </div>
        </div>

        {/* Header settings */}
        <HeaderSettingsCard
          header={header as Header}
          canEdit={canEdit}
          onSaved={() => utils.screens.get.invalidate({ id: recordId })}
        />

        {/* Screen cards */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold">Screens ({lines.length})</h2>
            {canEdit && (
              <Button
                size="sm"
                onClick={() => addLineMutation.mutate({ headerId: recordId, id: undefined })
                }disabled={addLineMutation.isPending}
              >
                <Plus className="w-3.5 h-3.5 mr-1.5" />
                Add Screen
              </Button>
            )}
          </div>

          {lines.length === 0 ? (
            <div className="border rounded-lg p-8 text-center text-muted-foreground">
              <p className="mb-3">No screens added yet.</p>
              {canEdit && (
                <Button
                  size="sm"
                  onClick={() => addLineMutation.mutate({ headerId: recordId, id: undefined })
              }    disabled={addLineMutation.isPending}
                >
                  <Plus className="w-3.5 h-3.5 mr-1.5" />
                  Add First Screen
                </Button>
              )}
            </div>
          ) : (
            (lines as Line[]).map((line, index) => (
              <LineCard
                key={line.id}
                line={line}
                index={index}
                canEdit={canEdit}
                remoteTypeOptions={(remoteTypes ?? []).map((r) => ({
                  code: r.code,
                  name: r.name,
                }))}
                onSave={handleSaveLine}
                onDelete={handleDeleteLine}
              />
            ))
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
