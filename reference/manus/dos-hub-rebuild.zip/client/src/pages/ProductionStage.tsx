import { StageOverview } from "./StageOverview";

export default function ProductionStage() {
  return (
    <StageOverview
      stage="production"
      title="Production"
      description="Manufacturing and assembly phase. Track materials, orders, and production status."
    />
  );
}
