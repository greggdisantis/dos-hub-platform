import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, ArrowLeft, Edit2, CheckCircle, Printer, MessageSquarePlus, TrendingUp, DollarSign, Lock } from "lucide-react";
import { useLocation, useRoute } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { useState, useEffect } from "react";

// ─── Helpers ─────────────────────────────────────────────────────────────────

function formatDate(dateValue: any): string {
  if (!dateValue) return "—";
  if (typeof dateValue === "string" && dateValue.match(/^\d{4}-\d{2}-\d{2}$/)) {
    const [year, month, day] = dateValue.split("-").map(Number);
    return new Date(year, month - 1, day).toLocaleDateString();
  }
  return new Date(dateValue).toLocaleDateString();
}

function formatCurrency(v: any): string {
  if (!v && v !== 0) return "—";
  const num = typeof v === "string" ? parseFloat(v) : Number(v);
  if (isNaN(num)) return "—";
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(num);
}

function Field({ label, value, span2 = false }: { label: string; value?: React.ReactNode; span2?: boolean }) {
  if (!value && value !== 0) return null;
  return (
    <div className={span2 ? "col-span-2" : ""}>
      <p className="text-xs text-muted-foreground uppercase tracking-wide mb-0.5">{label}</p>
      <p className="font-medium">{value}</p>
    </div>
  );
}

function SectionCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <Card className="p-6">
      <h2 className="text-base font-semibold mb-4 border-b pb-2">{title}</h2>
      <div className="grid grid-cols-2 gap-4">{children}</div>
    </Card>
  );
}

// ─── Inline Add Note ──────────────────────────────────────────────────────────

function AddNoteInline({ reportId, onSaved }: { reportId: number; onSaved: () => void }) {
  const [open, setOpen] = useState(false);
  const [noteText, setNoteText] = useState("");

  const addNoteMutation = trpc.cmr.addUpdateNote.useMutation({
    onSuccess: () => {
      toast.success("Note added");
      setNoteText("");
      setOpen(false);
      onSaved();
    },
    onError: () => toast.error("Failed to add note"),
  });

  if (!open) {
    return (
      <Button variant="outline" size="sm" className="gap-2" onClick={() => setOpen(true)}>
        <MessageSquarePlus className="w-4 h-4" />
        Add Update Note
      </Button>
    );
  }

  return (
    <div className="space-y-2 border rounded-lg p-3 bg-muted/30">
      <p className="text-sm font-medium">New Update Note</p>
      <Textarea
        placeholder="Enter update note..."
        value={noteText}
        onChange={(e) => setNoteText(e.target.value)}
        rows={3}
        autoFocus
      />
      <div className="flex gap-2">
        <Button size="sm" onClick={() => addNoteMutation.mutate({ reportId, note: noteText })} disabled={!noteText.trim() || addNoteMutation.isPending}>
          {addNoteMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Save Note"}
        </Button>
        <Button size="sm" variant="ghost" onClick={() => { setOpen(false); setNoteText(""); }}>Cancel</Button>
      </div>
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function CMRView() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [, params] = useRoute("/dashboard/cmr/:id");
  const reportId = params?.id ? parseInt(params.id) : null;
  const [isApproving, setIsApproving] = useState(false);

  const utils = trpc.useUtils();

  const { data: report, isLoading } = trpc.cmr.get.useQuery(
    { reportId: reportId! },
    { enabled: !!reportId }
  );

  const exportPdfMutation = trpc.cmrExport.exportPdf.useMutation({
    onSuccess: (data) => {
      const bytes = Uint8Array.from(atob(data.pdfBase64), (c) => c.charCodeAt(0));
      const blob = new Blob([bytes], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = data.filename;
      link.click();
      URL.revokeObjectURL(url);
      toast.success("PDF exported successfully");
    },
    onError: () => toast.error("Failed to export PDF"),
  });

  const approveMutation = trpc.cmr.update.useMutation({
    onSuccess: () => {
      toast.success("CMR report approved");
      utils.cmr.get.invalidate({ reportId: reportId! });
      setIsApproving(false);
    },
    onError: () => {
      toast.error("Failed to approve CMR report");
      setIsApproving(false);
    },
  });

  const handleApprove = () => {
    if (!reportId) return;
    setIsApproving(true);
    approveMutation.mutate({ reportId, status: "approved" });
  };

  const handlePrint = () => {
    if (!reportId) return;
    // Use the shared Puppeteer PDF export — no browser print dialog
    exportPdfMutation.mutate({ reportId });
  };

  // Auto-trigger PDF export when opened with ?print=1 (from per-card Print button)
  useEffect(() => {
    if (!isLoading && report && reportId) {
      const searchParams = new URLSearchParams(window.location.search);
      if (searchParams.get("print") === "1") {
        const timer = setTimeout(() => exportPdfMutation.mutate({ reportId }), 400);
        return () => clearTimeout(timer);
      }
    }
  }, [isLoading, report, reportId]);

  const handleNoteAdded = () => {
    utils.cmr.get.invalidate({ reportId: reportId! });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!report) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">CMR report not found</p>
          <Button onClick={() => setLocation("/dashboard/cmr")}>Back to CMR Reports</Button>
        </div>
      </div>
    );
  }

  const canEdit = report.status === "draft" && (report.userId === user?.id || ["admin", "super-admin"].includes(user?.role || ""));
  const canApprove = (user?.role === "admin" || user?.role === "super-admin") && report.status === "submitted";

  // Parse update notes safely
  let updateNotes: Array<{ note: string; createdAt: string; createdBy: string }> = [];
  if (report.updateNotes) {
    try {
      updateNotes = typeof report.updateNotes === "string" ? JSON.parse(report.updateNotes) : (report.updateNotes as any[]);
    } catch { updateNotes = []; }
  }

  const displayPc = report.currentConfidencePct ?? report.purchaseConfidencePct;
  const hasConfidenceDrift = report.originalPcPct !== null && report.originalPcPct !== undefined &&
    report.currentConfidencePct !== null && report.currentConfidencePct !== undefined &&
    report.originalPcPct !== report.currentConfidencePct;

  return (
    <div className="min-h-screen bg-background p-4 md:p-8 print:p-4">
      <div className="max-w-6xl mx-auto space-y-6">

        {/* Header */}
        <div className="flex items-center justify-between print:hidden">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" onClick={() => setLocation("/dashboard/cmr")}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-2xl font-bold">{report.clientName}</h1>
              <p className="text-sm text-muted-foreground mt-0.5">
                CMR Report • {formatDate(report.appointmentDate || report.createdAt)}
                {report.consultantName && <span> • {report.consultantName}</span>}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {report.status === "approved" && (
              <div className="flex items-center gap-2 px-3 py-1.5 bg-green-100 text-green-800 rounded-lg text-sm">
                <CheckCircle className="w-4 h-4" />
                Approved
              </div>
            )}
            <Button variant="outline" size="sm" onClick={handlePrint} disabled={exportPdfMutation.isPending} className="gap-2">
              {exportPdfMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Printer className="w-4 h-4" />}
              {exportPdfMutation.isPending ? "Generating..." : "Download PDF"}
            </Button>
            {canEdit && (
              <Button variant="outline" size="sm" onClick={() => setLocation(`/dashboard/cmr/${report.id}/edit`)} className="gap-2">
                <Edit2 className="w-4 h-4" />
                Edit
              </Button>
            )}
            {canApprove && (
              <Button size="sm" onClick={handleApprove} disabled={isApproving} className="gap-2">
                {isApproving ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
                Approve
              </Button>
            )}
          </div>
        </div>

        {/* Print header */}
        <div className="hidden print:block mb-4">
          <h1 className="text-2xl font-bold">{report.clientName} — CMR Report</h1>
          <p className="text-sm text-muted-foreground">{formatDate(report.appointmentDate)} • {report.consultantName || "Staff"} • Status: {report.status}</p>
        </div>

        {/* Confidence / Value highlight bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="p-4 flex items-center gap-3">
            <TrendingUp className="w-5 h-5 text-blue-600 shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">PC %</p>
              <p className="text-xl font-bold">{displayPc ?? "—"}%</p>
            </div>
          </Card>
          <Card className="p-4 flex items-center gap-3">
            <Lock className="w-5 h-5 text-gray-500 shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Original PC % (Locked)</p>
              <p className="text-xl font-bold">{report.originalPcPct ?? "—"}%</p>
              {hasConfidenceDrift && (
                <p className="text-xs text-amber-600">Drift: {(report.currentConfidencePct! - report.originalPcPct!)}pp</p>
              )}
            </div>
          </Card>
          <Card className="p-4 flex items-center gap-3">
            <DollarSign className="w-5 h-5 text-emerald-600 shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Estimated Value</p>
              <p className="text-xl font-bold">{formatCurrency(report.estimatedValue || report.estimatedContractValue)}</p>
            </div>
          </Card>
          <Card className="p-4 flex items-center gap-3">
            <CheckCircle className="w-5 h-5 text-green-600 shrink-0" />
            <div>
              <p className="text-xs text-muted-foreground">Closed Amount</p>
              <p className="text-xl font-bold">{formatCurrency(report.closedAmount)}</p>
            </div>
          </Card>
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">

            {/* Section 1: Appointment Details */}
            <SectionCard title="Appointment Details">
              <Field label="Client Name" value={report.clientName} />
              <Field label="Consultant" value={report.consultantName} />
              <Field label="Appointment Type" value={report.appointmentType} />
              <Field label="Appointment Date" value={formatDate(report.appointmentDate)} />
              <Field label="Client Type" value={report.clientType} />
              <Field label="Address" value={report.address} span2 />
              {report.leadSources && report.leadSources.length > 0 && (
                <Field label="Lead Sources" value={report.leadSources.join(", ")} span2 />
              )}
              {(report as any).leadSourceOther && (
                <Field label="Other Lead Source" value={(report as any).leadSourceOther} />
              )}
              {(report as any).referredClientName && (
                <Field label="Referred Client" value={(report as any).referredClientName} />
              )}
              {(report as any).contractorRefName && (
                <Field label="Referring Contractor" value={(report as any).contractorRefName} />
              )}
              {report.projectTypes && report.projectTypes.length > 0 && (
                <Field label="Project Types" value={report.projectTypes.join(", ")} span2 />
              )}
              {(report as any).projectTypeOther && (
                <Field label="Other Project Type" value={(report as any).projectTypeOther} />
              )}
              {report.convertedToInPerson ? (
                <>
                  <Field label="Converted to In-Person" value="Yes" />
                  <Field label="Converted Date" value={formatDate(report.convertedDate)} />
                  <Field label="Converted Type" value={report.convertedType} />
                </>
              ) : null}
            </SectionCard>

            {/* Section 2: Deal Status */}
            <SectionCard title="Deal Status">
              <Field label="Deal Status" value={report.dealStatus === 'other' && (report as any).otherDealStatus ? `Other: ${(report as any).otherDealStatus}` : report.dealStatus?.replace(/-/g, " ")} />
              <Field label="Close Timeline" value={report.closeTimeline} />
              <Field label="Follow-up Date" value={formatDate(report.followUpDate)} />
              {report.dealStatus === 'proposal-presented' && (
                <Field label="Proposal Date" value={formatDate(report.proposalDate)} />
              )}
              {report.dealStatus === 'lost' && (
                <Field label="Lost Reason" value={report.lostReason} span2 />
              )}
              <Field label="Last Conversation Summary" value={report.lastConversationSummary} span2 />
            </SectionCard>

            {/* Section 3: Purchase Confidence */}
            <SectionCard title="Purchase Confidence">
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wide mb-0.5">Confidence Level</p>
                <p className="text-2xl font-bold text-blue-700">{report.purchaseConfidencePct ?? "—"}%</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wide mb-0.5">Current Confidence %</p>
                <p className="text-2xl font-bold">{report.currentConfidencePct ?? "—"}%</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground uppercase tracking-wide mb-0.5">Original PC % (Locked)</p>
                <p className="text-lg font-semibold flex items-center gap-1">
                  <Lock className="w-3 h-3 text-gray-400" />
                  {report.originalPcPct ?? "—"}%
                </p>
              </div>
              <Field label="Estimated Contract Value" value={formatCurrency(report.estimatedContractValue)} />
              <Field label="Decision Makers" value={report.decisionMakers} span2 />
              <Field label="Main Motivation" value={report.mainMotivation === 'Other' && (report as any).otherMainMotivation ? `Other: ${(report as any).otherMainMotivation}` : report.mainMotivation} span2 />
              <Field label="Main Hesitation" value={report.mainHesitation === 'Other' && (report as any).otherMainHesitation ? `Other: ${(report as any).otherMainHesitation}` : report.mainHesitation} span2 />
              <Field label="PC Notes" value={report.pcNotes} span2 />
            </SectionCard>

            {/* Section 4: Value & Objections */}
            <SectionCard title="Value & Objections">
              {report.valueCommunicated && report.valueCommunicated.length > 0 && (
                <Field label="Value Communicated" value={report.valueCommunicated.join(", ")} span2 />
              )}
              <Field label="Financing Discussed" value={report.financingDiscussed ? "Yes" : "No"} />
              <Field label="Financing Reaction" value={report.financingReaction} />
              <Field label="Client Response" value={report.clientResponse === 'other' && (report as any).otherClientResponse ? `Other: ${(report as any).otherClientResponse}` : report.clientResponse?.replace(/-/g, " ")} />
              <Field label="Objection Notes" value={report.objectionNotes} span2 />
            </SectionCard>

            {/* Section 5: Next Steps & Marketing */}
            <SectionCard title="Next Steps & Marketing">
              {report.nextActions && report.nextActions.length > 0 && (
                <Field label="Next Actions" value={[
                  ...report.nextActions,
                  ...(report.nextActions.includes('Other') && (report as any).otherNextAction ? [`Other: ${(report as any).otherNextAction}`] : [])
                ].filter(a => a !== 'Other').join(", ")} span2 />
              )}
              <Field label="Next Follow-up Date" value={formatDate(report.nextFollowUpDate)} />
              <Field label="Lead Quality" value={report.leadQuality} />
              <Field label="Expectation Alignment" value={report.expectationAlignment} />
              <Field label="Budget Alignment" value={report.budgetAlignment?.replace(/-/g, " ")} />
              {report.messagingReferenced && report.messagingReferenced.length > 0 && (
                <Field label="Messaging Referenced" value={report.messagingReferenced.join(", ")} span2 />
              )}
              <Field label="Marketing Notes" value={report.marketingNotes} span2 />
            </SectionCard>

            {/* Section 6: Analytics & Tracking */}
            {(report.estimatedValue || report.closedAmount || report.closedDate || report.appointmentResult) && (
              <SectionCard title="Analytics & Tracking">
                <Field label="Estimated Value" value={formatCurrency(report.estimatedValue)} />
                <Field label="Closed Amount" value={formatCurrency(report.closedAmount)} />
                <Field label="Closed Date" value={formatDate(report.closedDate)} />
                <Field label="Appointment Result" value={report.appointmentResult?.replace(/_/g, " ")} />
              </SectionCard>
            )}

            {/* Meeting Notes Section */}
            {(report.attendees || report.notes || report.actionItems) && (
              <Card className="p-6">
                <h2 className="text-base font-semibold mb-4 border-b pb-2">Meeting Notes</h2>
                <div className="space-y-5">
                  {report.attendees && Array.isArray(report.attendees) && (report.attendees as string[]).length > 0 && (
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wide mb-2">Attendees</p>
                      <div className="flex flex-wrap gap-2">
                        {(report.attendees as string[]).map((a, i) => (
                          <span key={i} className="bg-secondary text-secondary-foreground text-sm px-3 py-1 rounded-full">{a}</span>
                        ))}
                      </div>
                    </div>
                  )}
                  {report.notes && (
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">Notes</p>
                      <p className="text-sm whitespace-pre-wrap">{report.notes}</p>
                    </div>
                  )}
                  {report.actionItems && Array.isArray(report.actionItems) && (report.actionItems as any[]).length > 0 && (
                    <div>
                      <p className="text-xs text-muted-foreground uppercase tracking-wide mb-2">Action Items</p>
                      <div className="space-y-2">
                        {(report.actionItems as Array<{ id: string; text: string; assignee?: string; dueDate?: string }>).map((item) => (
                          <div key={item.id} className="flex items-start gap-3 border rounded-lg p-3 bg-muted/20">
                            <div className="flex-1">
                              <p className="text-sm">{item.text}</p>
                              {(item.assignee || item.dueDate) && (
                                <p className="text-xs text-muted-foreground mt-1">
                                  {item.assignee && <span>Assignee: {item.assignee}</span>}
                                  {item.assignee && item.dueDate && <span className="mx-2">·</span>}
                                  {item.dueDate && <span>Due: {item.dueDate}</span>}
                                </p>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </Card>
            )}

            {/* Section 7: Update History */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4 border-b pb-2">
                <h2 className="text-base font-semibold">Update History</h2>
                <div className="print:hidden">
                  <AddNoteInline reportId={report.id} onSaved={handleNoteAdded} />
                </div>
              </div>
              {updateNotes.length > 0 ? (
                <div className="space-y-3">
                  {updateNotes.map((note, idx) => (
                    <div key={idx} className="border-l-2 border-primary/30 pl-4 py-1">
                      <p className="text-xs text-muted-foreground">
                        {new Date(note.createdAt).toLocaleString()} — <span className="font-medium">{note.createdBy}</span>
                      </p>
                      <p className="text-sm mt-0.5 whitespace-pre-wrap">{note.note}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No update notes yet.</p>
              )}
            </Card>

            {/* Section 8: Progress Notes */}
            {report.progressNotes && (
              <Card className="p-6">
                <h2 className="text-base font-semibold mb-4 border-b pb-2">Progress Notes</h2>
                <p className="text-sm text-muted-foreground whitespace-pre-wrap">
                  {typeof report.progressNotes === "string" ? report.progressNotes : JSON.stringify(report.progressNotes, null, 2)}
                </p>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            <Card className="p-5 sticky top-6">
              <h3 className="font-semibold mb-4 border-b pb-2">Report Details</h3>
              <div className="space-y-3 text-sm">
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wide">Status</p>
                  <span className={`inline-block mt-0.5 px-2 py-0.5 rounded-full text-xs font-medium ${
                    report.status === "approved" ? "bg-green-100 text-green-800" :
                    report.status === "submitted" ? "bg-blue-100 text-blue-800" :
                    "bg-gray-100 text-gray-800"
                  }`}>{report.status}</span>
                </div>
                {report.consultantName && (
                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wide">Consultant</p>
                    <p className="font-medium">{report.consultantName}</p>
                  </div>
                )}
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wide">Created Date</p>
                  <p className="font-medium">{new Date(report.createdAt).toLocaleDateString()}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wide">Last Updated</p>
                  <p className="font-medium">{new Date(report.updatedAt).toLocaleDateString()}</p>
                </div>
                {report.outcome && (
                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wide">Outcome</p>
                    <p className="font-medium capitalize">{report.outcome}</p>
                  </div>
                )}
                {report.appointmentResult && (
                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wide">Appointment Result</p>
                    <p className="font-medium capitalize">{report.appointmentResult.replace(/_/g, " ")}</p>
                  </div>
                )}
                {report.soldAt && (
                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wide">Sold/Lost Date</p>
                    <p className="font-medium">{new Date(report.soldAt).toLocaleDateString()}</p>
                  </div>
                )}
                {report.noFollowUpReason && (
                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wide">No Follow-up Reason</p>
                    <p className="font-medium">{report.noFollowUpReason}</p>
                  </div>
                )}
                {updateNotes.length > 0 && (
                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wide">Update Notes</p>
                    <p className="font-medium">{updateNotes.length} note{updateNotes.length !== 1 ? "s" : ""}</p>
                  </div>
                )}
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
