import { StageOverview } from "./StageOverview";

export default function InstallStage() {
  return (
    <StageOverview
      stage="install"
      title="Install / Field"
      description="On-site installation and field work. Measurements, photos, and real-time job tracking."
    />
  );
}
