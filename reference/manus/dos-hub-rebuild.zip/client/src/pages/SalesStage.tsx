import { SalesStageContent } from "@/components/SalesStageContent";

export default function SalesStage() {
  return <SalesStageContent />;
}
