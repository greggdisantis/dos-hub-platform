import { useState, useEffect } from 'react';
import { useLocation, useParams } from 'wouter';
import { useAuth } from '@/_core/hooks/useAuth';
import { trpc } from '@/lib/trpc';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, Info, Plus, X } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

// ─── Types ───────────────────────────────────────────────────────────────────

type DealStatus =
  | "working-on-design"
  | "proposal-presented"
  | "actively-considering"
  | "awaiting-financing"
  | "waiting-on-design"
  | "delayed"
  | "lost"
  | "other"
  | "";

type CMRFormData = {
  // Step 1 — Appointment Details
  clientName: string;
  appointmentDate: string;
  appointmentType: "in-home" | "showroom" | "phone" | "";
  address: string;
  clientType: "residential" | "commercial" | "";
  // Phone conditional
  convertedToInPerson: boolean;
  convertedType: "in-home" | "showroom" | "";
  convertedDate: string;
  // Lead Sources
  leadSources: string[];
  leadSourceOther: string;
  referredClientName: string;
  contractorRefName: string;

  // Step 2 — Project Information
  projectTypes: string[];
  projectTypeOther: string;

  // Step 3 — Deal Status
  dealStatus: DealStatus;
  otherDealStatus: string;
  followUpDate: string;
  noFollowUpReason: string;
  proposalDate: string;
  lostReason: string;
  closeTimeline: "0-30" | "31-60" | "61-90" | "90plus" | "";
  summaryOfLastConversation: string;

  // Step 4 — Purchase Confidence
  purchaseConfidencePct: number;
  decisionMakersInvolved: string;
  mainMotivation: string;
  otherMainMotivation: string;
  mainHesitation: string;
  otherMainHesitation: string;
  pcNotes: string;

  // Step 5 — Financing & Value
  financingDiscussed: "yes" | "no" | "";
  financingReaction: "interested" | "needs-follow-up" | "declined" | "";
  valueCommunicated: string[];
  objectionNotes: string;
  clientResponse: "strong-alignment" | "neutral" | "price-focused" | "comparing-online" | "other" | "";
  otherClientResponse: string;
  // Kept for backward compat (old records may have this)
  objections: string[];

  // Step 6 — Next Steps
  nextActions: string[];
  otherNextAction: string;
  nextFollowUpDate: string;
  estimatedContractValue: number | null;

  // Status
  status: 'draft' | 'submitted' | 'approved';

  // Meeting Notes (prod-aligned fields)
  attendees: string[];
  notes: string;
  actionItems: Array<{ id: string; text: string; assignee?: string; dueDate?: string }>;
};

const INITIAL_FORM_DATA: CMRFormData = {
  clientName: "",
  appointmentDate: "",
  appointmentType: "",
  address: "",
  clientType: "",
  convertedToInPerson: false,
  convertedType: "",
  convertedDate: "",
  leadSources: [],
  leadSourceOther: "",
  referredClientName: "",
  contractorRefName: "",
  projectTypes: [],
  projectTypeOther: "",
  dealStatus: "",
  otherDealStatus: "",
  followUpDate: "",
  noFollowUpReason: "",
  proposalDate: "",
  lostReason: "",
  closeTimeline: "",
  summaryOfLastConversation: "",
  purchaseConfidencePct: 50,
  decisionMakersInvolved: "",
  mainMotivation: "",
  otherMainMotivation: "",
  mainHesitation: "",
  otherMainHesitation: "",
  pcNotes: "",
  financingDiscussed: "",
  financingReaction: "",
  valueCommunicated: [],
  objectionNotes: "",
  clientResponse: "",
  otherClientResponse: "",
  objections: [],
  nextActions: [],
  otherNextAction: "",
  nextFollowUpDate: "",
  estimatedContractValue: null,
  status: 'draft',
  // Meeting Notes
  attendees: [],
  notes: '',
  actionItems: [],
};

// ─── Constants ────────────────────────────────────────────────────────────────

const PROJECT_TYPES = [
  "Pergola (Attached)",
  "Pergola (Freestanding)",
  "Pergotenda",
  "Pavilion",
  "Motorized Screens",
  "Retractable Awning",
  "Umbrella",
  "Cabana",
  "Deck",
  "Patio",
  "Other",
];

const LEAD_SOURCES = [
  "Google",
  "Meta",
  "StruxUre Corp",
  "Progressive",
  "Home Show",
  "Corradi USA",
  "Contractor Ref",
  "Client Ref",
  "Sales Rep",
  "TV",
  "Other",
];

const VALUE_OPTIONS = [
  "Years in Business",
  "Permit Department",
  "Product Quality",
  "Full-Service Design/Permit/Install",
  "Showroom Experience",
  "Experienced Install Team",
  "Stability vs Online Sellers",
];

const NEXT_ACTIONS = [
  "Follow-Up Call",
  "Showroom Visit",
  "Design Meeting",
  "Proposal Review",
  "Other",
];

const MOTIVATION_OPTIONS = [
  "Improve outdoor enjoyment",
  "Entertain family and guests",
  "Shade / weather protection",
  "Upgrade patio / pool area",
  "Increase home value",
  "Improve aesthetics / curb appeal",
  "Create more usable space",
  "Replace an older structure",
  "Other",
];

const HESITATION_OPTIONS = [
  "Price",
  "HOA / Permits",
  "Timing",
  "Decision Maker Not Present",
  "Financing",
  "Competitors",
  "Other",
];

const TOTAL_STEPS = 9;

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatCurrency(value: number | null): string {
  if (value === null || value === undefined) return "";
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
}

function parseCurrencyInput(raw: string): number | null {
  const cleaned = raw.replace(/[^0-9.]/g, "");
  const parsed = parseFloat(cleaned);
  return isNaN(parsed) ? null : Math.round(parsed);
}

function formatDateString(val: unknown): string {
  if (!val) return "";
  if (typeof val === "string") return val.split("T")[0];
  if (val instanceof Date) return val.toISOString().split("T")[0];
  return "";
}

// ─── Component ────────────────────────────────────────────────────────────────

export function CMRFormNew() {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<CMRFormData>(INITIAL_FORM_DATA);
  const [savedId, setSavedId] = useState<number | null>(null);
  const [newNoteText, setNewNoteText] = useState("");
  const [currencyDisplay, setCurrencyDisplay] = useState("");
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const params = useParams<{ id?: string }>();
  const cmrId = params?.id ? parseInt(params.id) : null;

  const createMutation = trpc.cmr.create.useMutation();
  const addNoteMutation = trpc.cmr.addUpdateNote.useMutation();
  const utils = trpc.useUtils();

  const { data: existingCMR, isLoading: isLoadingCMR, refetch: refetchCMR } = trpc.cmr.get.useQuery(
    { reportId: cmrId! },
    { enabled: !!cmrId }
  );

  // Load existing CMR data when editing
  useEffect(() => {
    if (existingCMR) {
      const d = existingCMR;
      const ecv = d.estimatedContractValue ? Number(d.estimatedContractValue) : null;
      setFormData({
        clientName: d.clientName || "",
        appointmentDate: formatDateString(d.appointmentDate),
        appointmentType: (d.appointmentType as CMRFormData["appointmentType"]) || "",
        address: d.address || "",
        clientType: (d.clientType as CMRFormData["clientType"]) || "",
        convertedToInPerson: d.convertedToInPerson === 1,
        convertedType: (d.convertedType as CMRFormData["convertedType"]) || "",
        convertedDate: formatDateString(d.convertedDate),
        leadSources: d.leadSources || [],
        leadSourceOther: (d as any).leadSourceOther || "",
        referredClientName: (d as any).referredClientName || "",
        contractorRefName: (d as any).contractorRefName || "",
        projectTypes: d.projectTypes || [],
        projectTypeOther: (d as any).projectTypeOther || "",
        dealStatus: (d.dealStatus as DealStatus) || "",
        otherDealStatus: (d as any).otherDealStatus || "",
        followUpDate: formatDateString(d.followUpDate),
        noFollowUpReason: d.noFollowUpReason || "",
        proposalDate: formatDateString(d.proposalDate),
        lostReason: d.lostReason || "",
        closeTimeline: (d.closeTimeline as CMRFormData["closeTimeline"]) || "",
        summaryOfLastConversation: d.lastConversationSummary || "",
        purchaseConfidencePct: d.purchaseConfidencePct || 50,
        decisionMakersInvolved: d.decisionMakers || "",
        mainMotivation: d.mainMotivation || "",
        otherMainMotivation: (d as any).otherMainMotivation || "",
        mainHesitation: d.mainHesitation || "",
        otherMainHesitation: (d as any).otherMainHesitation || "",
        pcNotes: d.pcNotes || "",
        financingDiscussed: d.financingDiscussed === 1 ? "yes" : d.financingDiscussed === 0 ? "no" : "",
        financingReaction: (d.financingReaction as CMRFormData["financingReaction"]) || "",
        valueCommunicated: d.valueCommunicated || [],
        objectionNotes: d.objectionNotes || "",
        clientResponse: (d.clientResponse as CMRFormData["clientResponse"]) || "",
        otherClientResponse: (d as any).otherClientResponse || "",
        objections: d.objections || [],
        nextActions: d.nextActions || [],
        otherNextAction: (d as any).otherNextAction || "",
        nextFollowUpDate: formatDateString(d.nextFollowUpDate),
        estimatedContractValue: ecv,
        status: (d.status as CMRFormData["status"]) || "draft",
        // Meeting Notes
        attendees: (d.attendees as string[]) || [],
        notes: d.notes || '',
        actionItems: (d.actionItems as CMRFormData["actionItems"]) || [],
      });
      setSavedId(d.id);
      if (ecv !== null) setCurrencyDisplay(formatCurrency(ecv));
    }
  }, [existingCMR]);

  if (isLoadingCMR) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin mx-auto mb-2" />
          <p>Loading CMR report...</p>
        </div>
      </div>
    );
  }

  // ─── Handlers ───────────────────────────────────────────────────────────────

  const set = (field: keyof CMRFormData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const toggleArray = (field: "projectTypes" | "leadSources" | "valueCommunicated" | "objections" | "nextActions", value: string) => {
    setFormData((prev) => {
      const current = prev[field] as string[];
      return {
        ...prev,
        [field]: current.includes(value) ? current.filter((i) => i !== value) : [...current, value],
      };
    });
  };

  const buildPayload = (submitStatus: 'draft' | 'submitted') => ({
    clientName: formData.clientName,
    appointmentDate: formData.appointmentDate,
    appointmentType: formData.appointmentType || undefined,
    address: formData.address || undefined,
    clientType: formData.clientType || undefined,
    convertedToInPerson: formData.convertedToInPerson,
    convertedType: formData.convertedType || undefined,
    convertedDate: formData.convertedDate || undefined,
    leadSources: formData.leadSources.length > 0 ? formData.leadSources : undefined,
    leadSourceOther: formData.leadSourceOther || undefined,
    referredClientName: formData.referredClientName || undefined,
    contractorRefName: formData.contractorRefName || undefined,
    projectTypes: formData.projectTypes.length > 0 ? formData.projectTypes : undefined,
    projectTypeOther: formData.projectTypeOther || undefined,
    dealStatus: formData.dealStatus || undefined,
    otherDealStatus: formData.otherDealStatus || undefined,
    followUpDate: formData.followUpDate || undefined,
    noFollowUpReason: formData.noFollowUpReason || undefined,
    proposalDate: formData.proposalDate || undefined,
    lostReason: formData.lostReason || undefined,
    closeTimeline: formData.closeTimeline || undefined,
    summaryOfLastConversation: formData.summaryOfLastConversation || undefined,
    purchaseConfidencePct: formData.purchaseConfidencePct,
    decisionMakersInvolved: formData.decisionMakersInvolved || undefined,
    mainMotivation: formData.mainMotivation || undefined,
    otherMainMotivation: formData.otherMainMotivation || undefined,
    mainHesitation: formData.mainHesitation || undefined,
    otherMainHesitation: formData.otherMainHesitation || undefined,
    pcNotes: formData.pcNotes || undefined,
    financingDiscussed: formData.financingDiscussed === "yes" ? true : formData.financingDiscussed === "no" ? false : undefined,
    financingReaction: formData.financingReaction || undefined,
    valueCommunicated: formData.valueCommunicated.length > 0 ? formData.valueCommunicated : undefined,
    objectionNotes: formData.objectionNotes || undefined,
    clientResponse: formData.clientResponse || undefined,
    otherClientResponse: formData.otherClientResponse || undefined,
    objections: formData.objections.length > 0 ? formData.objections : undefined,
    nextActions: formData.nextActions.length > 0 ? formData.nextActions : undefined,
    otherNextAction: formData.otherNextAction || undefined,
    nextFollowUpDate: formData.nextFollowUpDate || undefined,
    estimatedContractValue: formData.estimatedContractValue || undefined,
    status: submitStatus,
    // Meeting Notes
    attendees: formData.attendees.length > 0 ? formData.attendees : undefined,
    notes: formData.notes || undefined,
    actionItems: formData.actionItems.length > 0 ? formData.actionItems : undefined,
  });

  const handleSaveDraft = async () => {
    try {
      const result = await createMutation.mutateAsync(buildPayload('draft'));
      setSavedId(result.id);
      alert(`Saved as draft. ID: ${result.id}`);
    } catch (error) {
      console.error('Failed to save draft:', error);
      alert('Failed to save draft');
    }
  };

  const handleSubmit = async () => {
    try {
      const result = await createMutation.mutateAsync(buildPayload('submitted'));
      setSavedId(result.id);
      alert(`Submitted successfully. ID: ${result.id}`);
      setLocation('/dashboard/cmr');
    } catch (error) {
      console.error('Failed to submit:', error);
      alert('Failed to submit');
    }
  };

  const handleAddNote = async () => {
    if (!newNoteText.trim() || !savedId) return;
    try {
      await addNoteMutation.mutateAsync({ reportId: savedId, note: newNoteText.trim() });
      setNewNoteText("");
      refetchCMR();
    } catch (error) {
      console.error('Failed to add note:', error);
      alert('Failed to add note');
    }
  };

  // ─── Derived state ───────────────────────────────────────────────────────────

  const progressPercentage = (currentStep / TOTAL_STEPS) * 100;
  const isLastStep = currentStep === TOTAL_STEPS;

  const stepTitles = [
    "Appointment Details",
    "Project Information",
    "Deal Status",
    "Purchase Confidence",
    "Financing & Value",
    "Next Steps",
    "Meeting Notes",
    "Latest Notes",
    "Review & Submit",
  ];

  // Parse update notes from existing CMR
  let updateNotes: Array<{ note: string; createdAt: string; createdBy: string }> = [];
  if (existingCMR?.updateNotes) {
    try {
      updateNotes = typeof existingCMR.updateNotes === 'string'
        ? JSON.parse(existingCMR.updateNotes)
        : (existingCMR.updateNotes as typeof updateNotes);
    } catch { updateNotes = []; }
  }

  // ─── Render ──────────────────────────────────────────────────────────────────

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-background p-4">
        <Card className="max-w-4xl mx-auto">
          <CardHeader>
            <CardTitle>Client Meeting Report</CardTitle>
            <CardDescription>
              Step {currentStep} of {TOTAL_STEPS} — {stepTitles[currentStep - 1]}
            </CardDescription>
            <div className="w-full bg-secondary h-2 rounded-full mt-4 overflow-hidden">
              <div
                className="bg-primary h-full transition-all duration-300"
                style={{ width: `${progressPercentage}%` }}
              />
            </div>
          </CardHeader>

          <CardContent className="space-y-6">

            {/* ── STEP 1: Appointment Details ── */}
            {currentStep === 1 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Appointment Details</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="clientName">Client Name *</Label>
                    <Input id="clientName" value={formData.clientName} onChange={(e) => set('clientName', e.target.value)} placeholder="Enter client name" />
                  </div>
                  <div>
                    <Label htmlFor="appointmentDate">Appointment Date *</Label>
                    <Input id="appointmentDate" type="date" value={formData.appointmentDate} onChange={(e) => set('appointmentDate', e.target.value)} />
                  </div>
                  <div>
                    <Label htmlFor="appointmentType">Appointment Type</Label>
                    <Select value={formData.appointmentType} onValueChange={(v: any) => set('appointmentType', v)}>
                      <SelectTrigger id="appointmentType"><SelectValue placeholder="Select type" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="in-home">In-Home</SelectItem>
                        <SelectItem value="showroom">Showroom</SelectItem>
                        <SelectItem value="phone">Phone</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="address">Address</Label>
                    <Input id="address" value={formData.address} onChange={(e) => set('address', e.target.value)} placeholder="Enter address" />
                  </div>
                  <div>
                    <Label htmlFor="clientType">Client Type</Label>
                    <Select value={formData.clientType} onValueChange={(v: any) => set('clientType', v)}>
                      <SelectTrigger id="clientType"><SelectValue placeholder="Select type" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="residential">Residential</SelectItem>
                        <SelectItem value="commercial">Commercial</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Phone → Converted to In-Person */}
                {formData.appointmentType === "phone" && (
                  <div className="border rounded-lg p-4 space-y-4 bg-muted/30">
                    <h4 className="font-medium text-sm">Phone Appointment Follow-Up</h4>
                    <div>
                      <Label>Converted to In-Person?</Label>
                      <div className="flex gap-4 mt-2">
                        <div className="flex items-center gap-2">
                          <input type="radio" id="conv-no" name="convertedToInPerson" checked={!formData.convertedToInPerson} onChange={() => set('convertedToInPerson', false)} />
                          <label htmlFor="conv-no" className="text-sm cursor-pointer">No</label>
                        </div>
                        <div className="flex items-center gap-2">
                          <input type="radio" id="conv-yes" name="convertedToInPerson" checked={formData.convertedToInPerson} onChange={() => set('convertedToInPerson', true)} />
                          <label htmlFor="conv-yes" className="text-sm cursor-pointer">Yes</label>
                        </div>
                      </div>
                    </div>
                    {formData.convertedToInPerson && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label>In-Person Type</Label>
                          <Select value={formData.convertedType} onValueChange={(v: any) => set('convertedType', v)}>
                            <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="in-home">In-Home</SelectItem>
                              <SelectItem value="showroom">Showroom</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>In-Person Appointment Date</Label>
                          <Input type="date" value={formData.convertedDate} onChange={(e) => set('convertedDate', e.target.value)} />
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Lead Sources */}
                <div>
                  <Label>Lead Sources</Label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-2">
                    {LEAD_SOURCES.map((source) => (
                      <div key={source} className="flex items-center space-x-2">
                        <Checkbox id={`lead-${source}`} checked={formData.leadSources.includes(source)} onCheckedChange={() => toggleArray('leadSources', source)} />
                        <label htmlFor={`lead-${source}`} className="text-sm cursor-pointer">{source}</label>
                      </div>
                    ))}
                  </div>
                  {/* Conditional text fields */}
                  {formData.leadSources.includes("Other") && (
                    <div className="mt-3">
                      <Label htmlFor="leadSourceOther">Other Lead Source</Label>
                      <Input id="leadSourceOther" value={formData.leadSourceOther} onChange={(e) => set('leadSourceOther', e.target.value)} placeholder="Describe other lead source" />
                    </div>
                  )}
                  {formData.leadSources.includes("Client Ref") && (
                    <div className="mt-3">
                      <Label htmlFor="referredClientName">Referred Client Name</Label>
                      <Input id="referredClientName" value={formData.referredClientName} onChange={(e) => set('referredClientName', e.target.value)} placeholder="Enter referring client's name" />
                    </div>
                  )}
                  {formData.leadSources.includes("Contractor Ref") && (
                    <div className="mt-3">
                      <Label htmlFor="contractorRefName">Referring Contractor Name</Label>
                      <Input id="contractorRefName" value={formData.contractorRefName} onChange={(e) => set('contractorRefName', e.target.value)} placeholder="Enter referring contractor's name" />
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ── STEP 2: Project Information ── */}
            {currentStep === 2 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Project Information</h3>
                <div>
                  <Label>Project Types</Label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-2">
                    {PROJECT_TYPES.map((type) => (
                      <div key={type} className="flex items-center space-x-2">
                        <Checkbox id={`project-${type}`} checked={formData.projectTypes.includes(type)} onCheckedChange={() => toggleArray('projectTypes', type)} />
                        <label htmlFor={`project-${type}`} className="text-sm cursor-pointer">{type}</label>
                      </div>
                    ))}
                  </div>
                  {formData.projectTypes.includes("Other") && (
                    <div className="mt-3">
                      <Label htmlFor="projectTypeOther">Other Project Type</Label>
                      <Input id="projectTypeOther" value={formData.projectTypeOther} onChange={(e) => set('projectTypeOther', e.target.value)} placeholder="Describe other project type" />
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ── STEP 3: Deal Status ── */}
            {currentStep === 3 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Deal Status</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="dealStatus">Deal Status</Label>
                    <Select value={formData.dealStatus} onValueChange={(v: any) => set('dealStatus', v)}>
                      <SelectTrigger id="dealStatus"><SelectValue placeholder="Select status" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="working-on-design">Working on Design</SelectItem>
                        <SelectItem value="proposal-presented">Proposal Presented</SelectItem>
                        <SelectItem value="actively-considering">Actively Considering</SelectItem>
                        <SelectItem value="awaiting-financing">Awaiting Financing</SelectItem>
                        <SelectItem value="waiting-on-design">Waiting on Design</SelectItem>
                        <SelectItem value="delayed">Delayed</SelectItem>
                        <SelectItem value="lost">Lost</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="followUpDate">Follow-Up Date</Label>
                    <Input id="followUpDate" type="date" value={formData.followUpDate} onChange={(e) => set('followUpDate', e.target.value)} />
                  </div>
                  <div>
                    <Label htmlFor="closeTimeline">Estimated Close Timeline</Label>
                    <Select value={formData.closeTimeline} onValueChange={(v: any) => set('closeTimeline', v)}>
                      <SelectTrigger id="closeTimeline"><SelectValue placeholder="Select timeline" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="0-30">0–30 days</SelectItem>
                        <SelectItem value="31-60">31–60 days</SelectItem>
                        <SelectItem value="61-90">61–90 days</SelectItem>
                        <SelectItem value="90plus">90+ days</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="noFollowUpReason">No Follow-Up Reason</Label>
                    <Input id="noFollowUpReason" value={formData.noFollowUpReason} onChange={(e) => set('noFollowUpReason', e.target.value)} placeholder="If no follow-up, explain why" />
                  </div>
                </div>

                {/* Deal Status conditionals */}
                {formData.dealStatus === "other" && (
                  <div>
                    <Label htmlFor="otherDealStatus">Other Deal Status</Label>
                    <Input id="otherDealStatus" value={formData.otherDealStatus} onChange={(e) => set('otherDealStatus', e.target.value)} placeholder="Describe deal status" />
                  </div>
                )}
                {formData.dealStatus === "proposal-presented" && (
                  <div>
                    <Label htmlFor="proposalDate">Proposal Presented Date</Label>
                    <Input id="proposalDate" type="date" value={formData.proposalDate} onChange={(e) => set('proposalDate', e.target.value)} />
                  </div>
                )}
                {formData.dealStatus === "lost" && (
                  <div>
                    <Label htmlFor="lostReason">Lost Reason</Label>
                    <Input id="lostReason" value={formData.lostReason} onChange={(e) => set('lostReason', e.target.value)} placeholder="Why was this deal lost?" />
                  </div>
                )}

                <div>
                  <Label htmlFor="summaryOfLastConversation">Summary of Last Conversation</Label>
                  <Textarea id="summaryOfLastConversation" value={formData.summaryOfLastConversation} onChange={(e) => set('summaryOfLastConversation', e.target.value)} placeholder="Enter summary" rows={4} />
                </div>
              </div>
            )}

            {/* ── STEP 4: Purchase Confidence ── */}
            {currentStep === 4 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Purchase Confidence / Client Read</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="purchaseConfidencePct">Purchase Confidence %</Label>
                    <Input id="purchaseConfidencePct" type="number" min="0" max="100" value={formData.purchaseConfidencePct} onChange={(e) => set('purchaseConfidencePct', parseInt(e.target.value) || 0)} />
                  </div>
                  <div>
                    <Label htmlFor="decisionMakersInvolved">Decision Makers Involved</Label>
                    <Input id="decisionMakersInvolved" value={formData.decisionMakersInvolved} onChange={(e) => set('decisionMakersInvolved', e.target.value)} placeholder="Enter decision makers" />
                  </div>
                </div>

                {/* Main Motivation */}
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Label>Main Motivation</Label>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Info className="w-4 h-4 text-muted-foreground cursor-help" />
                      </TooltipTrigger>
                      <TooltipContent className="max-w-xs">
                        This is the primary reason the client wants to move forward with the project right now.
                      </TooltipContent>
                    </Tooltip>
                  </div>
                  <Select value={formData.mainMotivation} onValueChange={(v) => set('mainMotivation', v)}>
                    <SelectTrigger><SelectValue placeholder="Select main motivation" /></SelectTrigger>
                    <SelectContent>
                      {MOTIVATION_OPTIONS.map((opt) => (
                        <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {/* Show free-text if old record has a value not in the list */}
                  {formData.mainMotivation && !MOTIVATION_OPTIONS.includes(formData.mainMotivation) && (
                    <p className="text-sm text-muted-foreground mt-1">Legacy value: <em>{formData.mainMotivation}</em></p>
                  )}
                  {formData.mainMotivation === "Other" && (
                    <div className="mt-2">
                      <Label htmlFor="otherMainMotivation">Other Main Motivation</Label>
                      <Input id="otherMainMotivation" value={formData.otherMainMotivation} onChange={(e) => set('otherMainMotivation', e.target.value)} placeholder="Describe motivation" />
                    </div>
                  )}
                </div>

                {/* Main Hesitation */}
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Label>Main Hesitation / Objection</Label>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Info className="w-4 h-4 text-muted-foreground cursor-help" />
                      </TooltipTrigger>
                      <TooltipContent className="max-w-xs">
                        This is the main reason the client is hesitant, delaying, or unsure about moving forward.
                      </TooltipContent>
                    </Tooltip>
                  </div>
                  <Select value={formData.mainHesitation} onValueChange={(v) => set('mainHesitation', v)}>
                    <SelectTrigger><SelectValue placeholder="Select main hesitation" /></SelectTrigger>
                    <SelectContent>
                      {HESITATION_OPTIONS.map((opt) => (
                        <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {formData.mainHesitation && !HESITATION_OPTIONS.includes(formData.mainHesitation) && (
                    <p className="text-sm text-muted-foreground mt-1">Legacy value: <em>{formData.mainHesitation}</em></p>
                  )}
                  {formData.mainHesitation === "Other" && (
                    <div className="mt-2">
                      <Label htmlFor="otherMainHesitation">Other Main Hesitation / Objection</Label>
                      <Input id="otherMainHesitation" value={formData.otherMainHesitation} onChange={(e) => set('otherMainHesitation', e.target.value)} placeholder="Describe hesitation" />
                    </div>
                  )}
                </div>

                <div>
                  <Label htmlFor="pcNotes">PC Notes (Minimum 3 Sentences)</Label>
                  <Textarea id="pcNotes" value={formData.pcNotes} onChange={(e) => set('pcNotes', e.target.value)} placeholder="Enter detailed notes about purchase confidence" rows={4} />
                </div>
              </div>
            )}

            {/* ── STEP 5: Financing & Value ── */}
            {currentStep === 5 && (
              <div className="space-y-6">
                {/* Section 1: Financing */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold border-b pb-2">Financing</h3>
                  <div>
                    <Label>Financing Discussed?</Label>
                    <div className="flex gap-4 mt-2">
                      <div className="flex items-center gap-2">
                        <input type="radio" id="fin-yes" name="financingDiscussed" checked={formData.financingDiscussed === "yes"} onChange={() => set('financingDiscussed', 'yes')} />
                        <label htmlFor="fin-yes" className="text-sm cursor-pointer">Yes</label>
                      </div>
                      <div className="flex items-center gap-2">
                        <input type="radio" id="fin-no" name="financingDiscussed" checked={formData.financingDiscussed === "no"} onChange={() => set('financingDiscussed', 'no')} />
                        <label htmlFor="fin-no" className="text-sm cursor-pointer">No</label>
                      </div>
                    </div>
                  </div>
                  {formData.financingDiscussed === "yes" && (
                    <div>
                      <Label htmlFor="financingReaction">Client Reaction to Financing</Label>
                      <Select value={formData.financingReaction} onValueChange={(v: any) => set('financingReaction', v)}>
                        <SelectTrigger id="financingReaction"><SelectValue placeholder="Select reaction" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="interested">Interested</SelectItem>
                          <SelectItem value="needs-follow-up">Needs Follow-Up</SelectItem>
                          <SelectItem value="declined">Declined</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>

                {/* Section 2: Value Communicated */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold border-b pb-2">Value Communicated</h3>
                  <p className="text-sm text-muted-foreground">Select all items that you discussed with the client.</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {VALUE_OPTIONS.map((value) => (
                      <div key={value} className="flex items-center space-x-2">
                        <Checkbox id={`value-${value}`} checked={formData.valueCommunicated.includes(value)} onCheckedChange={() => toggleArray('valueCommunicated', value)} />
                        <label htmlFor={`value-${value}`} className="text-sm cursor-pointer">{value}</label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Objection Notes */}
                <div>
                  <Label htmlFor="objectionNotes">Objection Notes</Label>
                  <Textarea id="objectionNotes" value={formData.objectionNotes} onChange={(e) => set('objectionNotes', e.target.value)} placeholder="Notes about client objections" rows={3} />
                </div>

                {/* Client Response */}
                <div>
                  <Label htmlFor="clientResponse">Client Response</Label>
                  <Select value={formData.clientResponse} onValueChange={(v: any) => set('clientResponse', v)}>
                    <SelectTrigger id="clientResponse"><SelectValue placeholder="Select client response" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="strong-alignment">Strong Alignment</SelectItem>
                      <SelectItem value="neutral">Neutral</SelectItem>
                      <SelectItem value="price-focused">Price Focused</SelectItem>
                      <SelectItem value="comparing-online">Comparing Online</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  {formData.clientResponse === "other" && (
                    <div className="mt-2">
                      <Label htmlFor="otherClientResponse">Other Client Response</Label>
                      <Input id="otherClientResponse" value={formData.otherClientResponse} onChange={(e) => set('otherClientResponse', e.target.value)} placeholder="Describe client response" />
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ── STEP 6: Next Steps ── */}
            {currentStep === 6 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Next Steps</h3>
                <div>
                  <Label>Next Actions</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-2">
                    {NEXT_ACTIONS.map((action) => (
                      <div key={action} className="flex items-center space-x-2">
                        <Checkbox id={`action-${action}`} checked={formData.nextActions.includes(action)} onCheckedChange={() => toggleArray('nextActions', action)} />
                        <label htmlFor={`action-${action}`} className="text-sm cursor-pointer">{action}</label>
                      </div>
                    ))}
                  </div>
                  {formData.nextActions.includes("Other") && (
                    <div className="mt-3">
                      <Label htmlFor="otherNextAction">Other Next Action</Label>
                      <Input id="otherNextAction" value={formData.otherNextAction} onChange={(e) => set('otherNextAction', e.target.value)} placeholder="Describe other next action" />
                    </div>
                  )}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="nextFollowUpDate">Next Follow-Up Date</Label>
                    <Input id="nextFollowUpDate" type="date" value={formData.nextFollowUpDate} onChange={(e) => set('nextFollowUpDate', e.target.value)} />
                  </div>
                  <div>
                    <Label htmlFor="estimatedContractValue">Estimated Contract Value</Label>
                    <Input
                      id="estimatedContractValue"
                      type="text"
                      value={currencyDisplay}
                      onChange={(e) => {
                        const raw = e.target.value;
                        setCurrencyDisplay(raw);
                        set('estimatedContractValue', parseCurrencyInput(raw));
                      }}
                      onBlur={() => {
                        if (formData.estimatedContractValue !== null) {
                          setCurrencyDisplay(formatCurrency(formData.estimatedContractValue));
                        }
                      }}
                      onFocus={() => {
                        if (formData.estimatedContractValue !== null) {
                          setCurrencyDisplay(String(formData.estimatedContractValue));
                        }
                      }}
                      placeholder="$0"
                    />
                    {formData.estimatedContractValue !== null && (
                      <p className="text-xs text-muted-foreground mt-1">
                        Stored as: {formatCurrency(formData.estimatedContractValue)}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* ── STEP 7: Meeting Notes ── */}
            {currentStep === 7 && (
              <div className="space-y-6">
                <h3 className="text-lg font-semibold">Meeting Notes</h3>
                <p className="text-sm text-muted-foreground">
                  Record who attended, any general notes from the meeting, and follow-up action items.
                </p>

                {/* Attendees */}
                <div className="space-y-3">
                  <Label>Attendees</Label>
                  <p className="text-xs text-muted-foreground">Add each person who attended the meeting.</p>
                  <div className="flex gap-2">
                    <Input
                      id="newAttendee"
                      placeholder="Name or role (e.g. John Smith, Designer)"
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          const val = (e.target as HTMLInputElement).value.trim();
                          if (val && !formData.attendees.includes(val)) {
                            set('attendees', [...formData.attendees, val]);
                            (e.target as HTMLInputElement).value = '';
                          }
                        }
                      }}
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={() => {
                        const input = document.getElementById('newAttendee') as HTMLInputElement;
                        const val = input?.value.trim();
                        if (val && !formData.attendees.includes(val)) {
                          set('attendees', [...formData.attendees, val]);
                          input.value = '';
                        }
                      }}
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  {formData.attendees.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {formData.attendees.map((a, i) => (
                        <span key={i} className="inline-flex items-center gap-1 bg-secondary text-secondary-foreground text-sm px-3 py-1 rounded-full">
                          {a}
                          <button type="button" onClick={() => set('attendees', formData.attendees.filter((_, idx) => idx !== i))} className="hover:text-destructive">
                            <X className="w-3 h-3" />
                          </button>
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Meeting Notes */}
                <div className="space-y-2">
                  <Label htmlFor="meetingNotes">Meeting Notes</Label>
                  <Textarea
                    id="meetingNotes"
                    value={formData.notes}
                    onChange={(e) => set('notes', e.target.value)}
                    placeholder="General notes from the meeting..."
                    rows={4}
                  />
                </div>

                {/* Action Items */}
                <div className="space-y-3">
                  <Label>Action Items</Label>
                  <p className="text-xs text-muted-foreground">Track follow-up tasks from this meeting.</p>
                  <div className="flex gap-2">
                    <Input
                      id="newActionItem"
                      placeholder="Action item description"
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          const val = (e.target as HTMLInputElement).value.trim();
                          if (val) {
                            set('actionItems', [...formData.actionItems, { id: crypto.randomUUID(), text: val }]);
                            (e.target as HTMLInputElement).value = '';
                          }
                        }
                      }}
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="icon"
                      onClick={() => {
                        const input = document.getElementById('newActionItem') as HTMLInputElement;
                        const val = input?.value.trim();
                        if (val) {
                          set('actionItems', [...formData.actionItems, { id: crypto.randomUUID(), text: val }]);
                          input.value = '';
                        }
                      }}
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  {formData.actionItems.length > 0 && (
                    <div className="space-y-2">
                      {formData.actionItems.map((item, i) => (
                        <div key={item.id} className="flex items-start gap-2 border rounded-lg p-3 bg-muted/20">
                          <div className="flex-1 space-y-1">
                            <p className="text-sm">{item.text}</p>
                            <div className="flex gap-2">
                              <Input
                                placeholder="Assignee (optional)"
                                value={item.assignee || ''}
                                onChange={(e) => {
                                  const updated = [...formData.actionItems];
                                  updated[i] = { ...updated[i], assignee: e.target.value };
                                  set('actionItems', updated);
                                }}
                                className="h-7 text-xs"
                              />
                              <Input
                                type="date"
                                value={item.dueDate || ''}
                                onChange={(e) => {
                                  const updated = [...formData.actionItems];
                                  updated[i] = { ...updated[i], dueDate: e.target.value };
                                  set('actionItems', updated);
                                }}
                                className="h-7 text-xs"
                              />
                            </div>
                          </div>
                          <button type="button" onClick={() => set('actionItems', formData.actionItems.filter((_, idx) => idx !== i))} className="text-muted-foreground hover:text-destructive mt-1">
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* ── STEP 8: Latest Notes ── */}
            {currentStep === 8 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Latest Notes</h3>
                <p className="text-sm text-muted-foreground">
                  Add a note to this report. Notes are timestamped and visible on the CMR list and detail page.
                </p>

                {/* Add new note */}
                <div className="space-y-2">
                  <Label htmlFor="newNote">Add New Note</Label>
                  <Textarea
                    id="newNote"
                    value={newNoteText}
                    onChange={(e) => setNewNoteText(e.target.value)}
                    placeholder="Enter update note..."
                    rows={3}
                  />
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={handleAddNote}
                    disabled={!newNoteText.trim() || !savedId || addNoteMutation.isPending}
                  >
                    {addNoteMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                    {savedId ? "Add Note" : "Save draft first to add notes"}
                  </Button>
                  {!savedId && (
                    <p className="text-xs text-amber-600">Save this report as a draft first, then you can add notes here.</p>
                  )}
                </div>

                {/* Note history */}
                {updateNotes.length > 0 ? (
                  <div className="space-y-3">
                    <h4 className="text-sm font-medium text-muted-foreground">Note History (newest first)</h4>
                    {updateNotes.map((note, idx) => (
                      <div key={idx} className="border rounded-lg p-3 bg-muted/20">
                        <p className="text-sm">{note.note}</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          {new Date(note.createdAt).toLocaleString()} — {note.createdBy}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-sm text-muted-foreground border rounded-lg p-4 text-center">
                    No notes yet. Add the first note above.
                  </div>
                )}
              </div>
            )}

            {/* ── STEP 9: Review & Submit ── */}
            {currentStep === 9 && (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Review & Submit</h3>
                <Card className="bg-secondary">
                  <CardContent className="pt-6 space-y-2">
                    <p><strong>{formData.clientName}</strong></p>
                    <p className="text-sm text-muted-foreground">{formData.appointmentType} • {formData.appointmentDate || '—'}</p>
                    <p className="text-sm text-muted-foreground">Address: {formData.address || '—'}</p>
                    <p className="text-sm text-muted-foreground">Client Type: {formData.clientType || '—'}</p>
                    <p className="text-sm text-muted-foreground">Lead Sources: {formData.leadSources.join(', ') || '—'}</p>
                    <p className="text-sm text-muted-foreground">Project Types: {formData.projectTypes.join(', ') || '—'}</p>
                    <p className="text-sm text-muted-foreground">Deal Status: {formData.dealStatus || '—'}{formData.dealStatus === 'other' && formData.otherDealStatus ? ` (${formData.otherDealStatus})` : ''}</p>
                    <p className="text-sm text-muted-foreground">PC %: {formData.purchaseConfidencePct}%</p>
                    <p className="text-sm text-muted-foreground">Estimated Value: {formData.estimatedContractValue ? formatCurrency(formData.estimatedContractValue) : '—'}</p>
                    <p className="text-sm text-muted-foreground">Next Follow-Up: {formData.nextFollowUpDate || '—'}</p>
                    <p className="text-sm text-muted-foreground">Notes: {updateNotes.length} note(s)</p>
                  </CardContent>
                </Card>
                <p className="text-sm text-muted-foreground">
                  Click Submit to finalize this report. The original PC % will be locked after submission.
                </p>
                {savedId && (
                  <div className="bg-green-50 border border-green-200 rounded p-3">
                    <p className="text-sm text-green-800">✓ Saved as ID: {savedId}</p>
                  </div>
                )}
              </div>
            )}

            {/* ── Navigation ── */}
            <div className="flex justify-between pt-6 border-t">
              <Button
                variant="outline"
                onClick={() => setCurrentStep(Math.max(1, currentStep - 1))}
                disabled={currentStep === 1}
              >
                Previous
              </Button>

              <div className="flex gap-2">
                <Button
                  variant="secondary"
                  onClick={handleSaveDraft}
                  disabled={createMutation.isPending}
                >
                  {createMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                  Save Draft
                </Button>

                {!isLastStep ? (
                  <Button onClick={() => setCurrentStep(Math.min(TOTAL_STEPS, currentStep + 1))}>
                    Next
                  </Button>
                ) : (
                  <Button
                    onClick={handleSubmit}
                    disabled={createMutation.isPending}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    {createMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                    Submit
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </TooltipProvider>
  );
}
