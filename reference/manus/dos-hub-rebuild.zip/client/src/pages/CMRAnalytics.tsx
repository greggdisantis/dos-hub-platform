import { useMemo, useState } from "react";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, TrendingUp, DollarSign, Users, Target, CheckCircle, XCircle, Clock } from "lucide-react";

// ─── Types ───────────────────────────────────────────────────────────────────

interface CMRReport {
  id: number;
  clientName: string;
  consultantName?: string;
  userId: number;
  status: string;
  purchaseConfidencePct?: number;
  originalPcPct?: number;
  currentConfidencePct?: number;
  estimatedValue?: string | null;
  closedAmount?: string | null;
  appointmentResult?: string | null;
  dealStatus?: string | null;
  appointmentType?: string | null;
  leadSources?: string[] | null;
  projectTypes?: string[] | null;
  createdAt?: string | Date | null;
  outcome?: string | null;
}

interface Props {
  reports: CMRReport[];
  allUsers: any[];
  isLoading: boolean;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function toNum(v: any): number {
  if (v === null || v === undefined || v === "") return 0;
  const n = typeof v === "string" ? parseFloat(v) : Number(v);
  return isNaN(n) ? 0 : n;
}

function formatCurrency(v: number): string {
  return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(v);
}

function pct(part: number, total: number): string {
  if (total === 0) return "0%";
  return `${Math.round((part / total) * 100)}%`;
}

// ─── Stat Card ────────────────────────────────────────────────────────────────

function StatCard({ label, value, sub, icon: Icon, color = "text-primary" }: {
  label: string; value: string | number; sub?: string; icon: any; color?: string;
}) {
  return (
    <Card className="p-4 flex items-start gap-3">
      <div className={`mt-1 ${color}`}><Icon className="w-5 h-5" /></div>
      <div>
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-xl font-bold">{value}</p>
        {sub && <p className="text-xs text-muted-foreground">{sub}</p>}
      </div>
    </Card>
  );
}

// ─── Bar Chart (pure CSS) ─────────────────────────────────────────────────────

function BarChart({ data, title }: { data: { label: string; value: number; color?: string }[]; title: string }) {
  const max = Math.max(...data.map(d => d.value), 1);
  return (
    <Card className="p-4">
      <p className="text-sm font-semibold mb-3">{title}</p>
      <div className="space-y-2">
        {data.map(({ label, value, color = "bg-primary" }) => (
          <div key={label} className="flex items-center gap-2 text-sm">
            <span className="w-36 text-xs text-muted-foreground truncate">{label}</span>
            <div className="flex-1 bg-muted rounded-full h-4 overflow-hidden">
              <div
                className={`h-full rounded-full transition-all ${color}`}
                style={{ width: `${(value / max) * 100}%` }}
              />
            </div>
            <span className="w-8 text-right text-xs font-medium">{value}</span>
          </div>
        ))}
        {data.length === 0 && <p className="text-xs text-muted-foreground">No data</p>}
      </div>
    </Card>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function CMRAnalytics({ reports, allUsers, isLoading }: Props) {
  const [consultantFilter, setConsultantFilter] = useState<string>("all");
  const [periodFilter, setPeriodFilter] = useState<string>("all");

  // Build consultant name list
  const consultantNames = useMemo(() => {
    const names = new Set<string>();
    reports.forEach(r => {
      const name = r.consultantName || allUsers.find((u: any) => u.id === r.userId)?.firstName || "";
      if (name) names.add(name);
    });
    return Array.from(names).sort();
  }, [reports, allUsers]);

  // Filter reports
  const filtered = useMemo(() => {
    let list = [...reports];

    if (consultantFilter !== "all") {
      list = list.filter(r => {
        const name = r.consultantName || allUsers.find((u: any) => u.id === r.userId)?.firstName || "";
        return name === consultantFilter;
      });
    }

    if (periodFilter !== "all") {
      const now = new Date();
      const cutoff = new Date();
      if (periodFilter === "7d") cutoff.setDate(now.getDate() - 7);
      else if (periodFilter === "30d") cutoff.setDate(now.getDate() - 30);
      else if (periodFilter === "90d") cutoff.setDate(now.getDate() - 90);
      list = list.filter(r => r.createdAt && new Date(r.createdAt) >= cutoff);
    }

    return list;
  }, [reports, consultantFilter, periodFilter, allUsers]);

  // ── Aggregate metrics ──────────────────────────────────────────────────────
  const metrics = useMemo(() => {
    const total = filtered.length;
    const submitted = filtered.filter(r => r.status === "submitted" || r.status === "approved").length;
    const drafts = filtered.filter(r => r.status === "draft").length;

    const withConfidence = filtered.filter(r => r.purchaseConfidencePct !== null && r.purchaseConfidencePct !== undefined);
    const avgPc = withConfidence.length
      ? Math.round(withConfidence.reduce((s, r) => s + (r.purchaseConfidencePct ?? 0), 0) / withConfidence.length)
      : 0;

    const avgCurrentPc = (() => {
      const list = filtered.filter(r => r.currentConfidencePct !== null && r.currentConfidencePct !== undefined);
      if (!list.length) return null;
      return Math.round(list.reduce((s, r) => s + (r.currentConfidencePct ?? 0), 0) / list.length);
    })();

    const pipelineValue = filtered.reduce((s, r) => s + toNum(r.estimatedValue), 0);
    const closedValue = filtered.reduce((s, r) => s + toNum(r.closedAmount), 0);

    const sold = filtered.filter(r => r.appointmentResult === "sold").length;
    const notSold = filtered.filter(r => r.appointmentResult === "not_sold").length;
    const followUp = filtered.filter(r => r.appointmentResult === "follow_up").length;
    const pending = filtered.filter(r => !r.appointmentResult || r.appointmentResult === "pending").length;

    return { total, submitted, drafts, avgPc, avgCurrentPc, pipelineValue, closedValue, sold, notSold, followUp, pending };
  }, [filtered]);

  // ── Deal status distribution ───────────────────────────────────────────────
  const dealStatusData = useMemo(() => {
    const counts: Record<string, number> = {};
    filtered.forEach(r => {
      const key = r.dealStatus || "unknown";
      counts[key] = (counts[key] || 0) + 1;
    });
    const colors = ["bg-blue-500", "bg-green-500", "bg-yellow-500", "bg-red-500", "bg-purple-500", "bg-orange-500", "bg-pink-500"];
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .map(([label, value], i) => ({ label, value, color: colors[i % colors.length] }));
  }, [filtered]);

  // ── Appointment type distribution ──────────────────────────────────────────
  const apptTypeData = useMemo(() => {
    const counts: Record<string, number> = {};
    filtered.forEach(r => {
      const key = r.appointmentType || "unknown";
      counts[key] = (counts[key] || 0) + 1;
    });
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .map(([label, value]) => ({ label, value }));
  }, [filtered]);

  // ── Per-consultant breakdown ───────────────────────────────────────────────
  const consultantData = useMemo(() => {
    const map: Record<string, { total: number; submitted: number; pipeline: number; avgPc: number; pcList: number[] }> = {};
    filtered.forEach(r => {
      const name = r.consultantName || allUsers.find((u: any) => u.id === r.userId)?.firstName || `User #${r.userId}`;
      if (!map[name]) map[name] = { total: 0, submitted: 0, pipeline: 0, avgPc: 0, pcList: [] };
      map[name].total++;
      if (r.status === "submitted" || r.status === "approved") map[name].submitted++;
      map[name].pipeline += toNum(r.estimatedValue);
      if (r.purchaseConfidencePct !== null && r.purchaseConfidencePct !== undefined) map[name].pcList.push(r.purchaseConfidencePct);
    });
    return Object.entries(map).map(([name, d]) => ({
      name,
      total: d.total,
      submitted: d.submitted,
      pipeline: d.pipeline,
      avgPc: d.pcList.length ? Math.round(d.pcList.reduce((s, v) => s + v, 0) / d.pcList.length) : 0,
    })).sort((a, b) => b.total - a.total);
  }, [filtered, allUsers]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <Select value={consultantFilter} onValueChange={setConsultantFilter}>
          <SelectTrigger className="w-48"><SelectValue placeholder="All Consultants" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Consultants</SelectItem>
            {consultantNames.map(name => (
              <SelectItem key={name} value={name}>{name}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={periodFilter} onValueChange={setPeriodFilter}>
          <SelectTrigger className="w-40"><SelectValue placeholder="All Time" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Time</SelectItem>
            <SelectItem value="7d">Last 7 Days</SelectItem>
            <SelectItem value="30d">Last 30 Days</SelectItem>
            <SelectItem value="90d">Last 90 Days</SelectItem>
          </SelectContent>
        </Select>

        <span className="text-sm text-muted-foreground self-center">
          Showing {filtered.length} of {reports.length} records
        </span>
      </div>

      {/* Top Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total CMRs" value={metrics.total} icon={Users} />
        <StatCard label="Avg PC %" value={`${metrics.avgPc}%`} sub={metrics.avgCurrentPc !== null ? `Current avg: ${metrics.avgCurrentPc}%` : undefined} icon={TrendingUp} color="text-blue-600" />
        <StatCard label="Pipeline Value" value={formatCurrency(metrics.pipelineValue)} icon={DollarSign} color="text-emerald-600" />
        <StatCard label="Closed Value" value={formatCurrency(metrics.closedValue)} icon={CheckCircle} color="text-green-600" />
      </div>

      {/* Appointment Results */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Sold" value={metrics.sold} sub={pct(metrics.sold, metrics.total)} icon={CheckCircle} color="text-green-600" />
        <StatCard label="Not Sold" value={metrics.notSold} sub={pct(metrics.notSold, metrics.total)} icon={XCircle} color="text-red-500" />
        <StatCard label="Follow-Up" value={metrics.followUp} sub={pct(metrics.followUp, metrics.total)} icon={Clock} color="text-yellow-600" />
        <StatCard label="Pending" value={metrics.pending} sub={pct(metrics.pending, metrics.total)} icon={Target} color="text-gray-500" />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <BarChart title="Deal Status Distribution" data={dealStatusData} />
        <BarChart title="Appointment Type" data={apptTypeData} />
      </div>

      {/* Per-Consultant Table */}
      {consultantData.length > 0 && (
        <Card className="p-4">
          <p className="text-sm font-semibold mb-3">Consultant Breakdown</p>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-muted-foreground text-xs">
                  <th className="text-left py-2 pr-4">Consultant</th>
                  <th className="text-right py-2 pr-4">Total</th>
                  <th className="text-right py-2 pr-4">Submitted</th>
                  <th className="text-right py-2 pr-4">Avg PC %</th>
                  <th className="text-right py-2">Pipeline</th>
                </tr>
              </thead>
              <tbody>
                {consultantData.map(row => (
                  <tr key={row.name} className="border-b last:border-0 hover:bg-muted/30">
                    <td className="py-2 pr-4 font-medium">{row.name}</td>
                    <td className="text-right py-2 pr-4">{row.total}</td>
                    <td className="text-right py-2 pr-4">{row.submitted}</td>
                    <td className="text-right py-2 pr-4">{row.avgPc}%</td>
                    <td className="text-right py-2 text-emerald-700 font-medium">{formatCurrency(row.pipeline)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
