import { useState } from "react";
import { useLocation } from "wouter";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { trpc } from "@/lib/trpc";
import { Plus, Search, Monitor } from "lucide-react";
import { toast } from "sonner";

const STATUS_COLORS: Record<string, string> = {
  draft: "bg-gray-100 text-gray-700 border-gray-200",
  submitted: "bg-blue-50 text-blue-700 border-blue-200",
  approved: "bg-green-50 text-green-700 border-green-200",
  closed: "bg-slate-100 text-slate-600 border-slate-200",
  cancelled: "bg-red-50 text-red-600 border-red-200",
  archived: "bg-yellow-50 text-yellow-700 border-yellow-200",
};

export default function ScreenMeasurements() {
  const [, navigate] = useLocation();
  const [view, setView] = useState<"my" | "all">("my");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const { data: records, isLoading } = trpc.screens.list.useQuery({
    view,
    status: statusFilter !== "all" ? (statusFilter as any) : undefined,
  });

  const createMutation = trpc.screens.create.useMutation({
    onSuccess: (data) => {
      navigate(`/screen-measurements/${data.id}`);
    },
    onError: (err) => {
      toast.error("Failed to create record: " + err.message);
    },
  });

  const filtered = records?.filter((r) => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      r.recordNumber?.toLowerCase().includes(q) ||
      r.siteNotes?.toLowerCase().includes(q) ||
      r.ownerName?.toLowerCase().includes(q) ||
      r.manufacturerCode?.toLowerCase().includes(q)
    );
  }) ?? [];

  return (
    <DashboardLayout>
      <div className="p-6 max-w-7xl mx-auto">
        {/* Page header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Monitor className="w-6 h-6 text-primary" />
            <div>
              <h1 className="text-2xl font-bold">Screen Measurements</h1>
              <p className="text-sm text-muted-foreground">Motorized screen measurement records</p>
            </div>
          </div>
          <Button
            onClick={() => createMutation.mutate({})}
            disabled={createMutation.isPending}
          >
            <Plus className="w-4 h-4 mr-2" />
            New Record
          </Button>
        </div>

        {/* Filters row */}
        <div className="flex items-center gap-3 mb-4">
          {/* My / All toggle */}
          <div className="flex rounded-md border overflow-hidden">
            <button
              className={`px-4 py-2 text-sm font-medium transition-colors ${
                view === "my"
                  ? "bg-primary text-primary-foreground"
                  : "bg-background text-muted-foreground hover:bg-muted"
              }`}
              onClick={() => setView("my")}
            >
              My Records
            </button>
            <button
              className={`px-4 py-2 text-sm font-medium transition-colors ${
                view === "all"
                  ? "bg-primary text-primary-foreground"
                  : "bg-background text-muted-foreground hover:bg-muted"
              }`}
              onClick={() => setView("all")}
            >
              All Records
            </button>
          </div>

          {/* Status filter */}
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="All statuses" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="draft">Draft</SelectItem>
              <SelectItem value="submitted">Submitted</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="closed">Closed</SelectItem>
              <SelectItem value="cancelled">Cancelled</SelectItem>
              <SelectItem value="archived">Archived</SelectItem>
            </SelectContent>
          </Select>

          {/* Search */}
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search records..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
        </div>

        {/* Table */}
        <div className="border rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="w-36">Record #</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Manufacturer</TableHead>
                <TableHead>Motor Type</TableHead>
                <TableHead>Screens</TableHead>
                <TableHead>Date</TableHead>
                {view === "all" && <TableHead>Owner</TableHead>}
                <TableHead>Notes</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={view === "all" ? 8 : 7} className="text-center py-12 text-muted-foreground">
                    Loading records...
                  </TableCell>
                </TableRow>
              ) : filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={view === "all" ? 8 : 7} className="text-center py-12 text-muted-foreground">
                    {search || statusFilter !== "all"
                      ? "No records match your filters."
                      : view === "my"
                      ? 'You have no screen measurement records yet. Click "New Record" to get started.'
                      : "No screen measurement records found."}
                  </TableCell>
                </TableRow>
              ) : (
                filtered.map((r) => (
                  <TableRow
                    key={r.id}
                    className="cursor-pointer hover:bg-muted/50 transition-colors"
                    onClick={() => navigate(`/screen-measurements/${r.id}`)}
                  >
                    <TableCell className="font-mono text-sm font-medium">
                      {r.recordNumber ?? `#${r.id}`}
                    </TableCell>
                    <TableCell>
                      <span
                        className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border ${
                          STATUS_COLORS[r.status] ?? "bg-gray-100 text-gray-700"
                        }`}
                      >
                        {r.status.charAt(0).toUpperCase() + r.status.slice(1)}
                      </span>
                    </TableCell>
                    <TableCell className="text-sm">{r.manufacturerCode ?? "—"}</TableCell>
                    <TableCell className="text-sm">{r.motorType ?? "—"}</TableCell>
                    <TableCell className="text-sm">{r.lineCount ?? 0}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {r.measurementDate
                        ? new Date(r.measurementDate).toLocaleDateString()
                        : r.createdAt
                        ? new Date(r.createdAt).toLocaleDateString()
                        : "—"}
                    </TableCell>
                    {view === "all" && (
                      <TableCell className="text-sm text-muted-foreground">
                        {r.ownerName ?? "—"}
                      </TableCell>
                    )}
                    <TableCell className="text-sm text-muted-foreground max-w-xs truncate">
                      {r.siteNotes ?? "—"}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>

        {filtered.length > 0 && (
          <p className="text-xs text-muted-foreground mt-2">
            Showing {filtered.length} record{filtered.length !== 1 ? "s" : ""}
          </p>
        )}
      </div>
    </DashboardLayout>
  );
}
