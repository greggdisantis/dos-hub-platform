import { StageOverview } from "./StageOverview";

export default function AdminStage() {
  return (
    <StageOverview
      stage="admin"
      title="Admin"
      description="System administration and settings. User management, approvals, and system configuration."
    />
  );
}
