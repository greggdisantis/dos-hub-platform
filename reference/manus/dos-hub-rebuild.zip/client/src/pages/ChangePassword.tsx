import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function ChangePassword() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isChanging, setIsChanging] = useState(false);

  const utils = trpc.useUtils();
  const changePasswordMutation = trpc.auth.changePassword.useMutation();

  // If user doesn't need to change password (and is loaded), redirect to dashboard.
  // Must be in useEffect — never call setLocation in render body.
  useEffect(() => {
    if (!loading && user && !user.passwordChangeRequired) {
      setLocation("/dashboard");
    }
  }, [user, loading, setLocation]);

  // If not logged in at all, redirect to login
  useEffect(() => {
    if (!loading && !user) {
      setLocation("/login");
    }
  }, [user, loading, setLocation]);

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!currentPassword.trim()) {
      toast.error("Current password is required");
      return;
    }

    if (!newPassword.trim()) {
      toast.error("New password is required");
      return;
    }

    if (newPassword.length < 8) {
      toast.error("New password must be at least 8 characters");
      return;
    }

    if (newPassword !== confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }

    setIsChanging(true);
    try {
      await changePasswordMutation.mutateAsync({
        currentPassword,
        newPassword,
      });

      toast.success("Password changed successfully");

      // Invalidate auth.me so ProtectedRoute sees the updated passwordChangeRequired = false.
      // Without this, ProtectedRoute would still see the old value and redirect back here.
      await utils.auth.me.invalidate();

      setLocation("/dashboard");
    } catch (error: any) {
      const message =
        error?.data?.code === "UNAUTHORIZED"
          ? "Current password is incorrect"
          : "Failed to change password. Please try again.";
      toast.error(message);
    } finally {
      setIsChanging(false);
    }
  };

  // Show spinner while auth is loading or while redirecting
  if (loading || (!loading && user && !user.passwordChangeRequired)) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  // Not logged in — show nothing while redirect fires
  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800 p-4">
      <Card className="w-full max-w-md p-8">
        <div className="space-y-6">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-2">Change Your Password</h1>
            <p className="text-muted-foreground">
              A password change is required before you can continue.
            </p>
          </div>

          <form onSubmit={handleChangePassword} className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                Current Password
              </label>
              <Input
                type="password"
                placeholder="Enter your current or temporary password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                disabled={isChanging}
                autoComplete="current-password"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                New Password
              </label>
              <Input
                type="password"
                placeholder="Enter your new password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                disabled={isChanging}
                autoComplete="new-password"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Must be at least 8 characters
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                Confirm New Password
              </label>
              <Input
                type="password"
                placeholder="Confirm your new password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                disabled={isChanging}
                autoComplete="new-password"
              />
            </div>

            <Button
              type="submit"
              className="w-full"
              disabled={isChanging}
            >
              {isChanging ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Changing Password...
                </>
              ) : (
                "Change Password"
              )}
            </Button>
          </form>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-900">
              <strong>Default Temporary Password:</strong> Temp1234!
            </p>
            <p className="text-xs text-blue-800 mt-2">
              If you were assigned a temporary password, enter it above as your current password.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
