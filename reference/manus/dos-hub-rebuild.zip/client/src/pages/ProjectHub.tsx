import { useAuth } from "@/_core/hooks/useAuth";
import { Breadcrumb } from "@/components/Breadcrumb";
import { ProjectCMRTab } from "@/components/ProjectCMRTab";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";

interface ProjectHubProps {
  projectId: string;
}

export function ProjectHub({ projectId }: ProjectHubProps) {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  // Mock project data - will be replaced with actual API call
  const project = {
    id: parseInt(projectId),
    name: "Acme Corp - Office Screens",
    clientName: "Acme Corporation",
    stage: "engineering",
    createdAt: "2024-01-15",
    hubspotDealId: "deal-12345",
    serviceFusionJobId: "job-67890",
  };

  const handleBack = () => {
    // Go back to the stage page or dashboard
    const stageMap: Record<string, string> = {
      sales: "/stage/sales",
      engineering: "/stage/engineering",
      production: "/stage/production",
      install: "/stage/install",
      service: "/stage/service",
    };
    setLocation(stageMap[project.stage] || "/dashboard");
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center gap-2 mb-6">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleBack}
            className="gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
        </div>

        <Breadcrumb
          items={[
            { label: project.stage.charAt(0).toUpperCase() + project.stage.slice(1), href: `/stage/${project.stage}` },
            { label: project.name },
          ]}
        />

        {/* Project Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">{project.name}</h1>
          <div className="flex gap-4 text-sm text-muted-foreground">
            <span>Client: {project.clientName}</span>
            <span>Stage: {project.stage}</span>
            <span>Created: {project.createdAt}</span>
          </div>
        </div>

        {/* External System References */}
        {(project.hubspotDealId || project.serviceFusionJobId) && (
          <Card className="p-4 mb-6 bg-muted">
            <div className="text-sm">
              {project.hubspotDealId && (
                <div>HubSpot Deal: <span className="font-mono text-xs">{project.hubspotDealId}</span></div>
              )}
              {project.serviceFusionJobId && (
                <div>Service Fusion Job: <span className="font-mono text-xs">{project.serviceFusionJobId}</span></div>
              )}
            </div>
          </Card>
        )}

        {/* Module Tabs */}
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-8">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="cmr">CMR</TabsTrigger>
            <TabsTrigger value="measurements">Measurements</TabsTrigger>
            <TabsTrigger value="materials">Materials</TabsTrigger>
            <TabsTrigger value="checklists">Checklists</TabsTrigger>
            <TabsTrigger value="receipts">Receipts</TabsTrigger>
            <TabsTrigger value="files">Files</TabsTrigger>
            <TabsTrigger value="notes">Notes</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4">
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Project Overview</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-muted-foreground">Project Name</label>
                  <p className="font-medium">{project.name}</p>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground">Client</label>
                  <p className="font-medium">{project.clientName}</p>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground">Current Stage</label>
                  <p className="font-medium capitalize">{project.stage}</p>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground">Created</label>
                  <p className="font-medium">{project.createdAt}</p>
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* CMR Tab */}
          <TabsContent value="cmr" className="space-y-4">
            <ProjectCMRTab projectId={project.id} projectName={project.name} />
          </TabsContent>

          {/* Measurements Tab */}
          <TabsContent value="measurements" className="space-y-4">
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Screen Measurements</h3>
              <p className="text-sm text-muted-foreground">No measurements recorded yet.</p>
              <Button className="mt-4">Record Measurement</Button>
            </Card>
          </TabsContent>

          {/* Materials Tab */}
          <TabsContent value="materials" className="space-y-4">
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Material Checklist</h3>
              <p className="text-sm text-muted-foreground">No materials tracked yet.</p>
              <Button className="mt-4">Create Checklist</Button>
            </Card>
          </TabsContent>

          {/* Checklists Tab */}
          <TabsContent value="checklists" className="space-y-4">
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Preconstruction Checklists</h3>
              <p className="text-sm text-muted-foreground">No checklists created yet.</p>
              <Button className="mt-4">Create Checklist</Button>
            </Card>
          </TabsContent>

          {/* Receipts Tab */}
          <TabsContent value="receipts" className="space-y-4">
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Receipts & Expenses</h3>
              <p className="text-sm text-muted-foreground">No receipts recorded yet.</p>
              <Button className="mt-4">Add Receipt</Button>
            </Card>
          </TabsContent>

          {/* Files Tab */}
          <TabsContent value="files" className="space-y-4">
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Project Files</h3>
              <p className="text-sm text-muted-foreground">No files attached yet.</p>
              <Button className="mt-4">Upload File</Button>
            </Card>
          </TabsContent>

          {/* Notes Tab */}
          <TabsContent value="notes" className="space-y-4">
            <Card className="p-6">
              <h3 className="font-semibold mb-4">Project Notes</h3>
              <p className="text-sm text-muted-foreground">No notes yet. Add one to get started.</p>
              <Button className="mt-4">Add Note</Button>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
