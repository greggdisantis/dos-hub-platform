import { StageOverview } from "./StageOverview";

export default function EngineeringStage() {
  return (
    <StageOverview
      stage="engineering"
      title="Engineering"
      description="Design and engineering phase. Screen measurements, material lists, and preconstruction planning."
    />
  );
}
