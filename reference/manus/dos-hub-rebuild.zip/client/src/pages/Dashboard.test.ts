import { describe, expect, it } from "vitest";

// Test role-based module access
const MODULE_LINKS = [
  { label: "CMR Reports", path: "/dashboard/cmr", icon: "📋", roles: ["member", "manager", "admin", "super-admin"] },
  { label: "Screen Measurements", path: "/screen-measurements", icon: "📐", roles: ["member", "manager", "admin", "super-admin"] },
  { label: "Material Checklist", path: "/dashboard/materials", icon: "📦", roles: ["member", "manager", "admin", "super-admin"] },
  { label: "Receipt Capture", path: "/dashboard/receipts", icon: "🧾", roles: ["member", "manager", "admin", "super-admin"] },
  { label: "AquaClean Receipts", path: "/dashboard/aquaclean", icon: "💧", roles: ["member", "manager", "admin", "super-admin"] },
  { label: "Preconstruction", path: "/dashboard/precon", icon: "✓", roles: ["member", "manager", "admin", "super-admin"] },
  { label: "User Management", path: "/dashboard/users", icon: "👥", roles: ["admin", "super-admin"] },
  { label: "Approvals", path: "/admin/approval", icon: "✅", roles: ["super-admin"] },
];

describe("Dashboard Role-Based Access", () => {
  describe("Member role", () => {
    it("should have access to core modules", () => {
      const memberModules = MODULE_LINKS.filter((m) => m.roles.includes("member"));
      expect(memberModules.length).toBeGreaterThan(0);
      expect(memberModules.map((m) => m.label)).toContain("CMR Reports");
      expect(memberModules.map((m) => m.label)).toContain("Screen Measurements");
    });

    it("should not have access to admin modules", () => {
      const memberModules = MODULE_LINKS.filter((m) => m.roles.includes("member"));
      const adminOnlyModules = memberModules.filter((m) => m.roles.includes("admin"));
      expect(adminOnlyModules.length).toBe(0);
    });
  });

  describe("Manager role", () => {
    it("should have access to all core modules", () => {
      const managerModules = MODULE_LINKS.filter((m) => m.roles.includes("manager"));
      expect(managerModules.length).toBeGreaterThan(5);
    });

    it("should not have access to admin-only modules", () => {
      const managerModules = MODULE_LINKS.filter((m) => m.roles.includes("manager"));
      const hasUserManagement = managerModules.some((m) => m.label === "User Management");
      const hasApprovals = managerModules.some((m) => m.label === "Approvals");
      expect(hasUserManagement).toBe(false);
      expect(hasApprovals).toBe(false);
    });
  });

  describe("Admin role", () => {
    it("should have access to all modules except super-admin only", () => {
      const adminModules = MODULE_LINKS.filter((m) => m.roles.includes("admin"));
      expect(adminModules.map((m) => m.label)).toContain("User Management");
      expect(adminModules.map((m) => m.label)).not.toContain("Approvals");
    });
  });

  describe("Super-admin role", () => {
    it("should have access to all modules", () => {
      const superAdminModules = MODULE_LINKS.filter((m) => m.roles.includes("super-admin"));
      expect(superAdminModules.length).toBe(MODULE_LINKS.length);
    });

    it("should have access to approvals", () => {
      const superAdminModules = MODULE_LINKS.filter((m) => m.roles.includes("super-admin"));
      expect(superAdminModules.map((m) => m.label)).toContain("Approvals");
    });
  });

  describe("Module routing", () => {
    it("should have unique paths for all modules", () => {
      const paths = MODULE_LINKS.map((m) => m.path);
      const uniquePaths = new Set(paths);
      expect(uniquePaths.size).toBe(paths.length);
    });

    it("should have all dashboard routes defined", () => {
      const expectedRoutes = [
        "/dashboard/cmr",
        "/screen-measurements",
        "/dashboard/materials",
        "/dashboard/receipts",
        "/dashboard/aquaclean",
        "/dashboard/precon",
        "/dashboard/users",
        "/admin/approval",
      ];
      const actualRoutes = MODULE_LINKS.map((m) => m.path);
      expectedRoutes.forEach((route) => {
        expect(actualRoutes).toContain(route);
      });
    });
  });
});
