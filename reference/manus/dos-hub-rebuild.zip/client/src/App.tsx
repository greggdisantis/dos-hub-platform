import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import ProtectedRoute from "./components/ProtectedRoute";
import { ThemeProvider } from "./contexts/ThemeContext";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import CompleteProfile from "./pages/CompleteProfile";
import ChangePassword from "./pages/ChangePassword";
import AdminApproval from "./pages/AdminApproval";
import Dashboard from "./pages/Dashboard";
import CMRList from "./pages/CMRList";
import { CMRFormNew } from "./pages/CMRFormNew";
import CMRView from "./pages/CMRView";
import SalesStage from "./pages/SalesStage";
import EngineeringStage from "./pages/EngineeringStage";
import ProductionStage from "./pages/ProductionStage";
import InstallStage from "./pages/InstallStage";
import ServiceStage from "./pages/ServiceStage";
import AdminStage from "./pages/AdminStage";
import { ProjectHub } from "./pages/ProjectHub";
import UserManagement from "./pages/UserManagement";
import ScreenMeasurements from "./pages/ScreenMeasurements";
import ScreenMeasurementDetail from "./pages/ScreenMeasurementDetail";
import { ReceiptCapture } from "./pages/receipts/ReceiptCapture";
import { ReceiptNew } from "./pages/receipts/ReceiptNew";
import { MyReceipts } from "./pages/receipts/MyReceipts";
import { FinanceInbox } from "./pages/receipts/FinanceInbox";
import { FinanceInProgress } from "./pages/receipts/FinanceInProgress";
import { ReceiptArchive } from "./pages/receipts/ReceiptArchive";
import { ReceiptAnalytics } from "./pages/receipts/ReceiptAnalytics";
import { ReceiptDetail } from "./pages/receipts/ReceiptDetail";

// Placeholder module pages
function ModulePlaceholder({ moduleName }: { moduleName: string }) { 
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="text-center max-w-md">
        <h1 className="text-3xl font-bold mb-2">{moduleName}</h1>
        <p className="text-muted-foreground mb-6">
          This module is coming soon. Check back later for updates.
        </p>
        <a href="/dashboard" className="text-blue-600 hover:underline">
          ← Back to Dashboard
        </a>
      </div>
    </div>
  );
}

function Router() {
  return (
    <Switch>
      {/* Public auth routes - no protection */}
      <Route path={"/login"} component={Login} />
      <Route path={"/signup"} component={Signup} />
      <Route path={"/complete-profile"} component={CompleteProfile} />
      <Route path={"/change-password"} component={ChangePassword} />

      {/* Protected routes - require authentication */}
      <Route
        path={"/dashboard"}
        component={() => (
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        )}
      />

      {/* Stage routes */}
      <Route
        path={"/stage/sales"}
        component={() => (
          <ProtectedRoute>
            <SalesStage />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/stage/engineering"}
        component={() => (
          <ProtectedRoute>
            <EngineeringStage />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/stage/production"}
        component={() => (
          <ProtectedRoute>
            <ProductionStage />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/stage/install"}
        component={() => (
          <ProtectedRoute>
            <InstallStage />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/stage/service"}
        component={() => (
          <ProtectedRoute>
            <ServiceStage />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/stage/admin"}
        component={() => (
          <ProtectedRoute>
            <AdminStage />
          </ProtectedRoute>
        )}
      />

      {/* Project Hub route */}
      <Route
        path={"/project/:projectId"}
        component={({ params }) => (
          <ProtectedRoute>
            <ProjectHub projectId={params.projectId} />
          </ProtectedRoute>
        )}
      />

      {/* Module routes - protected placeholders */}
      <Route
        path={"/dashboard/cmr"}
        component={() => (
          <ProtectedRoute>
            <CMRList />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/dashboard/cmr/create"}
        component={() => (
          <ProtectedRoute>
            <CMRFormNew />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/dashboard/cmr/:id"}
        component={() => (
          <ProtectedRoute>
            <CMRView />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/dashboard/cmr/:id/edit"}
        component={() => (
          <ProtectedRoute>
            <CMRFormNew />
          </ProtectedRoute>
        )}
      />


      {/* Screen Measurements module */}
      <Route
        path={"/screen-measurements"}
        component={() => (
          <ProtectedRoute>
            <ScreenMeasurements />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/screen-measurements/:id"}
        component={() => (
          <ProtectedRoute>
            <ScreenMeasurementDetail />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/dashboard/materials"}
        component={() => (
          <ProtectedRoute>
            <ModulePlaceholder moduleName="Material Checklist" />
          </ProtectedRoute>
        )}
      />
      {/* Receipt Capture module routes */}
      <Route
        path={"/dashboard/receipts"}
        component={() => (
          <ProtectedRoute>
            <ReceiptCapture />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/dashboard/receipts/new"}
        component={() => (
          <ProtectedRoute>
            <ReceiptNew />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/dashboard/receipts/mine"}
        component={() => (
          <ProtectedRoute>
            <MyReceipts />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/dashboard/receipts/finance-inbox"}
        component={() => (
          <ProtectedRoute>
            <FinanceInbox />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/dashboard/receipts/finance-in-progress"}
        component={() => (
          <ProtectedRoute>
            <FinanceInProgress />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/dashboard/receipts/archive"}
        component={() => (
          <ProtectedRoute>
            <ReceiptArchive />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/dashboard/receipts/analytics"}
        component={() => (
          <ProtectedRoute>
            <ReceiptAnalytics />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/dashboard/receipts/:id"}
        component={() => (
          <ProtectedRoute>
            <ReceiptDetail />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/dashboard/aquaclean"}
        component={() => (
          <ProtectedRoute>
            <ModulePlaceholder moduleName="AquaClean Receipts" />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/dashboard/precon"}
        component={() => (
          <ProtectedRoute>
            <ModulePlaceholder moduleName="Preconstruction Checklist" />
          </ProtectedRoute>
        )}
      />
      <Route
        path={"/dashboard/users"}
        component={() => (
          <ProtectedRoute>
            <UserManagement />
          </ProtectedRoute>
        )}
      />

      {/* Admin routes */}
      <Route
        path={"/admin/approval"}
        component={() => (
          <ProtectedRoute>
            <AdminApproval />
          </ProtectedRoute>
        )}
      />

      {/* Redirect root to dashboard */}
      <Route
        path={"/"}
        component={() => (
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        )}
      />

      {/* 404 fallback - protected to prevent browsing */}
      <Route
        component={() => (
          <ProtectedRoute>
            <NotFound />
          </ProtectedRoute>
        )}
      />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
