import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { X } from "lucide-react";

interface ModuleFiltersProps {
  statusOptions?: Array<{ value: string; label: string }>;
  onStatusChange?: (status: string | undefined) => void;
  onUserFilterChange?: (userId: number | undefined) => void;
  onProjectFilterChange?: (projectId: number | undefined) => void;
  onDateRangeChange?: (startDate: string | undefined, endDate: string | undefined) => void;
  showUserFilter?: boolean;
  showProjectFilter?: boolean;
  showDateFilter?: boolean;
  activeFilters?: number;
}

export function ModuleFilters({
  statusOptions,
  onStatusChange,
  onUserFilterChange,
  onProjectFilterChange,
  onDateRangeChange,
  showUserFilter = false,
  showProjectFilter = false,
  showDateFilter = false,
  activeFilters = 0,
}: ModuleFiltersProps) {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <span className="text-sm font-medium text-muted-foreground">
          Filters
        </span>
        {activeFilters > 0 && (
          <span className="inline-flex items-center gap-1 px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs font-medium">
            {activeFilters} active
          </span>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Status Filter */}
        {statusOptions && onStatusChange && (
          <div>
            <label className="text-sm font-medium mb-2 block">Status</label>
            <Select onValueChange={(val) => onStatusChange(val === "all" ? undefined : val)}>
              <SelectTrigger>
                <SelectValue placeholder="All statuses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All statuses</SelectItem>
                {statusOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {/* User Filter */}
        {showUserFilter && onUserFilterChange && (
          <div>
            <label className="text-sm font-medium mb-2 block">User</label>
            <Input
              type="number"
              placeholder="Filter by user ID"
              onChange={(e) =>
                onUserFilterChange(e.target.value ? parseInt(e.target.value) : undefined)
              }
            />
          </div>
        )}

        {/* Project Filter */}
        {showProjectFilter && onProjectFilterChange && (
          <div>
            <label className="text-sm font-medium mb-2 block">Project</label>
            <Input
              type="number"
              placeholder="Filter by project ID"
              onChange={(e) =>
                onProjectFilterChange(e.target.value ? parseInt(e.target.value) : undefined)
              }
            />
          </div>
        )}

        {/* Date Range Filter */}
        {showDateFilter && onDateRangeChange && (
          <>
            <div>
              <label className="text-sm font-medium mb-2 block">From Date</label>
              <Input
                type="date"
                onChange={(e) =>
                  onDateRangeChange(e.target.value || undefined, undefined)
                }
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">To Date</label>
              <Input
                type="date"
                onChange={(e) =>
                  onDateRangeChange(undefined, e.target.value || undefined)
                }
              />
            </div>
          </>
        )}
      </div>
    </div>
  );
}
