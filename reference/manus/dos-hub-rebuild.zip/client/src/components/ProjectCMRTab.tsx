import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2, Plus, Eye, Edit2, Trash2 } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState } from "react";
import { toast } from "sonner";

interface ProjectCMRTabProps {
  projectId: number;
  projectName: string;
}

export function ProjectCMRTab({ projectId, projectName }: ProjectCMRTabProps) {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const { data: reports, isLoading, refetch } = trpc.cmr.listByProject.useQuery({ projectId });
  const deleteMutation = trpc.cmr.delete.useMutation();

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to delete this CMR report?")) return;

    try {
      await deleteMutation.mutateAsync({ reportId: id });
      toast.success("CMR report deleted");
      refetch();
    } catch (error) {
      toast.error("Failed to delete CMR report");
    }
  };

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case "draft":
        return "bg-gray-100 text-gray-800";
      case "submitted":
        return "bg-blue-100 text-blue-800";
      case "approved":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const formatDate = (date: Date | string) => {
    const d = typeof date === "string" ? new Date(date) : date;
    return d.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  if (isLoading) {
    return (
      <Card className="p-6">
        <div className="flex items-center justify-center h-32">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </div>
      </Card>
    );
  }

  const cmrReports = reports || [];

  return (
    <div className="space-y-4">
      {/* Header with Create Button */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-semibold">Client Meeting Reports</h3>
          <p className="text-sm text-muted-foreground">
            {cmrReports.length} report{cmrReports.length !== 1 ? "s" : ""} for this project
          </p>
        </div>
        <Button
          onClick={() => setLocation(`/project/${projectId}/cmr/create`)}
          size="sm"
          className="gap-2"
        >
          <Plus className="w-4 h-4" />
          New CMR
        </Button>
      </div>

      {/* CMR List */}
      {cmrReports.length === 0 ? (
        <Card className="p-6">
          <p className="text-sm text-muted-foreground text-center py-4">
            No CMR records yet. Create one to get started.
          </p>
        </Card>
      ) : (
        <div className="space-y-3">
          {cmrReports.map((report) => (
            <Card
              key={report.id}
              className="p-4 hover:bg-accent transition-colors"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <h4 className="font-medium truncate">{report.clientName}</h4>
                    <Badge className={`text-xs ${getStatusBadgeColor(report.status)}`}>
                      {report.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Meeting: {report.appointmentDate ? formatDate(report.appointmentDate) : formatDate(report.createdAt)}
                  </p>
                  {report.pcNotes && (
                    <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                      {report.pcNotes}
                    </p>
                  )}
                  {report.dealStatus && (
                    <p className="text-xs text-muted-foreground mt-1">
                      Deal Status: <span className="font-medium">{report.dealStatus}</span>
                    </p>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex gap-2 flex-shrink-0">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setLocation(`/project/${projectId}/cmr/${report.id}`)}
                    title="View"
                  >
                    <Eye className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setLocation(`/project/${projectId}/cmr/${report.id}/edit`)}
                    title="Edit"
                  >
                    <Edit2 className="w-4 h-4" />
                  </Button>
                  {report.status === "draft" && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(report.id)}
                      title="Delete"
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
