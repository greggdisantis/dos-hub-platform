import { useAuth } from "@/_core/hooks/useAuth";
import { Loader2 } from "lucide-react";
import { useLocation } from "wouter";
import { useEffect } from "react";

interface ProtectedRouteProps {
  children: React.ReactNode;
}

/**
 * Wrapper component that ensures only authenticated users can access a route.
 * Redirects unauthenticated users to /login.
 * Redirects users with incomplete profiles to /complete-profile.
 */
export default function ProtectedRoute({ children }: ProtectedRouteProps) {
  const { user, loading } = useAuth();
  const [location, setLocation] = useLocation();

  useEffect(() => {
    if (!loading && !user) {
      setLocation("/login");
    }
  }, [user, loading, setLocation]);

  // Check if user needs to change password
  // Skip this check on the change-password page itself to avoid redirect loops
  useEffect(() => {
    if (!loading && user && location !== "/change-password") {
      if (user.passwordChangeRequired) {
        setLocation("/change-password");
      }
    }
  }, [user, loading, location, setLocation]);

  // Check if user has incomplete profile (missing firstName or lastName)
  // Skip this check on the complete-profile page itself to avoid redirect loops
  useEffect(() => {
    if (!loading && user && location !== "/complete-profile" && location !== "/change-password") {
      if (!user.firstName || !user.lastName) {
        setLocation("/complete-profile");
      }
    }
  }, [user, loading, location, setLocation]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return <>{children}</>;
}
