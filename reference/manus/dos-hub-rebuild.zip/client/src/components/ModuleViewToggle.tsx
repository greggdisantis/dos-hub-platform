import { Button } from "@/components/ui/button";
import { useState } from "react";

interface ModuleViewToggleProps {
  onViewChange: (view: "my" | "all") => void;
  canSeeAll: boolean;
}

export function ModuleViewToggle({
  onViewChange,
  canSeeAll,
}: ModuleViewToggleProps) {
  const [view, setView] = useState<"my" | "all">("my");

  const handleViewChange = (newView: "my" | "all") => {
    setView(newView);
    onViewChange(newView);
  };

  return (
    <div className="flex gap-2 border-b border-border">
      <button
        onClick={() => handleViewChange("my")}
        className={`px-4 py-2 font-medium border-b-2 transition-colors ${
          view === "my"
            ? "border-primary text-primary"
            : "border-transparent text-muted-foreground hover:text-foreground"
        }`}
      >
        My Items
      </button>

      {canSeeAll && (
        <button
          onClick={() => handleViewChange("all")}
          className={`px-4 py-2 font-medium border-b-2 transition-colors ${
            view === "all"
              ? "border-primary text-primary"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          All Items
        </button>
      )}
    </div>
  );
}
