/**
 * ModulePageHeader — Shared DOS Hub Module Page Header
 *
 * Provides a consistent top-of-page header for all DOS Hub module pages.
 * Layout:
 *   LEFT:  ← Back to Dashboard (secondary ghost button) + module title
 *   RIGHT: module-specific action buttons (passed as children)
 *
 * Usage:
 *   <ModulePageHeader title="Client Meeting Reports">
 *     <Button variant="outline" size="sm">Export CSV</Button>
 *     <Button size="sm">New Report</Button>
 *   </ModulePageHeader>
 *
 * The back destination defaults to /dashboard and can be overridden via
 * the `backTo` prop for sub-module pages that should return to a parent module.
 */

import { ChevronLeft } from "lucide-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";

interface ModulePageHeaderProps {
  /** Page/module title displayed next to the back button */
  title: string;
  /** Route to navigate back to. Defaults to "/dashboard". */
  backTo?: string;
  /** Label for the back button. Defaults to "Back to Dashboard". */
  backLabel?: string;
  /** Right-side action buttons (Print, Export CSV, New Report, etc.) */
  children?: React.ReactNode;
}

export function ModulePageHeader({
  title,
  backTo = "/dashboard",
  backLabel = "Back to Dashboard",
  children,
}: ModulePageHeaderProps) {
  const [, setLocation] = useLocation();

  return (
    <div className="flex items-center justify-between gap-4">
      {/* Left: back button + title */}
      <div className="flex items-center gap-3 min-w-0">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setLocation(backTo)}
          className="shrink-0 gap-1 text-muted-foreground hover:text-foreground"
          aria-label={backLabel}
        >
          <ChevronLeft className="w-4 h-4" />
          <span className="hidden sm:inline">{backLabel}</span>
        </Button>
        <div className="h-5 w-px bg-border shrink-0" aria-hidden="true" />
        <h1 className="text-2xl font-bold truncate">{title}</h1>
      </div>

      {/* Right: module action buttons */}
      {children && (
        <div className="flex items-center gap-2 shrink-0">
          {children}
        </div>
      )}
    </div>
  );
}
