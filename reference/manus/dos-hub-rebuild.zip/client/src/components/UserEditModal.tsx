import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { X } from "lucide-react";

/**
 * Starter list of Special Tags for module/department access grouping.
 * Admins can assign any combination of these to users.
 */
const SPECIAL_TAGS = [
  "Permit Dept",
  "Finance",
  "Sales",
  "Engineering",
  "Screens",
  "Commercial",
  "Service",
  "Operations",
  "Marketing",
  "Leadership",
  "HR",
] as const;

type User = {
  id: number;
  email: string;
  firstName: string | null;
  lastName: string | null;
  role: string;
  userType: string;
  approved: number;
  passwordChangeRequired: number;
  specialTags?: string[] | null;
  createdAt: Date;
  updatedAt: Date;
  lastSignedIn: Date | null;
};

interface UserEditModalProps {
  user: User;
  isOpen: boolean;
  onClose: () => void;
}

export default function UserEditModal({ user, isOpen, onClose }: UserEditModalProps) {
  // Safely parse specialTags — handles null, undefined, and old users with no tags
  const initialTags: string[] = Array.isArray(user.specialTags)
    ? user.specialTags
    : [];

  const [formData, setFormData] = useState({
    firstName: user.firstName || "",
    lastName: user.lastName || "",
    role: user.role,
    userType: user.userType,
    approved: user.approved === 1,
    passwordChangeRequired: user.passwordChangeRequired === 1,
    specialTags: initialTags,
  });

  const updateMutation = trpc.user.updateManagement.useMutation({
    onSuccess: () => {
      onClose();
    },
    onError: (error) => {
      console.error("Failed to update user:", error);
      alert("Failed to update user. Please try again.");
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    updateMutation.mutate({
      userId: user.id,
      firstName: formData.firstName || undefined,
      lastName: formData.lastName || undefined,
      role: formData.role as any,
      userType: formData.userType as any,
      approved: formData.approved,
      passwordChangeRequired: formData.passwordChangeRequired,
      specialTags: formData.specialTags,
    });
  };

  const removeTag = (tag: string) => {
    setFormData((prev) => ({
      ...prev,
      specialTags: (Array.isArray(prev.specialTags) ? prev.specialTags : []).filter((t) => t !== tag),
    }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit User: {user.email}</DialogTitle>
          <DialogDescription>
            Update user details, role, type, and special tags
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* First Name */}
          <div>
            <Label htmlFor="firstName">First Name</Label>
            <Input
              id="firstName"
              value={formData.firstName}
              onChange={(e) =>
                setFormData({ ...formData, firstName: e.target.value })
              }
              placeholder="Enter first name"
            />
          </div>

          {/* Last Name */}
          <div>
            <Label htmlFor="lastName">Last Name</Label>
            <Input
              id="lastName"
              value={formData.lastName}
              onChange={(e) =>
                setFormData({ ...formData, lastName: e.target.value })
              }
              placeholder="Enter last name"
            />
          </div>

          {/* Role */}
          <div>
            <Label htmlFor="role">Role</Label>
            <Select
              value={formData.role}
              onValueChange={(value) =>
                setFormData({ ...formData, role: value })
              }
            >
              <SelectTrigger id="role">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="guest">Guest</SelectItem>
                <SelectItem value="member">Member</SelectItem>
                <SelectItem value="manager">Manager</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
                <SelectItem value="super-admin">Super Admin</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* User Type */}
          <div>
            <Label htmlFor="userType">User Type</Label>
            <Select
              value={formData.userType}
              onValueChange={(value) =>
                setFormData({ ...formData, userType: value })
              }
            >
              <SelectTrigger id="userType">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="internal">Internal</SelectItem>
                <SelectItem value="dealer">Dealer</SelectItem>
                <SelectItem value="sub-dealer">Sub-Dealer</SelectItem>
                <SelectItem value="vendor">Vendor</SelectItem>
                <SelectItem value="guest">Guest</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Special Tags */}
          <div>
            <Label className="block mb-2">
              Special Tags
              <span className="ml-1 text-xs font-normal text-muted-foreground">
                (module/department access grouping)
              </span>
            </Label>

            {/* Selected tags display */}
            {Array.isArray(formData.specialTags) && formData.specialTags.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mb-2">
                {formData.specialTags.map((tag) => (
                  <Badge
                    key={tag}
                    variant="secondary"
                    className="flex items-center gap-1 pl-2 pr-1 py-0.5 text-xs cursor-pointer hover:bg-red-100 hover:text-red-700 transition-colors"
                    onClick={() => removeTag(tag)}
                  >
                    {tag}
                    <X className="w-3 h-3" />
                  </Badge>
                ))}
              </div>
            )}

            {/* Tag checkboxes — only onCheckedChange fires; no onClick on wrapper to avoid double-trigger */}
            <div className="grid grid-cols-2 gap-1.5 border rounded-md p-3 bg-gray-50">
              {SPECIAL_TAGS.map((tag) => {
                const isSelected = Array.isArray(formData.specialTags) && formData.specialTags.includes(tag);
                return (
                  <div
                    key={tag}
                    className="flex items-center gap-2"
                  >
                    <Checkbox
                      id={`tag-${tag}`}
                      checked={isSelected}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setFormData((prev) => ({
                            ...prev,
                            specialTags: [...(Array.isArray(prev.specialTags) ? prev.specialTags : []), tag],
                          }));
                        } else {
                          setFormData((prev) => ({
                            ...prev,
                            specialTags: (Array.isArray(prev.specialTags) ? prev.specialTags : []).filter((t) => t !== tag),
                          }));
                        }
                      }}
                    />
                    <label
                      htmlFor={`tag-${tag}`}
                      className="text-sm cursor-pointer select-none"
                      onClick={(e) => e.preventDefault()}
                    >
                      {tag}
                    </label>
                  </div>
                );
              })}
            </div>
            {(!Array.isArray(formData.specialTags) || formData.specialTags.length === 0) && (
              <p className="text-xs text-muted-foreground mt-1">
                No tags selected — existing permissions apply as normal.
              </p>
            )}
          </div>

          {/* Approval Status */}
          <div className="flex items-center space-x-2">
            <Checkbox
              id="approved"
              checked={formData.approved}
              onCheckedChange={(checked) =>
                setFormData({ ...formData, approved: checked as boolean })
              }
            />
            <Label htmlFor="approved" className="cursor-pointer">
              Approved
            </Label>
          </div>

          {/* Password Change Required */}
          <div className="flex items-center space-x-2">
            <Checkbox
              id="passwordChangeRequired"
              checked={formData.passwordChangeRequired}
              onCheckedChange={(checked) =>
                setFormData({
                  ...formData,
                  passwordChangeRequired: checked as boolean,
                })
              }
            />
            <Label htmlFor="passwordChangeRequired" className="cursor-pointer">
              Require Password Change on Next Login
            </Label>
          </div>

          {/* User Info */}
          <div className="bg-gray-50 p-3 rounded text-sm text-gray-600 space-y-1">
            <p>
              <strong>Created:</strong>{" "}
              {new Date(user.createdAt).toLocaleDateString()}
            </p>
            <p>
              <strong>Last Updated:</strong>{" "}
              {new Date(user.updatedAt).toLocaleDateString()}
            </p>
            <p>
              <strong>Last Signed In:</strong>{" "}
              {user.lastSignedIn
                ? new Date(user.lastSignedIn).toLocaleDateString()
                : "Never"}
            </p>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={updateMutation.isPending}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={updateMutation.isPending}
            >
              {updateMutation.isPending ? "Saving..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
