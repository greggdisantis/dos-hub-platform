import { useState, useCallback, useEffect, useRef } from "react";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

// All 1/16th fraction options matching the old module's FRACTION_OPTIONS
function gcd(a: number, b: number): number {
  return b === 0 ? a : gcd(b, a % b);
}

const FRACTION_OPTIONS = Array.from({ length: 16 }, (_, i) => {
  if (i === 0) return { value: 0, label: "0" };
  const d = gcd(i, 16);
  return { value: i / 16, label: `${i / d}/${16 / d}` };
});

interface FractionInputProps {
  label?: string;
  shortLabel?: string;
  value: number | null;
  onChange: (value: number | null) => void;
  required?: boolean;
  disabled?: boolean;
  className?: string;
  showLabel?: boolean;
}

/**
 * Measurement input matching the old module:
 * [whole inches text field] [fraction dropdown button]
 * Stores and returns decimal inches (e.g. 47.5 for 47 1/2").
 */
export function FractionInput({
  label,
  shortLabel,
  value,
  onChange,
  required = false,
  disabled = false,
  className,
  showLabel = true,
}: FractionInputProps) {
  const [showPicker, setShowPicker] = useState(false);
  const pickerRef = useRef<HTMLDivElement>(null);

  const wholeInches = value != null ? Math.floor(value) : null;
  const fracValue = value != null ? Math.round((value - Math.floor(value)) * 16) / 16 : 0;

  const [editWhole, setEditWhole] = useState(wholeInches != null ? String(wholeInches) : "");
  const [editFrac, setEditFrac] = useState(fracValue);

  useEffect(() => {
    if (value != null) {
      setEditWhole(String(Math.floor(value)));
      setEditFrac(Math.round((value - Math.floor(value)) * 16) / 16);
    } else {
      setEditWhole("");
      setEditFrac(0);
    }
  }, [value]);

  useEffect(() => {
    if (!showPicker) return;
    const handler = (e: MouseEvent) => {
      if (pickerRef.current && !pickerRef.current.contains(e.target as Node)) {
        setShowPicker(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [showPicker]);

  const commitValue = useCallback(
    (whole: string, frac: number) => {
      if (whole === "" || whole === "0") { onChange(null); return; }
      const w = parseInt(whole, 10);
      if (isNaN(w) || w < 0) { onChange(null); return; }
      const total = w + frac;
      onChange(total > 0 ? total : null);
    },
    [onChange]
  );

  const handleWholeChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    setEditWhole(e.target.value.replace(/[^0-9]/g, ""));
  }, []);

  const handleWholeBlur = useCallback(() => {
    commitValue(editWhole, editFrac);
  }, [editWhole, editFrac, commitValue]);

  const handleFracSelect = useCallback(
    (frac: number) => {
      setEditFrac(frac);
      setShowPicker(false);
      commitValue(editWhole, frac);
    },
    [editWhole, commitValue]
  );

  const fracDisplay = (() => {
    const sixteenths = Math.round(editFrac * 16);
    if (sixteenths <= 0 || sixteenths >= 16) return "0";
    const g = gcd(sixteenths, 16);
    return `${sixteenths / g}/${16 / g}`;
  })();

  const displayLabel = label && shortLabel ? `${label} (${shortLabel})` : label ?? shortLabel ?? "";

  return (
    <div className={cn("flex flex-col gap-1", className)}>
      {showLabel && displayLabel && (
        <label className="text-xs font-semibold text-muted-foreground">
          {displayLabel}
          {required && <span className="text-destructive ml-0.5">*</span>}
        </label>
      )}
      <div className="flex gap-1.5 relative">
        <Input
          type="text"
          inputMode="numeric"
          pattern="[0-9]*"
          value={editWhole}
          onChange={handleWholeChange}
          onBlur={handleWholeBlur}
          disabled={disabled}
          placeholder="—"
          className="flex-1 min-w-0 h-9 text-sm font-mono"
        />
        <button
          type="button"
          disabled={disabled}
          onClick={() => setShowPicker((v) => !v)}
          className={cn(
            "h-9 px-2.5 rounded-md border text-sm font-mono min-w-[52px] flex items-center justify-center gap-1",
            "bg-background hover:bg-muted transition-colors border-input",
            disabled && "opacity-50 cursor-not-allowed"
          )}
        >
          <span>{fracDisplay}</span>
          <span className="text-muted-foreground text-[10px]">▼</span>
        </button>

        {showPicker && (
          <div
            ref={pickerRef}
            className="absolute top-full right-0 mt-1 z-50 bg-popover border rounded-md shadow-lg w-32 max-h-64 overflow-y-auto"
          >
            <div className="px-3 py-2 text-xs font-semibold text-muted-foreground border-b">
              Fraction (1/16ths)
            </div>
            {FRACTION_OPTIONS.map((opt) => (
              <button
                key={opt.label}
                type="button"
                onClick={() => handleFracSelect(opt.value)}
                className={cn(
                  "w-full px-3 py-2 text-sm font-mono text-left hover:bg-muted transition-colors",
                  editFrac === opt.value && "bg-primary/10 text-primary font-bold"
                )}
              >
                {opt.label}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/** Format decimal inches as fraction string for display (e.g. 47.5 → "47 1/2\"") */
export function formatInchesFrac(totalInches: number | null | undefined): string {
  if (totalInches == null || isNaN(totalInches)) return "—";
  const snapped = Math.round(totalInches * 16) / 16;
  const whole = Math.floor(snapped);
  const frac16 = Math.round((snapped - whole) * 16);
  if (frac16 <= 0 || frac16 >= 16) return `${whole}"`;
  const g = gcd(frac16, 16);
  return `${whole} ${frac16 / g}/${16 / g}"`;
}
