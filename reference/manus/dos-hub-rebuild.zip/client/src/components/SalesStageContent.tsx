import { useAuth } from "@/_core/hooks/useAuth";
import { Breadcrumb } from "@/components/Breadcrumb";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Loader2 } from "lucide-react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useState } from "react";

export function SalesStageContent() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");

  // Mock project data - will be replaced with actual API calls
  const mockProjects = [
    {
      id: 1,
      name: "Acme Corp - Office Screens",
      clientName: "Acme Corporation",
      status: "in-progress",
      lastUpdated: "2 hours ago",
    },
    {
      id: 2,
      name: "Tech Startup - Partition System",
      clientName: "Tech Startup Inc",
      status: "pending",
      lastUpdated: "1 day ago",
    },
    {
      id: 3,
      name: "Enterprise Solutions - Full Build",
      clientName: "Enterprise Solutions",
      status: "completed",
      lastUpdated: "3 days ago",
    },
  ];

  // Fetch CMR reports for Sales stage
  const { data: allCMRReports, isLoading: cmrLoading } = trpc.cmr.list.useQuery();

  const stageStats = {
    active: 8,
    pending: 3,
    total: 15,
  };

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800";
      case "in-progress":
        return "bg-blue-100 text-blue-800";
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const filteredProjects = mockProjects.filter(
    (project) =>
      project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.clientName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <Breadcrumb items={[{ label: "Sales" }]} />

        {/* Header */}
        <div className="flex justify-between items-start mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2">Sales</h1>
            <p className="text-muted-foreground">
              Manage client meetings, proposals, and deal tracking. CMR reports and client interactions live here.
            </p>
          </div>
          <Button onClick={() => setLocation("/project/new?stage=sales")} size="lg" className="gap-2">
            <Plus className="w-4 h-4" />
            New Project
          </Button>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <Card className="p-4">
            <div className="text-sm text-muted-foreground">Active</div>
            <div className="text-2xl font-bold">{stageStats.active}</div>
          </Card>
          <Card className="p-4">
            <div className="text-sm text-muted-foreground">Pending</div>
            <div className="text-2xl font-bold">{stageStats.pending}</div>
          </Card>
          <Card className="p-4">
            <div className="text-sm text-muted-foreground">Total</div>
            <div className="text-2xl font-bold">{stageStats.total}</div>
          </Card>
        </div>

        {/* Tabs for Projects and CMR */}
        <Tabs defaultValue="projects" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="projects">Projects</TabsTrigger>
            <TabsTrigger value="cmr">
              Recent CMR Reports
              {allCMRReports && allCMRReports.length > 0 && (
                <Badge variant="secondary" className="ml-2">
                  {allCMRReports.length}
                </Badge>
              )}
            </TabsTrigger>
          </TabsList>

          {/* Projects Tab */}
          <TabsContent value="projects" className="space-y-4 mt-6">
            {/* Search */}
            <div className="flex gap-4 mb-6">
              <Input
                placeholder="Search projects..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1"
              />
            </div>

            {/* Project List */}
            <div className="space-y-3">
              {filteredProjects.map((project) => (
                <Card
                  key={project.id}
                  className="p-4 cursor-pointer hover:bg-accent transition-colors"
                  onClick={() => setLocation(`/project/${project.id}`)}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold">{project.name}</h3>
                      <p className="text-sm text-muted-foreground">{project.clientName}</p>
                    </div>
                    <div className="text-right">
                      <Badge className={`text-sm ${getStatusBadgeColor(project.status)}`}>
                        {project.status}
                      </Badge>
                      <p className="text-xs text-muted-foreground mt-1">{project.lastUpdated}</p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* CMR Tab */}
          <TabsContent value="cmr" className="space-y-4 mt-6">
            {cmrLoading ? (
              <Card className="p-6">
                <div className="flex items-center justify-center h-32">
                  <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
                </div>
              </Card>
            ) : allCMRReports && allCMRReports.length > 0 ? (
              <div className="space-y-3">
                {allCMRReports.slice(0, 10).map((report) => (
                  <Card
                    key={report.id}
                    className="p-4 cursor-pointer hover:bg-accent transition-colors"
                    onClick={() => setLocation(`/dashboard/cmr/${report.id}`)}
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h3 className="font-semibold">{report.clientName}</h3>
                        <p className="text-sm text-muted-foreground">
                          {report.appointmentDate ? new Date(report.appointmentDate).toLocaleDateString("en-US", {
                            year: "numeric",
                            month: "short",
                            day: "numeric",
                          }) : new Date(report.createdAt).toLocaleDateString("en-US", {
                            year: "numeric",
                            month: "short",
                            day: "numeric",
                          })}
                        </p>
                        {report.pcNotes && (
                          <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{report.pcNotes}</p>
                        )}
                        {report.dealStatus && (
                          <p className="text-xs text-muted-foreground mt-1">
                            Deal: <span className="font-medium">{report.dealStatus}</span>
                          </p>
                        )}
                      </div>
                      <Badge className="text-xs">
                        {report.status}
                      </Badge>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="p-6">
                <p className="text-sm text-muted-foreground text-center py-4">
                  No CMR reports yet. Create one in a project to get started.
                </p>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
