/**
 * DOS Hub — Permission Helper Utilities
 *
 * Three-layer permission model:
 *   1. Role       — authority level (super-admin > admin > manager > member > guest > pending)
 *   2. User Type  — company relationship (internal, dealer, sub-dealer, vendor, guest)
 *   3. Special Tags — module/department/feature access grouping
 *
 * Usage (server-side in tRPC procedures):
 *   import { hasRole, hasTag, hasModuleAccess } from "../../shared/permissions";
 *   if (!hasModuleAccess(ctx.user, "permits")) throw new TRPCError({ code: "FORBIDDEN" });
 *
 * Usage (client-side in React):
 *   import { hasRole, hasTag } from "@/shared/permissions";
 *   const canAccessFinance = hasTag(user, "Finance");
 */

// ─── Types ────────────────────────────────────────────────────────────────────

export type UserRole =
  | "super-admin"
  | "admin"
  | "manager"
  | "member"
  | "guest"
  | "pending";

export type UserType =
  | "internal"
  | "dealer"
  | "sub-dealer"
  | "vendor"
  | "guest";

/** Minimal user shape required by all permission helpers */
export interface PermissionUser {
  role: string;
  userType?: string | null;
  specialTags?: string[] | null;
}

// ─── Role Hierarchy ───────────────────────────────────────────────────────────

const ROLE_RANK: Record<string, number> = {
  "super-admin": 100,
  admin: 80,
  manager: 60,
  member: 40,
  guest: 20,
  pending: 0,
};

/**
 * Returns true if the user has the exact role specified.
 * Prefer hasMinRole() for most access gates.
 */
export function hasRole(user: PermissionUser | null | undefined, role: UserRole): boolean {
  if (!user) return false;
  return user.role === role;
}

/**
 * Returns true if the user's role is at least the specified minimum.
 * super-admin always passes.
 *
 * @example hasMinRole(user, "manager") // true for manager, admin, super-admin
 */
export function hasMinRole(
  user: PermissionUser | null | undefined,
  minRole: UserRole
): boolean {
  if (!user) return false;
  const userRank = ROLE_RANK[user.role] ?? 0;
  const minRank = ROLE_RANK[minRole] ?? 0;
  return userRank >= minRank;
}

/**
 * Returns true if the user is a super-admin.
 * Super-admins bypass all other permission checks.
 */
export function isSuperAdmin(user: PermissionUser | null | undefined): boolean {
  return user?.role === "super-admin";
}

// ─── Special Tag Helpers ──────────────────────────────────────────────────────

/**
 * Returns the user's special tags as a clean array (never null/undefined).
 */
function getTags(user: PermissionUser | null | undefined): string[] {
  if (!user) return [];
  if (!Array.isArray(user.specialTags)) return [];
  return user.specialTags;
}

/**
 * Returns true if the user has the specified special tag.
 * Case-sensitive match.
 */
export function hasTag(
  user: PermissionUser | null | undefined,
  tag: string
): boolean {
  if (isSuperAdmin(user)) return true; // super-admin bypasses all tag checks
  return getTags(user).includes(tag);
}

/**
 * Returns true if the user has at least one of the specified tags.
 */
export function hasAnyTag(
  user: PermissionUser | null | undefined,
  tags: string[]
): boolean {
  if (isSuperAdmin(user)) return true;
  const userTags = getTags(user);
  return tags.some((t) => userTags.includes(t));
}

/**
 * Returns true if the user has all of the specified tags.
 */
export function hasAllTags(
  user: PermissionUser | null | undefined,
  tags: string[]
): boolean {
  if (isSuperAdmin(user)) return true;
  const userTags = getTags(user);
  return tags.every((t) => userTags.includes(t));
}

// ─── Module Access Map ────────────────────────────────────────────────────────

/**
 * Module access configuration.
 * Each module can be unlocked by:
 *   - minRole: minimum role required (inclusive)
 *   - tags: any of these special tags grants access
 *
 * super-admin always has access to every module.
 * admin always has access to every module.
 */
export const MODULE_ACCESS: Record<
  string,
  { minRole?: UserRole; tags?: string[] }
> = {
  // Core modules — accessible to all approved users
  dashboard: { minRole: "member" },
  projects: { minRole: "member" },
  cmr: { minRole: "member" },

  // Department modules — role OR tag
  permits: { minRole: "manager", tags: ["Permit Dept"] },
  finance: { minRole: "manager", tags: ["Finance"] },
  sales: { minRole: "manager", tags: ["Sales"] },
  engineering: { minRole: "manager", tags: ["Engineering"] },
  screens: { minRole: "manager", tags: ["Screens"] },
  commercial: { minRole: "manager", tags: ["Commercial"] },
  service: { minRole: "manager", tags: ["Service"] },
  operations: { minRole: "manager", tags: ["Operations"] },
  marketing: { minRole: "manager", tags: ["Marketing"] },
  leadership: { minRole: "admin", tags: ["Leadership"] },
  hr: { minRole: "admin", tags: ["HR"] },

  // Admin-only modules
  "user-management": { minRole: "admin" },
  "system-settings": { minRole: "admin" },
  analytics: { minRole: "manager", tags: ["Leadership", "Finance"] },
};

/**
 * Returns true if the user can access the given module.
 *
 * Access is granted if:
 *   - user is super-admin (always)
 *   - user is admin (always)
 *   - user meets the minRole requirement, OR
 *   - user has any of the required tags
 *
 * @example hasModuleAccess(user, "permits")
 */
export function hasModuleAccess(
  user: PermissionUser | null | undefined,
  moduleKey: string
): boolean {
  if (!user) return false;
  if (isSuperAdmin(user)) return true;
  if (hasRole(user, "admin")) return true;

  const config = MODULE_ACCESS[moduleKey];
  if (!config) {
    // Unknown module — default to admin-only
    return hasRole(user, "admin");
  }

  // Check minimum role
  if (config.minRole && hasMinRole(user, config.minRole)) return true;

  // Check special tags
  if (config.tags && hasAnyTag(user, config.tags)) return true;

  return false;
}

// ─── Feature Access Map ───────────────────────────────────────────────────────

/**
 * Feature-level access (more granular than module access).
 * Wire these up as needed when building specific UI features.
 */
export const FEATURE_ACCESS: Record<
  string,
  { minRole?: UserRole; tags?: string[] }
> = {
  // CMR features
  "cmr.view-all": { minRole: "manager" },
  "cmr.approve": { minRole: "manager" },
  "cmr.export": { minRole: "manager", tags: ["Sales", "Leadership"] },

  // Finance features
  "finance.view-commissions": { minRole: "admin", tags: ["Finance"] },
  "finance.edit-commissions": { minRole: "admin" },

  // User management features
  "users.edit": { minRole: "admin" },
  "users.view-tags": { minRole: "manager", tags: ["HR", "Leadership"] },

  // Permit features
  "permits.submit": { tags: ["Permit Dept"] },
  "permits.approve": { minRole: "manager", tags: ["Permit Dept"] },
};

/**
 * Returns true if the user can access the given feature.
 * Same logic as hasModuleAccess but for granular feature flags.
 *
 * @example hasFeatureAccess(user, "cmr.approve")
 */
export function hasFeatureAccess(
  user: PermissionUser | null | undefined,
  featureKey: string
): boolean {
  if (!user) return false;
  if (isSuperAdmin(user)) return true;
  if (hasRole(user, "admin")) return true;

  const config = FEATURE_ACCESS[featureKey];
  if (!config) return false;

  if (config.minRole && hasMinRole(user, config.minRole)) return true;
  if (config.tags && hasAnyTag(user, config.tags)) return true;

  return false;
}

// ─── Combined Checks ──────────────────────────────────────────────────────────

/**
 * Returns true if user meets role + tag requirements simultaneously.
 * Useful for "Managers with Permit Dept tag" style rules.
 *
 * @example hasRoleAndTag(user, "manager", "Permit Dept")
 */
export function hasRoleAndTag(
  user: PermissionUser | null | undefined,
  minRole: UserRole,
  tag: string
): boolean {
  if (isSuperAdmin(user)) return true;
  return hasMinRole(user, minRole) && hasTag(user, tag);
}

/**
 * Returns a summary of the user's effective permissions for debugging.
 */
export function getPermissionSummary(user: PermissionUser | null | undefined): {
  role: string;
  userType: string;
  specialTags: string[];
  isSuperAdmin: boolean;
  accessibleModules: string[];
} {
  if (!user) {
    return {
      role: "none",
      userType: "none",
      specialTags: [],
      isSuperAdmin: false,
      accessibleModules: [],
    };
  }

  const accessibleModules = Object.keys(MODULE_ACCESS).filter((key) =>
    hasModuleAccess(user, key)
  );

  return {
    role: user.role,
    userType: user.userType || "unknown",
    specialTags: getTags(user),
    isSuperAdmin: isSuperAdmin(user),
    accessibleModules,
  };
}
