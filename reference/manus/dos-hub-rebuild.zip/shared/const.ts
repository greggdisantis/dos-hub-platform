export const COOKIE_NAME = "app_session_id";
export const ONE_YEAR_MS = 1000 * 60 * 60 * 24 * 365;
export const AXIOS_TIMEOUT_MS = 30_000;
export const UNAUTHED_ERR_MSG = 'Please login (10001)';
export const NOT_ADMIN_ERR_MSG = 'You do not have required permission (10002)';

/**
 * Permanent super-admin email addresses
 * These accounts are automatically approved and assigned super-admin role
 * They cannot lose the super-admin role
 */
export const PERMANENT_SUPER_ADMIN_EMAILS = [
  "greggdisantis@gmail.com",
  "gdisantis@distinctiveos.com",
];

/**
 * Check if an email is a permanent super-admin
 */
export function isPermanentSuperAdmin(email: string): boolean {
  return PERMANENT_SUPER_ADMIN_EMAILS.includes(email.toLowerCase());
}
