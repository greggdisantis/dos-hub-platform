# DOS Hub Rebuild - Project TODO

## Foundation & Core Systems

- [x] Email/password authentication system (replace OAuth with email/password login)
- [x] User role system (pending, guest, member, manager, admin, super-admin)
- [x] User approval workflow for new registrations
- [x] Database schema with Drizzle ORM (users table with email/password fields)
- [x] Session management and JWT authentication
- [x] Secure password hashing (bcrypt)
- [ ] Project-centered architecture (central hub for HubSpot/Service Fusion integration)
- [ ] Project table with external system references
- [ ] Role-based access control (RBAC) middleware and procedures
- [ ] Database schema for remaining tables (screen_orders, receipts, aquaclean_receipts, precon_checklists, time_off_requests, module_permissions)

## Authentication UI & Access Control

- [x] Login page with email/password form
- [x] Signup page with email/first name/last name/password form
- [x] Form validation (email format, password length, password match)
- [x] Error handling and display
- [x] Success states and redirects
- [x] Route protection (redirect unauthenticated users to login)
- [x] Strict authentication enforcement (no browsing without login)
- [x] Logout functionality
- [x] App routing setup
- [x] Permanent super-admin accounts (auto-approved)
- [x] Email-based user identity (not name-based)
- [x] Admin approval workflow (super-admin page to approve/reject users)
- [x] Profile completion flow (check for missing firstName/lastName after login)
- [x] Complete Profile page (for users with incomplete profiles)
- [x] User migration preparation (support for legacy users with missing names)

## Navigation Architecture (Stage-Based + Project-Centered)

- [ ] Update Project table with projectStage field
- [ ] Create Stage Overview pages (Sales, Engineering, Production, Install, Service, Admin)
- [ ] Build Project Hub layout with tabs
- [ ] Implement breadcrumb navigation component
- [ ] Implement back button logic
- [ ] Create stage-based project filtering
- [ ] Add project list components

## Feature Modules

### 1. CMR (Client Meeting Report) Module
- [x] Create CMR report (form with attendees, notes, action items)
- [x] Edit CMR report
- [x] View CMR report details
- [x] CMR dashboard with filtering (by date, client, status)
- [x] CMR approval workflow (draft → submitted → approved)
- [x] Link CMR to Project table (integration-ready)
- [ ] Migrate legacy CMR records to Project-linked structure
- [ ] PDF export for CMR reports (using shared PDF system)
- [x] API endpoints for CMR CRUD operations

### CMR Restoration Phase 1: Database Schema
- [x] Add 37+ missing fields to cmr_reports table (additive only)
- [x] Update dealStatus enum with original options
- [x] Create performance indexes
- [x] Preserve existing CMR records

### CMR Restoration Phase 2: Workflow Logic
- [ ] Add originalPcPct locking on first submission
- [ ] Add outcome finality logic (sold/lost cannot revert to open)
- [ ] Add progress notes creation with timestamps
- [ ] Add required field validation
- [ ] Add conditional field validation
- [ ] Update tRPC endpoints to enforce workflow logic
- [ ] Write tests for workflow behavior

### CMR Restoration Phase 3: Form & UI
- [ ] Restore multi-step form (6 sections)
- [ ] Add conditional field visibility
- [ ] Restore all field types (text, date, dropdown, multi-select, slider, switch)
- [ ] Add form validation error messages
- [ ] Add auto-save for drafts
- [ ] Restore progress notes editor

### CMR Restoration Phase 4: List & Detail Pages
- [ ] Restore list page filters (consultant, month, deal status, lead source, project type)
- [ ] Restore grouping (by consultant, by month)
- [ ] Restore sorting options
- [ ] Restore row actions (edit, delete, export)
- [ ] Restore detail page with all 6 sections
- [ ] Restore approval controls
- [ ] Restore full PDF layout

### Shared PDF Export System
- [x] Design shared PDF architecture with standardized header
- [x] Create shared PDF service with pagination and formatting utilities
- [x] Implement CMR PDF export using shared system
- [x] Test PDF output, pagination, and formatting
- [x] Verify office-quality formatting and blank page prevention
- [x] Create server/pdf/engine.ts — Puppeteer singleton browser launcher
- [x] Create server/pdf/render.ts — shared renderToPdf(html) function
- [x] Create server/pdf/base.css — shared print stylesheet for all reports
- [x] Rewrite server/pdf/modules/cmr.ts as HTML template builder (no PDFKit)
- [x] Validate CMR PDF output — page count, layout, filename, TypeScript
- [x] Swap cmr-export.ts router to use new Puppeteer engine
- [x] Remove old PDFKit files (builder.ts, header.ts, pagination.ts, formatting.ts)
- [x] Update server/pdf/README.md for new architecture
- [x] Trace Download PDF button — which route it calls
- [x] Trace Print button — which path it uses
- [x] Fix failing export error — added manager role to permissions check
- [x] Unify both buttons to new Puppeteer export path
- [x] Remove/disable old bubbly PDF path for CMR

### 2. Screen Measurement Tool
- [ ] Create screen measurement record
- [ ] Capture on-site measurements (width, height, quantity)
- [ ] Photo capture integration
- [ ] Auto-calculate material needs
- [ ] Edit screen measurement record
- [ ] View screen measurement details
- [ ] Link to material orders
- [ ] PDF export with measurements
- [ ] API endpoints for screen measurements

### 3. Material Checklist Module
- [ ] Create material checklist (project-based)
- [ ] Track material deliveries
- [ ] Order status updates (pending, ordered, delivered, installed)
- [ ] Material categorization
- [ ] Delivery date tracking
- [ ] Completion status tracking
- [ ] Edit material checklist
- [ ] View material checklist details
- [ ] PDF export for material checklists
- [ ] API endpoints for material checklists

### 4. Receipt Capture Tool
- [ ] Create receipt record
- [ ] Photo/image upload for receipts
- [ ] OCR/AI extraction of line items (optional enhancement)
- [ ] Expense categorization (Job vs Overhead)
- [ ] Vendor tracking
- [ ] Edit receipt record
- [ ] View receipt details
- [ ] Archive old receipts
- [ ] Receipt dashboard with filters
- [ ] PDF export for receipts
- [ ] API endpoints for receipt CRUD

### 5. AquaClean Receipt Capture (Separate Module)
- [ ] Create AquaClean receipt record
- [ ] Photo/image upload for AquaClean receipts
- [ ] Expense categorization (Job vs Overhead)
- [ ] Vendor tracking
- [ ] Edit AquaClean receipt record
- [ ] View AquaClean receipt details
- [ ] Archive AquaClean receipts
- [ ] AquaClean receipt dashboard with filters
- [ ] PDF export for AquaClean receipts
- [ ] API endpoints for AquaClean receipt CRUD
- [ ] Ensure complete data isolation from standard receipts

### 6. Preconstruction Checklist Module
- [ ] Create preconstruction checklist (project-based)
- [ ] Task assignment to team members
- [ ] Completion tracking per task
- [ ] Edit preconstruction checklist
- [ ] View preconstruction checklist details
- [ ] Completion percentage calculation
- [ ] PDF export for preconstruction checklists
- [ ] API endpoints for preconstruction checklists

### 7. Dashboard System
- [x] Role-based dashboard shell (member, manager, admin, super-admin)
- [x] Post-login landing behavior by role
- [x] Collapsible sidebar navigation
- [x] Module quick-access tiles
- [x] Role-based module visibility
- [x] User profile display in sidebar
- [x] Admin section for user management
- [x] Super-admin approval access
- [ ] Main office dashboard enhancements (activity feed, metrics)
- [ ] Admin dashboard enhancements (system analytics)
- [ ] Super-admin dashboard enhancements (full system control)

## Desktop UI/UX

- [ ] Desktop-first responsive layout (Tailwind CSS)
- [ ] Sophisticated navigation structure (sidebar or top nav)
- [ ] High-density dashboard for office staff
- [ ] Complex workflow UI for data entry
- [ ] Consistent design system across all modules
- [ ] Loading states and error handling
- [ ] Empty states for all list views
- [ ] Form validation and user feedback

## Testing & Deployment

- [ ] Unit tests for authentication logic
- [ ] Integration tests for API endpoints
- [ ] E2E tests for critical user flows
- [ ] Database migration testing
- [ ] Deployment configuration verification
- [ ] Cloud Run deployment setup
- [ ] Environment variables configuration

## Vite Dev Server Fix (2026-03-18)

- [x] Fix blank white screen: removed nanoid cache-buster from vite.ts (was causing Vite pre-transform errors on /src/main.tsx?v=... URLs)
- [x] Fix blank white screen: added missing Vite plugins (react, tailwindcss, jsxLoc, manusRuntime) to inline Vite server config in server/_core/vite.ts

## Future Enhancements (Not in MVP)

- [ ] Service Fusion Intelligence integration
- [ ] HubSpot integration
- [ ] AI assistant integration
- [ ] Mobile app (React Native/Expo)
- [ ] Time Off Management module
- [ ] Real-time notifications
- [ ] Advanced reporting and analytics


## User Migration from Legacy System

### Migration Rules (MUST FOLLOW)
- [ ] Permanent super-admin accounts: Greggdisantis@gmail.com, Gdisantis@distinctiveos.com (cannot be overwritten)
- [ ] Email-based matching only (never match by name)
- [ ] No duplicate users (update existing by email, don't create new)
- [ ] Allow import of users with missing firstName/lastName
- [ ] Force profile completion on first login for incomplete profiles
- [ ] Preserve roles from legacy data where possible
- [ ] Do not auto-approve unknown users without review

### Migration Process
- [ ] Inspect legacy user export ZIP file
- [ ] Extract and analyze all legacy users
- [ ] Identify duplicates, missing names, and role information
- [ ] Compare with current system (currently 0 users)
- [ ] Propose migration plan for user approval
- [ ] Execute migration after confirmation
- [ ] Verify all users imported correctly
- [ ] Test profile completion flow with migrated users

### 8. User Management Module
- [x] Create tRPC endpoints for user management (list, update, approve, deactivate)
- [x] Build User Management page with table view of all users
- [x] Implement search functionality (by email, name)
- [x] Implement filters (role, userType, approval status, active/inactive)
- [x] Implement user edit/update modal with controls for:
  - [x] Role selection (pending, guest, member, manager, admin, super-admin)
  - [x] UserType selection (internal, dealer, sub-dealer, vendor, guest)
  - [x] Approval status toggle (approved/pending)
  - [x] First name and last name editing
- [ ] Add bulk actions (approve multiple users, change roles)
- [ ] Add user deactivation/reactivation
- [ ] Add audit logging for user management actions
- [x] Test User Management end-to-end


## Test Data Management & Safeguards

### Cleanup Completed (2026-03-09)
- [x] Identified and deleted 32 test/fake user accounts (test-pwd-*, cmr-project-test-*, test-password-change-*)
- [x] Verified 17 real users remain with correct roles
- [x] Confirmed login, CMR, and User Management still work
- [x] Verified no foreign key errors from CMR/projects/auth

### Future Safeguards (To Implement)
- [ ] Separate test database for development/testing (do not use production database)
- [ ] Auto-cleanup script for test data after test runs
- [ ] Pre-commit hook to prevent test account patterns from being committed
- [ ] Documentation: Test data naming conventions and cleanup procedures
- [ ] CI/CD integration: Automatic test data cleanup after test suite runs

## CMR Phase 3 — Advanced Features

- [ ] CMR: Add addUpdateNote procedure to router
- [ ] CMR: Add quickEdit procedure to router (estimatedValue + currentConfidencePct)
- [ ] CMR: Update list page with inline quick edit (estimatedValue, currentConfidencePct)
- [ ] CMR: Show estimated value on CMR list cards
- [ ] CMR: Show latest update note preview on CMR list
- [ ] CMR: Update detail page with update notes history (newest first)
- [ ] CMR: Show originalPcPct (locked) and currentConfidencePct (editable) separately in detail
- [ ] CMR: Build Analytics tab with filters and all 15+ metrics
- [ ] CMR: Add Print button to CMR list
- [ ] CMR: Add Export CSV button to CMR list
- [ ] CMR: Verify backward compatibility with all 11 imported records

## CMR Form Refinements (Phase 4)

- [x] CMR Step 1: Phone → Converted to In-Person conditional flow
- [x] CMR Step 1: Lead Source Other/ClientRef/ContractorRef conditional text fields
- [x] CMR Step 2: Other project type conditional text field
- [x] CMR Step 3: Other deal status conditional text field
- [x] CMR Step 3: Proposal Presented date conditional field
- [x] CMR Step 3: Lost reason conditional text field
- [x] CMR Step 4: Structured Main Motivation selectable options + Other text + info button
- [x] CMR Step 4: Structured Main Hesitation selectable options + Other text + info button
- [x] CMR Step 5: Restructure into Financing section + Value Communicated section
- [x] CMR Step 5: Updated Value Communicated options list
- [x] CMR Step 5: Objection Notes text box
- [x] CMR Step 5: Client Response Other conditional text field
- [x] CMR Step 5: Remove Objections checklist from this step
- [x] CMR Step 6: Other next action conditional text field
- [x] CMR Step 6: Estimated Contract Value currency formatting
- [x] CMR: New Latest Notes step (update note history + add note inline)
- [x] CMR: Update step count to 8 (was 7), update progress bar
- [x] CMR: Update CMR router to handle all new conditional fields
- [x] CMR: Update CMRView detail page to display all new conditional fields safely
- [x] CMR: Verify backward compatibility with all imported records

## Special Tags — User Permissions System

- [x] Add specialTags JSON column to users schema
- [x] Apply database migration for specialTags
- [x] Update user management endpoints to support specialTags read/write
- [x] Update User Edit modal with multi-select Special Tags UI
- [x] Display Special Tags in user list/admin view
- [x] Create permission helper utilities (hasRole, hasTag, hasAnyTag, hasModuleAccess, hasFeatureAccess, hasRoleAndTag)
- [x] Verify old users without tags still work correctly (38 permission tests pass)
- [x] Test: assign tags, save, reopen, confirm persistence

## User/Admin Cleanup & Tag Fix (2026-03-10)

- [x] Audit database for test/demo users (patterns: test-pwd-, cmr-project-test-, @test.com)
- [x] Remove identified test/demo users (24 removed, 17 real users preserved)
- [x] Diagnose Special Tags click error in UserEditModal (double-trigger: div onClick + Checkbox onCheckedChange both firing)
- [x] Fix Special Tags click error (removed div onClick, split into add/remove handlers, null-safe Array.isArray guards)
- [x] Validate all user edit fields still work after fix (103/103 tests pass)
- [x] Confirm no front-end crash on empty/null tags state (Array.isArray guards on all tag reads)

## Auth / User Access Verification (2026-03-10)

- [x] Audit login handler: approved check, passwordChangeRequired check, session creation
- [x] Trace password-change-on-next-login flow end-to-end (frontend route + backend enforcement)
- [x] Fix password change flow: setState-in-render crash + auth.me invalidation after change
- [x] Verify approved/unapproved flag behavior (all 17 real users approved=1)
- [x] Verify role loads correctly after login (full User row returned by auth.me)
- [x] Verify logout clears session (clearCookie confirmed)
- [x] Verify specialTags do not interfere with login (JSON column, not in JWT)
- [x] Confirm no console/runtime crash during auth (103/103 tests pass)
- [x] Add afterEach/afterAll cleanup to auth-password-change.test.ts and cmr-project-integration.test.ts
- [x] Delete 4 new test accounts created by test suite after last cleanup (IDs 90001-90004)

## CMR Junk Record Cleanup (2026-03-10)

- [x] Audit all CMR records in database (58 total found)
- [x] Identify obvious junk/test/demo records (38 exact-name + 8 test/verification = 46 junk)
- [x] Flag uncertain records separately (none uncertain — all 12 real records had real client names)
- [x] Remove confirmed junk/test/demo records (46 deleted)
- [x] Identify source: cmr-project-integration.test.ts creates real DB records with no CMR cleanup
- [x] Fix: afterAll now uses deleteCMRReport() for each created CMR ID — verified 12 records remain after full test run
- [x] Verify real records remain intact (12 real records, all submitted, all with real client names)

## AUTH — Login Restoration (2026-03-10)

- [x] Capture exact login failure: auth.login returns success:true but auth.me returns null (cookie dropped)
- [x] Inspect real user DB records: all 17 real users intact, approved=1, hashes present
- [x] Verify auth.login contract: correct, no mismatch
- [x] Verify password comparison path: bcrypt working correctly
- [x] Identify regression source: Express missing app.set('trust proxy',1) — SameSite=None cookie rejected by browsers without Secure=true
- [x] Apply minimal safe fix: added app.set('trust proxy',1) to server/_core/index.ts before all middleware
- [x] Verify end-to-end login: auth.me returns full user object, dashboard loads, 103/103 tests pass

## Motorized Screens Module (2026-03-12)

- [x] Schema: 8 tables created (screen_manufacturers, screen_motor_types, screen_remote_types, screen_calculation_profiles, screen_measurement_headers, screen_measurement_lines, screen_measurement_attachments, screen_measurement_line_attachments)
- [x] DB migration: all tables applied with indexes and FK constraints
- [x] Reference data seeded: manufacturers, motor types, remote types, default calculation profile
- [x] Workflow engine: isTransitionAllowed, canView, canEditHeader, canEditLines, canApprove, canDelete, canManageAttachments
- [x] Calculation service: calculateScreenLine (slope, u-channel, buildout, orderable dims, flags, track-to-track)
- [x] API: tRPC router (screens.list, screens.get, screens.create, screens.update, screens.transition, screens.delete, screens.upsertLine, screens.getLines, screens.deleteLine, screens.addAttachment, screens.getAttachments, screens.deleteAttachment, screens.getReferenceData)
- [x] Router registered in main appRouter
- [x] List page: /dashboard/screens with My/All toggle, status filter, search, status badges, New Record button
- [x] Detail page: header settings, global settings, screen lines section, calculation outputs, notes, history, workflow buttons
- [x] Line editor: per-line measurement fields (T/M/B, UL/LL/OL, UR/LR/OR), power connection type, calculation outputs, photo attachments
- [x] App.tsx routes: /dashboard/screens and /dashboard/screens/:id wired
- [x] Sidebar nav updated with real module links
- [x] Screens module vitest tests: 46 new tests (workflow, permissions, calculation) — 149/149 total pass
- [ ] Publish verification: trust proxy fix must be verified on published build before release
- [ ] header.project_id → projects.id FK: relationship is nullable, pending project table integration

## Screens Route Fix (2026-03-12)

- [x] Fix route: /dashboard/screens → /screen-measurements in App.tsx
- [x] Fix route: /dashboard/screens/:id → /screen-measurements/:id in App.tsx
- [x] Update DashboardLayout sidebar nav href from /dashboard/screens to /screen-measurements
- [x] Update ScreenMeasurements.tsx internal navigation links (New Record, row click)
- [x] Update ScreenMeasurementDetail.tsx back-navigation link
- [x] Update Dashboard.tsx MODULE_LINKS and Dashboard.test.ts
- [x] Mark calculation engine as provisional (not approved until full rules prompt received)

## Receipt Capture Module (DOS: Receipt Capture) — Spec v3

### Database (dev DB only)
- [x] receipt_submissions table (id, submitterId, receiptDate, vendor, amount, receiptType, description, imageKey, status, financeNote, voidReason, createdAt, updatedAt)
- [x] receipt_line_items table (id, submissionId, description, amount, category, createdAt)
- [x] receipt_tags table (id, submissionId, tag, createdAt)
- [x] receipt_audit_log table (id, submissionId, actorId, action, fromStatus, toStatus, note, createdAt)
- [x] voidReason column added to receipt_submissions

### Server-Side
- [x] server/db-receipts.ts — all query helpers (getAll, getById, getMyReceipts, getFinanceInbox, getFinanceInProgress, getArchive, getAnalytics, create, updateStatus, updateFinanceNote, void, addLineItem, addTag, addAuditLog)
- [x] server/routers/receipts.ts — full tRPC router (list, getById, getMyReceipts, getFinanceInbox, getFinanceInProgress, getArchive, getAnalytics, create, submit, enterReceipt, completeReceipt, voidReceipt, exportPdf, uploadImage)
- [x] server/pdf/modules/receipt.ts — receipt PDF HTML template
- [x] receiptsRouter registered in server/routers.ts

### Client-Side Pages
- [x] client/src/pages/receipts/ReceiptCapture.tsx — hub page at /dashboard/receipts
- [x] client/src/pages/receipts/ReceiptNew.tsx — image upload + LLM analysis + form + submit
- [x] client/src/pages/receipts/MyReceipts.tsx — current user's receipts with status badges
- [x] client/src/pages/receipts/FinanceInbox.tsx — submitted receipts awaiting finance entry
- [x] client/src/pages/receipts/FinanceInProgress.tsx — receipts being processed by finance
- [x] client/src/pages/receipts/ReceiptArchive.tsx — search completed and voided receipts
- [x] client/src/pages/receipts/ReceiptAnalytics.tsx — submission trends, totals, processing metrics
- [x] client/src/pages/receipts/ReceiptDetail.tsx — view/edit single receipt, finance actions, PDF export

### Routing
- [x] /dashboard/receipts → ReceiptCapture hub
- [x] /dashboard/receipts/new → ReceiptNew
- [x] /dashboard/receipts/my → MyReceipts
- [x] /dashboard/receipts/finance/inbox → FinanceInbox
- [x] /dashboard/receipts/finance/in-progress → FinanceInProgress
- [x] /dashboard/receipts/archive → ReceiptArchive
- [x] /dashboard/receipts/analytics → ReceiptAnalytics
- [x] /dashboard/receipts/:id → ReceiptDetail

### Protected Systems (unchanged)
- [x] Auth — not modified
- [x] Secrets — not modified
- [x] Env — not modified
- [x] Deployment config — not modified
- [x] Storage config — not modified
- [x] Production DB — not touched

## Receipt Auto-Parse Fix (2026-03-18)

- [x] Fix stale closure bug: removed useCallback wrappers from handleFileSelect and runAnalysis — tRPC mutation references were stale inside closures causing parse to silently fail
- [x] Add isParsingRef guard to prevent duplicate parse calls
- [x] Ensure parse fires automatically after upload completes (no button click required)
- [x] Ensure Replace Image also triggers auto-parse
- [x] Zero TypeScript errors confirmed

## Receipt Capture Module Fixes (2026-03-18)

- [x] Remove all hardcoded default vendor names (e.g., "Home Depot") from form defaults and AI parse mapping
- [x] Fix AI parse call to trigger automatically on image upload/replace
- [x] Map all parsed fields into form state: vendorName, receiptDate, subtotal, tax, total, receiptType, overheadCategory, description, notes, lineItems
- [x] Implement controlled overhead category dropdown using approved DOS overhead category list (no free-text)
- [x] If AI suggests a category, preselect it in the dropdown but allow user to change it
- [x] Add loading state while receipt is being analyzed
- [x] Add parse failure warning: "We couldn't fully read this receipt. Please review and complete any missing fields."
- [x] Auto-populate line items when extraction confidence is sufficient
- [x] Preserve manual edits after AI population (no overwrite on re-render)
- [x] Do not silently fall back to incorrect defaults

## Receipt Detail Debug Trace (2026-03-18)

- [ ] Add step-by-step logging to getById procedure
- [ ] Verify DB has accessible rows for current user in dev
- [ ] Trigger real request and read server logs for exact failure line
- [ ] Apply targeted fix based on confirmed failure point
- [ ] Remove debug logging after fix confirmed

## Screen Measurements PDF Export (2026-03-19)
- [x] Create server/pdf/modules/screens.ts — full HTML template (header info, per-screen sections, raw measurements, slope analysis, ordering outputs, power connection, flags, notes, footer)
- [x] Add exportPdf procedure to server/routers/screens.ts (additive only — no schema/auth/prod changes)
- [x] Add Export PDF button to client/src/pages/ScreenMeasurementDetail.tsx (FileDown icon, base64 download, toast feedback)
- [ ] Verify PDF export works end-to-end in dev preview

## Screen Measurements List Display Fixes (2026-03-19)
- [x] Add lineCount to list procedure — subquery COUNT(*) grouped by headerId, returned per record
- [x] Add ownerName to list procedure — left join users on ownerId, return firstName + lastName
- [x] Update ScreenMeasurements.tsx list UI — render lineCount (or — if 0) in Screens column
- [x] Update ScreenMeasurements.tsx list UI — render ownerName (or — if null) in Owner column instead of raw ownerId

## Screen Measurements Phase 2 (2026-03-19)

- [x] Verify screen_install_mounts — table did not exist, created it in dev DB only
- [x] Insert correct install mount reference data: undermount/Undermount, face_mount/Face-mount
- [x] Add screenInstallMounts table to Drizzle schema (no migration — table already created directly)
- [x] Add getInstallMounts tRPC procedure to screens router
- [x] Update Install Mount dropdown to use dynamic data from screen_install_mounts
- [x] Update read-only Install Mount display to show name from reference table
- [x] Redesign measurement input form to visual 9-field grid (Left/Right columns + Horizontal row)
- [x] Redesign read-only measurement view to match visual grid layout
- [x] Improve Calculated Outputs display — prominent orderable dimensions, secondary outputs, condition badges
- [x] Add Calc Profile read-only field to header settings view
- [x] Add UI-layer motor/remote narrowing (MOTOR_REMOTE_PREFIX map, filteredRemoteTypes)
- [x] Clear remoteType when motor type changes to prevent cross-wired selections
- [x] Fix pre-existing TS error: extendedHoodValue made optional in Line type
- [x] Confirmed: no schema migration, no prod changes, no deploy, no auth/core changes
- [x] All 193 tests pass, TypeScript 0 errors

## Screen Measurements Phase 3 (2026-03-19)

- [x] Verify motorSide, remoteType, numberOfCuts columns in actual schema and DB (all three were absent — added via ALTER TABLE on dos_hub_dev only)
- [x] Part A: Fractional measurement input — FractionInput component with inches/ft+in mode toggle per card
- [x] Part B: Per-screen photo upload — uploadLinePhoto + getLineAttachmentUrls procedures, photo grid with remove button
- [x] Part C: Motor Side, per-screen Remote, # of Cuts, Reverse Measurements — edit form + read-only view
- [x] Part D: Inline calculation flags — always visible, with [code] prefix, severity-colored borders (error/warning/info)

## Screen Measurements Phase 4 — Complete UI Rewrite (2026-03-19)

- [x] Full rewrite of ScreenMeasurementDetail.tsx to match old module blueprint exactly
- [x] FractionInput confirmed matching old module: whole-number text field + fraction dropdown picker (all 1/16th options)
- [x] Per-screen card field order matches old module: Description → Install Mount/Motor Side/Remote (3-col) → Measurements → # of Cuts → Power → Special Instructions → Photos
- [x] Reverse Measurements changed from checkbox to Yes/No button pair (matches old module)
- [x] Measurement grid: full labels (Upper Left (UL) *, Lower Left (LL), Overall Left (OL) *, etc.)
- [x] Inline mismatch warnings: UL+LL≠OL and UR+LR≠OR shown in edit and read-only views
- [x] Calculated Results section: separate card below measurements with warnings at top, orderable dims prominent, all calc rows with color coding
- [x] Flags always visible (not hidden behind toggle), severity-colored, [code] prefix
- [x] FLAG/manual-review state shown as destructive color in build-out row
- [x] Photos section in both edit and read-only views with upload + thumbnail grid + remove
- [x] Header settings: motor/remote filtering retained, install mount from reference table
- [x] No schema changes, no prod changes, no deploy, no auth/core changes
- [x] 193/193 tests pass, TypeScript 0 errors

## Screen Measurements Phase 4 — Clean Rebuild (complete rewrite from old module blueprint)

- [x] Deleted broken ScreenMeasurements.tsx, ScreenMeasurementDetail.tsx, FractionInput.tsx
- [x] Rebuilt ScreenMeasurements.tsx — list page with My/All toggle, status filter, search, table
- [x] Rebuilt FractionInput.tsx — whole-number text field + fraction dropdown picker (1/16th options), formatInchesFrac export
- [x] Rebuilt ScreenMeasurementDetail.tsx — clean single-pass write matching old module blueprint
- [x] HeaderSettingsCard — manufacturer/motor/remote/install mount/date/u-channel/site notes, edit/read-only modes
- [x] LineCard — correct field order: description → motor side/remote/cuts → measurements (reverse toggle + left/right/horizontal grid) → power connection → special instructions → calc results → photos
- [x] CalcResultsSection — orderable width/height cards, all secondary calc fields, mismatch warnings, inline flags with severity colors
- [x] PhotoSection — upload via uploadLinePhoto, URL resolution via getLineAttachmentUrls, thumbnail grid with remove
- [x] CalcFlagBadge — error/warning/info severity with [CODE] prefix, always visible
- [x] Reverse Measurements — Yes/No button pair (not checkbox), mirrors old module UX
- [x] Add Screen — uses upsertLine with no id (creates new), correct headerId passing
- [x] Transition buttons — Submit for Review (draft→submitted), Approve (submitted→approved), correct `to` field
- [x] Export PDF — exportPdf procedure, base64 download
- [x] TypeScript: 0 errors | Tests: 193/193 pass
