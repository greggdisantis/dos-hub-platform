# Final User Import List

**Status:** READY FOR EXECUTION  
**Date:** March 9, 2026  
**Total Users to Import:** 17

---

## Import Summary

| Metric | Count |
|--------|-------|
| **Total legacy users** | 18 |
| **Excluded** | 1 |
| **To import** | 17 |
| **With complete profiles** | 17 ✅ |
| **Super-admin (protected)** | 2 |

---

## Excluded User

| Email | Reason |
|-------|--------|
| `z6rr82xkpq@privaterelay.appleid.com` | Unknown identity - excluded by request |

---

## All Users to Import (17 Total)

| # | Email | First Name | Last Name | Role | Approved | Status |
|---|-------|-----------|-----------|------|----------|--------|
| 1 | `bthornton@distinctiveos.com` | Ben | Thornton | member | ✅ | Complete |
| 2 | `gdisantis@distinctiveos.com` | Gregg | DiSantis | super-admin | ✅ | 🔒 PROTECTED |
| 3 | `greggd.distinctiveos@gmail.com` | Senior | DiSantis | member | ✅ | Complete |
| 4 | `greggdisantis@gmail.com` | Gregg | DiSantis (gmail) | super-admin | ✅ | 🔒 PROTECTED |
| 5 | `jantonucci@salsnursery.com` | John | Antonucci | manager | ✅ | Complete |
| 6 | `judyantonucci32@salsnursery.com` | Judy | Antonucci | admin | ✅ | Complete |
| 7 | `kharry@salsnursery.com` | Karen | Harry | manager | ✅ | ✏️ UPDATED |
| 8 | `kpoarch@distinctiveos.com` | Kelley | Poarch | manager | ✅ | ✏️ UPDATED |
| 9 | `maksymm26@gmail.com` | Max | Melnyk | manager | ✅ | ✏️ UPDATED |
| 10 | `mjohnson@distinctiveos.com` | Mike | Johnson | manager | ✅ | ✏️ UPDATED |
| 11 | `nhitch@salsnursery.com` | Nadene | Hitch | manager | ✅ | Complete |
| 12 | `rmiller@distinctiveos.com` | Russell | Miller | member | ✅ | Complete |
| 13 | `sgiordano@distinctiveos.com` | Steve | Giordano | manager | ✅ | ✏️ UPDATED |
| 14 | `sliney99@gmail.com` | Sarah | Liney | manager | ✅ | ✏️ UPDATED |
| 15 | `smelnyk@distinctiveos.com` | Sydni | Melnyk | manager | ✅ | ✏️ UPDATED |
| 16 | `vcash@distinctiveos.com` | Valaree | Cash | member | ✅ | ✏️ UPDATED |
| 17 | `zacharyd@distinctiveos.com` | Zachary | Disantis | member | ✅ | Complete |

---

## Profile Updates Applied

These users had incomplete or placeholder names in the legacy system. They will be updated during import:

| Email | Updated From | Updated To |
|-------|--------------|-----------|
| `kharry@salsnursery.com` | NULL / NULL | Karen Harry |
| `kpoarch@distinctiveos.com` | User Account | Kelley Poarch |
| `maksymm26@gmail.com` | User Account | Max Melnyk |
| `mjohnson@distinctiveos.com` | NULL / NULL | Mike Johnson |
| `sgiordano@distinctiveos.com` | User Account | Steve Giordano |
| `sliney99@gmail.com` | User Account | Sarah Liney |
| `smelnyk@distinctiveos.com` | User Account | Sydni Melnyk |
| `vcash@distinctiveos.com` | User Account | Valaree Cash |

---

## Permanent Super-Admin Accounts (Protected)

These accounts are locked and cannot be changed:

| Email | Name | Role | Approved | Protection |
|-------|------|------|----------|-----------|
| `gdisantis@distinctiveos.com` | Gregg DiSantis | super-admin | ✅ | 🔒 LOCKED |
| `greggdisantis@gmail.com` | Gregg DiSantis (gmail) | super-admin | ✅ | 🔒 LOCKED |

**Rules:**
- Cannot be downgraded
- Cannot be duplicated
- Will always have full access
- Approval status cannot be changed

---

## Role Distribution

| Role | Count |
|------|-------|
| Super-admin | 2 |
| Admin | 1 |
| Manager | 9 |
| Member | 5 |
| **TOTAL** | **17** |

---

## Validation Checklist

✅ **Email normalization:** All emails converted to lowercase  
✅ **Duplicate prevention:** No duplicate emails in import set  
✅ **Super-admin protection:** Both accounts locked and protected  
✅ **Profile completeness:** All 17 users have firstName + lastName  
✅ **Role preservation:** All roles preserved from legacy system  
✅ **Approval status:** All users imported as approved  
✅ **Auth system integrity:** No overwrites to existing super-admin rules  
✅ **All profiles complete:** 0 incomplete profiles - Ready for import!  

---

## Next Steps

**Ready to execute migration:**

1. ✅ All 17 users prepared
2. ✅ All profiles complete
3. ✅ All updates applied
4. ✅ Super-admin accounts protected
5. ⏳ **AWAITING CONFIRMATION TO EXECUTE**

**To proceed, confirm:** "Execute migration"

