# DOS Hub Infrastructure Source of Truth
**Version:** 2.0
**Date:** 2026-03-14
**Status:** CONFIRMED PRODUCTION LIVE
**Authority:** This document supersedes all prior infrastructure notes and checklist versions.

---

## 1. Environment Registry

| Environment | Purpose | Status |
|-------------|---------|--------|
| **Production** | Permanent live site for DOS Hub | ACTIVE |
| **Development** | Manus sandbox — development and testing only | ACTIVE (separation in progress) |
| **Legacy** | Manus-managed gateway04 cluster | FROZEN — read-only reference only |

---

## 2. Production Environment

| Field | Value |
|-------|-------|
| GCP Project | `dos-hub-production` |
| GCP Region | `us-east1` |
| Cloud Run Service | `dos-hub` |
| Current Healthy Revision | `dos-hub-00025-8c7` |
| Current Image | `us-east1-docker.pkg.dev/dos-hub-production/dos-hub/app:v11` |
| Artifact Registry | `us-east1-docker.pkg.dev/dos-hub-production/dos-hub` |
| Service URL | Cloud Run auto-assigned URL (see GCP Console) |
| `NODE_ENV` at runtime | `production` |
| Login | Working — confirmed |
| CMR Records | Visible and confirmed |

---

## 3. Database Registry

### 3.1 Production Database — SINGLE SOURCE OF TRUTH

| Field | Value |
|-------|-------|
| **Host** | `gateway01.us-east-1.prod.aws.tidbcloud.com` |
| **Port** | `4000` |
| **Database** | `dos_hub_prod` |
| **User** | `4R5HJpcn2iDQSh6.root` |
| **Owner** | User-owned TiDB Serverless cluster |
| **SSL** | Required — `TLS_AES_128_GCM_SHA256` (TLS 1.3) |
| **Status** | ACTIVE — live production |
| **Row counts (confirmed)** | users: 17, cmr_reports: 12, screen_measurement_headers: 2, screen_measurement_lines: 2 |

### 3.2 Development Database

| Field | Value |
|-------|-------|
| **Host** | `gateway01.us-east-1.prod.aws.tidbcloud.com` |
| **Port** | `4000` |
| **Database** | `dos_hub_dev` |
| **User** | `4R5HJpcn2iDQSh6.root` |
| **Owner** | User-owned TiDB Serverless cluster |
| **Status** | ACTIVE — development use only |
| **Schema** | 25 tables (most complete schema — includes all module tables) |
| **Data** | Minimal / empty — development data only |

### 3.3 Legacy Database — DO NOT USE

| Field | Value |
|-------|-------|
| **Host** | `gateway04.us-east-1.prod.aws.tidbcloud.com` |
| **Database** | `YxtbJqJxmKMGKQFMBD7qrd` |
| **Owner** | Manus-managed (not user-owned) |
| **Status** | **LEGACY — FROZEN — READ-ONLY REFERENCE ONLY** |
| **Notes** | Was the temporary production database prior to Phase 3 cutover. Do not write to, migrate from, or reference in any new code. Do not delete — retain as historical backup. |

### 3.4 Legacy Database — test (gateway01)

| Field | Value |
|-------|-------|
| **Host** | `gateway01.us-east-1.prod.aws.tidbcloud.com` |
| **Database** | `test` |
| **Status** | **UNUSED — DO NOT USE** |
| **Notes** | Structurally identical to `dos_hub_prod` but with no data. No active purpose. |

---

## 4. Secret Registry

| Secret Name | Environment | Location | Current Version | Value Points To |
|-------------|-------------|----------|-----------------|-----------------|
| `DATABASE_URL` | Production (Cloud Run) | GCP Secret Manager | **Version 17** | `gateway01 / dos_hub_prod` |
| `DATABASE_URL_DEV` | Development (Manus sandbox) | Manus Secrets | Current | `gateway01 / dos_hub_dev` (separation in progress) |
| `GATEWAY01_URL` | Manus sandbox (scripts only) | Manus Secrets | Current | `gateway01` base URL — used for migration scripts |
| `JWT_SECRET` | Production | GCP Secret Manager | Current | Production JWT signing key |
| `AWS_REGION` | Production | GCP Secret Manager | Current | `us-east-1` |
| `AWS_ACCESS_KEY_ID` | Production | GCP Secret Manager | Current | dos-hub-production-storage IAM key |
| `AWS_SECRET_ACCESS_KEY` | Production | GCP Secret Manager | Current | dos-hub-production-storage IAM secret |
| `S3_BUCKET_NAME` | Production | GCP Secret Manager | Current | `dos-hub-production-storage` |

---

## 5. Runtime Resolution Rules

The server entry point (`server/_core/env.ts`) resolves the active database URL as follows:

```
if (NODE_ENV === 'production')  → use DATABASE_URL   → gateway01 / dos_hub_prod
if (NODE_ENV === 'development') → use DATABASE_URL_DEV → gateway01 / dos_hub_dev
```

**Single Production DB Rule:** Only `dos_hub_prod` on gateway01 is the production database. No other database may be used by the Cloud Run production service. This rule is enforced by the `DATABASE_URL` secret in GCP Secret Manager.

---

## 6. Network Access

| IP Address | Purpose | Allowlisted On |
|------------|---------|----------------|
| Cloud Run egress IPs | Production runtime → gateway01 | gateway01 TiDB allowlist |
| `13.217.92.139` | Manus sandbox (migration session) | gateway01 TiDB allowlist |
| `54.90.236.54` | Manus sandbox (prior session) | gateway01 TiDB allowlist (may be removed) |

> **Note:** Manus sandbox IPs rotate between sessions. If a future migration script cannot connect to gateway01, the current sandbox IP must be added to the TiDB allowlist. Run `curl https://api.ipify.org` to get the current IP, then check the mysql2 error message for the actual connecting IP (which may differ due to NAT routing).

---

## 7. AWS S3 Storage

| Field | Value |
|-------|-------|
| Bucket | `dos-hub-production-storage` |
| Region | `us-east-1` |
| IAM User | `dos-hub-production-s3` |
| Access | Write-only to this bucket — no other AWS permissions |
| Public Access | Blocked |

---

## 8. Artifact Registry

| Field | Value |
|-------|-------|
| Registry | `us-east1-docker.pkg.dev/dos-hub-production/dos-hub` |
| Current Production Image | `app:v11` |
| Build Method | `gcloud builds submit` from source zip |
| Source | Manus project export zip (Phase A Dockerfile) |

---

## 9. Phase History

| Phase | Description | Status |
|-------|-------------|--------|
| Phase A | Dockerfile, .dockerignore, AWS S3 storage rewrite | COMPLETE |
| Phase B | GCP project, APIs, Artifact Registry, Secret Manager | COMPLETE |
| Phase C | Docker build, Cloud Run deploy, PORT fix | COMPLETE |
| Phase 2 | Build dos_hub_prod: schema from dos_hub_dev, data from gateway04 | COMPLETE |
| Phase 3 | Production cutover: DATABASE_URL → gateway01/dos_hub_prod | **COMPLETE — LIVE** |
| Phase 4 | Development separation: Manus dev → dos_hub_dev exclusively | IN PROGRESS |

---

## 10. Root Cause Notes (For Reference)

**Prior production failure cause:** The `DATABASE_URL` secret in GCP Secret Manager contained an outdated password for the gateway01 user `4R5HJpcn2iDQSh6.root`. The password had been rotated in TiDB Cloud but the secret was not updated, causing all Cloud Run revisions to fail with `ER_ACCESS_DENIED_ERROR`.

**Resolution:** Updated `DATABASE_URL` to Secret Manager version 17 with the current gateway01 password. Cloud Run revision `dos-hub-00025-8c7` became healthy immediately after the secret update and redeploy.

**Cloud Run IP allowlist:** The Cloud Run service egress IPs must be present in the gateway01 TiDB Serverless IP allowlist. If production connectivity fails in the future, verify that Cloud Run's current egress IPs are still on the allowlist.

---

## 11. Operational Rules

1. **Do not modify production** without an explicit approved change plan.
2. **Do not write to gateway04** — it is frozen legacy.
3. **Do not use `test` database** — it has no purpose.
4. **Do not change `DATABASE_URL` in GCP Secret Manager** without a full cutover plan and rollback procedure.
5. **Development work uses `dos_hub_dev` only** — never point the Manus dev server at `dos_hub_prod`.
6. **Schema changes** must be applied to `dos_hub_dev` first, verified, then promoted to `dos_hub_prod` via a controlled migration plan.
7. **New Docker images** must be built and tested before being deployed to the production Cloud Run service.
8. **Rollback path:** Previous Cloud Run revisions are retained. To roll back, redeploy the previous image tag and restore the previous `DATABASE_URL` secret version.
