# DOS Hub — Phase B: Google Cloud & AWS Setup Instructions

**Purpose:** Prepare the permanent production infrastructure for DOS Hub on Google Cloud Run.
**Rule:** Do not deploy the application yet. Do not touch any database. Do not change any code.
**Estimated time:** 30–45 minutes.

---

## Overview of Steps

| Step | Platform | Action |
|------|----------|--------|
| 1 | Google Cloud | Create the GCP project |
| 2 | Google Cloud | Enable required APIs |
| 3 | Google Cloud | Create Artifact Registry repository |
| 4 | Google Cloud | Create Secret Manager secrets |
| 5 | AWS | Create S3 bucket |
| 6 | AWS | Create IAM user and access key |
| 7 | AWS | Attach bucket-only permissions policy |
| 8 | — | Report back with collected values |

---

## PART 1 — Google Cloud Setup

### Step 1 — Create the GCP Project

1. Open [https://console.cloud.google.com/projectcreate](https://console.cloud.google.com/projectcreate) in your browser.
2. Fill in the form exactly as follows:

   | Field | Value |
   |-------|-------|
   | Project name | `dos-hub-production` |
   | Project ID | `dos-hub-production` |
   | Organization | Select your organization if prompted, or leave as "No organization" |
   | Location | Leave as default |

3. Click **Create**.
4. Wait for the notification "Project dos-hub-production created" (usually 10–20 seconds).
5. Click **Select Project** in the notification, or use the project picker at the top of the page to switch to `dos-hub-production`.

> **Confirm:** The header bar at the top of the GCP Console should now show **dos-hub-production** as the active project before continuing.

---

### Step 2 — Enable Required APIs

You must enable four APIs. The fastest way is to use the direct links below — each link opens the exact API enable page for your project.

Open each URL in a new tab, confirm the project shown is `dos-hub-production`, and click **Enable**. Wait for the green checkmark before moving to the next.

| API | Direct Enable URL |
|-----|-------------------|
| Cloud Run API | [https://console.cloud.google.com/apis/library/run.googleapis.com?project=dos-hub-production](https://console.cloud.google.com/apis/library/run.googleapis.com?project=dos-hub-production) |
| Artifact Registry API | [https://console.cloud.google.com/apis/library/artifactregistry.googleapis.com?project=dos-hub-production](https://console.cloud.google.com/apis/library/artifactregistry.googleapis.com?project=dos-hub-production) |
| Secret Manager API | [https://console.cloud.google.com/apis/library/secretmanager.googleapis.com?project=dos-hub-production](https://console.cloud.google.com/apis/library/secretmanager.googleapis.com?project=dos-hub-production) |
| Cloud Build API | [https://console.cloud.google.com/apis/library/cloudbuild.googleapis.com?project=dos-hub-production](https://console.cloud.google.com/apis/library/cloudbuild.googleapis.com?project=dos-hub-production) |

> **Note:** Cloud Build may ask you to enable billing. Cloud Run and Artifact Registry have a free tier sufficient for DOS Hub's traffic, but a billing account must be attached to the project for Cloud Build to function. If you have not attached a billing account yet, GCP will prompt you to do so when you click Enable on Cloud Build.

---

### Step 3 — Create the Artifact Registry Repository

This is the private Docker image registry where DOS Hub production images will be stored before deployment.

1. Open [https://console.cloud.google.com/artifacts?project=dos-hub-production](https://console.cloud.google.com/artifacts?project=dos-hub-production).
2. Click **+ Create Repository**.
3. Fill in the form exactly as follows:

   | Field | Value |
   |-------|-------|
   | Name | `dos-hub` |
   | Format | **Docker** |
   | Mode | Standard |
   | Location type | Region |
   | Region | `us-east1` (US East — South Carolina) |
   | Encryption | Google-managed encryption key (default) |
   | Immutable image tags | Leave unchecked |
   | Cleanup policies | Leave as default |

4. Click **Create**.
5. After creation, the repository full path will be:
   ```
   us-east1-docker.pkg.dev/dos-hub-production/dos-hub
   ```
   Write this down — it is needed in Phase C when building and pushing the Docker image.

---

### Step 4 — Create Secrets in Secret Manager

This is the most important step. Each secret listed below must be created individually in Secret Manager. The Cloud Run service will read them at startup — no secrets are ever baked into the Docker image.

1. Open [https://console.cloud.google.com/security/secret-manager?project=dos-hub-production](https://console.cloud.google.com/security/secret-manager?project=dos-hub-production).
2. Click **+ Create Secret** for each row in the table below.
3. For each secret:
   - Set the **Name** exactly as shown (case-sensitive).
   - Paste the **Value** into the "Secret value" field.
   - Leave all other settings at their defaults.
   - Click **Create Secret**.

#### Secrets Table

| Secret Name | Value Source | Notes |
|-------------|-------------|-------|
| `DATABASE_URL` | Your production TiDB connection string | This is the `gateway04.us-east-1.prod.aws.tidbcloud.com` connection string already in use. Format: `mysql://user:password@gateway04.us-east-1.prod.aws.tidbcloud.com:4000/dbname?ssl={"rejectUnauthorized":true}` |
| `JWT_SECRET` | The 22-character production JWT secret already stored in Manus | This is the existing production `JWT_SECRET` (not `JWT_SECRET_DEV`). Retrieve it from the Manus Secrets panel. |
| `AWS_REGION` | `us-east-1` | Literal value — type exactly as shown |
| `AWS_ACCESS_KEY_ID` | From AWS Step 6 below | Complete AWS steps first, then return here |
| `AWS_SECRET_ACCESS_KEY` | From AWS Step 6 below | Complete AWS steps first, then return here |
| `S3_BUCKET_NAME` | `dos-hub-production-storage` | Literal value — type exactly as shown |

> **Important:** The `DATABASE_URL` and `JWT_SECRET` values for production are already stored in the Manus Secrets panel (the production values, not the `_DEV` variants). To retrieve them: open the Manus Management UI → Settings → Secrets, and copy the values for `DATABASE_URL` and `JWT_SECRET`.

> **Do not** enter `DATABASE_URL_DEV` or `JWT_SECRET_DEV` — those are for the Manus development environment only.

---

## PART 2 — AWS S3 Setup

### Step 5 — Create the S3 Bucket

1. Sign in to the AWS Console at [https://console.aws.amazon.com](https://console.aws.amazon.com).
2. Navigate to **S3** (search "S3" in the top search bar).
3. Click **Create bucket**.
4. Fill in the form exactly as follows:

   | Field | Value |
   |-------|-------|
   | Bucket name | `dos-hub-production-storage` |
   | AWS Region | `US East (N. Virginia) us-east-1` |
   | Object Ownership | **ACLs disabled** (recommended) |
   | Block Public Access | Leave **all four checkboxes checked** (block all public access) |
   | Bucket Versioning | Disable |
   | Default encryption | Server-side encryption with Amazon S3 managed keys (SSE-S3) |

5. Click **Create bucket**.

> **Why block public access?** DOS Hub uses presigned URLs to serve files. The bucket itself stays private; the server generates temporary signed URLs on demand. This is more secure than a public bucket.

---

### Step 6 — Create an IAM User with Programmatic Access

1. Navigate to **IAM** (search "IAM" in the top search bar).
2. In the left sidebar, click **Users**.
3. Click **Create user**.
4. Set the **User name** to: `dos-hub-production-s3`
5. Click **Next**.
6. On the "Set permissions" page, select **Attach policies directly**.
7. Do **not** attach any policy yet — click **Next**, then **Create user**.
   (You will attach a custom policy in Step 7.)
8. After the user is created, click on the username `dos-hub-production-s3` to open the user detail page.
9. Click the **Security credentials** tab.
10. Scroll to **Access keys** and click **Create access key**.
11. Select **Application running outside AWS** as the use case.
12. Click **Next**, then **Create access key**.
13. **IMPORTANT:** On the confirmation screen, you will see:
    - **Access key ID** — copy and save this now
    - **Secret access key** — copy and save this now (it will never be shown again)
14. Click **Done**.

> Store these two values securely. You will paste them into Secret Manager in Step 4 above (the `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` secrets).

---

### Step 7 — Attach Bucket-Only Permissions Policy

This policy gives the `dos-hub-production-s3` IAM user permission to read and write objects in the `dos-hub-production-storage` bucket only — nothing else in your AWS account.

1. In IAM, navigate to **Users** → click `dos-hub-production-s3`.
2. Click the **Permissions** tab.
3. Click **Add permissions** → **Create inline policy**.
4. Click the **JSON** tab and replace the entire contents with the following policy:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowDosHubBucketAccess",
      "Effect": "Allow",
      "Action": [
        "s3:PutObject",
        "s3:GetObject",
        "s3:DeleteObject",
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::dos-hub-production-storage",
        "arn:aws:s3:::dos-hub-production-storage/*"
      ]
    }
  ]
}
```

5. Click **Next**.
6. Set the policy name to: `dos-hub-production-s3-policy`
7. Click **Create policy**.

> **Verify:** On the user's Permissions tab, you should now see `dos-hub-production-s3-policy` listed as an inline policy. This user has no other permissions — it cannot read other buckets, access EC2, or perform any other AWS action.

---

## PART 3 — Return to Secret Manager

### Step 4 (continued) — Add the AWS Secrets

Now that you have the AWS Access Key ID and Secret Access Key from Step 6, return to Secret Manager and create the two remaining secrets:

- `AWS_ACCESS_KEY_ID` → paste the Access key ID from Step 6
- `AWS_SECRET_ACCESS_KEY` → paste the Secret access key from Step 6

---

## Phase B Completion Checklist

When all steps are done, confirm each item below before reporting back:

| # | Item | Done? |
|---|------|-------|
| 1 | GCP project `dos-hub-production` created and active | |
| 2 | Cloud Run API enabled | |
| 3 | Artifact Registry API enabled | |
| 4 | Secret Manager API enabled | |
| 5 | Cloud Build API enabled | |
| 6 | Artifact Registry repo `dos-hub` created in `us-east1` | |
| 7 | Secret `DATABASE_URL` created in Secret Manager | |
| 8 | Secret `JWT_SECRET` created in Secret Manager | |
| 9 | Secret `AWS_REGION` created (`us-east-1`) | |
| 10 | Secret `AWS_ACCESS_KEY_ID` created | |
| 11 | Secret `AWS_SECRET_ACCESS_KEY` created | |
| 12 | Secret `S3_BUCKET_NAME` created (`dos-hub-production-storage`) | |
| 13 | S3 bucket `dos-hub-production-storage` created in `us-east-1` | |
| 14 | IAM user `dos-hub-production-s3` created | |
| 15 | Inline policy `dos-hub-production-s3-policy` attached to IAM user | |
| 16 | Access key ID and secret key saved securely | |

Once all 16 items are checked, report back and Phase C (build, push, deploy) will begin.

---

## What Happens in Phase C (Preview)

Phase C will not begin until you confirm Phase B is complete. When it does:

1. The Docker image will be built from the `Dockerfile` created in Phase A.
2. The image will be pushed to `us-east1-docker.pkg.dev/dos-hub-production/dos-hub`.
3. A Cloud Run service named `dos-hub` will be deployed in `us-east1`, with all 6 secrets wired in from Secret Manager.
4. A smoke test will confirm login, CMR dashboard, and Screens module load correctly.
5. A custom domain (if desired) can be mapped to the Cloud Run service URL.

No database changes occur in Phase C.

---

*Document prepared for DOS Hub deployment — Phase B. Project: dos-hub-production. Date: March 2026.*
