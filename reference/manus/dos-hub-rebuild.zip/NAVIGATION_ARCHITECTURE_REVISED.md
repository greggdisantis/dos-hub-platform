# DOS Hub Navigation Architecture - Revised (Hybrid Model)

## Core Principle

**Stage-based navigation + Project-centered data**

- **Navigation:** Users navigate by stage (Sales, Engineering, Production, etc.)
- **Data:** All modules attach to Projects; projects can appear in multiple stages
- **Access:** Stages control which projects and modules users see
- **Hub:** Projects act as the central hub for all related records

---

## 1. Top-Level Navigation

```
DOS Hub
├── Dashboard (Home)
├── Sales
├── Engineering
├── Production
├── Install / Field
├── Service
├── Admin
└── Settings
```

Each stage is a first-class navigation entry point. Clicking a stage shows projects relevant to that stage.

---

## 2. Stage Pages (Project List View)

### Sales Stage
**URL:** `/sales`

**Content:**
```
Sales
├── Filter Bar
│   ├── Status (prospect, proposal, active, closed)
│   ├── Client Name
│   ├── Date Range
│   └── Confidence Level
├── Project List (filtered)
│   ├── Project Card 1
│   │   ├── Client Name
│   │   ├── Status
│   │   ├── Last CMR Date
│   │   └── [View Project]
│   ├── Project Card 2
│   └── ...
├── Quick Stats
│   ├── Active Deals
│   ├── Pending Approvals
│   └── This Week's Activity
└── [+ New Project] button
```

**Projects shown:** All projects with `projectStage` = "sales" OR projects in any stage that have Sales-related data (CMRs)

**Modules visible:** CMR (primary), linked Measurements (read-only)

**Navigation:** Click [View Project] → Project Hub

---

### Engineering Stage
**URL:** `/engineering`

**Content:**
```
Engineering
├── Filter Bar
│   ├── Status (design, ready-for-production, in-progress)
│   ├── Assigned To
│   ├── Priority
│   └── Due Date
├── Project List (filtered)
│   ├── Project Card 1
│   │   ├── Project Name
│   │   ├── Status
│   │   ├── Measurements Count
│   │   ├── Materials Status
│   │   └── [View Project]
│   ├── Project Card 2
│   └── ...
├── Quick Stats
│   ├── In Design
│   ├── Ready for Production
│   └── Overdue Items
└── [+ New Project] button
```

**Projects shown:** All projects with `projectStage` = "engineering" OR projects that have Engineering-related data (Measurements, Materials, Preconstruction)

**Modules visible:** Measurements (primary), Material Checklist, Preconstruction Checklist, linked CMR (read-only)

**Navigation:** Click [View Project] → Project Hub

---

### Production Stage
**URL:** `/production`

**Content:**
```
Production
├── Filter Bar
│   ├── Status (queued, in-progress, ready-for-install)
│   ├── Due Date
│   └── Material Status
├── Project List (filtered)
│   ├── Project Card 1
│   │   ├── Project Name
│   │   ├── Status
│   │   ├── Material Status (% delivered)
│   │   ├── Due Date
│   │   └── [View Project]
│   ├── Project Card 2
│   └── ...
├── Quick Stats
│   ├── In Production
│   ├── Material Issues
│   └── Behind Schedule
└── Material Orders (global view)
```

**Projects shown:** All projects with `projectStage` = "production" OR projects that have Production-related data (Material Checklists with status updates)

**Modules visible:** Material Checklist (primary), Production Schedule, linked Measurements (read-only)

**Navigation:** Click [View Project] → Project Hub

---

### Install / Field Stage
**URL:** `/install`

**Content:**
```
Install / Field
├── Filter Bar
│   ├── Status (scheduled, in-progress, completed)
│   ├── Location
│   ├── Crew Assigned
│   └── Date
├── Active Jobs List (filtered)
│   ├── Job Card 1
│   │   ├── Project Name / Address
│   │   ├── Status
│   │   ├── Crew
│   │   ├── Date
│   │   └── [View Job]
│   ├── Job Card 2
│   └── ...
├── Quick Stats
│   ├── Active Installations
│   ├── Scheduled This Week
│   └── Completed This Month
└── Completed Jobs Archive
```

**Projects shown:** All projects with `projectStage` = "install" OR projects that have Install-related data (Field Measurements, Photos)

**Modules visible:** Screen Measurements (field capture), Photo Gallery, Field Notes, linked Materials (read-only)

**Navigation:** Click [View Job] → Project Hub (Install view)

---

### Service Stage
**URL:** `/service`

**Content:**
```
Service
├── Filter Bar
│   ├── Status (active, pending, completed)
│   ├── Service Type
│   ├── Customer
│   └── Date
├── Service Requests List (filtered)
│   ├── Request Card 1
│   │   ├── Customer / Project
│   │   ├── Service Type
│   │   ├── Status
│   │   ├── Date
│   │   └── [View Request]
│   ├── Request Card 2
│   └── ...
├── Quick Stats
│   ├── Active Service Requests
│   ├── Pending Parts
│   └── Warranty Claims
└── Completed Service Archive
```

**Projects shown:** All projects with `projectStage` = "service" OR projects that have Service-related data (Service Requests, Service Receipts)

**Modules visible:** Service Requests, Receipt Capture (service expenses), Photo Gallery, Parts Tracking, linked CMR (read-only)

**Navigation:** Click [View Request] → Project Hub (Service view)

---

### Admin Stage
**URL:** `/admin`

**Content:**
```
Admin
├── User Management
│   ├── Pending Approvals
│   ├── User List
│   └── Role Management
├── Approvals Queue
│   ├── CMR Approvals
│   ├── Project Approvals
│   └── Other Workflow Approvals
├── System Settings
│   ├── Company Info
│   ├── Module Permissions
│   └── Integrations (HubSpot, Service Fusion)
└── Reports & Analytics
    ├── Project Pipeline
    ├── Revenue Tracking
    └── Performance Metrics
```

**Projects shown:** All projects (for reporting and management)

**Modules visible:** All modules (read/manage)

**Navigation:** Click user/project → Detail view

---

## 3. Project Hub (Central Record)

**URL:** `/project/:id`

**Accessed from:** Any stage (Sales, Engineering, Production, Install, Service)

**Layout:**
```
Project Hub
├── Header
│   ├── Project Name
│   ├── Client Name
│   ├── Current Stage (sales, engineering, production, install, service)
│   ├── Status
│   └── [Edit Project] [Move to Next Stage]
│
├── Tabs / Sections
│   ├── Overview
│   │   ├── Project Info
│   │   ├── Client Info
│   │   ├── Timeline
│   │   └── External References (HubSpot Deal ID, Service Fusion Job ID)
│   │
│   ├── CMR (Client Meeting Reports)
│   │   ├── List of all CMRs for this project
│   │   ├── [+ New CMR]
│   │   └── Click CMR → CMR Detail
│   │
│   ├── Measurements (Screen / Field)
│   │   ├── List of all measurements
│   │   ├── [+ New Measurement]
│   │   └── Click Measurement → Measurement Detail
│   │
│   ├── Materials
│   │   ├── Material Checklist
│   │   ├── Delivery Status
│   │   ├── [+ New Material]
│   │   └── Click Material → Material Detail
│   │
│   ├── Checklists
│   │   ├── Preconstruction Checklist
│   │   ├── Production Checklist
│   │   ├── Installation Checklist
│   │   └── Click Checklist → Checklist Detail
│   │
│   ├── Receipts
│   │   ├── All receipts (Production, Service, etc.)
│   │   ├── [+ New Receipt]
│   │   └── Click Receipt → Receipt Detail
│   │
│   ├── Files & PDFs
│   │   ├── Exported PDFs
│   │   ├── Drawings
│   │   ├── Photos
│   │   └── [+ Upload File]
│   │
│   ├── Notes
│   │   ├── Project Notes
│   │   ├── Timeline of changes
│   │   └── [+ Add Note]
│   │
│   └── History
│       ├── Activity log
│       ├── Stage changes
│       └── User actions
```

**Key Behavior:**
- All modules are accessible from the Project Hub
- Users can see the full project context regardless of which stage they entered from
- Modules show only relevant data (e.g., if in Sales stage, CMR is primary; if in Production, Materials are primary)
- Back button returns to the stage that launched the Project Hub

---

## 4. Module Placement (Where Modules Live)

| Module | Primary Stage(s) | Secondary Stage(s) | Data Model |
|--------|------------------|-------------------|-----------|
| CMR | Sales | Engineering, Service | Belongs to Project |
| Screen Measurements | Engineering | Install/Field, Production | Belongs to Project |
| Material Checklist | Engineering | Production, Install | Belongs to Project |
| Preconstruction Checklist | Engineering | Production | Belongs to Project |
| Receipt Capture | Service | Production, Admin | Belongs to Project |
| AquaClean Receipts | Service | Admin | Separate table, belongs to Project |
| Photo Gallery | Install/Field | Service, Engineering | Belongs to Project |
| Service Requests | Service | Admin | Belongs to Project |
| Production Schedule | Production | Engineering | Belongs to Project |

**Key Point:** Modules are not "owned" by a stage. They belong to Projects. Stages control visibility and filtering.

---

## 5. Breadcrumb Behavior

### Breadcrumb Pattern

**From Sales → Project → CMR:**
```
Dashboard > Sales > [Project Name] > CMR > [CMR Detail]
```

**From Engineering → Project → Measurements:**
```
Dashboard > Engineering > [Project Name] > Measurements > [Measurement Detail]
```

**From Service → Project → Receipts:**
```
Dashboard > Service > [Project Name] > Receipts > [Receipt Detail]
```

### Back Button Behavior

| Current Page | Back Button Goes To |
|--------------|-------------------|
| CMR Detail | CMR List (in Project Hub) |
| CMR List (in Project) | Project Hub |
| Project Hub | Stage Page (Sales, Engineering, etc.) |
| Stage Page | Dashboard |

**Never jumps to homepage directly.**

---

## 6. Navigation Flow Examples

### Example 1: Sales User Creating a CMR

```
Dashboard
  ↓ [Click Sales]
Sales Stage Page (project list)
  ↓ [Click Project]
Project Hub
  ↓ [Click CMR tab]
CMR List (for this project)
  ↓ [Click + New CMR]
CMR Form
  ↓ [Save]
CMR Detail
  ↓ [Back]
CMR List
  ↓ [Back]
Project Hub
  ↓ [Back]
Sales Stage Page
```

### Example 2: Engineering User Viewing Measurements

```
Dashboard
  ↓ [Click Engineering]
Engineering Stage Page (project list)
  ↓ [Click Project]
Project Hub
  ↓ [Click Measurements tab]
Measurements List (for this project)
  ↓ [Click Measurement]
Measurement Detail
  ↓ [Back]
Measurements List
  ↓ [Back]
Project Hub
  ↓ [Back]
Engineering Stage Page
```

### Example 3: Cross-Stage Access (Service User Viewing CMR)

```
Dashboard
  ↓ [Click Service]
Service Stage Page
  ↓ [Click Project]
Project Hub (from Service context)
  ↓ [Click CMR tab]
CMR List (read-only, from Service context)
  ↓ [View CMR]
CMR Detail (read-only)
  ↓ [Back]
CMR List
  ↓ [Back]
Project Hub (Service context)
  ↓ [Back]
Service Stage Page
```

---

## 7. Project Stage Transitions

**Projects move through stages as work progresses:**

```
Sales (prospect, proposal, active)
  ↓ [Move to Engineering]
Engineering (design, ready-for-production)
  ↓ [Move to Production]
Production (queued, in-progress, ready-for-install)
  ↓ [Move to Install]
Install / Field (scheduled, in-progress, completed)
  ↓ [Move to Service]
Service (active, pending, completed)
  ↓ [Archive]
Archived
```

**UI:** Project Hub header has [Move to Next Stage] button (admin/manager only)

**Database:** `projects.projectStage` enum field tracks current stage

---

## 8. Dashboard Design

**Post-Login Dashboard (Clean, not cluttered):**

```
Dashboard
├── Welcome Message (role-specific)
├── Quick Stats (role-dependent)
│   ├── Pending Approvals (admin/manager)
│   ├── Active Projects (your role)
│   └── This Week's Activity
├── Recent Items (by stage)
│   ├── Recent CMRs (Sales)
│   ├── Recent Measurements (Engineering)
│   ├── Recent Receipts (Service)
│   └── etc.
├── Stage Navigation Tiles
│   ├── Sales (X active deals)
│   ├── Engineering (X in design)
│   ├── Production (X in progress)
│   ├── Install/Field (X scheduled)
│   ├── Service (X active requests)
│   └── Admin (X pending approvals)
└── [Settings]
```

**Purpose:** Quick overview and entry point to stages, not detailed work.

---

## 9. Implementation Roadmap

### Phase 1: Foundation
- [ ] Update Project table with `projectStage` field
- [ ] Create Stage Overview pages (Sales, Engineering, Production, Install, Service, Admin)
- [ ] Build Project Hub layout with tabs
- [ ] Implement breadcrumb navigation
- [ ] Implement back button logic

### Phase 2: Module Integration
- [ ] Wire CMR to Sales stage (primary) and Project Hub
- [ ] Wire Measurements to Engineering stage (primary) and Project Hub
- [ ] Wire Material Checklist to Engineering/Production stages
- [ ] Wire Preconstruction Checklist to Engineering/Production stages
- [ ] Wire Receipts to Service stage (primary) and Project Hub

### Phase 3: Cross-Stage Access
- [ ] Implement read-only access for non-primary stages
- [ ] Add stage context indicators (e.g., "Viewing from Service")
- [ ] Implement stage-specific filtering

### Phase 4: Advanced Features
- [ ] Project stage transitions (Move to Next Stage)
- [ ] Workflow approvals by stage
- [ ] Stage-specific dashboards
- [ ] Reporting and analytics

---

## 10. Benefits of This Architecture

✅ **Stage-based navigation** — Users navigate by how they work
✅ **Project-centered data** — Clean database model, no duplication
✅ **Flexible module access** — Modules visible in multiple stages
✅ **Clear hierarchy** — Dashboard → Stage → Project → Module
✅ **Intuitive back navigation** — One level up, never to homepage
✅ **Desktop-first** — High-density layouts for office users
✅ **Scalable** — Easy to add stages or modules
✅ **Clean UI** — No dumping everything on one screen
✅ **Integration-ready** — Projects link to HubSpot/Service Fusion
✅ **Role-based access** — Each role sees appropriate stages/modules

---

## Next Steps

1. **Approve this revised architecture** — Does this match your vision?
2. **Define role-to-stage mapping** — Which roles see which stages?
3. **Build Stage Overview pages** — Create the landing page for each stage
4. **Build Project Hub** — Create the central project record view
5. **Wire first module (CMR)** — Integrate CMR with Sales stage and Project Hub
6. **Implement breadcrumb navigation** — Show current path
7. **Migrate legacy data** — Map old CMR records to projects
