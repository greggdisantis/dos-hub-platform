# Original DOS Hub CMR Specification

**Document Version:** 1.0  
**Last Updated:** March 9, 2026  
**Status:** Complete and Ready for Rebuild

---

## OVERVIEW

The original CMR (Client Meeting Report) module is a comprehensive sales tracking system with 50+ fields organized in 6 sections, supporting a complete sales workflow from initial appointment through deal closure.

---

## SECTIONS & FIELDS

### Section 1: Appointment Details
- clientName (required)
- hubspotContactId (optional)
- address (optional)
- clientType (dropdown: Residential, Commercial)
- appointmentDate (required, defaults to today)
- appointmentType (required: In-Home, Showroom, Phone)
- convertedToInPerson (toggle, only if Phone)
- convertedDate (date, only if converted)
- convertedType (dropdown: In-Home, Showroom, only if converted)
- leadSources (multi-select: Google, Meta, Home Show, Sales Rep, TV, StruXure Corp, Progressive, Corradi USA, Contractor Ref, Client Ref, Other)
- leadSourceOther (text, only if Other selected)
- projectTypes (multi-select: Pergola Attached, Pergola Freestanding, Pergotenda, Pavilion, Motorized Screens, Retractable Awning, Umbrella, Cabana, Deck, Patio, Other)
- projectTypeOther (text, only if Other selected)

### Section 2: Deal Status
- dealStatus (required, dropdown: Working on Design/Proposal, Proposal Presented/Sent, Actively Considering, Awaiting Financing, Waiting on Design, Delayed, Lost)
- followUpDate (date, optional)
- noFollowUpReason (text, only if no followUpDate)
- proposalDate (date, optional)
- lostReason (text, required if dealStatus = Lost)
- closeTimeline (dropdown: 0-30 days, 31-60 days, 61-90 days, 90+ days)
- lastConversationSummary (textarea, optional)

### Section 3: Purchase Confidence
- purchaseConfidencePct (required, slider 0-100 in 10% increments)
- originalPcPct (locked after first submission, never changes)
- estimatedContractValue (currency, optional but editable in pipeline)
- decisionMakers (text, optional)
- mainMotivation (textarea, optional)
- mainHesitation (textarea, optional)
- pcNotes (required, minimum 3 sentences)

### Section 4: Value & Objections
- financingDiscussed (toggle: Yes/No)
- financingReaction (dropdown: Interested, Needs Follow-up, Declined, only if financingDiscussed)
- valueCommunicated (multi-select: Years in Business, Full-Service Design/Permit/Install, Experienced Install Team, Permit Department, Showroom Experience, Stability vs Online Sellers, Product Quality)
- clientResponse (dropdown: Strong Alignment, Neutral, Price-Focused, Comparing Online)
- objections (multi-select: Price, Timing, Financing, Competitors, HOA/Permits, Decision Maker Not Present, Other)
- objectionOther (text, only if Other selected)
- objectionNotes (textarea, optional)

### Section 5: Next Steps & Marketing
- nextActions (multi-select: Follow-up Call, Design Revision, Financing Follow-up, Showroom Visit, Site Revisit)
- nextFollowUpDate (date, optional)
- leadQuality (dropdown: Excellent, Good, Average, Poor, required for marketing leads)
- expectationAlignment (dropdown: Yes, Somewhat, No, required for marketing leads)
- messagingReferenced (multi-select: Price Promotion, Financing Offer, Product Type, Lifestyle, Other)
- messagingOther (text, only if Other selected)
- budgetAlignment (dropdown: Aligned, Slightly Below, Significantly Below)
- marketingNotes (textarea, optional)

### Section 6: Progress Notes
- progressNotes (list of timestamped notes, each with id, text, createdAt)
- Add note button for creating new timestamped notes

---

## WORKFLOW & PERMISSIONS

### User Roles
- **super-admin**: View/edit/delete ALL CMRs, approve, export
- **admin**: View/edit/delete ALL CMRs, approve, export
- **manager**: View/edit/delete own + team CMRs, approve, export
- **member**: View/edit/delete own CMRs only, export own
- **guest**: View own CMRs only (read-only)

### CMR Lifecycle
1. **Draft** - User creates new CMR (not submitted)
   - Only visible to creator
   - Can be edited/deleted freely
   - Not in reports/dashboards

2. **Submitted** - User submits CMR
   - Visible to creator + managers/admins
   - Can still be edited by creator
   - Appears in dashboards
   - `originalPcPct` is locked on first submission

3. **Approved** - Manager/admin approves
   - Visible to all authorized users
   - Can be edited by creator or approver
   - Appears in all reports

4. **Sold/Lost** - Marked as sold or lost
   - `outcome` field updated to 'sold' or 'lost'
   - `soldAt` timestamp recorded
   - `soldBy` user ID recorded
   - Moves to "Closed" section in dashboard

### Key Workflow Rules
- **First Submission Lock**: `originalPcPct` is set on first submission and never changes
- **PC Editable**: `purchaseConfidencePct` can be edited anytime (current confidence)
- **Contract Value Editable**: `estimatedContractValue` can be edited in pipeline view
- **Progress Notes**: Can be added anytime, never deleted
- **Status Transitions**: Deal status can be changed anytime
- **Outcome Finality**: Once marked 'sold' or 'lost', outcome cannot be changed back to 'open'

---

## VALIDATION RULES

### Required Fields
- clientName
- appointmentDate
- appointmentType
- dealStatus
- purchaseConfidencePct
- pcNotes (minimum 3 sentences)

### Conditional Required Fields
- If appointmentType = "phone" and convertedToInPerson = true:
  - convertedDate (required)
  - convertedType (required)
- If dealStatus = "lost":
  - lostReason (required)
- If marketing lead:
  - leadQuality (required)
  - expectationAlignment (required)

---

## VIEWS & FEATURES

### List Page
- Tabs: "My Reports" (default) and "All Reports" (for managers/admins)
- Filters: By consultant, month, deal status, lead source, project type
- Grouping: By consultant or by month
- Sorting: By date, deal status, PC percentage
- Row actions: Edit, Delete, Export to PDF

### Detail Page
- Display all 6 sections
- Edit button to modify CMR
- Export to PDF button
- Progress notes section
- Back button
- Delete button (if owner/admin)

### PDF Export
- 7-page professional report
- Company header/footer
- All sections formatted
- Currency and date formatting
- Multi-select display
- Page numbers and timestamps

---

## COMPARISON: ORIGINAL vs SIMPLIFIED

### What's in the Original
✅ 6 complete sections with 50+ fields
✅ Multi-step wizard form
✅ Purchase confidence slider with interpretation
✅ Progress notes with timestamps
✅ Pipeline tracking (open/sold/lost)
✅ Marketing feedback section
✅ Financing discussion tracking
✅ Deal status with 7 options
✅ Next actions tracking
✅ Value communicated tracking
✅ Objections tracking
✅ Lead quality assessment
✅ Budget alignment assessment
✅ Messaging referenced tracking
✅ Full PDF export with 7+ pages
✅ List page with filters and grouping
✅ Role-based permissions
✅ Draft/Submitted/Approved workflow
✅ Locked originalPcPct after first submission
✅ Consultant/manager/admin access control

