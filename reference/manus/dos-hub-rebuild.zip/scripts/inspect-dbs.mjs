/**
 * Read-only inspection script.
 * Connects to SOURCE (DATABASE_URL_DEV) and TARGET (DATABASE_URL),
 * collects row counts and column lists for all 22 tables, then prints a JSON report.
 * Makes NO writes of any kind.
 */
import mysql from "mysql2/promise";
import * as dotenv from "dotenv";
import { fileURLToPath } from "url";
import path from "path";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.join(__dirname, "../.env") });

const TABLES = [
  "users",
  "companies",
  "module_permissions",
  "projects",
  "cmr_reports",
  "cmr_line_items",
  "screen_orders",
  "order_revisions",
  "receipts",
  "aquaclean_receipts",
  "project_material_checklists",
  "notifications",
  "preconstruction_checklists",
  "zoning_lookups",
  "time_off_policies",
  "time_off_requests",
  "screen_calculation_profiles",
  "screen_manufacturers",
  "screen_measurement_headers",
  "screen_measurement_lines",
  "screen_measurement_attachments",
  "screen_measurement_line_attachments",
];

async function inspectDb(label, url) {
  const result = { label, host: null, database: null, tables: {} };
  let conn;
  try {
    // Parse host/db from URL for reporting (no password)
    const u = new URL(url);
    result.host = u.hostname;
    result.database = u.pathname.replace(/^\//, "");

    conn = await mysql.createConnection({
      uri: url,
      ssl: { rejectUnauthorized: false },
      connectTimeout: 15000,
    });

    for (const table of TABLES) {
      const tableInfo = { exists: false, rowCount: null, columns: [] };
      try {
        // Check existence and get columns
        const [cols] = await conn.execute(
          `SELECT COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE, COLUMN_DEFAULT, EXTRA
           FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?
           ORDER BY ORDINAL_POSITION`,
          [table]
        );
        if (cols.length > 0) {
          tableInfo.exists = true;
          tableInfo.columns = cols.map(c => ({
            name: c.COLUMN_NAME,
            type: c.COLUMN_TYPE,
            nullable: c.IS_NULLABLE,
            default: c.COLUMN_DEFAULT,
            extra: c.EXTRA,
          }));
          // Row count
          const [[{ cnt }]] = await conn.execute(
            `SELECT COUNT(*) AS cnt FROM \`${table}\``
          );
          tableInfo.rowCount = Number(cnt);
        }
      } catch (e) {
        tableInfo.error = e.message;
      }
      result.tables[table] = tableInfo;
    }
  } catch (e) {
    result.connectionError = e.message;
  } finally {
    if (conn) await conn.end();
  }
  return result;
}

async function main() {
  const srcUrl = process.env.DATABASE_URL_DEV;
  const tgtUrl = process.env.DATABASE_URL;

  if (!srcUrl) { console.error("DATABASE_URL_DEV not set"); process.exit(1); }
  if (!tgtUrl) { console.error("DATABASE_URL not set"); process.exit(1); }

  console.error("Inspecting SOURCE database...");
  const src = await inspectDb("SOURCE (Manus dev — gateway01)", srcUrl);

  console.error("Inspecting TARGET database...");
  const tgt = await inspectDb("TARGET (production — gateway04)", tgtUrl);

  console.log(JSON.stringify({ source: src, target: tgt }, null, 2));
}

main().catch(e => { console.error(e); process.exit(1); });
