/**
 * Pre-migration safety backup:
 * 1. SHOW CREATE TABLE for every table in gateway04
 * 2. SHOW CREATE TABLE for every table in dos_hub_prod
 * 3. Row counts for every table in both databases
 * Read-only. No changes.
 */
import mysql from "mysql2/promise";
import { writeFileSync } from "fs";

function parseUrl(urlStr, dbOverride) {
  const u = new URL(urlStr);
  return {
    host: u.hostname,
    port: parseInt(u.port) || 4000,
    user: decodeURIComponent(u.username),
    password: decodeURIComponent(u.password),
    database: dbOverride || u.pathname.replace(/^\//, ""),
    ssl: { rejectUnauthorized: true },
    connectTimeout: 15000,
  };
}

async function backupDatabase(conn, label) {
  const result = { label, schemas: {}, row_counts: {} };

  // Get table list
  const [tableRows] = await conn.query("SHOW TABLES");
  const tables = tableRows.map((r) => Object.values(r)[0]);

  // SHOW CREATE TABLE for each
  for (const tbl of tables) {
    const [[row]] = await conn.query(`SHOW CREATE TABLE \`${tbl}\``);
    result.schemas[tbl] = row["Create Table"];
  }

  // Row counts for each
  for (const tbl of tables) {
    const [[countRow]] = await conn.query(
      `SELECT COUNT(*) AS cnt FROM \`${tbl}\``
    );
    result.row_counts[tbl] = Number(countRow.cnt);
  }

  return result;
}

async function main() {
  console.log("Starting pre-migration safety backup...\n");

  // gateway04
  const gw4conn = await mysql.createConnection(
    parseUrl(process.env.DATABASE_URL)
  );
  console.log("Connected to gateway04");
  const gw4backup = await backupDatabase(gw4conn, "gateway04/YxtbJqJxmKMGKQFMBD7qrd");
  await gw4conn.end();
  console.log(
    `  ✓ gateway04: ${Object.keys(gw4backup.schemas).length} tables backed up`
  );

  // dos_hub_prod
  const prodconn = await mysql.createConnection(
    parseUrl(process.env.GATEWAY01_URL, "dos_hub_prod")
  );
  console.log("Connected to dos_hub_prod");
  const prodbackup = await backupDatabase(prodconn, "gateway01/dos_hub_prod");
  await prodconn.end();
  console.log(
    `  ✓ dos_hub_prod: ${Object.keys(prodbackup.schemas).length} tables backed up`
  );

  const output = {
    backup_timestamp: new Date().toISOString(),
    note: "Pre-migration safety backup — read-only, no changes made",
    gateway04: gw4backup,
    dos_hub_prod: prodbackup,
  };

  writeFileSync(
    "/tmp/pre-migration-backup.json",
    JSON.stringify(output, null, 2)
  );
  console.log("\nBackup written to /tmp/pre-migration-backup.json");

  // Print row count summary
  console.log("\n=== PRE-MIGRATION ROW COUNTS ===");
  console.log(
    "TABLE".padEnd(45) + "GATEWAY04".padEnd(12) + "DOS_HUB_PROD"
  );
  console.log("-".repeat(70));

  const allTables = new Set([
    ...Object.keys(gw4backup.row_counts),
    ...Object.keys(prodbackup.row_counts),
  ]);
  for (const tbl of [...allTables].sort()) {
    const g4 =
      gw4backup.row_counts[tbl] !== undefined
        ? String(gw4backup.row_counts[tbl])
        : "NOT FOUND";
    const pr =
      prodbackup.row_counts[tbl] !== undefined
        ? String(prodbackup.row_counts[tbl])
        : "NOT FOUND";
    console.log(tbl.padEnd(45) + g4.padEnd(12) + pr);
  }
}

main().catch((e) => {
  console.error("Fatal:", e.message);
  process.exit(1);
});
