/**
 * Read-only inspection of gateway01.
 * Attempts SHOW DATABASES, then row counts if connected.
 * Makes NO writes.
 */
import mysql from "mysql2/promise";
import * as dotenv from "dotenv";
import { fileURLToPath } from "url";
import path from "path";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.join(__dirname, "../.env") });

async function main() {
  const url = process.env.DATABASE_URL_DEV;
  if (!url) { process.stderr.write("DATABASE_URL_DEV not set\n"); process.exit(1); }

  const u = new URL(url);
  const host = u.hostname;
  const user = u.username;
  const database = u.pathname.replace(/^\//, "");

  process.stderr.write(`Attempting connection to gateway01:\n`);
  process.stderr.write(`  host: ${host}\n`);
  process.stderr.write(`  user: ${user}\n`);
  process.stderr.write(`  database: ${database}\n`);

  let conn;
  try {
    conn = await mysql.createConnection({
      uri: url,
      ssl: { rejectUnauthorized: false },
      connectTimeout: 15000,
    });
    process.stderr.write("Connection: SUCCESS\n");
  } catch (e) {
    process.stderr.write(`Connection FAILED: ${e.message}\n`);
    console.log(JSON.stringify({
      host,
      user,
      configured_database: database,
      connection_status: "FAILED",
      error: e.message,
    }, null, 2));
    process.exit(0);
  }

  // SHOW DATABASES
  let databases = [];
  try {
    const [rows] = await conn.execute("SHOW DATABASES");
    databases = rows.map(r => Object.values(r)[0]);
    process.stderr.write(`Databases visible: ${databases.join(", ")}\n`);
  } catch (e) {
    process.stderr.write(`SHOW DATABASES failed: ${e.message}\n`);
  }

  // Current database
  let currentDb = null;
  try {
    const [[row]] = await conn.execute("SELECT DATABASE() AS db");
    currentDb = row.db;
  } catch (e) {
    process.stderr.write(`SELECT DATABASE() failed: ${e.message}\n`);
  }

  // Row counts in configured database
  const counts = {};
  for (const tbl of ["users", "cmr_reports", "projects"]) {
    try {
      const [[{ cnt }]] = await conn.execute(`SELECT COUNT(*) AS cnt FROM \`${tbl}\``);
      counts[tbl] = Number(cnt);
    } catch (e) {
      counts[tbl] = `ERROR: ${e.message.substring(0, 80)}`;
    }
  }

  // Check for dos_hub_prod and dos_hub_dev databases
  const namedDbs = ["dos_hub_prod", "dos_hub_dev", "test"];
  const dbChecks = {};
  for (const db of namedDbs) {
    if (databases.includes(db)) {
      try {
        const [[u]] = await conn.execute(`SELECT COUNT(*) AS cnt FROM \`${db}\`.users`);
        const [[c]] = await conn.execute(`SELECT COUNT(*) AS cnt FROM \`${db}\`.cmr_reports`);
        dbChecks[db] = { users: Number(u.cnt), cmr_reports: Number(c.cnt) };
      } catch (e) {
        dbChecks[db] = { error: e.message.substring(0, 80) };
      }
    } else {
      dbChecks[db] = { exists: false };
    }
  }

  await conn.end();

  console.log(JSON.stringify({
    host,
    user,
    configured_database: database,
    connection_status: "SUCCESS",
    current_database: currentDb,
    all_databases: databases,
    counts_in_configured_db: counts,
    named_database_checks: dbChecks,
  }, null, 2));
}

main().catch(e => { process.stderr.write(e.message + "\n"); process.exit(1); });
