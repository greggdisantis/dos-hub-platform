/**
 * Phase 2 Migration: Build real production database on dos_hub_prod
 * Execution order: schema → data → verify
 * Rules:
 *   - Target state for migrated tables must equal gateway04 exactly (no merge)
 *   - No DROP without prior SHOW CREATE TABLE capture
 *   - No Cloud Run / secrets / deployment changes
 *   - Pre-migration backup already captured in /tmp/pre-migration-backup.json
 */
import mysql from "mysql2/promise";
import { readFileSync, writeFileSync } from "fs";

function parseUrl(urlStr, dbOverride) {
  const u = new URL(urlStr);
  return {
    host: u.hostname,
    port: parseInt(u.port) || 4000,
    user: decodeURIComponent(u.username),
    password: decodeURIComponent(u.password),
    database: dbOverride || u.pathname.replace(/^\//, ""),
    ssl: { rejectUnauthorized: true },
    connectTimeout: 20000,
    multipleStatements: false,
  };
}

function log(msg) {
  const ts = new Date().toISOString();
  console.log(`[${ts}] ${msg}`);
}

// ─────────────────────────────────────────────
// STEP 1: SCHEMA PHASE
// ─────────────────────────────────────────────
async function step1_schema(prod, dev) {
  log("═══ STEP 1: SCHEMA PHASE ═══");

  // 1a. Create 13 missing tables from dos_hub_dev DDL
  const createTablesJson = readFileSync("/tmp/create-tables.json", "utf8");
  const createTables = JSON.parse(createTablesJson);

  const MISSING_TABLES = [
    "aquaclean_receipts", "audit_logs", "companies", "module_permissions",
    "notifications", "order_revisions", "preconstruction_checklists",
    "project_material_checklists", "receipts", "screen_orders",
    "time_off_policies", "time_off_requests", "zoning_lookups",
  ];

  log("1a. Creating 13 missing tables in dos_hub_prod...");
  for (const tbl of MISSING_TABLES) {
    const ddl = createTables[tbl];
    if (!ddl) throw new Error(`Missing DDL for table: ${tbl}`);
    // Convert to IF NOT EXISTS
    const safeDdl = ddl.replace(
      /^CREATE TABLE `/,
      "CREATE TABLE IF NOT EXISTS `"
    );
    await prod.query(safeDdl);
    log(`  ✓ Created: ${tbl}`);
  }

  // 1b. ALTER cmr_reports — add 3 missing columns
  log("1b. Altering cmr_reports to add missing columns (attendees, notes, actionItems)...");

  // Check which columns already exist
  const [existingCols] = await prod.query("SHOW COLUMNS FROM `cmr_reports`");
  const colNames = existingCols.map((r) => r.Field);

  // Get column definitions from gateway04 backup
  const backup = JSON.parse(readFileSync("/tmp/pre-migration-backup.json", "utf8"));
  const gw4CreateCmr = backup.gateway04.schemas["cmr_reports"];

  // Extract column definitions for the 3 missing columns from gateway04 DDL
  const missingCols = ["attendees", "notes", "actionItems"];
  for (const col of missingCols) {
    if (colNames.includes(col)) {
      log(`  ⊘ Column ${col} already exists — skipping`);
      continue;
    }
    // Extract the column definition line from gateway04 CREATE TABLE
    const regex = new RegExp(`\`${col}\`[^\n,]+`, "i");
    const match = gw4CreateCmr.match(regex);
    if (!match) throw new Error(`Cannot find column def for ${col} in gateway04 schema`);
    const colDef = match[0].trim();
    await prod.query(`ALTER TABLE \`cmr_reports\` ADD COLUMN ${colDef}`);
    log(`  ✓ Added column: ${col} (${colDef.substring(0, 60)}...)`);
  }

  // 1c. Recreate screen_calculation_profiles
  log("1c. Recreating screen_calculation_profiles in dos_hub_prod...");
  // Safety: capture existing row before drop
  const [existingRows] = await prod.query("SELECT * FROM `screen_calculation_profiles`");
  log(`  → Existing dos_hub_prod row(s) captured before DROP: ${existingRows.length} row(s)`);
  writeFileSync("/tmp/screen_calc_profiles_backup.json", JSON.stringify(existingRows, null, 2));

  // Drop and recreate using gateway04 schema
  const gw4CreateScp = backup.gateway04.schemas["screen_calculation_profiles"];
  await prod.query("DROP TABLE `screen_calculation_profiles`");
  log("  ✓ Dropped screen_calculation_profiles");
  await prod.query(gw4CreateScp);
  log("  ✓ Recreated screen_calculation_profiles with gateway04 schema");

  log("STEP 1 COMPLETE ✓\n");
}

// ─────────────────────────────────────────────
// STEP 2: DATA PHASE
// ─────────────────────────────────────────────
async function step2_data(prod) {
  log("═══ STEP 2: DATA PHASE ═══");

  const exportData = JSON.parse(
    readFileSync("/tmp/gateway04-export.json", "utf8")
  ).export_data;

  // Helper: escape values for INSERT
  function escapeVal(conn, v) {
    if (v === null || v === undefined) return "NULL";
    if (typeof v === "number" || typeof v === "bigint") return String(v);
    if (typeof v === "boolean") return v ? "1" : "0";
    if (v instanceof Date) return `'${v.toISOString().slice(0, 19).replace("T", " ")}'`;
    // Buffer (binary)
    if (Buffer.isBuffer(v)) return `0x${v.toString("hex")}`;
    // JSON objects/arrays — serialize to JSON string then escape
    if (typeof v === "object") return conn.escape(JSON.stringify(v));
    return conn.escape(v);
  }

  async function insertRows(conn, tbl, rows) {
    if (!rows || rows.length === 0) {
      log(`  ⊘ ${tbl}: 0 rows — skip`);
      return;
    }
    const cols = Object.keys(rows[0]);
    const colList = cols.map((c) => `\`${c}\``).join(", ");
    let inserted = 0;
    for (const row of rows) {
      const vals = cols.map((c) => escapeVal(conn, row[c])).join(", ");
      await conn.query(`INSERT INTO \`${tbl}\` (${colList}) VALUES (${vals})`);
      inserted++;
    }
    log(`  ✓ ${tbl}: ${inserted} rows inserted`);
  }

  // 2-1: users — TRUNCATE then insert 17
  log("2-1. users: TRUNCATE then INSERT 17 rows...");
  await prod.query("SET FOREIGN_KEY_CHECKS=0");
  await prod.query("TRUNCATE TABLE `users`");
  await prod.query("SET FOREIGN_KEY_CHECKS=1");
  await insertRows(prod, "users", exportData["users"]);

  // 2-2: screen_manufacturers
  log("2-2. screen_manufacturers: TRUNCATE then INSERT...");
  await prod.query("TRUNCATE TABLE `screen_manufacturers`");
  await insertRows(prod, "screen_manufacturers", exportData["screen_manufacturers"]);

  // 2-3: screen_motor_types
  log("2-3. screen_motor_types: TRUNCATE then INSERT...");
  await prod.query("TRUNCATE TABLE `screen_motor_types`");
  await insertRows(prod, "screen_motor_types", exportData["screen_motor_types"]);

  // 2-4: screen_remote_types
  log("2-4. screen_remote_types: TRUNCATE then INSERT...");
  await prod.query("TRUNCATE TABLE `screen_remote_types`");
  await insertRows(prod, "screen_remote_types", exportData["screen_remote_types"]);

  // 2-5: screen_calculation_profiles (already recreated in step 1c)
  log("2-5. screen_calculation_profiles: INSERT 1 row...");
  await insertRows(prod, "screen_calculation_profiles", exportData["screen_calculation_profiles"]);

  // 2-6: screen_measurement_headers — TRUNCATE (replace existing 1 row) then INSERT 2
  log("2-6. screen_measurement_headers: TRUNCATE then INSERT 2 rows...");
  await prod.query("SET FOREIGN_KEY_CHECKS=0");
  await prod.query("TRUNCATE TABLE `screen_measurement_headers`");
  await prod.query("SET FOREIGN_KEY_CHECKS=1");
  await insertRows(prod, "screen_measurement_headers", exportData["screen_measurement_headers"]);

  // 2-7: screen_measurement_lines
  log("2-7. screen_measurement_lines: TRUNCATE then INSERT 2 rows...");
  await prod.query("TRUNCATE TABLE `screen_measurement_lines`");
  await insertRows(prod, "screen_measurement_lines", exportData["screen_measurement_lines"]);

  // 2-8: cmr_reports — INSERT 12 rows (table was empty, schema fixed in step 1b)
  log("2-8. cmr_reports: INSERT 12 rows...");
  await prod.query("TRUNCATE TABLE `cmr_reports`");
  await insertRows(prod, "cmr_reports", exportData["cmr_reports"]);

  log("STEP 2 COMPLETE ✓\n");
}

// ─────────────────────────────────────────────
// STEP 3: VERIFY PHASE
// ─────────────────────────────────────────────
async function step3_verify(prod) {
  log("═══ STEP 3: VERIFY PHASE ═══");

  const expected = {
    users: 17,
    cmr_reports: 12,
    screen_calculation_profiles: 1,
    screen_manufacturers: 6,
    screen_measurement_headers: 2,
    screen_measurement_lines: 2,
    screen_motor_types: 12,
    screen_remote_types: 13,
    projects: 0,
    screen_measurement_attachments: 0,
    screen_measurement_line_attachments: 0,
    cmr_line_items: 0,
  };

  const results = {};
  let allPass = true;

  console.log("\nTABLE".padEnd(45) + "EXPECTED".padEnd(12) + "ACTUAL".padEnd(10) + "STATUS");
  console.log("-".repeat(75));

  for (const [tbl, exp] of Object.entries(expected)) {
    try {
      const [[row]] = await prod.query(`SELECT COUNT(*) AS cnt FROM \`${tbl}\``);
      const actual = Number(row.cnt);
      const pass = actual === exp;
      if (!pass) allPass = false;
      results[tbl] = { expected: exp, actual, pass };
      console.log(
        tbl.padEnd(45) + String(exp).padEnd(12) + String(actual).padEnd(10) +
        (pass ? "✓ PASS" : "✗ FAIL")
      );
    } catch (e) {
      results[tbl] = { expected: exp, actual: "ERROR", pass: false };
      allPass = false;
      console.log(tbl.padEnd(45) + String(exp).padEnd(12) + "ERROR".padEnd(10) + "✗ FAIL");
    }
  }

  console.log("-".repeat(75));
  if (allPass) {
    log("\n✓ ALL COUNTS MATCH — dos_hub_prod equals gateway04 exactly.");
  } else {
    log("\n✗ SOME COUNTS DO NOT MATCH — review failures above.");
  }

  writeFileSync("/tmp/migration-verify.json", JSON.stringify(results, null, 2));
  log("Verification results written to /tmp/migration-verify.json");
  log("STEP 3 COMPLETE ✓");
  return allPass;
}

// ─────────────────────────────────────────────
// MAIN
// ─────────────────────────────────────────────
async function main() {
  log("Phase 2 Migration Starting");
  log("Source: gateway04/YxtbJqJxmKMGKQFMBD7qrd (read-only)");
  log("Target: gateway01/dos_hub_prod");
  log("Schema source for new tables: gateway01/dos_hub_dev\n");

  const prod = await mysql.createConnection(
    parseUrl(process.env.GATEWAY01_URL, "dos_hub_prod")
  );
  const dev = await mysql.createConnection(
    parseUrl(process.env.GATEWAY01_URL, "dos_hub_dev")
  );

  log("Connections established.\n");

  // Step 1 (schema phase) already completed successfully in prior run.
  // Resuming from Step 2 (data phase).
  try {
    await step2_data(prod);
    const passed = await step3_verify(prod);
    if (!passed) {
      process.exit(1);
    }
  } finally {
    await prod.end();
    await dev.end();
  }

  log("\nPhase 2 Migration Complete.");
}

main().catch((e) => {
  console.error("\nFATAL ERROR:", e.message);
  console.error(e.stack);
  process.exit(1);
});
