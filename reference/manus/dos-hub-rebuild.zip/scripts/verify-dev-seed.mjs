/**
 * verify-dev-seed.mjs
 * Read-only: checks row counts and CMR column presence in dos_hub_dev.
 * No writes. No changes.
 */
import mysql from "mysql2/promise";

const url = process.env.DATABASE_URL_DEV;
if (!url) { console.error("DATABASE_URL_DEV not set"); process.exit(1); }

const u = new URL(url);
const conn = await mysql.createConnection({
  host: u.hostname,
  port: parseInt(u.port || "3306"),
  user: decodeURIComponent(u.username),
  password: decodeURIComponent(u.password),
  database: u.pathname.replace(/^\//, ""),
  ssl: { rejectUnauthorized: true },
  connectTimeout: 15000,
});

const checks = [
  ["screen_manufacturers row count",        "SELECT COUNT(*) AS n FROM screen_manufacturers"],
  ["screen_motor_types row count",           "SELECT COUNT(*) AS n FROM screen_motor_types"],
  ["screen_remote_types row count",          "SELECT COUNT(*) AS n FROM screen_remote_types"],
  ["screen_calculation_profiles row count",  "SELECT COUNT(*) AS n FROM screen_calculation_profiles"],
  ["cmr_reports.attendees exists",           "SELECT COUNT(*) AS n FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='cmr_reports' AND COLUMN_NAME='attendees'"],
  ["cmr_reports.notes exists",               "SELECT COUNT(*) AS n FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='cmr_reports' AND COLUMN_NAME='notes'"],
  ["cmr_reports.actionItems exists",         "SELECT COUNT(*) AS n FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='cmr_reports' AND COLUMN_NAME='actionItems'"],
  ["idx_profile_manufacturer exists",        "SELECT COUNT(*) AS n FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='screen_calculation_profiles' AND INDEX_NAME='idx_profile_manufacturer'"],
  ["idx_profile_status exists",              "SELECT COUNT(*) AS n FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='screen_calculation_profiles' AND INDEX_NAME='idx_profile_status'"],
];

let errors = 0;
for (const [label, sql] of checks) {
  const [rows] = await conn.query(sql);
  const n = rows[0].n;
  const ok = n > 0;
  if (!ok) { errors++; console.error(`FAIL  ${label}: ${n}`); }
  else      { console.log(`OK    ${label}: ${n}`); }
}

await conn.end();
if (errors > 0) { console.error(`\n${errors} check(s) failed.`); process.exit(1); }
else            { console.log("\nAll checks passed."); }
