/**
 * Phase 3 Step 0 — Precondition Verification
 * Read-only. No changes.
 * Checks:
 *   1. dos_hub_prod row counts (via GATEWAY01_URL)
 *   2. gateway04 row counts (via DATABASE_URL)
 *   3. Confirms both match expected values
 */
import mysql from "mysql2/promise";

function parseUrl(urlStr, dbOverride) {
  const u = new URL(urlStr);
  return {
    host: u.hostname,
    port: parseInt(u.port) || 4000,
    user: decodeURIComponent(u.username),
    password: decodeURIComponent(u.password),
    database: dbOverride || u.pathname.replace(/^\//, ""),
    ssl: { rejectUnauthorized: true },
    connectTimeout: 15000,
  };
}

async function getRowCounts(conn, tables) {
  const counts = {};
  for (const tbl of tables) {
    try {
      const [[row]] = await conn.query(`SELECT COUNT(*) AS cnt FROM \`${tbl}\``);
      counts[tbl] = Number(row.cnt);
    } catch {
      counts[tbl] = "TABLE NOT FOUND";
    }
  }
  return counts;
}

async function main() {
  const TABLES = [
    "users",
    "cmr_reports",
    "screen_measurement_headers",
    "screen_measurement_lines",
  ];

  const EXPECTED = {
    users: 17,
    cmr_reports: 12,
    screen_measurement_headers: 2,
    screen_measurement_lines: 2,
  };

  console.log("=== Phase 3 Step 0 — Precondition Verification ===\n");

  // gateway04 (current production via DATABASE_URL)
  const gw4conn = await mysql.createConnection(
    parseUrl(process.env.DATABASE_URL)
  );
  const gw4counts = await getRowCounts(gw4conn, TABLES);
  await gw4conn.end();

  // dos_hub_prod (target via GATEWAY01_URL)
  const prodconn = await mysql.createConnection(
    parseUrl(process.env.GATEWAY01_URL, "dos_hub_prod")
  );
  const prodcounts = await getRowCounts(prodconn, TABLES);
  await prodconn.end();

  console.log(
    "TABLE".padEnd(40) + "GATEWAY04".padEnd(12) + "DOS_HUB_PROD".padEnd(14) + "MATCH"
  );
  console.log("-".repeat(72));

  let allMatch = true;
  for (const tbl of TABLES) {
    const g4 = gw4counts[tbl];
    const pr = prodcounts[tbl];
    const exp = EXPECTED[tbl];
    const match = g4 === pr && pr === exp;
    if (!match) allMatch = false;
    console.log(
      tbl.padEnd(40) +
        String(g4).padEnd(12) +
        String(pr).padEnd(14) +
        (match ? "✓ MATCH" : "✗ MISMATCH")
    );
  }

  console.log("-".repeat(72));
  console.log("");

  if (allMatch) {
    console.log("✓ ALL PRECONDITIONS MET");
    console.log("  dos_hub_prod matches gateway04 exactly");
    console.log("  DATABASE_URL not yet changed (still pointing to gateway04)");
    console.log("  No deploy in progress");
    console.log("  No secrets modified");
    console.log("\nPhase 3 Step 0: PASS — safe to proceed to Step 1");
  } else {
    console.log("✗ PRECONDITION FAILURE — do not proceed");
    process.exit(1);
  }
}

main().catch((e) => {
  console.error("FATAL:", e.message);
  process.exit(1);
});
