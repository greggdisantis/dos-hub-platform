/**
 * Read-only: export all data from gateway04 tables that need to be copied to dos_hub_prod
 * Tables: users, cmr_reports, screen_calculation_profiles, screen_manufacturers,
 *         screen_measurement_headers, screen_measurement_lines,
 *         screen_measurement_attachments, screen_measurement_line_attachments,
 *         screen_motor_types, screen_remote_types, projects
 * Uses DATABASE_URL (gateway04)
 */
import mysql from "mysql2/promise";
import { writeFileSync } from "fs";

const DB_URL = process.env.DATABASE_URL;
if (!DB_URL) { console.error("DATABASE_URL not set"); process.exit(1); }

function parseUrl(urlStr) {
  const u = new URL(urlStr);
  return {
    host: u.hostname, port: parseInt(u.port) || 4000,
    user: decodeURIComponent(u.username),
    password: decodeURIComponent(u.password),
    database: u.pathname.replace(/^\//, ""),
    ssl: { rejectUnauthorized: true },
    connectTimeout: 15000,
  };
}

// Tables to export from gateway04 (all tables that exist there)
const TABLES_TO_EXPORT = [
  "users",
  "cmr_reports",
  "projects",
  "screen_calculation_profiles",
  "screen_manufacturers",
  "screen_measurement_headers",
  "screen_measurement_lines",
  "screen_measurement_attachments",
  "screen_measurement_line_attachments",
  "screen_motor_types",
  "screen_remote_types",
];

async function main() {
  const conn = await mysql.createConnection(parseUrl(DB_URL));
  console.log("Connected to gateway04");

  const export_data = {};

  for (const tbl of TABLES_TO_EXPORT) {
    try {
      const [rows] = await conn.query(`SELECT * FROM \`${tbl}\``);
      export_data[tbl] = rows;
      console.log(`  ✓ ${tbl}: ${rows.length} rows`);
    } catch (e) {
      export_data[tbl] = { error: e.message };
      console.log(`  ✗ ${tbl}: ${e.message}`);
    }
  }

  // Also get SHOW CREATE TABLE for each to understand schema
  const schemas = {};
  for (const tbl of TABLES_TO_EXPORT) {
    try {
      const [[row]] = await conn.query(`SHOW CREATE TABLE \`${tbl}\``);
      schemas[tbl] = row["Create Table"];
    } catch (e) {
      schemas[tbl] = `ERROR: ${e.message}`;
    }
  }

  await conn.end();

  writeFileSync("/tmp/gateway04-export.json", JSON.stringify({ export_data, schemas }, null, 2));
  console.log("\nExport written to /tmp/gateway04-export.json");

  // Print summary
  console.log("\n=== EXPORT SUMMARY ===");
  for (const tbl of TABLES_TO_EXPORT) {
    const d = export_data[tbl];
    if (Array.isArray(d)) {
      console.log(`  ${tbl}: ${d.length} rows`);
    } else {
      console.log(`  ${tbl}: ERROR - ${d.error}`);
    }
  }
}

main().catch(e => { console.error(e.message); process.exit(1); });
