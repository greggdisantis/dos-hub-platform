/**
 * Print the currently loaded GATEWAY01_URL with password masked.
 * Read-only. No connections attempted.
 */
const raw = process.env.GATEWAY01_URL || "";

if (!raw) {
  console.log("GATEWAY01_URL: NOT SET in environment");
  process.exit(0);
}

try {
  const u = new URL(raw);
  console.log("=== GATEWAY01_URL (currently loaded) ===");
  console.log("host:         ", u.hostname);
  console.log("port:         ", u.port || "4000 (default)");
  console.log("database:     ", u.pathname.replace(/^\//, "") || "(empty — base URL only)");
  console.log("username:     ", decodeURIComponent(u.username));
  console.log("ssl param:    ", raw.includes("ssl") ? "YES" : "NO");
  console.log("masked conn:  ", raw.replace(/:([^:@]+)@/, ":<REDACTED>@"));
} catch (e) {
  console.log("PARSE ERROR:", e.message);
  console.log("raw (masked):", raw.replace(/:([^:@]+)@/, ":<REDACTED>@"));
}
