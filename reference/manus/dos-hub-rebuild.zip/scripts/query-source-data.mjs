/**
 * Read-only query of the SOURCE database (DATABASE_URL_DEV).
 * Fetches users, projects, cmr_reports, and checks for cmr_line_items.
 * Makes NO writes.
 */
import mysql from "mysql2/promise";
import * as dotenv from "dotenv";
import { fileURLToPath } from "url";
import path from "path";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.join(__dirname, "../.env") });

async function main() {
  const url = process.env.DATABASE_URL_DEV;
  if (!url) { process.stderr.write("DATABASE_URL_DEV not set\n"); process.exit(1); }

  const u = new URL(url);
  process.stderr.write(`Connecting to SOURCE: ${u.hostname} / ${u.pathname.replace(/^\//,'')}\n`);

  const conn = await mysql.createConnection({
    uri: url,
    ssl: { rejectUnauthorized: false },
    connectTimeout: 15000,
  });

  // Row counts
  const [[counts]] = await conn.execute(`
    SELECT
      (SELECT COUNT(*) FROM users) AS users,
      (SELECT COUNT(*) FROM projects) AS projects,
      (SELECT COUNT(*) FROM cmr_reports) AS cmr_reports
  `);

  // Check if cmr_line_items exists
  let cmrLineItemsExists = false;
  let cmrLineItemsCount = 0;
  try {
    const [[{ cnt }]] = await conn.execute("SELECT COUNT(*) AS cnt FROM cmr_line_items");
    cmrLineItemsExists = true;
    cmrLineItemsCount = Number(cnt);
  } catch (e) {
    if (!e.message.includes("doesn't exist") && !e.message.includes("ER_NO_SUCH_TABLE")) {
      process.stderr.write("cmr_line_items error: " + e.message + "\n");
    }
  }

  // Full user list
  const [users] = await conn.execute(
    "SELECT id, email, firstName, lastName, role, approved, userType, passwordHash, passwordChangeRequired, specialTags, createdAt, updatedAt, lastSignedIn FROM users ORDER BY id"
  );

  // Projects
  const [projects] = await conn.execute(
    "SELECT id, userId, name, description, externalSourceType, hubspotDealId, hubspotContactId, serviceFusionJobId, serviceFusionCustomerId, projectStage, createdAt, updatedAt, clientName FROM projects ORDER BY id"
  );

  // CMR reports — just IDs and key fields for analysis
  const [cmrReports] = await conn.execute(
    "SELECT id, userId, projectId, clientName, status, createdAt FROM cmr_reports ORDER BY id"
  );

  await conn.end();

  const result = {
    counts: {
      users: Number(counts.users),
      projects: Number(counts.projects),
      cmr_reports: Number(counts.cmr_reports),
      cmr_line_items: cmrLineItemsExists ? cmrLineItemsCount : "TABLE_DOES_NOT_EXIST",
    },
    users,
    projects,
    cmrReportsSummary: cmrReports,
  };

  console.log(JSON.stringify(result, null, 2));
}

main().catch(e => { process.stderr.write(e.message + "\n"); process.exit(1); });
