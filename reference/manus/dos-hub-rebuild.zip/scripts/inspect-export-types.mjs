import { readFileSync } from "fs";

const data = JSON.parse(readFileSync("/tmp/gateway04-export.json", "utf8"));
const users = data.export_data.users;

if (users.length > 0) {
  const cols = Object.keys(users[0]);
  console.log("Users columns with non-primitive values:");
  cols.forEach((col) => {
    const val = users[0][col];
    const isNull = val === null;
    const isBuf = Buffer.isBuffer(val);
    const isObj = !isNull && !isBuf && typeof val === "object";
    if (isObj || isBuf) {
      console.log(
        `  ${col}: type=${typeof val} isBuf=${isBuf} isObj=${isObj} sample=${JSON.stringify(val).substring(0, 100)}`
      );
    }
  });
  console.log(`Total columns: ${cols.length}`);
  console.log(`Total users: ${users.length}`);
}

// Also check cmr_reports for JSON columns
const cmr = data.export_data.cmr_reports;
if (cmr.length > 0) {
  const cols = Object.keys(cmr[0]);
  console.log("\ncmr_reports columns with non-primitive values:");
  cols.forEach((col) => {
    const val = cmr[0][col];
    const isNull = val === null;
    const isBuf = Buffer.isBuffer(val);
    const isObj = !isNull && !isBuf && typeof val === "object";
    if (isObj || isBuf) {
      console.log(
        `  ${col}: type=${typeof val} isBuf=${isBuf} isObj=${isObj} sample=${JSON.stringify(val).substring(0, 100)}`
      );
    }
  });
}
