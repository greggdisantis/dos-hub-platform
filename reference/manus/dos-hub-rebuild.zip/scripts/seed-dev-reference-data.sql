-- ============================================================
-- DOS Hub Dev Seed SQL
-- Target: dos_hub_dev ONLY
-- Source: dos_hub_prod (data captured 2026-03-14)
-- Safe: INSERT IGNORE only — no drops, no deletes, no schema changes
-- Run from: TiDB Cloud SQL Editor, connected to dos_hub_dev
-- ============================================================

USE dos_hub_dev;

-- ── screen_manufacturers (6 rows from prod) ──
INSERT IGNORE INTO `screen_manufacturers` (`id`, `code`, `name`, `isActive`, `createdAt`, `updatedAt`) VALUES (1, 'hunter-douglas', 'Hunter Douglas', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_manufacturers` (`id`, `code`, `name`, `isActive`, `createdAt`, `updatedAt`) VALUES (2, 'lutron', 'Lutron', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_manufacturers` (`id`, `code`, `name`, `isActive`, `createdAt`, `updatedAt`) VALUES (3, 'mechoshade', 'MechoShade', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_manufacturers` (`id`, `code`, `name`, `isActive`, `createdAt`, `updatedAt`) VALUES (4, 'other', 'Other', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_manufacturers` (`id`, `code`, `name`, `isActive`, `createdAt`, `updatedAt`) VALUES (5, 'rollease', 'Rollease Acmeda', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_manufacturers` (`id`, `code`, `name`, `isActive`, `createdAt`, `updatedAt`) VALUES (6, 'somfy', 'Somfy', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');

-- ── screen_motor_types (12 rows from prod) ──
INSERT IGNORE INTO `screen_motor_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (1, 'somfy-rs100', 'RS100', 'somfy', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_motor_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (2, 'somfy-rs100-hz', 'RS100 Hz', 'somfy', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_motor_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (3, 'somfy-rs232', 'RS232', 'somfy', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_motor_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (4, 'somfy-lt50', 'LT50', 'somfy', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_motor_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (5, 'somfy-lt50-hz', 'LT50 Hz', 'somfy', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_motor_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (6, 'rollease-q-motor', 'Q-Motor', 'rollease', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_motor_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (7, 'rollease-q-motor-hz', 'Q-Motor Hz', 'rollease', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_motor_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (8, 'lutron-hyperion', 'Hyperion', 'lutron', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_motor_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (9, 'lutron-triathlon', 'Triathlon', 'lutron', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_motor_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (10, 'hunter-douglas-powerview', 'PowerView', 'hunter-douglas', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_motor_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (11, 'mechoshade-mecho5', 'MechoShade 5', 'mechoshade', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_motor_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (12, 'other-motor', 'Other', 'other', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');

-- ── screen_remote_types (13 rows from prod) ──
INSERT IGNORE INTO `screen_remote_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (1, 'somfy-situo-1', 'Situo 1', 'somfy', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_remote_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (2, 'somfy-situo-5', 'Situo 5', 'somfy', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_remote_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (3, 'somfy-telis-1', 'Telis 1', 'somfy', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_remote_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (4, 'somfy-telis-4', 'Telis 4', 'somfy', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_remote_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (5, 'somfy-smoove-1', 'Smoove 1', 'somfy', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_remote_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (6, 'rollease-automate-1ch', 'Automate 1-Channel', 'rollease', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_remote_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (7, 'rollease-automate-5ch', 'Automate 5-Channel', 'rollease', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_remote_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (8, 'lutron-pico-2bt', 'Pico 2-Button', 'lutron', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_remote_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (9, 'lutron-pico-3bt', 'Pico 3-Button', 'lutron', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_remote_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (10, 'lutron-sunnata', 'Sunnata', 'lutron', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_remote_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (11, 'hunter-douglas-powerview-pebble', 'PowerView Pebble', 'hunter-douglas', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_remote_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (12, 'mechoshade-mecho5-remote', 'MechoShade 5 Remote', 'mechoshade', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');
INSERT IGNORE INTO `screen_remote_types` (`id`, `code`, `name`, `manufacturerCode`, `isActive`, `createdAt`, `updatedAt`) VALUES (13, 'other-remote', 'Other', 'other', 1, '2025-01-01 00:00:00', '2025-01-01 00:00:00');

-- ── screen_calculation_profiles (1 row from prod) ──
-- Prod uses code='default-v1'. Dev already has code='default'.
-- This inserts the prod row as-is; the dev 'default' row is left untouched.
INSERT IGNORE INTO `screen_calculation_profiles` (`code`, `version`, `label`, `description`, `motorTorqueMultiplier`, `safetyFactorPct`, `uChannelThreshold`, `maxDropFt`, `maxWidthFt`, `manufacturerCode`, `status`, `createdAt`, `updatedAt`) VALUES ('default-v1', 1, 'Default Profile v1', 'Standard calculation profile used in production', 1.15, 15, 0.750, 20.0, 16.0, NULL, 'active', '2025-01-01 00:00:00', '2025-01-01 00:00:00');

-- ============================================================
-- End of seed SQL
-- Verify with:
--   SELECT COUNT(*) FROM screen_manufacturers;   -- expect >= 6
--   SELECT COUNT(*) FROM screen_motor_types;     -- expect >= 12
--   SELECT COUNT(*) FROM screen_remote_types;    -- expect >= 13
--   SELECT code, version, status FROM screen_calculation_profiles;
-- ============================================================
