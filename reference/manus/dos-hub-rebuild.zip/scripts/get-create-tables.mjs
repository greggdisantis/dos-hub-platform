/**
 * Read-only: retrieve SHOW CREATE TABLE for the 13 tables missing from dos_hub_prod
 * Uses GATEWAY01_URL (dos_hub_dev database)
 */
import mysql from "mysql2/promise";
import { writeFileSync } from "fs";

const BASE_URL = process.env.GATEWAY01_URL;
if (!BASE_URL) { console.error("GATEWAY01_URL not set"); process.exit(1); }

const MISSING_TABLES = [
  "aquaclean_receipts",
  "audit_logs",
  "companies",
  "module_permissions",
  "notifications",
  "order_revisions",
  "preconstruction_checklists",
  "project_material_checklists",
  "receipts",
  "screen_orders",
  "time_off_policies",
  "time_off_requests",
  "zoning_lookups",
];

function parseUrl(urlStr, dbName) {
  const u = new URL(urlStr);
  return {
    host: u.hostname, port: parseInt(u.port) || 4000,
    user: decodeURIComponent(u.username),
    password: decodeURIComponent(u.password),
    database: dbName,
    ssl: { rejectUnauthorized: true },
    connectTimeout: 15000,
  };
}

async function main() {
  const conn = await mysql.createConnection(parseUrl(BASE_URL, "dos_hub_dev"));
  console.log("Connected to dos_hub_dev");

  const results = {};
  for (const tbl of MISSING_TABLES) {
    const [[row]] = await conn.query(`SHOW CREATE TABLE \`${tbl}\``);
    const createSql = row["Create Table"];
    results[tbl] = createSql;
    console.log(`  ✓ Got CREATE TABLE for ${tbl}`);
  }

  await conn.end();
  writeFileSync("/tmp/create-tables.json", JSON.stringify(results, null, 2));
  console.log("\nWritten to /tmp/create-tables.json");
}

main().catch(e => { console.error(e.message); process.exit(1); });
