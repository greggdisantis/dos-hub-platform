/**
 * Gateway01 Read-Only Forensic Inspection Script
 * Tries multiple SSL configurations to find the working one.
 * Password never printed or logged.
 */
import mysql from "mysql2/promise";
import { writeFileSync } from "fs";

const BASE_URL = process.env.GATEWAY01_URL;
if (!BASE_URL) {
  console.error("ERROR: GATEWAY01_URL environment variable is not set.");
  process.exit(1);
}

function parseBase(urlStr) {
  const u = new URL(urlStr);
  return {
    host: u.hostname,
    port: parseInt(u.port) || 4000,
    user: decodeURIComponent(u.username),
    password: decodeURIComponent(u.password),
  };
}

const SSL_VARIANTS = [
  { label: "ssl=rejectUnauthorized:true", ssl: { rejectUnauthorized: true } },
  { label: "ssl=rejectUnauthorized:false", ssl: { rejectUnauthorized: false } },
  { label: "ssl=true", ssl: true },
  { label: "no ssl", ssl: undefined },
];

const TABLES_TO_COUNT = [
  "users",
  "cmr_reports",
  "projects",
  "cmr_line_items",
  "screen_measurement_headers",
  "screen_measurement_lines",
];

const DATABASES = ["dos_hub_dev", "dos_hub_prod", "test"];

async function tryConnect(base, dbName, sslConfig) {
  const config = {
    ...base,
    database: dbName,
    connectTimeout: 12000,
  };
  if (sslConfig !== undefined) {
    config.ssl = sslConfig;
  }

  const conn = await mysql.createConnection(config);
  return conn;
}

async function inspectDatabase(base, dbName, workingSsl) {
  const result = {
    database: dbName,
    connection_status: null,
    error: null,
    ssl_variant: workingSsl.label,
    current_database: null,
    current_user: null,
    tables: [],
    counts: {},
  };

  let conn;
  try {
    conn = await tryConnect(base, dbName, workingSsl.ssl);
    result.connection_status = "CONNECTED";

    const [[dbRow]] = await conn.query("SELECT DATABASE() AS d");
    result.current_database = dbRow.d;

    const [[userRow]] = await conn.query("SELECT CURRENT_USER() AS u");
    result.current_user = userRow.u;

    const [tableRows] = await conn.query("SHOW TABLES");
    result.tables = tableRows.map((r) => Object.values(r)[0]);

    for (const tbl of TABLES_TO_COUNT) {
      if (result.tables.includes(tbl)) {
        try {
          const [[countRow]] = await conn.query(
            `SELECT COUNT(*) AS cnt FROM \`${tbl}\``
          );
          result.counts[tbl] = Number(countRow.cnt);
        } catch (e) {
          result.counts[tbl] = `ERROR: ${e.message}`;
        }
      } else {
        result.counts[tbl] = "TABLE NOT FOUND";
      }
    }
  } catch (e) {
    result.connection_status = "FAILED";
    result.error = e.message;
  } finally {
    if (conn) {
      try { await conn.end(); } catch (_) {}
    }
  }

  return result;
}

async function findWorkingSsl(base) {
  for (const variant of SSL_VARIANTS) {
    console.log(`  Testing SSL variant: ${variant.label}...`);
    try {
      const conn = await tryConnect(base, "test", variant.ssl);
      const [[r]] = await conn.query("SELECT 1 AS ok");
      await conn.end();
      if (r.ok === 1) {
        console.log(`  ✓ Working SSL variant: ${variant.label}`);
        return variant;
      }
    } catch (e) {
      const ipMatch = e.message.match(/@'([^']+)'/);
      const blockedIp = ipMatch ? ipMatch[1] : "unknown";
      console.log(`  ✗ ${variant.label}: ${e.code || e.message.slice(0, 60)} (TiDB sees IP: ${blockedIp})`);
    }
  }
  return null;
}

async function main() {
  const base = parseBase(BASE_URL);
  console.log(`\nGateway01 Read-Only Forensic Inspection`);
  console.log(`Host: ${base.host}:${base.port}`);
  console.log(`User: ${base.user}`);
  console.log(`\nStep 1: Finding working SSL configuration...`);

  const workingSsl = await findWorkingSsl(base);

  if (!workingSsl) {
    console.error("\nAll SSL variants failed. Cannot connect to gateway01.");
    const output = {
      inspection_timestamp: new Date().toISOString(),
      connection_test: "ALL_VARIANTS_FAILED",
      results: DATABASES.map(db => ({
        database: db,
        connection_status: "FAILED",
        error: "All SSL variants rejected — IP may still be blocked or credentials invalid",
      })),
    };
    writeFileSync("/tmp/gateway01-inspect.json", JSON.stringify(output, null, 2));
    console.log("Results written to /tmp/gateway01-inspect.json");
    return;
  }

  console.log(`\nStep 2: Inspecting all databases with ${workingSsl.label}...`);
  const results = [];

  for (const db of DATABASES) {
    process.stdout.write(`  Inspecting ${db}... `);
    const r = await inspectDatabase(base, db, workingSsl);
    results.push(r);
    if (r.connection_status === "CONNECTED") {
      console.log(`✓ | Tables: ${r.tables.length} | users: ${r.counts.users} | cmr_reports: ${r.counts.cmr_reports}`);
    } else {
      console.log(`✗ ${r.error}`);
    }
  }

  const output = {
    inspection_timestamp: new Date().toISOString(),
    working_ssl_variant: workingSsl.label,
    results,
  };

  writeFileSync("/tmp/gateway01-inspect.json", JSON.stringify(output, null, 2));
  console.log("\nResults written to /tmp/gateway01-inspect.json");
}

main().catch((e) => {
  console.error("Fatal:", e.message);
  process.exit(1);
});
