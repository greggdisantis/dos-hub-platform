/**
 * seed-dev-reference-data.mjs
 * Copies reference data from dos_hub_prod → dos_hub_dev using INSERT IGNORE.
 * Safe to re-run: existing rows are skipped.
 * Does NOT modify dos_hub_prod.
 */

import mysql from "mysql2/promise";

const DEV_URL = process.env.DATABASE_URL_DEV;
const PROD_URL = DEV_URL?.replace(/\/dos_hub_dev(\?|$)/, "/dos_hub_prod$1");

if (!DEV_URL) {
  console.error("ERROR: DATABASE_URL_DEV is not set");
  process.exit(1);
}

if (!PROD_URL || PROD_URL === DEV_URL) {
  console.error("ERROR: Could not derive prod URL from DATABASE_URL_DEV");
  process.exit(1);
}

console.log("Prod DB:", PROD_URL.replace(/:([^:@]+)@/, ":***@"));
console.log("Dev DB: ", DEV_URL.replace(/:([^:@]+)@/, ":***@"));
console.log("");

function parseUrl(url) {
  const u = new URL(url);
  return {
    host: u.hostname,
    port: parseInt(u.port || "3306"),
    user: decodeURIComponent(u.username),
    password: decodeURIComponent(u.password),
    database: u.pathname.replace(/^\//, ""),
    ssl: { rejectUnauthorized: true },
    connectTimeout: 15000,
  };
}

const prod = await mysql.createConnection(parseUrl(PROD_URL));
const dev  = await mysql.createConnection(parseUrl(DEV_URL));

const TABLES = [
  "screen_manufacturers",
  "screen_motor_types",
  "screen_remote_types",
  "screen_calculation_profiles",
];

for (const table of TABLES) {
  // Count prod rows
  const [prodRows] = await prod.query(`SELECT * FROM ${table}`);
  console.log(`[${table}] Prod has ${prodRows.length} rows`);

  if (prodRows.length === 0) {
    console.log(`[${table}] Nothing to seed — skipping\n`);
    continue;
  }

  let inserted = 0;
  let skipped = 0;

  for (const row of prodRows) {
    const cols = Object.keys(row);
    const placeholders = cols.map(() => "?").join(", ");
    const values = cols.map((c) => row[c]);
    const sql = `INSERT IGNORE INTO ${table} (${cols.map(c => `\`${c}\``).join(", ")}) VALUES (${placeholders})`;

    try {
      const [result] = await dev.execute(sql, values);
      if (result.affectedRows > 0) {
        inserted++;
      } else {
        skipped++;
      }
    } catch (err) {
      console.error(`  ERROR on row:`, row);
      console.error(`  SQL: ${sql}`);
      console.error(`  Error:`, err.message);
    }
  }

  console.log(`[${table}] Inserted: ${inserted}, Skipped (already exists): ${skipped}\n`);
}

await prod.end();
await dev.end();
console.log("Done. dos_hub_dev reference data is now aligned to dos_hub_prod.");
