/**
 * Read-only row count script for the SOURCE database (DATABASE_URL_DEV).
 * Uses the same mysql2 driver as the app. Makes NO writes.
 */
import mysql from "mysql2/promise";
import * as dotenv from "dotenv";
import { fileURLToPath } from "url";
import path from "path";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: path.join(__dirname, "../.env") });

const TABLES = [
  "users",
  "companies",
  "module_permissions",
  "projects",
  "cmr_reports",
  "cmr_line_items",
  "screen_orders",
  "order_revisions",
  "receipts",
  "aquaclean_receipts",
  "project_material_checklists",
  "notifications",
  "preconstruction_checklists",
  "zoning_lookups",
  "time_off_policies",
  "time_off_requests",
  "screen_calculation_profiles",
  "screen_manufacturers",
  "screen_measurement_headers",
  "screen_measurement_lines",
  "screen_measurement_attachments",
  "screen_measurement_line_attachments",
];

async function main() {
  const url = process.env.DATABASE_URL_DEV;
  if (!url) { console.error("DATABASE_URL_DEV not set"); process.exit(1); }

  const u = new URL(url);
  process.stderr.write(`Connecting to SOURCE: ${u.hostname} / ${u.pathname.replace(/^\//,'')}\n`);

  const conn = await mysql.createConnection({
    uri: url,
    ssl: { rejectUnauthorized: false },
    connectTimeout: 15000,
  });

  const results = {};
  for (const table of TABLES) {
    try {
      const [[{ cnt }]] = await conn.execute(`SELECT COUNT(*) AS cnt FROM \`${table}\``);
      results[table] = { exists: true, rowCount: Number(cnt) };
    } catch (e) {
      if (e.code === "ER_NO_SUCH_TABLE") {
        results[table] = { exists: false, rowCount: null };
      } else {
        results[table] = { exists: null, error: e.message };
      }
    }
  }

  await conn.end();
  console.log(JSON.stringify(results, null, 2));
}

main().catch(e => { console.error(e); process.exit(1); });
