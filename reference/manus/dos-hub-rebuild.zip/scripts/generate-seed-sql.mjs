/**
 * generate-seed-sql.mjs
 * Reads reference data from dos_hub_prod and outputs INSERT IGNORE SQL
 * targeting dos_hub_dev. Safe — read-only on prod.
 */

import mysql from "mysql2/promise";
import { writeFileSync } from "fs";

const DEV_URL = process.env.DATABASE_URL_DEV;
const PROD_URL = DEV_URL?.replace(/\/dos_hub_dev(\?|$)/, "/dos_hub_prod$1");

if (!DEV_URL || !PROD_URL) {
  console.error("ERROR: DATABASE_URL_DEV is not set");
  process.exit(1);
}

function parseUrl(url) {
  const u = new URL(url);
  return {
    host: u.hostname,
    port: parseInt(u.port || "3306"),
    user: decodeURIComponent(u.username),
    password: decodeURIComponent(u.password),
    database: u.pathname.replace(/^\//, ""),
    ssl: { rejectUnauthorized: true },
    connectTimeout: 15000,
  };
}

function escapeValue(val) {
  if (val === null || val === undefined) return "NULL";
  if (typeof val === "number") return String(val);
  if (typeof val === "boolean") return val ? "1" : "0";
  if (val instanceof Date) return `'${val.toISOString().slice(0, 19).replace("T", " ")}'`;
  if (typeof val === "object") return `'${JSON.stringify(val).replace(/'/g, "\\'")}'`;
  // string
  return `'${String(val).replace(/\\/g, "\\\\").replace(/'/g, "\\'")}'`;
}

const prod = await mysql.createConnection(parseUrl(PROD_URL));

const TABLES = [
  "screen_manufacturers",
  "screen_motor_types",
  "screen_remote_types",
  "screen_calculation_profiles",
];

const lines = [];
lines.push("-- ============================================================");
lines.push("-- DOS Hub Dev Seed SQL");
lines.push("-- Target: dos_hub_dev ONLY");
lines.push("-- Source: dos_hub_prod (read-only)");
lines.push("-- Generated: " + new Date().toISOString());
lines.push("-- Safe: INSERT IGNORE only — no drops, no deletes, no schema changes");
lines.push("-- ============================================================");
lines.push("");
lines.push("USE dos_hub_dev;");
lines.push("");

for (const table of TABLES) {
  const [rows] = await prod.query(`SELECT * FROM ${table}`);
  lines.push(`-- ── ${table} (${rows.length} rows from prod) ──`);

  if (rows.length === 0) {
    lines.push(`-- (no rows in prod — nothing to insert)`);
    lines.push("");
    continue;
  }

  const cols = Object.keys(rows[0]);
  const colList = cols.map(c => `\`${c}\``).join(", ");

  for (const row of rows) {
    const vals = cols.map(c => escapeValue(row[c])).join(", ");
    lines.push(`INSERT IGNORE INTO \`${table}\` (${colList}) VALUES (${vals});`);
  }
  lines.push("");
}

await prod.end();

const sql = lines.join("\n");
const outPath = "/home/ubuntu/dos-hub-rebuild/scripts/seed-dev-reference-data.sql";
writeFileSync(outPath, sql, "utf8");

console.log("SQL written to:", outPath);
console.log("Row counts:");
for (const table of TABLES) {
  const match = sql.match(new RegExp(`-- ── ${table} \\((\\d+) rows`, ""));
  if (match) console.log(`  ${table}: ${match[1]} rows`);
}
