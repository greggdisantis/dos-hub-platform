/**
 * Phase 4 — Development Separation Verification
 * Confirms DATABASE_URL_DEV points to dos_hub_dev and connection succeeds.
 * Read-only. No changes.
 */
import mysql from "mysql2/promise";

async function main() {
  const devUrl = process.env.DATABASE_URL_DEV;
  if (!devUrl) {
    console.error("FAIL: DATABASE_URL_DEV is not set");
    process.exit(1);
  }

  const u = new URL(devUrl);
  console.log("=== Phase 4 — Development Separation Verification ===\n");
  console.log("DATABASE_URL_DEV host:    ", u.hostname);
  console.log("DATABASE_URL_DEV database:", u.pathname.replace("/", ""));
  console.log("");

  const conn = await mysql.createConnection({
    host: u.hostname,
    port: parseInt(u.port) || 4000,
    user: decodeURIComponent(u.username),
    password: decodeURIComponent(u.password),
    database: u.pathname.replace("/", ""),
    ssl: { rejectUnauthorized: true },
    connectTimeout: 15000,
  });

  const [[dbRow]] = await conn.query("SELECT DATABASE() AS db");
  const [[userRow]] = await conn.query("SELECT COUNT(*) AS cnt FROM users");
  const [tables] = await conn.query("SHOW TABLES");
  await conn.end();

  const db = dbRow.db;
  const userCount = Number(userRow.cnt);
  const tableCount = tables.length;

  console.log("Connected database:   ", db);
  console.log("users row count:      ", userCount);
  console.log("Table count:          ", tableCount);
  console.log("");

  const dbOk = db === "dos_hub_dev";
  const notProd = !devUrl.includes("dos_hub_prod");
  const notGw4 = !devUrl.includes("gateway04");

  console.log("CHECK: database = dos_hub_dev  →", dbOk ? "✓ PASS" : "✗ FAIL (got: " + db + ")");
  console.log("CHECK: not dos_hub_prod        →", notProd ? "✓ PASS" : "✗ FAIL");
  console.log("CHECK: not gateway04           →", notGw4 ? "✓ PASS" : "✗ FAIL");
  console.log("CHECK: table count = 25        →", tableCount === 25 ? "✓ PASS" : `⚠ INFO (got ${tableCount})`);
  console.log("");

  if (dbOk && notProd && notGw4) {
    console.log("✓ DEVELOPMENT SEPARATION COMPLETE");
    console.log("  Dev server → dos_hub_dev on gateway01");
    console.log("  Production → dos_hub_prod on gateway01 (unchanged)");
    console.log("  gateway04  → legacy/frozen (not referenced)");
  } else {
    console.error("✗ SEPARATION FAILED — check DATABASE_URL_DEV value");
    process.exit(1);
  }
}

main().catch((e) => {
  console.error("FATAL:", e.message);
  process.exit(1);
});
