/**
 * Read-only forensic inspection of gateway01.
 * Attempts to connect using the DATABASE_URL_DEV credentials
 * and probes three database names: test, dos_hub_dev, dos_hub_prod.
 * Makes NO writes of any kind.
 */
import mysql from "mysql2/promise";

const DATABASE_URL_DEV = process.env.DATABASE_URL_DEV;

if (!DATABASE_URL_DEV) {
  console.log(JSON.stringify({ error: "DATABASE_URL_DEV not set" }));
  process.exit(0);
}

const parsed = new URL(DATABASE_URL_DEV);
const baseConfig = {
  host: parsed.hostname,
  port: Number(parsed.port) || 4000,
  user: parsed.username,
  password: decodeURIComponent(parsed.password),
  ssl: { rejectUnauthorized: false },
  connectTimeout: 15000,
};

const configuredDb = decodeURIComponent(parsed.pathname.replace(/^\//, ""));

async function probeDatabase(dbName) {
  let conn;
  try {
    conn = await mysql.createConnection({ ...baseConfig, database: dbName });
  } catch (e) {
    return {
      database: dbName,
      connection_status: "FAILED",
      error: e.message,
    };
  }

  const result = {
    database: dbName,
    connection_status: "SUCCESS",
    current_database: null,
    current_user: null,
    tables: [],
    counts: {},
  };

  try {
    const [[row]] = await conn.execute("SELECT DATABASE() AS db, CURRENT_USER() AS usr");
    result.current_database = row.db;
    result.current_user = row.usr;
  } catch (e) {
    result.current_database = `ERROR: ${e.message.substring(0, 60)}`;
  }

  try {
    const [rows] = await conn.execute("SHOW TABLES");
    result.tables = rows.map(r => Object.values(r)[0]);
  } catch (e) {
    result.tables = `ERROR: ${e.message.substring(0, 60)}`;
  }

  const tablesToCount = [
    "users", "cmr_reports", "projects",
    "cmr_line_items", "screen_measurement_headers", "screen_measurement_lines"
  ];

  for (const tbl of tablesToCount) {
    try {
      const [[{ cnt }]] = await conn.execute(`SELECT COUNT(*) AS cnt FROM \`${tbl}\``);
      result.counts[tbl] = Number(cnt);
    } catch (e) {
      if (e.message.includes("doesn't exist") || e.message.includes("ER_NO_SUCH_TABLE")) {
        result.counts[tbl] = "TABLE_NOT_FOUND";
      } else {
        result.counts[tbl] = `ERROR: ${e.message.substring(0, 60)}`;
      }
    }
  }

  await conn.end();
  return result;
}

async function main() {
  const output = {
    host: parsed.hostname,
    port: baseConfig.port,
    user: parsed.username,
    configured_database: configuredDb,
    probes: [],
  };

  // First try the configured database (test)
  process.stderr.write(`Probing gateway01 / ${configuredDb}...\n`);
  output.probes.push(await probeDatabase(configuredDb));

  // Try dos_hub_dev
  if (configuredDb !== "dos_hub_dev") {
    process.stderr.write(`Probing gateway01 / dos_hub_dev...\n`);
    output.probes.push(await probeDatabase("dos_hub_dev"));
  }

  // Try dos_hub_prod
  if (configuredDb !== "dos_hub_prod") {
    process.stderr.write(`Probing gateway01 / dos_hub_prod...\n`);
    output.probes.push(await probeDatabase("dos_hub_prod"));
  }

  console.log(JSON.stringify(output, null, 2));
}

main().catch(e => {
  console.log(JSON.stringify({ fatal_error: e.message }));
  process.exit(0);
});
