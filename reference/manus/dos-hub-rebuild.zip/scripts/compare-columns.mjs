/**
 * Read-only: compare column schemas between gateway04 and dos_hub_prod
 * for all shared tables to detect any mismatches before data copy.
 */
import mysql from "mysql2/promise";

async function getColumns(conn, tbl) {
  const [rows] = await conn.query(`SHOW COLUMNS FROM \`${tbl}\``);
  return rows.map((r) => r.Field);
}

function parseUrl(urlStr, dbOverride) {
  const u = new URL(urlStr);
  return {
    host: u.hostname,
    port: parseInt(u.port) || 4000,
    user: decodeURIComponent(u.username),
    password: decodeURIComponent(u.password),
    database: dbOverride || u.pathname.replace(/^\//, ""),
    ssl: { rejectUnauthorized: true },
    connectTimeout: 12000,
  };
}

const SHARED_TABLES = [
  "users",
  "cmr_reports",
  "projects",
  "screen_calculation_profiles",
  "screen_manufacturers",
  "screen_measurement_headers",
  "screen_measurement_lines",
  "screen_measurement_attachments",
  "screen_measurement_line_attachments",
  "screen_motor_types",
  "screen_remote_types",
];

async function main() {
  const gw4 = await mysql.createConnection(parseUrl(process.env.DATABASE_URL));
  const gw1 = await mysql.createConnection(
    parseUrl(process.env.GATEWAY01_URL, "dos_hub_prod")
  );

  console.log("Comparing column schemas: gateway04 vs dos_hub_prod\n");
  console.log("TABLE".padEnd(45) + "GW4_COLS  PROD_COLS  STATUS");
  console.log("-".repeat(80));

  let allMatch = true;
  const mismatches = [];

  for (const tbl of SHARED_TABLES) {
    const g4cols = await getColumns(gw4, tbl);
    const g1cols = await getColumns(gw1, tbl);
    const g4set = new Set(g4cols);
    const g1set = new Set(g1cols);
    const missingInProd = g4cols.filter((c) => !g1set.has(c));
    const extraInProd = g1cols.filter((c) => !g4set.has(c));
    const match = missingInProd.length === 0 && extraInProd.length === 0;

    const status = match ? "✓ MATCH" : "✗ MISMATCH";
    console.log(
      tbl.padEnd(45) +
        String(g4cols.length).padEnd(10) +
        String(g1cols.length).padEnd(11) +
        status
    );

    if (!match) {
      allMatch = false;
      mismatches.push({ table: tbl, missingInProd, extraInProd });
      if (missingInProd.length > 0)
        console.log(`  → Missing in dos_hub_prod: ${missingInProd.join(", ")}`);
      if (extraInProd.length > 0)
        console.log(`  → Extra in dos_hub_prod: ${extraInProd.join(", ")}`);
    }
  }

  console.log("-".repeat(80));
  if (allMatch) {
    console.log("\n✓ All shared tables have identical column schemas.");
    console.log("  Safe to INSERT data directly — no column remapping needed.");
  } else {
    console.log("\n✗ Schema mismatches detected. Review before copying data.");
  }

  await gw4.end();
  await gw1.end();
}

main().catch((e) => {
  console.error("Fatal:", e.message);
  process.exit(1);
});
