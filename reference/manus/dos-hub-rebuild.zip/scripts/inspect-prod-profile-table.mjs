/**
 * inspect-prod-profile-table.mjs
 * Read-only: fetches SHOW CREATE TABLE and column info from dos_hub_prod.
 * No writes. No changes.
 */
import mysql from "mysql2/promise";

const DEV_URL = process.env.DATABASE_URL_DEV;
if (!DEV_URL) { console.error("DATABASE_URL_DEV not set"); process.exit(1); }

const PROD_URL = DEV_URL.replace(/\/dos_hub_dev(\?|$)/, "/dos_hub_prod$1");

function parseUrl(url) {
  const u = new URL(url);
  return {
    host: u.hostname,
    port: parseInt(u.port || "3306"),
    user: decodeURIComponent(u.username),
    password: decodeURIComponent(u.password),
    database: u.pathname.replace(/^\//, ""),
    ssl: { rejectUnauthorized: true },
    connectTimeout: 15000,
  };
}

const conn = await mysql.createConnection(parseUrl(PROD_URL));

console.log("=== SHOW CREATE TABLE ===");
const [createRows] = await conn.query("SHOW CREATE TABLE `screen_calculation_profiles`");
console.log(createRows[0]["Create Table"]);

console.log("\n=== SHOW INDEXES ===");
const [indexRows] = await conn.query("SHOW INDEX FROM `screen_calculation_profiles`");
for (const r of indexRows) {
  console.log(`Key: ${r.Key_name} | Column: ${r.Column_name} | Unique: ${r.Non_unique === 0 ? "YES" : "NO"} | Seq: ${r.Seq_in_index}`);
}

await conn.end();
