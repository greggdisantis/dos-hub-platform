/**
 * Read-only schema diff: dos_hub_dev vs dos_hub_prod
 * Compares: tables, columns (type/nullable/default/extra), indexes, enums
 * No writes. No changes. Inspection only.
 */
import mysql from "mysql2/promise";
import { writeFileSync } from "fs";

function parseUrl(urlStr, dbOverride) {
  const u = new URL(urlStr);
  return {
    host: u.hostname,
    port: parseInt(u.port) || 4000,
    user: decodeURIComponent(u.username),
    password: decodeURIComponent(u.password),
    database: dbOverride || u.pathname.replace(/^\//, ""),
    ssl: { rejectUnauthorized: true },
    connectTimeout: 15000,
  };
}

async function getTables(conn) {
  const [rows] = await conn.query("SHOW TABLES");
  return rows.map((r) => Object.values(r)[0]);
}

async function getColumns(conn, db, table) {
  const [rows] = await conn.query(
    `SELECT COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE, COLUMN_DEFAULT, EXTRA, COLUMN_COMMENT
     FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
     ORDER BY ORDINAL_POSITION`,
    [db, table]
  );
  return rows;
}

async function getIndexes(conn, db, table) {
  const [rows] = await conn.query(
    `SELECT INDEX_NAME, NON_UNIQUE, SEQ_IN_INDEX, COLUMN_NAME, INDEX_TYPE
     FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?
     ORDER BY INDEX_NAME, SEQ_IN_INDEX`,
    [db, table]
  );
  return rows;
}

function colKey(col) {
  return `${col.COLUMN_TYPE}|${col.IS_NULLABLE}|${col.COLUMN_DEFAULT ?? "NULL"}|${col.EXTRA}`;
}

function indexSig(idxRows) {
  const map = {};
  for (const r of idxRows) {
    if (!map[r.INDEX_NAME]) map[r.INDEX_NAME] = { unique: !r.NON_UNIQUE, cols: [], type: r.INDEX_TYPE };
    map[r.INDEX_NAME].cols.push(r.COLUMN_NAME);
  }
  return map;
}

async function main() {
  const devConn = await mysql.createConnection(
    parseUrl(process.env.GATEWAY01_DEV_URL, "dos_hub_dev")
  );
  const prodConn = await mysql.createConnection(
    parseUrl(process.env.GATEWAY01_DEV_URL, "dos_hub_prod")
  );

  const devTables = new Set(await getTables(devConn));
  const prodTables = new Set(await getTables(prodConn));

  const result = {
    devOnly: [],
    prodOnly: [],
    shared: [],
  };

  // Tables only in dev
  for (const t of devTables) {
    if (!prodTables.has(t)) result.devOnly.push(t);
  }

  // Tables only in prod
  for (const t of prodTables) {
    if (!devTables.has(t)) result.prodOnly.push(t);
  }

  // Shared tables — column + index diff
  for (const t of devTables) {
    if (!prodTables.has(t)) continue;

    const devCols = await getColumns(devConn, "dos_hub_dev", t);
    const prodCols = await getColumns(prodConn, "dos_hub_prod", t);

    const devColMap = Object.fromEntries(devCols.map((c) => [c.COLUMN_NAME, c]));
    const prodColMap = Object.fromEntries(prodCols.map((c) => [c.COLUMN_NAME, c]));

    const colDiffs = [];

    // Columns in dev but not prod
    for (const col of Object.keys(devColMap)) {
      if (!prodColMap[col]) {
        colDiffs.push({ type: "dev_only_column", column: col, devDef: devColMap[col] });
      }
    }

    // Columns in prod but not dev
    for (const col of Object.keys(prodColMap)) {
      if (!devColMap[col]) {
        colDiffs.push({ type: "prod_only_column", column: col, prodDef: prodColMap[col] });
      }
    }

    // Columns in both — check for differences
    for (const col of Object.keys(devColMap)) {
      if (!prodColMap[col]) continue;
      const dk = colKey(devColMap[col]);
      const pk = colKey(prodColMap[col]);
      if (dk !== pk) {
        colDiffs.push({
          type: "column_diff",
          column: col,
          dev: {
            type: devColMap[col].COLUMN_TYPE,
            nullable: devColMap[col].IS_NULLABLE,
            default: devColMap[col].COLUMN_DEFAULT,
            extra: devColMap[col].EXTRA,
          },
          prod: {
            type: prodColMap[col].COLUMN_TYPE,
            nullable: prodColMap[col].IS_NULLABLE,
            default: prodColMap[col].COLUMN_DEFAULT,
            extra: prodColMap[col].EXTRA,
          },
        });
      }
    }

    // Index diff
    const devIdxRows = await getIndexes(devConn, "dos_hub_dev", t);
    const prodIdxRows = await getIndexes(prodConn, "dos_hub_prod", t);
    const devIdx = indexSig(devIdxRows);
    const prodIdx = indexSig(prodIdxRows);

    const idxDiffs = [];
    for (const name of Object.keys(devIdx)) {
      if (!prodIdx[name]) {
        idxDiffs.push({ type: "dev_only_index", name, def: devIdx[name] });
      } else {
        const dc = devIdx[name].cols.join(",");
        const pc = prodIdx[name].cols.join(",");
        if (dc !== pc || devIdx[name].unique !== prodIdx[name].unique) {
          idxDiffs.push({ type: "index_diff", name, dev: devIdx[name], prod: prodIdx[name] });
        }
      }
    }
    for (const name of Object.keys(prodIdx)) {
      if (!devIdx[name]) {
        idxDiffs.push({ type: "prod_only_index", name, def: prodIdx[name] });
      }
    }

    result.shared.push({ table: t, colDiffs, idxDiffs });
  }

  await devConn.end();
  await prodConn.end();

  writeFileSync("/tmp/schema-diff.json", JSON.stringify(result, null, 2));
  console.log("Schema diff written to /tmp/schema-diff.json");
  return result;
}

main()
  .then((r) => {
    console.log("\nDev-only tables:", r.devOnly.length, r.devOnly);
    console.log("Prod-only tables:", r.prodOnly.length, r.prodOnly);
    const withDiffs = r.shared.filter((t) => t.colDiffs.length > 0 || t.idxDiffs.length > 0);
    console.log("Shared tables with diffs:", withDiffs.length);
    for (const t of withDiffs) {
      console.log(`\n  TABLE: ${t.table}`);
      for (const d of t.colDiffs) console.log("    COL:", JSON.stringify(d));
      for (const d of t.idxDiffs) console.log("    IDX:", JSON.stringify(d));
    }
    const clean = r.shared.filter((t) => t.colDiffs.length === 0 && t.idxDiffs.length === 0);
    console.log("\nShared tables with NO diffs:", clean.length, clean.map((t) => t.table));
  })
  .catch((e) => {
    console.error("FATAL:", e.message);
    process.exit(1);
  });
