import mysql from 'mysql2/promise';

const url = new URL(process.env.GATEWAY01_DEV_URL);
const conn = await mysql.createConnection({
  host: url.hostname,
  port: parseInt(url.port) || 4000,
  user: decodeURIComponent(url.username),
  password: decodeURIComponent(url.password),
  database: 'dos_hub_dev',
  ssl: { rejectUnauthorized: true },
  connectTimeout: 15000,
});

console.log('Connected to dos_hub_dev');

// ─── Step 1: Add 3 missing columns to cmr_reports ───────────────────────────
console.log('\n── Step 1: cmr_reports missing columns ──');
const cmrStmts = [
  `ALTER TABLE cmr_reports ADD COLUMN IF NOT EXISTS attendees JSON NULL`,
  `ALTER TABLE cmr_reports ADD COLUMN IF NOT EXISTS notes TEXT NULL`,
  `ALTER TABLE cmr_reports ADD COLUMN IF NOT EXISTS actionItems JSON NULL`,
];

for (const sql of cmrStmts) {
  try {
    await conn.query(sql);
    console.log('  OK:', sql.substring(0, 90));
  } catch (e) {
    console.log('  ERR:', e.message);
  }
}

// ─── Step 2: Align screen_calculation_profiles to match prod ────────────────
// Prod schema:
//   PRIMARY KEY: code (varchar 50)
//   version: int NOT NULL DEFAULT 1
//   code: varchar(50) NOT NULL
//   uChannelThreshold: decimal(6,3)
//   manufacturerCode: varchar(50) NOT NULL
//   status: enum('active','deprecated') NOT NULL DEFAULT 'active'
//   (no id, no name, no description, no isActive)
//
// Dev schema currently has:
//   PRIMARY KEY: id (auto_increment int)
//   code: varchar(64)
//   version: varchar(32) DEFAULT 'v1'
//   uChannelThreshold: decimal(6,4)
//   name, description, isActive (not in prod)
//   no manufacturerCode, no status
//
// Strategy (no DROP COLUMN per rules):
//   1. Add manufacturerCode and status columns if missing
//   2. Modify code to varchar(50)
//   3. Modify version to int NOT NULL DEFAULT 1
//   4. Modify uChannelThreshold to decimal(6,3)
//   5. Add indexes that prod has
//   NOTE: We cannot change PRIMARY KEY without dropping it first.
//         We will add the prod indexes and align column types.
//         The id/name/description/isActive columns remain (no-drop rule).

console.log('\n── Step 2: screen_calculation_profiles alignment ──');

const profileStmts = [
  // Add missing columns
  `ALTER TABLE screen_calculation_profiles
     ADD COLUMN IF NOT EXISTS manufacturerCode VARCHAR(50) NOT NULL DEFAULT ''`,
  `ALTER TABLE screen_calculation_profiles
     ADD COLUMN IF NOT EXISTS status ENUM('active','deprecated') NOT NULL DEFAULT 'active'`,
  // Align column types to match prod
  `ALTER TABLE screen_calculation_profiles
     MODIFY COLUMN code VARCHAR(50) NOT NULL`,
  `ALTER TABLE screen_calculation_profiles
     MODIFY COLUMN uChannelThreshold DECIMAL(6,3) NULL`,
  // version: prod uses int. We need to convert varchar 'v1' -> 1 first, then modify.
  // Safe approach: update existing 'v1' -> '1', then modify type.
  `UPDATE screen_calculation_profiles SET version = '1' WHERE version = 'v1'`,
  `ALTER TABLE screen_calculation_profiles
     MODIFY COLUMN version INT NOT NULL DEFAULT 1`,
  // Add prod indexes (IF NOT EXISTS equivalent — ignore duplicate key errors)
];

for (const sql of profileStmts) {
  try {
    await conn.query(sql);
    console.log('  OK:', sql.trim().substring(0, 90));
  } catch (e) {
    console.log('  ERR:', e.message, '|', sql.trim().substring(0, 60));
  }
}

// Add prod indexes (CREATE INDEX IF NOT EXISTS)
const indexStmts = [
  `CREATE INDEX IF NOT EXISTS idx_profile_manufacturer ON screen_calculation_profiles (manufacturerCode)`,
  `CREATE INDEX IF NOT EXISTS idx_profile_status ON screen_calculation_profiles (status)`,
];
for (const sql of indexStmts) {
  try {
    await conn.query(sql);
    console.log('  OK:', sql.trim().substring(0, 90));
  } catch (e) {
    console.log('  ERR:', e.message);
  }
}

// ─── Verification ────────────────────────────────────────────────────────────
console.log('\n── Verification ──');

const [cmrCols] = await conn.query(
  `SELECT COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE
   FROM information_schema.COLUMNS
   WHERE TABLE_SCHEMA='dos_hub_dev' AND TABLE_NAME='cmr_reports'
   AND COLUMN_NAME IN ('attendees','notes','actionItems')
   ORDER BY COLUMN_NAME`
);
console.log('cmr_reports new columns:');
cmrCols.forEach(c => console.log(`  ${c.COLUMN_NAME}: ${c.COLUMN_TYPE} nullable=${c.IS_NULLABLE}`));

const [profCols] = await conn.query(
  `SELECT COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE, COLUMN_DEFAULT
   FROM information_schema.COLUMNS
   WHERE TABLE_SCHEMA='dos_hub_dev' AND TABLE_NAME='screen_calculation_profiles'
   ORDER BY ORDINAL_POSITION`
);
console.log('screen_calculation_profiles columns:');
profCols.forEach(c => console.log(`  ${c.COLUMN_NAME}: ${c.COLUMN_TYPE} nullable=${c.IS_NULLABLE} default=${c.COLUMN_DEFAULT}`));

const [profIdx] = await conn.query(
  `SELECT INDEX_NAME, GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) AS cols
   FROM information_schema.STATISTICS
   WHERE TABLE_SCHEMA='dos_hub_dev' AND TABLE_NAME='screen_calculation_profiles'
   GROUP BY INDEX_NAME`
);
console.log('screen_calculation_profiles indexes:');
profIdx.forEach(i => console.log(`  ${i.INDEX_NAME}: (${i.cols})`));

await conn.end();
console.log('\nDone.');
