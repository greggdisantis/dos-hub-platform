/**
 * Pre-cutover connection test: gateway01 / dos_hub_prod
 * Verifies: SSL, IP allowlist, credentials, basic queries
 * Read-only. No changes.
 */
import mysql from "mysql2/promise";

async function main() {
  const url = process.env.GATEWAY01_URL;
  if (!url) {
    console.error("FATAL: GATEWAY01_URL is not set");
    process.exit(1);
  }

  const u = new URL(url);
  const config = {
    host: u.hostname,
    port: parseInt(u.port) || 4000,
    user: decodeURIComponent(u.username),
    password: decodeURIComponent(u.password),
    database: "dos_hub_prod",
    ssl: { rejectUnauthorized: true },
    connectTimeout: 15000,
  };

  console.log("=== DOS Hub Production Connection Test ===");
  console.log(`Host:     ${config.host}:${config.port}`);
  console.log(`User:     ${config.user}`);
  console.log(`Database: ${config.database}`);
  console.log(`SSL:      rejectUnauthorized=true`);
  console.log("");

  let conn;
  try {
    const start = Date.now();
    conn = await mysql.createConnection(config);
    const elapsed = Date.now() - start;
    console.log(`✓ CONNECTION ESTABLISHED (${elapsed}ms)`);

    // Test 1: SELECT DATABASE()
    const [[dbRow]] = await conn.query("SELECT DATABASE() AS current_db");
    console.log(`✓ SELECT DATABASE() = ${dbRow.current_db}`);

    // Test 2: SELECT COUNT(*) FROM users
    const [[countRow]] = await conn.query("SELECT COUNT(*) AS cnt FROM users");
    console.log(`✓ SELECT COUNT(*) FROM users = ${countRow.cnt}`);

    // Test 3: Confirm SSL is active
    const [[sslRow]] = await conn.query(
      "SHOW STATUS LIKE 'Ssl_cipher'"
    );
    const cipher = sslRow ? sslRow.Value : "unknown";
    console.log(`✓ SSL cipher: ${cipher || "(none — check TiDB SSL status)"}`);

    console.log("");
    console.log("=== ALL CHECKS PASSED ===");
    console.log("Connection:  PASS");
    console.log("SSL:         PASS");
    console.log("IP Allowlist: PASS (connection succeeded)");
    console.log("Credentials: PASS");
    console.log(`Database:    ${dbRow.current_db}`);
    console.log(`users count: ${countRow.cnt}`);

  } catch (err) {
    console.error(`✗ CONNECTION FAILED: ${err.message}`);
    console.error(`  Error code: ${err.code}`);
    process.exit(1);
  } finally {
    if (conn) await conn.end();
  }
}

main();
