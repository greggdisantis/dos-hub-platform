# CMR Gap Analysis: Original vs Current Rebuilt Version

**Date:** March 9, 2026  
**Status:** Gap Analysis Complete - Ready for Restoration Plan

---

## EXECUTIVE SUMMARY

The current rebuilt CMR is significantly oversimplified compared to the original specification. The original CMR has **50+ fields across 6 sections** with complex workflow logic, while the current version has only **8 fields** in a single flat structure.

**Current Status:** ~15% of original functionality implemented

---

## CURRENT REBUILT CMR SCHEMA

```typescript
cmrReports table fields:
- id (primary key)
- userId (creator)
- projectId (optional link to project)
- clientName
- meetingDate
- attendees (JSON array)
- notes (text)
- actionItems (JSON array with id, description, assignedTo, dueDate, completed)
- dealStatus (varchar)
- purchaseConfidencePct (int)
- estimatedContractValue (decimal)
- status (enum: draft, submitted, approved)
- createdAt, updatedAt
```

**Total Fields in Current Version:** 13 (including metadata)  
**Total Fields in Original Spec:** 50+

---

## MISSING DATABASE FIELDS

### Section 1: Appointment Details (12 fields missing)
| Field | Type | Current | Original | Status |
|-------|------|---------|----------|--------|
| hubspotContactId | varchar | ❌ | ✅ | MISSING |
| address | varchar | ❌ | ✅ | MISSING |
| clientType | enum | ❌ | ✅ | MISSING |
| appointmentDate | date | ❌ | ✅ | MISSING (using meetingDate instead) |
| appointmentType | enum | ❌ | ✅ | MISSING |
| convertedToInPerson | boolean | ❌ | ✅ | MISSING |
| convertedDate | date | ❌ | ✅ | MISSING |
| convertedType | enum | ❌ | ✅ | MISSING |
| leadSources | json array | ❌ | ✅ | MISSING |
| leadSourceOther | varchar | ❌ | ✅ | MISSING |
| projectTypes | json array | ❌ | ✅ | MISSING |
| projectTypeOther | varchar | ❌ | ✅ | MISSING |

### Section 2: Deal Status (6 fields missing)
| Field | Type | Current | Original | Status |
|-------|------|---------|----------|--------|
| dealStatus | enum | ✅ PARTIAL | ✅ | Exists but options may differ |
| followUpDate | date | ❌ | ✅ | MISSING |
| noFollowUpReason | varchar | ❌ | ✅ | MISSING |
| proposalDate | date | ❌ | ✅ | MISSING |
| lostReason | varchar | ❌ | ✅ | MISSING |
| closeTimeline | enum | ❌ | ✅ | MISSING |
| lastConversationSummary | text | ❌ | ✅ | MISSING |

### Section 3: Purchase Confidence (6 fields missing)
| Field | Type | Current | Original | Status |
|-------|------|---------|----------|--------|
| purchaseConfidencePct | int | ✅ | ✅ | EXISTS |
| originalPcPct | int | ❌ | ✅ | MISSING - CRITICAL (locked after first submission) |
| estimatedContractValue | decimal | ✅ | ✅ | EXISTS |
| decisionMakers | varchar | ❌ | ✅ | MISSING |
| mainMotivation | text | ❌ | ✅ | MISSING |
| mainHesitation | text | ❌ | ✅ | MISSING |
| pcNotes | text | ❌ | ✅ | MISSING - REQUIRED |

### Section 4: Value & Objections (8 fields missing)
| Field | Type | Current | Original | Status |
|-------|------|---------|----------|--------|
| financingDiscussed | boolean | ❌ | ✅ | MISSING |
| financingReaction | enum | ❌ | ✅ | MISSING |
| valueCommunicated | json array | ❌ | ✅ | MISSING |
| clientResponse | enum | ❌ | ✅ | MISSING |
| objections | json array | ❌ | ✅ | MISSING |
| objectionOther | varchar | ❌ | ✅ | MISSING |
| objectionNotes | text | ❌ | ✅ | MISSING |

### Section 5: Next Steps & Marketing (8 fields missing)
| Field | Type | Current | Original | Status |
|-------|------|---------|----------|--------|
| nextActions | json array | ❌ | ✅ | MISSING |
| nextFollowUpDate | date | ❌ | ✅ | MISSING |
| leadQuality | enum | ❌ | ✅ | MISSING |
| expectationAlignment | enum | ❌ | ✅ | MISSING |
| messagingReferenced | json array | ❌ | ✅ | MISSING |
| messagingOther | varchar | ❌ | ✅ | MISSING |
| budgetAlignment | enum | ❌ | ✅ | MISSING |
| marketingNotes | text | ❌ | ✅ | MISSING |

### Section 6: Progress Notes (1 field missing)
| Field | Type | Current | Original | Status |
|-------|------|---------|----------|--------|
| progressNotes | json array | ❌ | ✅ | MISSING - CRITICAL |

### Pipeline Tracking (3 fields missing)
| Field | Type | Current | Original | Status |
|-------|------|---------|----------|--------|
| outcome | enum | ❌ | ✅ | MISSING - CRITICAL (open/sold/lost) |
| soldAt | timestamp | ❌ | ✅ | MISSING |
| soldBy | int (userId) | ❌ | ✅ | MISSING |

---

## MISSING WORKFLOW LOGIC

### Critical Workflow Rules NOT Implemented
1. ❌ **First Submission Lock**: `originalPcPct` should be locked after first submission and never change
2. ❌ **PC Editable**: `purchaseConfidencePct` should be editable anytime (current confidence)
3. ❌ **Contract Value Editable**: `estimatedContractValue` should be editable in pipeline view
4. ❌ **Progress Notes**: Should be addable anytime, never deleted
5. ❌ **Status Transitions**: Deal status can be changed anytime
6. ❌ **Outcome Finality**: Once marked 'sold' or 'lost', outcome cannot be changed back to 'open'
7. ❌ **Draft Visibility**: Draft CMRs should only be visible to creator
8. ❌ **Submitted Visibility**: Submitted CMRs should be visible to creator + managers/admins
9. ❌ **Approval Workflow**: Manager/admin approval step not implemented

---

## MISSING UI COMPONENTS

### Form Components
| Component | Current | Original | Status |
|-----------|---------|----------|--------|
| Multi-step wizard (6 steps) | ❌ | ✅ | MISSING |
| Slider for PC % (0-100 in 10% increments) | ❌ | ✅ | MISSING |
| Multi-select checkboxes | ❌ | ✅ | MISSING |
| Conditional field visibility | ❌ | ✅ | MISSING |
| Toggle/switch components | ❌ | ✅ | MISSING |
| Textarea with validation (min 3 sentences) | ❌ | ✅ | MISSING |
| Progress notes editor | ❌ | ✅ | MISSING |
| Auto-save for drafts | ❌ | ✅ | MISSING |

### List Page Components
| Component | Current | Original | Status |
|-----------|---------|----------|--------|
| My / All tabs | ✅ | ✅ | EXISTS |
| Filter by consultant | ❌ | ✅ | MISSING |
| Filter by month | ❌ | ✅ | MISSING |
| Filter by deal status | ✅ PARTIAL | ✅ | EXISTS but limited |
| Filter by lead source | ❌ | ✅ | MISSING |
| Filter by project type | ❌ | ✅ | MISSING |
| Grouping by consultant | ❌ | ✅ | MISSING |
| Grouping by month | ❌ | ✅ | MISSING |
| Sorting options | ❌ | ✅ | MISSING |
| Row actions (edit, delete, export) | ❌ | ✅ | MISSING |
| Create button | ❌ | ✅ | MISSING |

### Detail Page Components
| Component | Current | Original | Status |
|-----------|---------|----------|--------|
| Display all 6 sections | ❌ | ✅ | MISSING |
| Edit button | ❌ | ✅ | MISSING |
| Export to PDF button | ❌ | ✅ | MISSING |
| Progress notes section | ❌ | ✅ | MISSING |
| Back button | ❌ | ✅ | MISSING |
| Delete button | ❌ | ✅ | MISSING |
| Approval controls | ❌ | ✅ | MISSING |

---

## MISSING VALIDATION RULES

### Required Field Validation
| Rule | Current | Original | Status |
|------|---------|----------|--------|
| clientName cannot be empty | ❌ | ✅ | MISSING |
| appointmentDate must be valid | ❌ | ✅ | MISSING |
| appointmentType must be selected | ❌ | ✅ | MISSING |
| dealStatus must be selected | ✅ PARTIAL | ✅ | EXISTS but incomplete |
| purchaseConfidencePct must be 0-100 | ✅ | ✅ | EXISTS |
| pcNotes must be at least 3 sentences | ❌ | ✅ | MISSING |

### Conditional Validation
| Rule | Current | Original | Status |
|------|---------|----------|--------|
| If Phone appointment, convertedDate required if converted | ❌ | ✅ | MISSING |
| If Phone appointment, convertedType required if converted | ❌ | ✅ | MISSING |
| If dealStatus = Lost, lostReason required | ❌ | ✅ | MISSING |
| If marketing lead, leadQuality required | ❌ | ✅ | MISSING |
| If marketing lead, expectationAlignment required | ❌ | ✅ | MISSING |

---

## MISSING FEATURES

### PDF Export
| Feature | Current | Original | Status |
|---------|---------|----------|--------|
| 7-page professional report | ❌ | ✅ | MISSING |
| Company header/footer | ✅ PARTIAL | ✅ | Exists but may need enhancement |
| All sections formatted | ❌ | ✅ | MISSING |
| Currency formatting | ❌ | ✅ | MISSING |
| Date formatting | ❌ | ✅ | MISSING |
| Multi-select display | ❌ | ✅ | MISSING |
| Page numbers and timestamps | ❌ | ✅ | MISSING |

### Reporting & Analytics
| Feature | Current | Original | Status |
|---------|---------|----------|--------|
| Pipeline dashboard | ❌ | ✅ | MISSING |
| Sales funnel view | ❌ | ✅ | MISSING |
| PC distribution chart | ❌ | ✅ | MISSING |
| Deal status breakdown | ❌ | ✅ | MISSING |
| Lead source attribution | ❌ | ✅ | MISSING |

---

## FIELD COUNT COMPARISON

| Category | Current | Original | Gap |
|----------|---------|----------|-----|
| Appointment Details | 2 | 12 | -10 |
| Deal Status | 1 | 7 | -6 |
| Purchase Confidence | 2 | 7 | -5 |
| Value & Objections | 0 | 8 | -8 |
| Next Steps & Marketing | 0 | 8 | -8 |
| Progress Notes | 0 | 1 | -1 |
| Pipeline Tracking | 0 | 3 | -3 |
| **TOTAL** | **13** | **50+** | **-37+** |

---

## RESTORATION PRIORITY

### Phase 1: Critical (Must restore first)
1. ✅ Add `originalPcPct` field (locked after first submission)
2. ✅ Add `outcome` field (open/sold/lost pipeline tracking)
3. ✅ Add `progressNotes` field (timestamped notes)
4. ✅ Add appointment details section (appointmentDate, appointmentType, etc.)
5. ✅ Add deal status fields (followUpDate, lostReason, etc.)
6. ✅ Implement first submission lock workflow

### Phase 2: Important (Restore next)
7. ✅ Add value & objections section (financing, objections, etc.)
8. ✅ Add next steps & marketing section (nextActions, leadQuality, etc.)
9. ✅ Add multi-select field support (leadSources, projectTypes, etc.)
10. ✅ Implement conditional field visibility
11. ✅ Build multi-step wizard form

### Phase 3: Enhancement (Restore after core)
12. ✅ Add progress notes UI
13. ✅ Add filters and grouping to list page
14. ✅ Enhance PDF export to include all sections
15. ✅ Add sorting and row actions
16. ✅ Add approval workflow UI

---

## RESTORATION PLAN

### Step 1: Database Schema Update
Add 37+ missing fields to `cmr_reports` table in this order:

**Appointment Details:**
- hubspotContactId, address, clientType
- appointmentDate, appointmentType
- convertedToInPerson, convertedDate, convertedType
- leadSources (JSON), leadSourceOther
- projectTypes (JSON), projectTypeOther

**Deal Status:**
- followUpDate, noFollowUpReason
- proposalDate, lostReason
- closeTimeline, lastConversationSummary

**Purchase Confidence:**
- originalPcPct (locked after first submission)
- decisionMakers, mainMotivation, mainHesitation
- pcNotes (required, min 3 sentences)

**Value & Objections:**
- financingDiscussed, financingReaction
- valueCommunicated (JSON), clientResponse
- objections (JSON), objectionOther, objectionNotes

**Next Steps & Marketing:**
- nextActions (JSON), nextFollowUpDate
- leadQuality, expectationAlignment
- messagingReferenced (JSON), messagingOther
- budgetAlignment, marketingNotes

**Progress Notes & Pipeline:**
- progressNotes (JSON array with id, text, createdAt)
- outcome (enum: open/sold/lost)
- soldAt, soldBy

### Step 2: Backend API Updates
- Add new database query functions for all fields
- Implement originalPcPct locking logic
- Implement outcome finality logic
- Add progress note creation endpoint
- Add validation for all required fields
- Implement conditional field validation

### Step 3: Frontend Form Restoration
- Build 6-step wizard form
- Add all field types (text, date, dropdown, multi-select, slider, switch)
- Implement conditional field visibility
- Add validation error messages
- Add auto-save for drafts
- Add progress notes editor

### Step 4: Frontend List Page Enhancement
- Add filters (consultant, month, deal status, lead source, project type)
- Add grouping (by consultant, by month)
- Add sorting options
- Add row actions (edit, delete, export)
- Add create button

### Step 5: Frontend Detail Page
- Display all 6 sections
- Add edit button
- Add export to PDF button
- Add progress notes section
- Add delete button (if owner/admin)
- Add approval controls

### Step 6: PDF Export Enhancement
- Update to include all 6 sections
- Add currency and date formatting
- Add multi-select display
- Add page numbers and timestamps

---

## IMPLEMENTATION CHECKLIST

### Database
- [ ] Add all 37+ missing fields to cmr_reports table
- [ ] Create migration SQL
- [ ] Add indexes on frequently filtered fields
- [ ] Test JSON field storage for arrays
- [ ] Verify existing data compatibility

### Backend API
- [ ] Add new database query functions
- [ ] Implement originalPcPct locking logic
- [ ] Implement outcome finality logic
- [ ] Add progress note creation
- [ ] Add validation for all required fields
- [ ] Implement conditional validation
- [ ] Update PDF generation

### Frontend - Form
- [ ] Create 6-step wizard
- [ ] Add all field types
- [ ] Implement conditional visibility
- [ ] Add validation
- [ ] Add auto-save
- [ ] Add progress notes editor

### Frontend - List Page
- [ ] Add filters
- [ ] Add grouping
- [ ] Add sorting
- [ ] Add row actions
- [ ] Add create button

### Frontend - Detail Page
- [ ] Display all sections
- [ ] Add edit button
- [ ] Add export button
- [ ] Add progress notes
- [ ] Add delete button
- [ ] Add approval controls

### Testing
- [ ] Test all field types
- [ ] Test validation rules
- [ ] Test workflow logic
- [ ] Test PDF export
- [ ] Test list filtering/sorting
- [ ] Test form wizard
- [ ] Test originalPcPct locking
- [ ] Test outcome finality

---

## NEXT STEPS

1. **Approve Restoration Plan** - Confirm this gap analysis is accurate
2. **Create Database Migration** - Add all 37+ missing fields
3. **Update Backend** - Implement new query functions and validation
4. **Restore Form UI** - Build 6-step wizard with all fields
5. **Enhance List Page** - Add filters, grouping, sorting
6. **Update Detail Page** - Display all sections and actions
7. **Test End-to-End** - Verify all workflows work correctly
8. **Migrate Legacy Data** - Import existing CMR records with new fields

---

**Status:** Ready for Implementation  
**Estimated Effort:** 2-3 days for complete restoration  
**Risk Level:** Low (preserving existing architecture, adding missing functionality)

