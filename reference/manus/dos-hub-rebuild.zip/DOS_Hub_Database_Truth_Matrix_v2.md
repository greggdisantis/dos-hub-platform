# DOS Hub — Database Truth Matrix (Full Comparison)
## Forensic Inspection Report — All Four Databases

**Date:** March 14, 2026  
**Prepared by:** Manus AI  
**Classification:** Read-Only Forensic Findings — No Changes Made  
**Inspection Timestamp:** 2026-03-14T14:45:04Z  
**SSL Configuration Used:** `ssl=rejectUnauthorized:true` (TLSv1.2+)

---

## 1. Summary Comparison Matrix

| Property | gateway04 / YxtbJqJxmKMGKQFMBD7qrd | gateway01 / dos_hub_dev | gateway01 / dos_hub_prod | gateway01 / test |
|----------|:-----------------------------------:|:-----------------------:|:------------------------:|:----------------:|
| **Host** | gateway04.us-east-1.prod.aws.tidbcloud.com | gateway01.us-east-1.prod.aws.tidbcloud.com | gateway01.us-east-1.prod.aws.tidbcloud.com | gateway01.us-east-1.prod.aws.tidbcloud.com |
| **Port** | 4000 | 4000 | 4000 | 4000 |
| **User** | rUcyWo8oc4HgvHh.2fda7799e361@% | 4R5HJpcn2iDQSh6.root@% | 4R5HJpcn2iDQSh6.root@% | 4R5HJpcn2iDQSh6.root@% |
| **Ownership** | **Manus-managed** | **User-owned** | **User-owned** | **User-owned** |
| **Connection** | CONNECTED | CONNECTED | CONNECTED | CONNECTED |
| **Table Count** | 12 | **25** | 12 | 12 |
| **users** | **17** | 3 | 3 | 3 |
| **cmr_reports** | **12** | 0 | 0 | 0 |
| **projects** | 0 | 0 | 0 | 0 |
| **cmr_line_items** | TABLE NOT FOUND | 0 | 0 | 0 |
| **screen_measurement_headers** | 2 | 0 | **1** | 0 |
| **screen_measurement_lines** | 2 | 0 | 0 | 0 |

---

## 2. Full Table Lists

### gateway04 / YxtbJqJxmKMGKQFMBD7qrd (Manus-managed — 12 tables)

| Table |
|-------|
| `__drizzle_migrations` |
| `cmr_reports` |
| `projects` |
| `screen_calculation_profiles` |
| `screen_manufacturers` |
| `screen_measurement_attachments` |
| `screen_measurement_headers` |
| `screen_measurement_line_attachments` |
| `screen_measurement_lines` |
| `screen_motor_types` |
| `screen_remote_types` |
| `users` |

**Notable absences:** `cmr_line_items`, `companies`, `module_permissions`, `notifications`, `audit_logs`, `screen_orders`, `receipts`, `time_off_*`, `zoning_lookups`, `preconstruction_checklists`, `project_material_checklists`, `aquaclean_receipts`

---

### gateway01 / dos_hub_dev (User-owned — 25 tables)

| Table |
|-------|
| `aquaclean_receipts` |
| `audit_logs` |
| `cmr_line_items` |
| `cmr_reports` |
| `companies` |
| `module_permissions` |
| `notifications` |
| `order_revisions` |
| `preconstruction_checklists` |
| `project_material_checklists` |
| `projects` |
| `receipts` |
| `screen_calculation_profiles` |
| `screen_manufacturers` |
| `screen_measurement_attachments` |
| `screen_measurement_headers` |
| `screen_measurement_line_attachments` |
| `screen_measurement_lines` |
| `screen_motor_types` |
| `screen_orders` |
| `screen_remote_types` |
| `time_off_policies` |
| `time_off_requests` |
| `users` |
| `zoning_lookups` |

**This is the most complete schema** — 25 tables vs 12 on all other databases.

---

### gateway01 / dos_hub_prod (User-owned — 12 tables)

| Table |
|-------|
| `cmr_line_items` |
| `cmr_reports` |
| `projects` |
| `screen_calculation_profiles` |
| `screen_manufacturers` |
| `screen_measurement_attachments` |
| `screen_measurement_headers` |
| `screen_measurement_line_attachments` |
| `screen_measurement_lines` |
| `screen_motor_types` |
| `screen_remote_types` |
| `users` |

**Missing 13 tables** that exist in `dos_hub_dev`: `aquaclean_receipts`, `audit_logs`, `cmr_line_items` *(wait — this IS present)*, `companies`, `module_permissions`, `notifications`, `order_revisions`, `preconstruction_checklists`, `project_material_checklists`, `receipts`, `screen_orders`, `time_off_policies`, `time_off_requests`, `zoning_lookups`

---

### gateway01 / test (User-owned — 12 tables)

Identical table list to `dos_hub_prod`. All row counts are zero except `screen_measurement_headers` which is also zero here (vs 1 in `dos_hub_prod`).

---

## 3. Critical Findings

### Finding 1 — The Real DOS Hub Data Lives on the Manus-Managed Cluster

The **17 users and 12 CMR reports** that represent the real DOS Hub operational data exist **only** on `gateway04 / YxtbJqJxmKMGKQFMBD7qrd` (Manus-managed). All three user-owned gateway01 databases have only **3 users and 0 CMR reports**.

### Finding 2 — dos_hub_dev Has the Most Complete Schema (25 Tables)

`dos_hub_dev` is the only database with the full module schema including `companies`, `module_permissions`, `audit_logs`, `screen_orders`, `receipts`, `time_off_*`, `zoning_lookups`, `preconstruction_checklists`, `project_material_checklists`, and `aquaclean_receipts`. These 13 tables are absent from all other databases.

### Finding 3 — dos_hub_prod and test Are Structurally Identical

Both have 12 tables and nearly identical row counts. `dos_hub_prod` has 1 row in `screen_measurement_headers`; `test` has 0. Otherwise they are the same.

### Finding 4 — cmr_line_items Does Not Exist on gateway04

The Manus-managed cluster is missing `cmr_line_items` entirely. The 12 CMR reports on gateway04 have no associated line items. All three gateway01 databases have the `cmr_line_items` table but it contains 0 rows.

### Finding 5 — The Live Cloud Run App Is Using the Wrong Database

The deployed Cloud Run service reads `DATABASE_URL`, which points to `gateway04 / YxtbJqJxmKMGKQFMBD7qrd`. This is the Manus-managed cluster with real data but an incomplete schema (missing 13 tables). The user-owned `dos_hub_prod` on gateway01 has a more complete schema but no real data and is not currently used by any service.

---

## 4. Database Role Classification

| Database | Owner | Schema Completeness | Real Data | Current Role |
|----------|-------|--------------------:|----------:|-------------|
| gateway04 / YxtbJqJxmKMGKQFMBD7qrd | Manus | 12 tables (partial) | **Yes** — 17 users, 12 CMR | Live Cloud Run production (current) |
| gateway01 / dos_hub_dev | User | **25 tables (full)** | No — 3 users, 0 CMR | Development environment |
| gateway01 / dos_hub_prod | User | 12 tables (partial) | No — 3 users, 0 CMR | Intended production (unused) |
| gateway01 / test | User | 12 tables (partial) | No — 3 users, 0 CMR | Unknown / legacy |

---

## 5. Tables Present in dos_hub_dev But Missing from dos_hub_prod

The following 13 tables exist in `dos_hub_dev` but are absent from `dos_hub_prod`:

| Missing Table | Rows in dos_hub_dev |
|---------------|--------------------:|
| `aquaclean_receipts` | 0 |
| `audit_logs` | 0 |
| `companies` | 0 |
| `module_permissions` | 0 |
| `notifications` | 0 |
| `order_revisions` | 0 |
| `preconstruction_checklists` | 0 |
| `project_material_checklists` | 0 |
| `receipts` | 0 |
| `screen_orders` | 0 |
| `time_off_policies` | 0 |
| `time_off_requests` | 0 |
| `zoning_lookups` | 0 |

All 13 missing tables are currently empty in `dos_hub_dev`.

---

## 6. What Cannot Be Determined From This Inspection

- The exact column schemas for each table (would require `SHOW CREATE TABLE` — not run)
- Whether the 3 users in gateway01 databases are the same as any of the 17 users in gateway04
- The content of the 12 CMR reports on gateway04 (row counts only, not row data)
- Whether the `screen_measurement_headers` row in `dos_hub_prod` is test data or real data

---

*End of report. No changes were made during this inspection.*
