# DOS Hub Navigation Architecture Proposal

## Overview

This document proposes a **stage-based navigation structure** that organizes work by business stage/department while keeping Projects as the central database record. The goal is to create a clean, hierarchical UI that avoids clutter and provides intuitive back navigation.

---

## 1. Top-Level Navigation

**Primary Navigation (Sidebar or Top Nav):**

```
DOS Hub
├── Dashboard (Home)
├── Sales
├── Engineering
├── Production
├── Install / Field
├── Service
├── Admin
└── Settings
```

Each stage is a first-class navigation item. Users navigate to the stage they're working in, not to Projects first.

---

## 2. Stage / Department Sections

### Sales Stage
**Purpose:** Manage client meetings, proposals, deal tracking, and early-stage project setup.

**Content:**
- CMR List (filtered to Sales stage)
  - View all client meeting reports
  - Create new CMR
  - Filter by: date, client, status, confidence level
- Quick Stats
  - Active deals
  - Pending approvals
  - This week's meetings
- Project Creation
  - Create new project (moves to Engineering)

**Navigation Flow:**
```
Sales
├── CMR List
│   ├── CMR Detail / View
│   ├── CMR Edit
│   └── CMR Approval (admin only)
└── Create Project → moves to Engineering
```

**Back Navigation:** CMR Detail → CMR List → Sales (not homepage)

---

### Engineering Stage
**Purpose:** Design work, screen measurements, material planning, preconstruction.

**Content:**
- Projects in Engineering
  - List of projects being designed
  - Filter by: status, assigned to, priority
- Project Detail
  - Project overview
  - Linked CMR (from Sales)
  - Screen Measurements (create/view)
  - Material Checklist (create/view)
  - Preconstruction Checklist (create/view)
  - Project status tracking

**Navigation Flow:**
```
Engineering
├── Projects List
│   └── Project Detail
│       ├── Screen Measurements
│       │   ├── Measurement Detail
│       │   └── Measurement Edit
│       ├── Material Checklist
│       │   ├── Checklist Detail
│       │   └── Checklist Edit
│       ├── Preconstruction Checklist
│       │   ├── Checklist Detail
│       │   └── Checklist Edit
│       └── Linked CMR (view only)
└── Create Project
```

**Back Navigation:** Measurement Detail → Project Detail → Projects List → Engineering

---

### Production Stage
**Purpose:** Manufacturing, assembly, material tracking, quality control.

**Content:**
- Projects in Production
  - List of projects being manufactured
  - Filter by: status, due date, material status
- Project Detail
  - Material Checklist (view/update delivery status)
  - Production Schedule
  - Quality Checklist
  - Linked Engineering data

**Navigation Flow:**
```
Production
├── Projects List
│   └── Project Detail
│       ├── Material Checklist (update status)
│       ├── Production Schedule
│       └── Quality Checklist
└── Material Orders (global view)
```

**Back Navigation:** Checklist Detail → Project Detail → Projects List → Production

---

### Install / Field Stage
**Purpose:** On-site installation, measurements, photo documentation, field notes.

**Content:**
- Active Jobs (projects in field)
  - List of jobs being installed
  - Filter by: location, crew, date
- Job Detail (mobile-friendly)
  - Screen Measurements (view/capture on-site)
  - Photo Gallery
  - Field Notes
  - Checklist (completion tracking)

**Navigation Flow:**
```
Install / Field
├── Active Jobs List
│   └── Job Detail
│       ├── Screen Measurements (capture/view)
│       ├── Photo Gallery
│       └── Field Notes
└── Completed Jobs Archive
```

**Back Navigation:** Measurement → Job Detail → Active Jobs → Install / Field

---

### Service Stage
**Purpose:** Post-installation service, maintenance, warranty, customer support.

**Content:**
- Service Requests
  - List of active service requests
  - Filter by: date, customer, type
- Service Request Detail
  - Service history
  - Photos
  - Notes
  - Parts/Materials used
  - Receipt Capture (service expenses)

**Navigation Flow:**
```
Service
├── Service Requests List
│   └── Service Request Detail
│       ├── Service History
│       ├── Photo Gallery
│       ├── Receipt Capture
│       └── Parts Tracking
└── Completed Service Archive
```

**Back Navigation:** Receipt Detail → Service Request Detail → Service Requests → Service

---

### Admin Stage
**Purpose:** User management, system configuration, approvals, reporting.

**Content:**
- User Management
  - Pending approvals
  - User list
  - Role management
- Approvals Queue
  - Pending CMR approvals
  - Pending project approvals
  - Other workflow approvals
- System Settings
  - Company info
  - Module permissions
  - Integrations (HubSpot, Service Fusion)

**Navigation Flow:**
```
Admin
├── User Management
│   ├── Pending Approvals
│   └── User List
├── Approvals Queue
│   ├── CMR Approvals
│   └── Project Approvals
└── System Settings
```

**Back Navigation:** User Detail → User Management → Admin

---

## 3. Where Projects Live

**Projects are not a top-level navigation item.** Instead, projects appear within each stage where they're relevant:

- **Sales:** Projects are created here (as new deals)
- **Engineering:** Projects are managed here (design phase)
- **Production:** Projects are tracked here (manufacturing phase)
- **Install/Field:** Projects become "Jobs" here (installation phase)
- **Service:** Projects have service records here (post-installation)

**Database:** Projects table is central, with `projectStage` field tracking which stage a project is in.

**UI:** Users see projects filtered by their current stage, not all projects at once.

---

## 4. Where Modules Live

| Module | Primary Stage | Secondary Stages | Notes |
|--------|---------------|------------------|-------|
| CMR | Sales | Engineering | Created in Sales, viewable in Engineering |
| Screen Measurements | Engineering | Install/Field | Designed in Engineering, captured on-site in Install |
| Material Checklist | Engineering | Production, Install | Created in Engineering, tracked in Production, used in Install |
| Preconstruction Checklist | Engineering | Production | Created in Engineering, executed in Production |
| Receipt Capture | Service | Production | Primarily for Service expenses, also for Production materials |
| AquaClean Receipts | Service | - | Separate module for AquaClean service expenses |
| Photo Gallery | Install/Field | Service | Captured in Install, reviewed in Service |

---

## 5. How Users Move Between Levels

### Navigation Patterns

**1. Forward Navigation (into detail):**
- Click a list item → opens detail view
- Detail view shows all related data (measurements, checklists, etc.)
- User stays in the same stage context

**2. Back Navigation (one level up):**
- Back button in detail view → returns to list in same stage
- Back button in list → returns to stage overview
- Back button in stage → returns to Dashboard
- **Never jumps directly to homepage**

**3. Cross-Stage Navigation:**
- Linked records show context (e.g., CMR in Engineering shows "From Sales")
- Click linked record → opens in original stage (read-only or limited edit)
- Return to current stage with back button

**4. Quick Access:**
- Dashboard shows recent items from all stages
- Quick-access tiles for most-used modules
- Search across all stages (optional enhancement)

---

## 6. Dashboard Design

**Post-Login Dashboard** (not a dumping ground):

```
Dashboard
├── Welcome Message
├── Quick Stats (role-dependent)
│   ├── Pending Approvals (admin/manager only)
│   ├── Active Projects (your stage)
│   └── This Week's Activity
├── Recent Items (by stage)
│   ├── Recent CMRs (Sales)
│   ├── Recent Measurements (Engineering)
│   ├── Recent Service Requests (Service)
│   └── etc.
└── Stage Navigation Tiles
    ├── Sales
    ├── Engineering
    ├── Production
    ├── Install/Field
    ├── Service
    └── Admin
```

**Purpose:** Quick overview and entry point to each stage, not detailed work.

---

## 7. Implementation Notes

### Database
- **Projects table** remains central
- Add `projectStage` enum field (sales, engineering, production, install, service, archived)
- All modules link to `projectId`
- Queries filter by stage to show relevant data

### Frontend Routing
```
/dashboard (home)
/sales (stage overview)
/sales/cmr (CMR list in Sales)
/sales/cmr/:id (CMR detail)
/engineering (stage overview)
/engineering/projects (projects in Engineering)
/engineering/projects/:id (project detail)
/engineering/projects/:id/measurements (measurements for project)
/engineering/projects/:id/measurements/:mid (measurement detail)
... and so on
```

### Navigation Component
- Sidebar shows stage navigation
- Breadcrumb shows current path (Dashboard > Sales > CMR > Detail)
- Back button navigates one level up
- Stage context is always visible

---

## 8. Benefits of This Architecture

✅ **Clear hierarchy** — Users know where they are at all times
✅ **Intuitive back navigation** — One level up, not to homepage
✅ **Stage-based workflow** — Matches how the business actually works
✅ **Project as database center** — Clean data model without UI clutter
✅ **Scalable** — Easy to add new stages or modules
✅ **Role-based access** — Each role sees only their stage(s)
✅ **Mobile-friendly** — Stages can have mobile-optimized views
✅ **Avoids clutter** — Dashboard stays clean, detail is in stages

---

## Next Steps

1. **Approve/refine this architecture** — Does this match your vision?
2. **Define role-to-stage mapping** — Which roles see which stages?
3. **Build stage overview pages** — Create the landing page for each stage
4. **Wire CMR to Sales stage** — First module implementation
5. **Implement breadcrumb navigation** — Show current path
6. **Build project list pages** — Engineering, Production, etc.
