# DOS Hub — Migration History Notes

## Drizzle Journal vs Physical DB

The Drizzle migration journal (`drizzle/meta/_journal.json`) tracks migrations `0000` through `0007`.

Migration SQL files `0008` through `0012` exist in `drizzle/` but are **not tracked in the journal**. These were applied manually to both `dos_hub_dev` and `dos_hub_prod` outside of the Drizzle migration runner, prior to this project being rebuilt in the current stack.

Additionally, the `index()` declarations added to `screenCalculationProfiles` in `drizzle/schema.ts` (for `idx_profile_manufacturer` and `idx_profile_status`) are not reflected in any migration file or Drizzle snapshot. The physical indexes were applied manually to `dos_hub_dev` via `scripts/align-dev-schema.mjs` and exist in `dos_hub_prod` from the original production migration.

## Decision Record — March 14, 2026

**Decision:** Accept the migration journal as out of sync. Do not run `pnpm drizzle-kit generate` before the current release.

**Rationale:**
- The physical database schema in both `dos_hub_dev` and `dos_hub_prod` matches `drizzle/schema.ts` exactly.
- TypeScript compiles clean (0 errors). Runtime is healthy. All tRPC procedures resolve correctly.
- The journal gap is a record-keeping issue only — it does not affect runtime behavior, query correctness, or deployment safety.
- Running `drizzle-kit generate` at this point would produce a migration that attempts to CREATE tables and indexes that already exist, which would require careful review before execution. This risk is not justified for the current release.

**Accepted as non-blocking for this release.**

## Post-Release Action Item

After the current release is stable, run `pnpm drizzle-kit generate` in a controlled session, review the generated SQL carefully, and either:
1. Apply it with `IF NOT EXISTS` guards to bring the journal into sync, or
2. Create a baseline snapshot that reflects the current physical state.

This should be done before the next schema change to restore clean migration tracking.

## Manual Migrations Applied Outside Journal

| File | Description | Applied To |
|---|---|---|
| `0008_cmr_restoration_phase1.sql` | CMR table restoration | dos_hub_dev, dos_hub_prod |
| `0009_add_cmr_new_fields.sql` | CMR new fields | dos_hub_dev, dos_hub_prod |
| `0010_add_consultant_name.sql` | Consultant name column | dos_hub_dev, dos_hub_prod |
| `0011_cmr_conditional_fields.sql` | CMR conditional fields | dos_hub_dev, dos_hub_prod |
| `0012_screen_profile_rule_columns.sql` | Screen profile rule JSON columns | dos_hub_dev, dos_hub_prod |
| `align-dev-schema.mjs` (script) | `idx_profile_manufacturer`, `idx_profile_status` indexes; `attendees`, `notes`, `actionItems` columns on `cmr_reports`; `screen_calculation_profiles` column type alignment | dos_hub_dev only |
