import { date, decimal, index, int, json, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Email address (unique identifier for login) */
  email: varchar("email", { length: 320 }).notNull().unique(),
  /** First name */
  firstName: varchar("firstName", { length: 100 }),
  /** Last name */
  lastName: varchar("lastName", { length: 100 }),
  /** Bcrypt password hash */
  passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
  /** User role (for permissions) */
  role: mysqlEnum("role", ["pending", "guest", "member", "manager", "admin", "super-admin"]).default("pending").notNull(),
  /** User type (for external access and filtering) */
  userType: mysqlEnum("userType", ["internal", "dealer", "sub-dealer", "vendor", "guest"]).default("internal").notNull(),
  /** Whether user has been approved by admin */
  approved: int("approved").default(0).notNull(),
  /** Whether user must change password on next login */
  passwordChangeRequired: int("passwordChangeRequired").default(0).notNull(),
  /**
   * Special Tags — second layer of permissions beyond Role.
   * Used for module/department/feature access grouping.
   * Examples: 'Permit Dept', 'Finance', 'Sales', 'Engineering', 'Screens', etc.
   * Stored as JSON array. Old users with no tags default to empty array.
   */
  specialTags: json("specialTags").$type<string[]>().default([]),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn"),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Project table - central hub for all operations
 * Links to HubSpot (sales) and Service Fusion (production)
 * All modules (CMR, Screen Measurements, Materials, etc.) link to Project
 */
export const projects = mysqlTable("projects", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(), // Project owner/creator
  
  // Project identification
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  
  // External system references (integration-ready)
  externalSourceType: varchar("externalSourceType", { length: 50 }), // 'hubspot', 'service-fusion', 'internal'
  hubspotDealId: varchar("hubspotDealId", { length: 100 }), // HubSpot deal ID
  hubspotContactId: varchar("hubspotContactId", { length: 100 }), // HubSpot contact ID
  serviceFusionJobId: varchar("serviceFusionJobId", { length: 100 }), // Service Fusion job ID
  serviceFusionCustomerId: varchar("serviceFusionCustomerId", { length: 100 }), // Service Fusion customer ID
  
  // Project stage tracking
  projectStage: mysqlEnum("projectStage", ["sales", "engineering", "production", "install", "service", "archived"]).default("sales").notNull(),
  
  // Quick reference fields
  clientName: varchar("clientName", { length: 255 }),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Project = typeof projects.$inferSelect;
export type InsertProject = typeof projects.$inferInsert;
export type ProjectStage = "sales" | "engineering" | "production" | "install" | "service" | "archived";

/**
 * CMR (Client Meeting Report) table
 * Includes both general meeting notes and CRM analytics fields for reporting
 * Links to Project for integration with HubSpot and Service Fusion
 */
export const cmrReports = mysqlTable("cmr_reports", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  projectId: int("projectId"), // Link to Project table (optional for legacy records)
  
  // Section 1: Appointment Details
  clientName: varchar("clientName", { length: 255 }).notNull(),
  consultantName: varchar("consultantName", { length: 255 }), // Name of consultant/staff member who conducted meeting (editable from user dropdown)
  hubspotContactId: varchar("hubspotContactId", { length: 100 }),
  address: varchar("address", { length: 255 }),
  clientType: mysqlEnum("clientType", ["residential", "commercial"]),
  appointmentDate: date("appointmentDate"), // Original appointment date
  appointmentType: mysqlEnum("appointmentType", ["in-home", "showroom", "phone"]),
  convertedToInPerson: int("convertedToInPerson").default(0), // Boolean: 0 or 1
  convertedDate: date("convertedDate"),
  convertedType: mysqlEnum("convertedType", ["in-home", "showroom"]),
  leadSources: json("leadSources").$type<string[]>(), // Multi-select array
  leadSourceOther: varchar("leadSourceOther", { length: 255 }),
  referredClientName: varchar("referredClientName", { length: 255 }), // When leadSource includes "Client Ref"
  contractorRefName: varchar("contractorRefName", { length: 255 }), // When leadSource includes "Contractor Ref"
  projectTypes: json("projectTypes").$type<string[]>(), // Multi-select array
  projectTypeOther: varchar("projectTypeOther", { length: 255 }),
  
  // Section 2: Deal Status
  dealStatus: mysqlEnum("dealStatus", [
    "working-on-design",
    "proposal-presented",
    "actively-considering",
    "awaiting-financing",
    "waiting-on-design",
    "delayed",
    "lost",
    "other"
  ]),
  otherDealStatus: varchar("otherDealStatus", { length: 255 }), // When dealStatus = "other"
  followUpDate: date("followUpDate"),
  noFollowUpReason: varchar("noFollowUpReason", { length: 255 }),
  proposalDate: date("proposalDate"),
  lostReason: varchar("lostReason", { length: 255 }),
  closeTimeline: mysqlEnum("closeTimeline", ["0-30", "31-60", "61-90", "90plus"]),
  lastConversationSummary: text("lastConversationSummary"),
  
  // Section 3: Purchase Confidence
  meetingDate: timestamp("meetingDate").defaultNow(), // Keep for backward compatibility
  purchaseConfidencePct: int("purchaseConfidencePct"), // 0-100 percentage, editable
  originalPcPct: int("originalPcPct"), // Locked after first submission, never changes
  estimatedContractValue: decimal("estimatedContractValue", { precision: 12, scale: 2 }), // Dollar amount, editable
  decisionMakers: varchar("decisionMakers", { length: 255 }),
  mainMotivation: text("mainMotivation"),
  otherMainMotivation: varchar("otherMainMotivation", { length: 255 }), // When mainMotivation = "Other"
  mainHesitation: text("mainHesitation"),
  otherMainHesitation: varchar("otherMainHesitation", { length: 255 }), // When mainHesitation = "Other"
  pcNotes: text("pcNotes"), // Required, minimum 3 sentences
  
  // Section 4: Value & Objections
  financingDiscussed: int("financingDiscussed"), // Boolean: 0 or 1
  financingReaction: mysqlEnum("financingReaction", ["interested", "needs-follow-up", "declined"]),
  valueCommunicated: json("valueCommunicated").$type<string[]>(), // Multi-select array
  clientResponse: mysqlEnum("clientResponse", ["strong-alignment", "neutral", "price-focused", "comparing-online", "other"]),
  otherClientResponse: varchar("otherClientResponse", { length: 255 }), // When clientResponse = "other"
  objections: json("objections").$type<string[]>(), // Multi-select array (kept for backward compat)
  objectionOther: varchar("objectionOther", { length: 255 }),
  objectionNotes: text("objectionNotes"),
  
  // Section 5: Next Steps & Marketing
  nextActions: json("nextActions").$type<string[]>(), // Multi-select array
  otherNextAction: varchar("otherNextAction", { length: 255 }), // When nextActions includes "Other"
  nextFollowUpDate: date("nextFollowUpDate"),
  leadQuality: mysqlEnum("leadQuality", ["excellent", "good", "average", "poor"]),
  expectationAlignment: mysqlEnum("expectationAlignment", ["yes", "somewhat", "no"]),
  messagingReferenced: json("messagingReferenced").$type<string[]>(), // Multi-select array
  messagingOther: varchar("messagingOther", { length: 255 }),
  budgetAlignment: mysqlEnum("budgetAlignment", ["aligned", "slightly-below", "significantly-below"]),
  marketingNotes: text("marketingNotes"),
  
  // Section 6: Progress Notes & Pipeline Tracking
  progressNotes: json("progressNotes").$type<Array<{ id: string; text: string; createdAt: string }>>(), // Timestamped notes

  
  // Pipeline Tracking
  outcome: mysqlEnum("outcome", ["open", "sold", "lost"]).default("open"), // Current status in pipeline
  soldAt: timestamp("soldAt"), // When marked as sold/lost
  soldBy: int("soldBy"), // User ID who marked it
  
  // NEW FIELDS - Added for enhanced tracking and analytics
  // 1. Estimated Value - entered by PC for analytics
  estimatedValue: decimal("estimatedValue", { precision: 12, scale: 2 }),
  
  // 2. Current Confidence % - latest confidence, editable after submission
  currentConfidencePct: int("currentConfidencePct"), // 0-100 percentage, can be updated after submission
  
  // 3. Update Notes - timestamped update history
  updateNotes: json("updateNotes").$type<Array<{ note: string; createdAt: string; createdBy: string }>>(),
  
  // 4. Approved Status - extended status tracking
  approvedStatus: mysqlEnum("approvedStatus", ["draft", "submitted", "approved", "closed", "lost"]).default("draft"),
  
  // 5. Closed Amount - actual deal value if job closes
  closedAmount: decimal("closedAmount", { precision: 12, scale: 2 }),
  
  // 6. Closed Date - when job officially closed
  closedDate: date("closedDate"),
  
  // 7. Appointment Result - analytics tracking
  appointmentResult: mysqlEnum("appointmentResult", ["pending", "sold", "not_sold", "follow_up", "cancelled"]),
  
  // 8. Last Updated At - auto-updated timestamp
  lastUpdatedAt: timestamp("lastUpdatedAt").defaultNow().onUpdateNow(),
  
  // 9. Last Updated By - user who made last update
  lastUpdatedBy: int("lastUpdatedBy"),
  
  // 10. Allow Quick Edit - permissions flag for future use
  allowQuickEdit: int("allowQuickEdit").default(1), // Boolean: 0 or 1
  
  // Meeting Notes (prod fields — added during migration)
  // attendees: list of people who attended the meeting
  attendees: json("attendees").$type<string[]>(),
  // notes: free-form meeting notes
  notes: text("notes"),
  // actionItems: list of follow-up action items from the meeting
  actionItems: json("actionItems").$type<Array<{ id: string; text: string; assignee?: string; dueDate?: string }>>(),

  // Status & Metadata
  status: mysqlEnum("status", ["draft", "submitted", "approved"]).default("draft").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CMRReport = typeof cmrReports.$inferSelect;
export type InsertCMRReport = typeof cmrReports.$inferInsert;

// TODO: Add remaining tables (screen_orders, receipts, aquaclean_receipts, precon_checklists, time_off_requests)

// =============================================================================
// MOTORIZED SCREENS MODULE
// Route: /screen-measurements
// Build order: schema → workflow → permissions → calculation → API → UI
// =============================================================================

/**
 * screen_manufacturers
 * Configurable list of manufacturers. Drives motor/remote type dropdowns.
 */
export const screenManufacturers = mysqlTable("screen_manufacturers", {
  code: varchar("code", { length: 50 }).primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  active: int("active").default(1).notNull(),
});

export type ScreenManufacturer = typeof screenManufacturers.$inferSelect;

/**
 * screen_motor_types
 * Per-manufacturer motor type options.
 */
export const screenMotorTypes = mysqlTable("screen_motor_types", {
  code: varchar("code", { length: 50 }).primaryKey(),
  manufacturerCode: varchar("manufacturerCode", { length: 50 }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  active: int("active").default(1).notNull(),
});

export type ScreenMotorType = typeof screenMotorTypes.$inferSelect;

/**
 * screen_remote_types
 * Per-manufacturer remote type options.
 */
export const screenRemoteTypes = mysqlTable("screen_remote_types", {
  code: varchar("code", { length: 50 }).primaryKey(),
  manufacturerCode: varchar("manufacturerCode", { length: 50 }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  active: int("active").default(1).notNull(),
});

export type ScreenRemoteType = typeof screenRemoteTypes.$inferSelect;

/**
 * screen_install_mounts
 * Reference lookup for install mount options (replaces hard-coded enum values in UI).
 */
export const screenInstallMounts = mysqlTable("screen_install_mounts", {
  code: varchar("code", { length: 50 }).primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  sortOrder: int("sortOrder").default(0).notNull(),
});

export type ScreenInstallMount = typeof screenInstallMounts.$inferSelect;

/**
 * screen_calculation_profiles
 * Versioned calculation rules per manufacturer.
 * Old records pin to a specific version so rule changes never alter historical outputs.
 */
export const screenCalculationProfiles = mysqlTable(
  "screen_calculation_profiles",
  {
    code: varchar("code", { length: 50 }).primaryKey(),
    manufacturerCode: varchar("manufacturerCode", { length: 50 }).notNull(),
    version: int("version").notNull().default(1),
    status: mysqlEnum("status", ["active", "deprecated"]).default("active").notNull(),

    uChannelThreshold: decimal("uChannelThreshold", { precision: 6, scale: 3 }),

    buildoutRulesJson: json("buildoutRulesJson"),
    trackRulesJson: json("trackRulesJson"),
    extendedHoodRulesJson: json("extendedHoodRulesJson"),
    toleranceRulesJson: json("toleranceRulesJson"),

    slopeRulesJson: json("slopeRulesJson"),
    tbRulesJson: json("tbRulesJson"),
    biasRulesJson: json("biasRulesJson"),

    manufacturerUChannelThresholdsJson: json("manufacturerUChannelThresholdsJson"),

    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  (table) => ({
    manufacturerIdx: index("idx_profile_manufacturer").on(table.manufacturerCode),
    statusIdx: index("idx_profile_status").on(table.status),
  })
);

export type ScreenCalculationProfile = typeof screenCalculationProfiles.$inferSelect;

/**
 * screen_measurement_headers
 * One record per measurement set / job.
 * project_id → projects.id (nullable — measurement may exist before a project is created)
 * cmr_id → cmr_reports.id (nullable — measurement may exist without a CMR)
 */
export const screenMeasurementHeaders = mysqlTable("screen_measurement_headers", {
  id: int("id").autoincrement().primaryKey(),

  // Auto-generated record number (e.g. SM-0001)
  recordNumber: varchar("recordNumber", { length: 20 }).notNull().unique(),

  // Workflow status
  status: mysqlEnum("status", [
    "draft",
    "submitted",
    "approved",
    "closed",
    "cancelled",
    "archived",
  ]).default("draft").notNull(),

  // Ownership
  ownerId: int("ownerId").notNull(), // → users.id

  // Parent relationships (nullable — see architecture note above)
  projectId: int("projectId"),   // → projects.id
  cmrId: int("cmrId"),           // → cmr_reports.id

  // Manufacturer & equipment
  manufacturerCode: varchar("manufacturerCode", { length: 50 }),
  motorType: varchar("motorType", { length: 50 }),
  remoteType: varchar("remoteType", { length: 50 }),

  // Installation settings
  installMount: mysqlEnum("installMount", ["face-mount", "inside-mount", "ceiling-mount", "other"]),
  faceMountSides: mysqlEnum("faceMountSides", ["both", "left-only", "right-only", "none"]),

  // Global U-channel override
  applyUChannelToAll: int("applyUChannelToAll").default(0).notNull(), // Boolean: 0 or 1

  // Calculation profile pinned at time of creation
  calculationProfileCode: varchar("calculationProfileCode", { length: 50 }),
  calculationVersion: int("calculationVersion"),

  // Dates
  measurementDate: date("measurementDate"),

  // Notes
  siteNotes: text("siteNotes"),

  // Approval tracking
  approvedBy: int("approvedBy"),  // → users.id
  approvedAt: timestamp("approvedAt"),

  // Soft delete
  archivedFlag: int("archivedFlag").default(0).notNull(), // Boolean: 0 or 1

  // Audit
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy").notNull(), // → users.id
  updatedBy: int("updatedBy"),           // → users.id
});

export type ScreenMeasurementHeader = typeof screenMeasurementHeaders.$inferSelect;
export type InsertScreenMeasurementHeader = typeof screenMeasurementHeaders.$inferInsert;
export type ScreenMeasurementStatus = "draft" | "submitted" | "approved" | "closed" | "cancelled" | "archived";

/**
 * screen_measurement_lines
 * One row per screen within a header.
 * Lines are editable only when header.status = 'draft'.
 */
export const screenMeasurementLines = mysqlTable("screen_measurement_lines", {
  id: int("id").autoincrement().primaryKey(),
  headerId: int("headerId").notNull(), // → screen_measurement_headers.id

  // Display label and ordering
  screenLabel: varchar("screenLabel", { length: 100 }),
  sortOrder: int("sortOrder").default(0).notNull(),

  // Raw measurements (inches, 3 decimal places)
  // Left column: upper-left, lower-left, outer-left
  ul: decimal("ul", { precision: 8, scale: 3 }),
  ll: decimal("ll", { precision: 8, scale: 3 }),
  ol: decimal("ol", { precision: 8, scale: 3 }),
  // Right column: upper-right, lower-right, outer-right
  ur: decimal("ur", { precision: 8, scale: 3 }),
  lr: decimal("lr", { precision: 8, scale: 3 }),
  orMeasurement: decimal("orMeasurement", { precision: 8, scale: 3 }), // 'or' is a JS reserved word

  // Horizontal measurements: top, middle, bottom
  t: decimal("t", { precision: 8, scale: 3 }),
  m: decimal("m", { precision: 8, scale: 3 }),
  b: decimal("b", { precision: 8, scale: 3 }),

  // Reverse measurement flag
  reverseMeasurements: int("reverseMeasurements").default(0).notNull(),

  // Per-screen parity fields (dev-only extension — creates temporary dev/prod schema mismatch)
  // Added to dos_hub_dev via ALTER TABLE on 2026-03-19.
  // Must be resolved through normal schema-diff/approval flow before production promotion.
  motorSide: varchar("motorSide", { length: 20 }),       // "left" | "right" | null
  remoteType: varchar("remoteType", { length: 50 }),     // remote code, per-screen override
  numberOfCuts: int("numberOfCuts"),                     // number of cuts for this screen

  // Power connection
  powerConnectionType: mysqlEnum("powerConnectionType", ["plugged", "hardwired", "other"]),
  powerConnectionOtherText: varchar("powerConnectionOtherText", { length: 255 }),

  // Slope analysis (calculated by engine)
  upperSlope: decimal("upperSlope", { precision: 8, scale: 3 }),
  slopeDirection: mysqlEnum("slopeDirection", ["left-high", "right-high", "level"]),
  highSide: decimal("highSide", { precision: 8, scale: 3 }),
  lowSide: decimal("lowSide", { precision: 8, scale: 3 }),

  // Height outputs (calculated)
  leftHeight: decimal("leftHeight", { precision: 8, scale: 3 }),
  rightHeight: decimal("rightHeight", { precision: 8, scale: 3 }),

  // Top-to-bottom difference (calculated)
  tbDiff: decimal("tbDiff", { precision: 8, scale: 3 }),

  // U-channel (calculated + override)
  uChannelNeeded: int("uChannelNeeded").default(0).notNull(),
  uChannelReason: varchar("uChannelReason", { length: 255 }),

  // Build-out (calculated + override)
  buildOutRequired: int("buildOutRequired").default(0).notNull(),
  buildOutType: varchar("buildOutType", { length: 100 }),

  // Track and hood outputs (calculated)
  trackToTrack: decimal("trackToTrack", { precision: 8, scale: 3 }),
  extendedHood: int("extendedHood").default(0).notNull(),
  bias: decimal("bias", { precision: 8, scale: 3 }),

  // Orderable dimensions (final outputs)
  orderableWidth: decimal("orderableWidth", { precision: 8, scale: 3 }),
  orderableHeight: decimal("orderableHeight", { precision: 8, scale: 3 }),

  // Mismatch flags (calculated)
  leftSideMismatch: int("leftSideMismatch").default(0).notNull(),
  rightSideMismatch: int("rightSideMismatch").default(0).notNull(),

  // Structured calculation flags (warnings, notes from engine)
  calculationFlagsJson: json("calculationFlagsJson").$type<Array<{ code: string; severity: "info" | "warning" | "error"; message: string }>>(),

  // Free-form notes
  notes: text("notes"),

  // Audit
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  createdBy: int("createdBy").notNull(),
  updatedBy: int("updatedBy"),
});

export type ScreenMeasurementLine = typeof screenMeasurementLines.$inferSelect;
export type InsertScreenMeasurementLine = typeof screenMeasurementLines.$inferInsert;

/**
 * screen_measurement_attachments
 * Header-level file attachments (general job documents).
 * Locked when header.status >= 'approved'.
 */
export const screenMeasurementAttachments = mysqlTable("screen_measurement_attachments", {
  id: int("id").autoincrement().primaryKey(),
  recordId: int("recordId").notNull(),  // → screen_measurement_headers.id
  fileId: varchar("fileId", { length: 255 }).notNull(), // S3 key or file reference
  uploadedBy: int("uploadedBy").notNull(), // → users.id
  uploadedAt: timestamp("uploadedAt").defaultNow().notNull(),
});

export type ScreenMeasurementAttachment = typeof screenMeasurementAttachments.$inferSelect;

/**
 * screen_measurement_line_attachments
 * Per-screen-line photo attachments (field photos, problem documentation).
 * Locked when header.status >= 'approved'.
 */
export const screenMeasurementLineAttachments = mysqlTable("screen_measurement_line_attachments", {
  id: int("id").autoincrement().primaryKey(),
  lineId: int("lineId").notNull(), // → screen_measurement_lines.id
  fileId: varchar("fileId", { length: 255 }).notNull(), // S3 key or file reference
  caption: varchar("caption", { length: 500 }),
  photoType: mysqlEnum("photoType", ["overview", "detail", "problem", "measurement", "other"]),
  sortOrder: int("sortOrder").default(0).notNull(),
  uploadedBy: int("uploadedBy").notNull(), // → users.id
  uploadedAt: timestamp("uploadedAt").defaultNow().notNull(),
});

export type ScreenMeasurementLineAttachment = typeof screenMeasurementLineAttachments.$inferSelect;

// =============================================================================
// ARCHITECTURE NOTES — Motorized Screens Module
// =============================================================================
// project_id → projects.id (nullable): measurement may exist before project is created
// cmr_id → cmr_reports.id (nullable): measurement may exist without a CMR
// Calculation outputs are stored on lines; formulas live in screen_calculation_profiles
// Lines are editable only when header.status = 'draft'
// Attachments are locked when header.status >= 'approved'
// Do NOT delete headers or lines if children exist — archive instead
// =============================================================================

// =============================================================================
// DOS: Receipt Capture Module
// Spec: DOS_Receipt_Capture_Module_Spec_v3_ARCHITECTURE_LEVEL.docx
// Tables: receipt_submissions, receipt_line_items, receipt_status_history,
//         receipt_analysis_snapshot
// Dev DB only — do not migrate to production without approval
// =============================================================================

/**
 * receipt_submissions — primary record for each submitted receipt
 */
export const receiptSubmissions = mysqlTable("receipt_submissions", {
  id: int("id").autoincrement().primaryKey(),

  // Submitter
  submittedByUserId: int("submittedByUserId").notNull(), // → users.id
  submittedAt: timestamp("submittedAt"),

  // Receipt data
  vendorName: varchar("vendorName", { length: 255 }),
  receiptDate: date("receiptDate"),
  subtotal: decimal("subtotal", { precision: 10, scale: 2 }),
  tax: decimal("tax", { precision: 10, scale: 2 }),
  total: decimal("total", { precision: 10, scale: 2 }),
  description: text("description"),
  notes: text("notes"),

  // Classification
  receiptType: mysqlEnum("receiptType", ["job_related", "overhead"]),
  overheadCategory: varchar("overheadCategory", { length: 100 }),
  jobName: varchar("jobName", { length: 255 }),
  poNumber: varchar("poNumber", { length: 100 }),

  // Storage
  originalImageKey: varchar("originalImageKey", { length: 500 }), // S3 key for receipt image
  pdfKey: varchar("pdfKey", { length: 500 }),                     // S3 key for generated PDF

  // Workflow status
  status: mysqlEnum("status", ["draft", "submitted", "entered", "complete", "voided"])
    .default("draft")
    .notNull(),

  // Finance processing
  enteredByUserId: int("enteredByUserId"),   // → users.id
  enteredAt: timestamp("enteredAt"),
  completedByUserId: int("completedByUserId"), // → users.id
  completedAt: timestamp("completedAt"),
  financeNote: text("financeNote"),
  voidReason: text("voidReason"),

  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type ReceiptSubmission = typeof receiptSubmissions.$inferSelect;
export type InsertReceiptSubmission = typeof receiptSubmissions.$inferInsert;

/**
 * receipt_line_items — individual line items on a receipt
 */
export const receiptLineItems = mysqlTable("receipt_line_items", {
  id: int("id").autoincrement().primaryKey(),
  receiptId: int("receiptId").notNull(), // → receipt_submissions.id
  description: varchar("description", { length: 500 }),
  amount: decimal("amount", { precision: 10, scale: 2 }),
  sortOrder: int("sortOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type ReceiptLineItem = typeof receiptLineItems.$inferSelect;
export type InsertReceiptLineItem = typeof receiptLineItems.$inferInsert;

/**
 * receipt_status_history — immutable audit trail of status transitions
 */
export const receiptStatusHistory = mysqlTable("receipt_status_history", {
  id: int("id").autoincrement().primaryKey(),
  receiptId: int("receiptId").notNull(), // → receipt_submissions.id
  fromStatus: varchar("fromStatus", { length: 50 }),
  toStatus: varchar("toStatus", { length: 50 }).notNull(),
  changedByUserId: int("changedByUserId").notNull(), // → users.id
  note: text("note"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type ReceiptStatusHistory = typeof receiptStatusHistory.$inferSelect;

/**
 * receipt_analysis_snapshot — stores the raw LLM extraction result for audit
 */
export const receiptAnalysisSnapshots = mysqlTable("receipt_analysis_snapshot", {
  id: int("id").autoincrement().primaryKey(),
  receiptId: int("receiptId").notNull(), // → receipt_submissions.id
  rawResponse: text("rawResponse"),      // full LLM JSON response
  extractedVendor: varchar("extractedVendor", { length: 255 }),
  extractedDate: date("extractedDate"),
  extractedSubtotal: decimal("extractedSubtotal", { precision: 10, scale: 2 }),
  extractedTax: decimal("extractedTax", { precision: 10, scale: 2 }),
  extractedTotal: decimal("extractedTotal", { precision: 10, scale: 2 }),
  confidence: varchar("confidence", { length: 50 }), // 'high' | 'medium' | 'low'
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});
export type ReceiptAnalysisSnapshot = typeof receiptAnalysisSnapshots.$inferSelect;
