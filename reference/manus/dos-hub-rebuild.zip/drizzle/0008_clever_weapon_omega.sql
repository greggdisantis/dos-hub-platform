CREATE TABLE `receipt_analysis_snapshot` (
	`id` int AUTO_INCREMENT NOT NULL,
	`receiptId` int NOT NULL,
	`rawResponse` text,
	`extractedVendor` varchar(255),
	`extractedDate` date,
	`extractedSubtotal` decimal(10,2),
	`extractedTax` decimal(10,2),
	`extractedTotal` decimal(10,2),
	`confidence` varchar(50),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `receipt_analysis_snapshot_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `receipt_line_items` (
	`id` int AUTO_INCREMENT NOT NULL,
	`receiptId` int NOT NULL,
	`description` varchar(500),
	`amount` decimal(10,2),
	`sortOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `receipt_line_items_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `receipt_status_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`receiptId` int NOT NULL,
	`fromStatus` varchar(50),
	`toStatus` varchar(50) NOT NULL,
	`changedByUserId` int NOT NULL,
	`note` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `receipt_status_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `receipt_submissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`submittedByUserId` int NOT NULL,
	`submittedAt` timestamp,
	`vendorName` varchar(255),
	`receiptDate` date,
	`subtotal` decimal(10,2),
	`tax` decimal(10,2),
	`total` decimal(10,2),
	`description` text,
	`notes` text,
	`receiptType` enum('job_related','overhead'),
	`overheadCategory` varchar(100),
	`jobName` varchar(255),
	`poNumber` varchar(100),
	`originalImageKey` varchar(500),
	`pdfKey` varchar(500),
	`status` enum('draft','submitted','entered','complete','voided') NOT NULL DEFAULT 'draft',
	`enteredByUserId` int,
	`enteredAt` timestamp,
	`completedByUserId` int,
	`completedAt` timestamp,
	`financeNote` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `receipt_submissions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `screen_calculation_profiles` (
	`code` varchar(50) NOT NULL,
	`manufacturerCode` varchar(50) NOT NULL,
	`version` int NOT NULL DEFAULT 1,
	`status` enum('active','deprecated') NOT NULL DEFAULT 'active',
	`uChannelThreshold` decimal(6,3),
	`buildoutRulesJson` json,
	`trackRulesJson` json,
	`extendedHoodRulesJson` json,
	`toleranceRulesJson` json,
	`slopeRulesJson` json,
	`tbRulesJson` json,
	`biasRulesJson` json,
	`manufacturerUChannelThresholdsJson` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `screen_calculation_profiles_code` PRIMARY KEY(`code`)
);
--> statement-breakpoint
CREATE TABLE `screen_manufacturers` (
	`code` varchar(50) NOT NULL,
	`name` varchar(255) NOT NULL,
	`active` int NOT NULL DEFAULT 1,
	CONSTRAINT `screen_manufacturers_code` PRIMARY KEY(`code`)
);
--> statement-breakpoint
CREATE TABLE `screen_measurement_attachments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`recordId` int NOT NULL,
	`fileId` varchar(255) NOT NULL,
	`uploadedBy` int NOT NULL,
	`uploadedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `screen_measurement_attachments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `screen_measurement_headers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`recordNumber` varchar(20) NOT NULL,
	`status` enum('draft','submitted','approved','closed','cancelled','archived') NOT NULL DEFAULT 'draft',
	`ownerId` int NOT NULL,
	`projectId` int,
	`cmrId` int,
	`manufacturerCode` varchar(50),
	`motorType` varchar(50),
	`remoteType` varchar(50),
	`installMount` enum('face-mount','inside-mount','ceiling-mount','other'),
	`faceMountSides` enum('both','left-only','right-only','none'),
	`applyUChannelToAll` int NOT NULL DEFAULT 0,
	`calculationProfileCode` varchar(50),
	`calculationVersion` int,
	`measurementDate` date,
	`siteNotes` text,
	`approvedBy` int,
	`approvedAt` timestamp,
	`archivedFlag` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdBy` int NOT NULL,
	`updatedBy` int,
	CONSTRAINT `screen_measurement_headers_id` PRIMARY KEY(`id`),
	CONSTRAINT `screen_measurement_headers_recordNumber_unique` UNIQUE(`recordNumber`)
);
--> statement-breakpoint
CREATE TABLE `screen_measurement_line_attachments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`lineId` int NOT NULL,
	`fileId` varchar(255) NOT NULL,
	`caption` varchar(500),
	`photoType` enum('overview','detail','problem','measurement','other'),
	`sortOrder` int NOT NULL DEFAULT 0,
	`uploadedBy` int NOT NULL,
	`uploadedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `screen_measurement_line_attachments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `screen_measurement_lines` (
	`id` int AUTO_INCREMENT NOT NULL,
	`headerId` int NOT NULL,
	`screenLabel` varchar(100),
	`sortOrder` int NOT NULL DEFAULT 0,
	`ul` decimal(8,3),
	`ll` decimal(8,3),
	`ol` decimal(8,3),
	`ur` decimal(8,3),
	`lr` decimal(8,3),
	`orMeasurement` decimal(8,3),
	`t` decimal(8,3),
	`m` decimal(8,3),
	`b` decimal(8,3),
	`reverseMeasurements` int NOT NULL DEFAULT 0,
	`powerConnectionType` enum('plugged','hardwired','other'),
	`powerConnectionOtherText` varchar(255),
	`upperSlope` decimal(8,3),
	`slopeDirection` enum('left-high','right-high','level'),
	`highSide` decimal(8,3),
	`lowSide` decimal(8,3),
	`leftHeight` decimal(8,3),
	`rightHeight` decimal(8,3),
	`tbDiff` decimal(8,3),
	`uChannelNeeded` int NOT NULL DEFAULT 0,
	`uChannelReason` varchar(255),
	`buildOutRequired` int NOT NULL DEFAULT 0,
	`buildOutType` varchar(100),
	`trackToTrack` decimal(8,3),
	`extendedHood` int NOT NULL DEFAULT 0,
	`bias` decimal(8,3),
	`orderableWidth` decimal(8,3),
	`orderableHeight` decimal(8,3),
	`leftSideMismatch` int NOT NULL DEFAULT 0,
	`rightSideMismatch` int NOT NULL DEFAULT 0,
	`calculationFlagsJson` json,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`createdBy` int NOT NULL,
	`updatedBy` int,
	CONSTRAINT `screen_measurement_lines_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `screen_motor_types` (
	`code` varchar(50) NOT NULL,
	`manufacturerCode` varchar(50) NOT NULL,
	`name` varchar(255) NOT NULL,
	`active` int NOT NULL DEFAULT 1,
	CONSTRAINT `screen_motor_types_code` PRIMARY KEY(`code`)
);
--> statement-breakpoint
CREATE TABLE `screen_remote_types` (
	`code` varchar(50) NOT NULL,
	`manufacturerCode` varchar(50) NOT NULL,
	`name` varchar(255) NOT NULL,
	`active` int NOT NULL DEFAULT 1,
	CONSTRAINT `screen_remote_types_code` PRIMARY KEY(`code`)
);
--> statement-breakpoint
ALTER TABLE `cmr_reports` MODIFY COLUMN `meetingDate` timestamp DEFAULT (now());--> statement-breakpoint
ALTER TABLE `cmr_reports` MODIFY COLUMN `dealStatus` enum('working-on-design','proposal-presented','actively-considering','awaiting-financing','waiting-on-design','delayed','lost','other');--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `consultantName` varchar(255);--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `hubspotContactId` varchar(100);--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `address` varchar(255);--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `clientType` enum('residential','commercial');--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `appointmentDate` date;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `appointmentType` enum('in-home','showroom','phone');--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `convertedToInPerson` int DEFAULT 0;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `convertedDate` date;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `convertedType` enum('in-home','showroom');--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `leadSources` json;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `leadSourceOther` varchar(255);--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `referredClientName` varchar(255);--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `contractorRefName` varchar(255);--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `projectTypes` json;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `projectTypeOther` varchar(255);--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `otherDealStatus` varchar(255);--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `followUpDate` date;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `noFollowUpReason` varchar(255);--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `proposalDate` date;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `lostReason` varchar(255);--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `closeTimeline` enum('0-30','31-60','61-90','90plus');--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `lastConversationSummary` text;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `originalPcPct` int;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `decisionMakers` varchar(255);--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `mainMotivation` text;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `otherMainMotivation` varchar(255);--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `mainHesitation` text;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `otherMainHesitation` varchar(255);--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `pcNotes` text;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `financingDiscussed` int;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `financingReaction` enum('interested','needs-follow-up','declined');--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `valueCommunicated` json;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `clientResponse` enum('strong-alignment','neutral','price-focused','comparing-online','other');--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `otherClientResponse` varchar(255);--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `objections` json;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `objectionOther` varchar(255);--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `objectionNotes` text;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `nextActions` json;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `otherNextAction` varchar(255);--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `nextFollowUpDate` date;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `leadQuality` enum('excellent','good','average','poor');--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `expectationAlignment` enum('yes','somewhat','no');--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `messagingReferenced` json;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `messagingOther` varchar(255);--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `budgetAlignment` enum('aligned','slightly-below','significantly-below');--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `marketingNotes` text;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `progressNotes` json;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `outcome` enum('open','sold','lost') DEFAULT 'open';--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `soldAt` timestamp;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `soldBy` int;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `estimatedValue` decimal(12,2);--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `currentConfidencePct` int;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `updateNotes` json;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `approvedStatus` enum('draft','submitted','approved','closed','lost') DEFAULT 'draft';--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `closedAmount` decimal(12,2);--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `closedDate` date;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `appointmentResult` enum('pending','sold','not_sold','follow_up','cancelled');--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `lastUpdatedAt` timestamp DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `lastUpdatedBy` int;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `allowQuickEdit` int DEFAULT 1;--> statement-breakpoint
ALTER TABLE `users` ADD `specialTags` json DEFAULT ('[]');--> statement-breakpoint
CREATE INDEX `idx_profile_manufacturer` ON `screen_calculation_profiles` (`manufacturerCode`);--> statement-breakpoint
CREATE INDEX `idx_profile_status` ON `screen_calculation_profiles` (`status`);