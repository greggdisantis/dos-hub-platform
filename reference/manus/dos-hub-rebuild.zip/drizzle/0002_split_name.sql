-- Add firstName and lastName columns
ALTER TABLE `users` ADD COLUMN `firstName` varchar(100) NOT NULL DEFAULT '';
ALTER TABLE `users` ADD COLUMN `lastName` varchar(100) NOT NULL DEFAULT '';

-- Migrate existing data: split name into firstName and lastName
UPDATE `users` SET 
  `firstName` = TRIM(SUBSTRING_INDEX(COALESCE(`name`, ''), ' ', 1)),
  `lastName` = TRIM(SUBSTRING_INDEX(COALESCE(`name`, ''), ' ', -1))
WHERE `name` IS NOT NULL AND `name` != '';

-- Drop the old name column
ALTER TABLE `users` DROP COLUMN `name`;
