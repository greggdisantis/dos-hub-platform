CREATE TABLE `projects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`externalSourceType` varchar(50),
	`hubspotDealId` varchar(100),
	`hubspotContactId` varchar(100),
	`serviceFusionJobId` varchar(100),
	`serviceFusionCustomerId` varchar(100),
	`projectStage` varchar(50),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `projects_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `cmr_reports` MODIFY COLUMN `attendees` json;--> statement-breakpoint
ALTER TABLE `cmr_reports` MODIFY COLUMN `actionItems` json;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `projectId` int;