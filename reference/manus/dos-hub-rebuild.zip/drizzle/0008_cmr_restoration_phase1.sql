-- CMR Restoration Phase 1: Add missing fields for original CMR structure
-- This migration is ADDITIVE ONLY - no data loss, all new fields are nullable

ALTER TABLE `cmr_reports` 
ADD COLUMN `hubspotContactId` varchar(100),
ADD COLUMN `address` varchar(255),
ADD COLUMN `clientType` enum('residential','commercial'),
ADD COLUMN `appointmentDate` date,
ADD COLUMN `appointmentType` enum('in-home','showroom','phone'),
ADD COLUMN `convertedToInPerson` int DEFAULT 0,
ADD COLUMN `convertedDate` date,
ADD COLUMN `convertedType` enum('in-home','showroom'),
ADD COLUMN `leadSources` json,
ADD COLUMN `leadSourceOther` varchar(255),
ADD COLUMN `projectTypes` json,
ADD COLUMN `projectTypeOther` varchar(255),
ADD COLUMN `followUpDate` date,
ADD COLUMN `noFollowUpReason` varchar(255),
ADD COLUMN `proposalDate` date,
ADD COLUMN `lostReason` varchar(255),
ADD COLUMN `closeTimeline` enum('0-30','31-60','61-90','90plus'),
ADD COLUMN `lastConversationSummary` text,
ADD COLUMN `originalPcPct` int,
ADD COLUMN `decisionMakers` varchar(255),
ADD COLUMN `mainMotivation` text,
ADD COLUMN `mainHesitation` text,
ADD COLUMN `pcNotes` text,
ADD COLUMN `financingDiscussed` int,
ADD COLUMN `financingReaction` enum('interested','needs-follow-up','declined'),
ADD COLUMN `valueCommunicated` json,
ADD COLUMN `clientResponse` enum('strong-alignment','neutral','price-focused','comparing-online'),
ADD COLUMN `objections` json,
ADD COLUMN `objectionOther` varchar(255),
ADD COLUMN `objectionNotes` text,
ADD COLUMN `nextActions` json,
ADD COLUMN `nextFollowUpDate` date,
ADD COLUMN `leadQuality` enum('excellent','good','average','poor'),
ADD COLUMN `expectationAlignment` enum('yes','somewhat','no'),
ADD COLUMN `messagingReferenced` json,
ADD COLUMN `messagingOther` varchar(255),
ADD COLUMN `budgetAlignment` enum('aligned','slightly-below','significantly-below'),
ADD COLUMN `marketingNotes` text,
ADD COLUMN `progressNotes` json,
ADD COLUMN `outcome` enum('open','sold','lost') DEFAULT 'open',
ADD COLUMN `soldAt` timestamp,
ADD COLUMN `soldBy` int;

-- Update dealStatus enum to include all original options
ALTER TABLE `cmr_reports` 
MODIFY COLUMN `dealStatus` enum('working-on-design','proposal-presented','actively-considering','awaiting-financing','waiting-on-design','delayed','lost');

-- Create indexes on frequently filtered fields for performance
CREATE INDEX `idx_cmr_userId` ON `cmr_reports`(`userId`);
CREATE INDEX `idx_cmr_dealStatus` ON `cmr_reports`(`dealStatus`);
CREATE INDEX `idx_cmr_outcome` ON `cmr_reports`(`outcome`);
CREATE INDEX `idx_cmr_appointmentDate` ON `cmr_reports`(`appointmentDate`);
CREATE INDEX `idx_cmr_createdAt` ON `cmr_reports`(`createdAt`);
