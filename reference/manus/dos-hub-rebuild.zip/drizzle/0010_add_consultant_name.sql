ALTER TABLE `cmr_reports` ADD COLUMN `consultantName` varchar(255) AFTER `clientName`;
