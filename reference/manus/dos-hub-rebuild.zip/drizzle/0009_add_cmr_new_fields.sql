-- Add 10 new fields to cmr_reports table for enhanced tracking and analytics

ALTER TABLE `cmr_reports` 
ADD COLUMN `estimatedValue` decimal(12,2),
ADD COLUMN `currentConfidencePct` int,
ADD COLUMN `updateNotes` json,
ADD COLUMN `approvedStatus` enum('draft','submitted','approved','closed','lost') DEFAULT 'draft',
ADD COLUMN `closedAmount` decimal(12,2),
ADD COLUMN `closedDate` date,
ADD COLUMN `appointmentResult` enum('pending','sold','not_sold','follow_up','cancelled'),
ADD COLUMN `lastUpdatedAt` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
ADD COLUMN `lastUpdatedBy` int,
ADD COLUMN `allowQuickEdit` int DEFAULT 1;
