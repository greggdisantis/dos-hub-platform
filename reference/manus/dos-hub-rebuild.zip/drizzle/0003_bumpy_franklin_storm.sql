ALTER TABLE `cmr_reports` ADD `dealStatus` varchar(50);--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `purchaseConfidencePct` int;--> statement-breakpoint
ALTER TABLE `cmr_reports` ADD `estimatedContractValue` decimal(12,2);