-- Migration: 0012_screen_profile_rule_columns
-- Adds the three missing rule JSON columns and the manufacturer U-channel override map
-- to screen_calculation_profiles.
--
-- All columns are nullable so existing rows are unaffected (backward-safe).
-- The default-v1 seed INSERT/UPDATE is included at the bottom of this file.

ALTER TABLE `screen_calculation_profiles`
  ADD COLUMN `slopeRulesJson` json NULL
    COMMENT 'Slope warning thresholds: { levelThresholdInches, largeWarningThresholdInches }',
  ADD COLUMN `tbRulesJson` json NULL
    COMMENT 'Top-to-bottom difference warning: { largeWarningThresholdInches }',
  ADD COLUMN `biasRulesJson` json NULL
    COMMENT 'Bias warning threshold: { largeWarningThresholdInches }',
  ADD COLUMN `manufacturerUChannelThresholdsJson` json NULL
    COMMENT 'Per-manufacturer U-channel threshold overrides. Keys = manufacturer codes (lowercase). Example: { "magnatrack": 0.375, "dos-screens": 1.5 }';

-- ─── Seed / update the default-v1 profile row ────────────────────────────────
--
-- INSERT ... ON DUPLICATE KEY UPDATE is idempotent:
--   • First run: inserts the row.
--   • Subsequent runs: updates only the columns listed, leaving any manual
--     overrides to other columns intact.
--
-- Approved threshold values (source: DOS Hub Architecture V1, Section 19):
--   uChannelThreshold         = 0.250  (generic fallback; manufacturer map overrides per-mfr)
--   buildoutRulesJson         = none threshold 7/16", 1x2 up to 3/4", 2x2 up to 1.75", FLAG above
--   trackRulesJson            = track width 1.75"
--   extendedHoodRulesJson     = slope threshold 0.5"
--   toleranceRulesJson        = mismatch 0.125", height 0.125"
--   slopeRulesJson            = level < 0.0625" (1/16"), large warning > 1.0"
--   tbRulesJson               = large warning > 0.5"
--   biasRulesJson             = large warning > 0.5"
--   manufacturerUChannelThresholdsJson = { "magnatrack": 0.375, "dos-screens": 1.5 }

INSERT INTO `screen_calculation_profiles` (
  `code`,
  `manufacturerCode`,
  `version`,
  `status`,
  `uChannelThreshold`,
  `buildoutRulesJson`,
  `trackRulesJson`,
  `extendedHoodRulesJson`,
  `toleranceRulesJson`,
  `slopeRulesJson`,
  `tbRulesJson`,
  `biasRulesJson`,
  `manufacturerUChannelThresholdsJson`
) VALUES (
  'default-v1',
  'generic',
  1,
  'active',
  0.250,
  '{"noneThresholdInches": 0.4375, "oneX2ThresholdInches": 0.75, "twoX2ThresholdInches": 1.75}',
  '{"trackWidthInches": 1.75}',
  '{"slopeThresholdInches": 0.5}',
  '{"widthToleranceInches": 0.125, "heightToleranceInches": 0.125}',
  '{"levelThresholdInches": 0.0625, "largeWarningThresholdInches": 1.0}',
  '{"largeWarningThresholdInches": 0.5}',
  '{"largeWarningThresholdInches": 0.5}',
  '{"magnatrack": 0.375, "dos-screens": 1.5}'
)
ON DUPLICATE KEY UPDATE
  `uChannelThreshold`                  = VALUES(`uChannelThreshold`),
  `buildoutRulesJson`                  = VALUES(`buildoutRulesJson`),
  `trackRulesJson`                     = VALUES(`trackRulesJson`),
  `extendedHoodRulesJson`              = VALUES(`extendedHoodRulesJson`),
  `toleranceRulesJson`                 = VALUES(`toleranceRulesJson`),
  `slopeRulesJson`                     = VALUES(`slopeRulesJson`),
  `tbRulesJson`                        = VALUES(`tbRulesJson`),
  `biasRulesJson`                      = VALUES(`biasRulesJson`),
  `manufacturerUChannelThresholdsJson` = VALUES(`manufacturerUChannelThresholdsJson`),
  `updatedAt`                          = NOW();
