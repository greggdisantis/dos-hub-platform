-- Add conditional fields for CMR form refinements
ALTER TABLE `cmr_reports`
  ADD COLUMN `referredClientName` varchar(255) AFTER `leadSourceOther`,
  ADD COLUMN `contractorRefName` varchar(255) AFTER `referredClientName`,
  ADD COLUMN `otherDealStatus` varchar(255) AFTER `lostReason`,
  ADD COLUMN `otherMainMotivation` varchar(255) AFTER `mainMotivation`,
  ADD COLUMN `otherMainHesitation` varchar(255) AFTER `mainHesitation`,
  ADD COLUMN `otherClientResponse` varchar(255) AFTER `objectionOther`,
  ADD COLUMN `otherNextAction` varchar(255) AFTER `nextActions`;

-- Modify dealStatus enum to add "other"
ALTER TABLE `cmr_reports`
  MODIFY COLUMN `dealStatus` enum('working-on-design','proposal-presented','actively-considering','awaiting-financing','waiting-on-design','delayed','lost','other');

-- Modify clientResponse enum to add "other"
ALTER TABLE `cmr_reports`
  MODIFY COLUMN `clientResponse` enum('strong-alignment','neutral','price-focused','comparing-online','other');
