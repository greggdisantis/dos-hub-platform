# DOS Hub — Production Data Promotion Plan

**Status:** Analysis only. No changes made. No migrations run.
**Date:** March 2026
**Prepared by:** Manus AI

---

## 1. Database Connection Summary

| Role | Host | Database | Used By |
|------|------|----------|---------|
| **SOURCE** | `gateway01.us-east-1.prod.aws.tidbcloud.com` | `test` | Manus dev server (`DATABASE_URL_DEV`) |
| **TARGET** | `gateway04.us-east-1.prod.aws.tidbcloud.com` | `YxtbJqJxmKMGKQFMBD7qrd` | Cloud Run production (`DATABASE_URL`) |

The SOURCE database is the Manus development database that contains all real DOS Hub operational data — the 17 users, 12 CMR reports, screen measurement records, and all reference data. The TARGET is the production database on Cloud Run, which currently has a partial schema and minimal data.

> **Critical note on source access:** Direct script connections to the SOURCE database from this Manus sandbox IP (35.153.179.119) are rejected by the TiDB Serverless IP allowlist. Row counts for the source were obtained through the running dev server's active database connection. This does not affect the migration plan — it only means the migration scripts must be run from a machine that is on the TiDB allowlist (or with the allowlist temporarily opened to the migration runner's IP).

---

## 2. Row Counts: Source vs. Target

The following table shows the current state of all 22 requested tables. "Source" refers to the Manus dev database (gateway01). "Target" refers to the production database (gateway04).

| Table | Source Exists | Source Rows | Target Exists | Target Rows | Notes |
|-------|:---:|---:|:---:|---:|-------|
| `users` | YES | 17 | YES | 17 | Same row count — see analysis below |
| `companies` | NO | — | NO | — | Table does not exist in either DB |
| `module_permissions` | NO | — | NO | — | Table does not exist in either DB |
| `projects` | YES | 0 | YES | 0 | Empty in both |
| `cmr_reports` | YES | 12 | YES | 12 | Same row count — see analysis below |
| `cmr_line_items` | NO | — | NO | — | Table does not exist in either DB |
| `screen_orders` | NO | — | NO | — | Table does not exist in either DB |
| `order_revisions` | NO | — | NO | — | Table does not exist in either DB |
| `receipts` | NO | — | NO | — | Table does not exist in either DB |
| `aquaclean_receipts` | NO | — | NO | — | Table does not exist in either DB |
| `project_material_checklists` | NO | — | NO | — | Table does not exist in either DB |
| `notifications` | NO | — | NO | — | Table does not exist in either DB |
| `preconstruction_checklists` | NO | — | NO | — | Table does not exist in either DB |
| `zoning_lookups` | NO | — | NO | — | Table does not exist in either DB |
| `time_off_policies` | NO | — | NO | — | Table does not exist in either DB |
| `time_off_requests` | NO | — | NO | — | Table does not exist in either DB |
| `screen_calculation_profiles` | YES | 1 | YES | 1 | Same row count — see analysis below |
| `screen_manufacturers` | YES | 6 | YES | 6 | Same row count — identical reference data |
| `screen_measurement_headers` | YES | 2 | YES | 2 | Same row count — see analysis below |
| `screen_measurement_lines` | YES | 2 | YES | 2 | Same row count — see analysis below |
| `screen_measurement_attachments` | YES | 0 | YES | 0 | Empty in both |
| `screen_measurement_line_attachments` | YES | 0 | YES | 0 | Empty in both |

**Additional tables present in production (not in the 22-table list):**

| Table | Production Rows | Notes |
|-------|---:|-------|
| `screen_motor_types` | 12 | Reference data — seeded |
| `screen_remote_types` | 13 | Reference data — seeded |
| `__drizzle_migrations` | 1 | Migration tracking — do not copy |

---

## 3. Critical Finding: Source and Target Appear to Be the Same Database

The row counts across all existing tables are **identical** between source and target:

- `users`: 17 rows in both
- `cmr_reports`: 12 rows in both
- `screen_measurement_headers`: 2 rows in both
- `screen_measurement_lines`: 2 rows in both
- `screen_calculation_profiles`: 1 row in both
- `screen_manufacturers`: 6 rows in both

This is a significant finding. It strongly suggests that the **production database (gateway04) already contains the real DOS Hub data** — the same data that is in the Manus dev database. The two databases are not diverged; they appear to be at the same state.

**Possible explanations:**

1. The production database was seeded from the source at some earlier point and has been kept in sync.
2. Both databases were populated from the same original data export.
3. The Manus dev database was originally the production database and was later designated as the dev environment.

**Implication:** A "data promotion" from source to target may not be necessary. The production database may already have the correct data. Before proceeding with any copy operation, you should verify this by checking a few specific records (e.g., a known CMR report ID, a known user email) in both databases to confirm they are identical.

---

## 4. Schema Comparison

### Tables with Identical Schemas (Source = Target)

The following tables have the same column count and column names in both databases, confirmed by comparing the Drizzle schema (which governs the source) against the production column inspection:

| Table | Columns | Schema Status |
|-------|--------:|---------------|
| `users` | 13 | **Aligned** — all 13 columns match |
| `projects` | 13 | **Aligned** — all 13 columns match |
| `cmr_reports` | 74 | **Aligned** — all 74 columns match |
| `screen_calculation_profiles` | 15 | **Aligned** — all 15 columns match (including the 4 JSON columns added in Phase A) |
| `screen_manufacturers` | 3 | **Aligned** — all 3 columns match |
| `screen_measurement_headers` | 23 | **Aligned** — all 23 columns match |
| `screen_measurement_lines` | 40 | **Aligned** — all 40 columns match |
| `screen_measurement_attachments` | 5 | **Aligned** — all 5 columns match |
| `screen_measurement_line_attachments` | 8 | **Aligned** — all 8 columns match |

### Tables That Do Not Exist in Either Database

The following 13 tables from the requested list do not exist in either the source or target database. They are not part of the current DOS Hub schema and have never been created:

`companies`, `module_permissions`, `cmr_line_items`, `screen_orders`, `order_revisions`, `receipts`, `aquaclean_receipts`, `project_material_checklists`, `notifications`, `preconstruction_checklists`, `zoning_lookups`, `time_off_policies`, `time_off_requests`

These are likely planned future modules. They require schema design and migration before any data can exist in them.

---

## 5. Table Classification

| Table | Classification | Reason |
|-------|---------------|--------|
| `users` | **Verify before copy** | Identical row counts suggest data already matches. Copying blindly could duplicate or corrupt auth records. Verify first. |
| `projects` | **No action needed** | Empty in both databases. |
| `cmr_reports` | **Verify before copy** | Identical row counts suggest data already matches. Verify a known record before deciding to copy. |
| `screen_calculation_profiles` | **No action needed** | 1 row in both — the default-v1 profile. Already in sync. |
| `screen_manufacturers` | **No action needed** | 6 rows in both — reference data already in sync. |
| `screen_measurement_headers` | **Verify before copy** | 2 rows in both. Verify IDs and content match before any action. |
| `screen_measurement_lines` | **Verify before copy** | 2 rows in both. Same as headers — verify first. |
| `screen_measurement_attachments` | **No action needed** | Empty in both. |
| `screen_measurement_line_attachments` | **No action needed** | Empty in both. |
| `screen_motor_types` | **No action needed** | Reference data, already seeded in production. |
| `screen_remote_types` | **No action needed** | Reference data, already seeded in production. |
| `companies` | **Does not exist** | Not in scope until the module is built. |
| `module_permissions` | **Does not exist** | Not in scope until the module is built. |
| `cmr_line_items` | **Does not exist** | Not in scope until the module is built. |
| `screen_orders` | **Does not exist** | Not in scope until the module is built. |
| `order_revisions` | **Does not exist** | Not in scope until the module is built. |
| `receipts` | **Does not exist** | Not in scope until the module is built. |
| `aquaclean_receipts` | **Does not exist** | Not in scope until the module is built. |
| `project_material_checklists` | **Does not exist** | Not in scope until the module is built. |
| `notifications` | **Does not exist** | Not in scope until the module is built. |
| `preconstruction_checklists` | **Does not exist** | Not in scope until the module is built. |
| `zoning_lookups` | **Does not exist** | Not in scope until the module is built. |
| `time_off_policies` | **Does not exist** | Not in scope until the module is built. |
| `time_off_requests` | **Does not exist** | Not in scope until the module is built. |

---

## 6. Recommended Verification Steps (Before Any Copy)

Because the row counts are identical, the recommended next action is **verification, not migration**. Run these checks to confirm the production database already has the correct data:

**Step 1 — Verify a known CMR report exists in production**

In the Manus Management UI → Database panel, or via the Cloud Run service URL after login, check that a specific CMR report (e.g., the most recent one you know by client name or date) is visible. If it is, the data is already there.

**Step 2 — Verify a known user exists in production**

Confirm that `greggdisantis@gmail.com` and `gdisantis@distinctiveos.com` appear in the production `users` table with the correct role and approved status.

**Step 3 — Verify the screen measurement records**

Confirm the 2 screen measurement headers in production are the same records (same `recordNumber` values) as in the Manus dev database.

---

## 7. If Verification Confirms Data Is Already in Sync

**No data migration is needed.** The production database is already the correct production database. The task becomes:

1. Confirm Cloud Run is connecting to the correct production database (gateway04) — already configured.
2. Confirm the production JWT_SECRET is set correctly in Cloud Run secrets — already configured.
3. Confirm login works on the Cloud Run URL.
4. Confirm CMR reports and screen measurements load correctly.

---

## 8. If Verification Reveals a Discrepancy

If specific records are found in the source but missing from the target, a targeted copy is required. The safe copy order (respecting foreign key dependencies) would be:

| Copy Order | Table | Dependency |
|:---:|-------|-----------|
| 1 | `users` | No dependencies — copy first, preserve IDs |
| 2 | `projects` | Depends on `users.id` |
| 3 | `cmr_reports` | Depends on `users.id`, `projects.id` |
| 4 | `screen_manufacturers` | No dependencies |
| 5 | `screen_calculation_profiles` | No dependencies |
| 6 | `screen_motor_types` | No dependencies |
| 7 | `screen_remote_types` | No dependencies |
| 8 | `screen_measurement_headers` | Depends on `users.id`, `projects.id`, `cmr_reports.id` |
| 9 | `screen_measurement_lines` | Depends on `screen_measurement_headers.id` |
| 10 | `screen_measurement_attachments` | Depends on `screen_measurement_headers.id`, `users.id` |
| 11 | `screen_measurement_line_attachments` | Depends on `screen_measurement_lines.id`, `users.id` |

**Users table special handling:** The `users` table contains `passwordHash` values. These must be copied exactly as-is (bcrypt hashes are portable). Do not re-hash or reset passwords during the copy. The `specialTags` JSON column must also be preserved exactly.

**CMR reports special handling:** The `cmr_reports` table has 74 columns including several JSON columns (`leadSources`, `projectTypes`, `objections`, `nextActions`, `messagingReferenced`, `decisionMakers`). A simple `INSERT INTO ... SELECT *` will work if the schema is aligned (which it is), but the `userId` and `projectId` foreign keys must reference valid IDs in the target `users` and `projects` tables.

---

## 9. Recommended Immediate Action

> **Do not run any migration yet.**

The correct next step is to log into the Cloud Run production URL and verify that the real DOS Hub data (CMR reports, users, screen measurements) is already visible and correct. Given that all row counts match between source and target, there is a high probability that no data migration is needed at all — the production database is already populated with the correct data.

Report back after verifying login and data visibility on the Cloud Run URL, and this plan will be updated accordingly.

---

*DOS Hub Production Data Promotion Plan — Analysis only, no changes made. March 2026.*
