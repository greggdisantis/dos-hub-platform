import { describe, it, expect, beforeEach, afterEach } from "vitest";
import * as db from "./db";
import { hashPassword, verifyPassword } from "./_core/auth";
import { appRouter } from "./routers";

describe("Password Change Flow", () => {
  let testUserId: number;
  let testEmail: string;
  const tempPassword = "Temp1234!";
  const newPassword = "NewPassword123!";

  afterEach(async () => {
    // Clean up test user after each test to prevent DB accumulation
    if (testUserId) {
      try {
        await db.deleteUser(testUserId);
      } catch {
        // Ignore cleanup errors
      }
    }
  });

  beforeEach(async () => {
    // Generate unique email for each test
    testEmail = `test-pwd-${Date.now()}-${Math.random().toString(36).substr(2, 9)}@test.com`;

    // Create a test user with temporary password and passwordChangeRequired flag
    const tempHash = await hashPassword(tempPassword);
    await db.createUser({
      email: testEmail,
      firstName: "Test",
      lastName: "User",
      passwordHash: tempHash,
      role: "member",
      approved: 1,
    });

    // Get the user ID
    const user = await db.getUserByEmail(testEmail);
    testUserId = user!.id;

    // Set passwordChangeRequired flag
    await db.changePassword(testUserId, tempHash); // This will set passwordChangeRequired to 0
    // Manually set it back to 1 for testing
    const dbInstance = await db.getDb();
    if (dbInstance) {
      await dbInstance.execute(
        `UPDATE users SET passwordChangeRequired = 1 WHERE id = ${testUserId}`
      );
    }
  });

  it("should allow user to change password with correct current password", async () => {
    const caller = appRouter.createCaller({
      user: {
        id: testUserId,
        email: testEmail,
        firstName: "Test",
        lastName: "User",
        role: "member",
        approved: 1,
        passwordChangeRequired: 1,
        userType: "internal",
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: null,
        passwordHash: "",
      },
      req: {} as any,
      res: {} as any,
    });

    const result = await caller.auth.changePassword({
      currentPassword: tempPassword,
      newPassword: newPassword,
    });

    expect(result.success).toBe(true);

    // Verify new password works
    const user = await db.getUserById(testUserId);
    expect(user).toBeDefined();
    const passwordValid = await verifyPassword(newPassword, user!.passwordHash);
    expect(passwordValid).toBe(true);

    // Verify passwordChangeRequired flag is cleared
    expect(user!.passwordChangeRequired).toBe(0);
  });

  it("should reject incorrect current password", async () => {
    const caller = appRouter.createCaller({
      user: {
        id: testUserId,
        email: testEmail,
        firstName: "Test",
        lastName: "User",
        role: "member",
        approved: 1,
        passwordChangeRequired: 1,
        userType: "internal",
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: null,
        passwordHash: "",
      },
      req: {} as any,
      res: {} as any,
    });

    try {
      await caller.auth.changePassword({
        currentPassword: "WrongPassword123!",
        newPassword: newPassword,
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.code).toBe("UNAUTHORIZED");
      expect(error.message).toContain("Current password is incorrect");
    }
  });

  it("should require authentication to change password", async () => {
    const caller = appRouter.createCaller({
      user: null,
      req: {} as any,
      res: {} as any,
    });

    try {
      await caller.auth.changePassword({
        currentPassword: tempPassword,
        newPassword: newPassword,
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.code).toBe("UNAUTHORIZED");
    }
  });
});
