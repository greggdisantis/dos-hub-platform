import { COOKIE_NAME, ONE_YEAR_MS, isPermanentSuperAdmin } from "@shared/const";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import * as db from "./db";
import { getSessionCookieOptions } from "./_core/cookies";
import {
  createSessionToken,
  hashPassword,
  verifyPassword,
} from "./_core/auth";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { cmrRouter } from "./routers/cmr";
import { cmrExportRouter } from "./routers/cmr-export";
import { userRouter } from "./routers/user";
import { projectRouter } from "./routers/project";
import { screensRouter } from "./routers/screens";
import { migrationExportRouter } from "./routers/migration-export";
import { receiptsRouter } from "./routers/receipts";

export const appRouter = router({
  system: systemRouter,
  cmr: cmrRouter,
  cmrExport: cmrExportRouter,
  user: userRouter,
  project: projectRouter,
  auth: router({
    /**
     * Get current authenticated user
     */
    me: publicProcedure.query((opts) => opts.ctx.user),

    /**
     * Sign up a new user with email, first name, last name, and password
     */
    signup: publicProcedure
      .input(
        z.object({
          email: z.string().email("Invalid email address"),
          firstName: z.string().min(1, "First name is required"),
          lastName: z.string().min(1, "Last name is required"),
          password: z.string().min(8, "Password must be at least 8 characters"),
        })
      )
      .mutation(async ({ input }) => {
        // Check if user already exists (email-based identity)
        const existingUser = await db.getUserByEmail(input.email);
        if (existingUser) {
          throw new TRPCError({
            code: "CONFLICT",
            message: "User with this email already exists",
          });
        }

        // Hash password
        const passwordHash = await hashPassword(input.password);

        // Check if this is a permanent super-admin email
        const isSuperAdmin = isPermanentSuperAdmin(input.email);

        // Create user
        await db.createUser({
          email: input.email,
          firstName: input.firstName,
          lastName: input.lastName,
          passwordHash,
          role: isSuperAdmin ? "super-admin" : "pending",
          approved: isSuperAdmin ? 1 : 0,
        });

        // Get the newly created user
        const user = await db.getUserByEmail(input.email);
        if (!user) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to create user",
          });
        }

        return {
          success: true,
          message: isSuperAdmin
            ? "Super-admin account created and approved."
            : "Account created successfully. Please wait for admin approval.",
          user: {
            id: user.id,
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName,
            role: user.role,
            approved: user.approved === 1,
          },
        };
      }),

    /**
     * Login with email and password
     */
    login: publicProcedure
      .input(
        z.object({
          email: z.string().email("Invalid email address"),
          password: z.string().min(1, "Password is required"),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // Find user by email (email-based identity)
        const user = await db.getUserByEmail(input.email);
        if (!user) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "Invalid email or password",
          });
        }

        // Verify password
        const passwordValid = await verifyPassword(input.password, user.passwordHash);
        if (!passwordValid) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "Invalid email or password",
          });
        }

        // Check if user is approved
        if (!user.approved) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "Your account is pending admin approval",
          });
        }

        // Create session token
        const sessionToken = await createSessionToken(user.id, user.email, {
          expiresInMs: ONE_YEAR_MS,
        });

        // Set session cookie
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, sessionToken, {
          ...cookieOptions,
          maxAge: ONE_YEAR_MS,
        });

        // Update last signed in
        await db.updateLastSignedIn(user.id);

        return {
          success: true,
          user: {
            id: user.id,
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName,
            role: user.role,
            approved: user.approved === 1,
            passwordChangeRequired: user.passwordChangeRequired === 1,
          },
        };
      }),

    /**
     * Update user profile (firstName, lastName)
     */
    updateProfile: protectedProcedure
      .input(
        z.object({
          firstName: z.string().min(1, "First name is required"),
          lastName: z.string().min(1, "Last name is required"),
        })
      )
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "User not authenticated",
          });
        }

        await db.updateUserProfile(ctx.user.id, {
          firstName: input.firstName.trim(),
          lastName: input.lastName.trim(),
        });

        const updatedUser = await db.getUserById(ctx.user.id);
        if (!updatedUser) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to update profile",
          });
        }

        return {
          success: true,
          user: {
            id: updatedUser.id,
            email: updatedUser.email,
            firstName: updatedUser.firstName,
            lastName: updatedUser.lastName,
            role: updatedUser.role,
            approved: updatedUser.approved === 1,
          },
        };
      }),

    /**
     * Change password and clear passwordChangeRequired flag
     */
    changePassword: protectedProcedure
      .input(
        z.object({
          currentPassword: z.string().min(1, "Current password is required"),
          newPassword: z.string().min(8, "New password must be at least 8 characters"),
        })
      )
      .mutation(async ({ input, ctx }) => {
        if (!ctx.user) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "User not authenticated",
          });
        }

        // Get user with password hash
        const user = await db.getUserById(ctx.user.id);
        if (!user) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "User not found",
          });
        }

        // Verify current password
        const passwordValid = await verifyPassword(
          input.currentPassword,
          user.passwordHash
        );
        if (!passwordValid) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "Current password is incorrect",
          });
        }

        // Hash new password
        const newPasswordHash = await hashPassword(input.newPassword);

        // Update password and clear flag
        await db.changePassword(ctx.user.id, newPasswordHash);

        return {
          success: true,
          message: "Password changed successfully",
        };
      }),

    /**
     * Logout current user
     */
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Admin procedures
  admin: router({
    /**
     * Get all pending users (super-admin only)
     */
    getPendingUsers: protectedProcedure.query(async ({ ctx }) => {
      // Check if user is super-admin
      if (ctx.user?.role !== "super-admin") {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "Only super-admins can access this",
        });
      }

      return await db.getPendingUsers();
    }),

    /**
     * Approve a user (super-admin only)
     */
    approveUser: protectedProcedure
      .input(
        z.object({
          userId: z.number(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // Check if user is super-admin
        if (ctx.user?.role !== "super-admin") {
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "Only super-admins can approve users",
          });
        }

        // Update user
        await db.updateUserApproval(input.userId, true);

        return {
          success: true,
          message: "User approved",
        };
      }),

    /**
     * Reject a user (super-admin only)
     */
    rejectUser: protectedProcedure
      .input(
        z.object({
          userId: z.number(),
        })
      )
      .mutation(async ({ input, ctx }) => {
        // Check if user is super-admin
        if (ctx.user?.role !== "super-admin") {
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "Only super-admins can reject users",
          });
        }

        // Delete user (or mark as rejected)
        await db.deleteUser(input.userId);

        return {
          success: true,
          message: "User rejected",
        };
      }),
  }),

  screens: screensRouter,
  migrationExport: migrationExportRouter,
  receipts: receiptsRouter,
  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
