/**
 * File storage helpers — environment-aware dual-mode implementation.
 *
 * DEV / PREVIEW (Manus platform):
 *   Uses the Manus built-in Forge storage proxy.
 *   Required env vars: BUILT_IN_FORGE_API_URL, BUILT_IN_FORGE_API_KEY
 *
 * PRODUCTION (Cloud Run / AWS):
 *   Uses direct AWS S3 SDK.
 *   Required env vars: AWS_REGION, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, S3_BUCKET_NAME
 *
 * Mode selection: if AWS_REGION + AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY are all set,
 * the AWS S3 path is used. Otherwise the Manus Forge proxy is used.
 *
 * Public API is identical in both modes:
 *   storagePut(relKey, data, contentType?) → { key, url }
 *   storageGet(relKey, expiresIn?)         → { key, url }
 */

import { ENV } from "./_core/env";

// ---------------------------------------------------------------------------
// Helpers shared by both modes
// ---------------------------------------------------------------------------

function normalizeKey(relKey: string): string {
  return relKey.replace(/^\/+/, "");
}

function isAwsConfigured(): boolean {
  return !!(
    process.env.AWS_REGION &&
    process.env.AWS_ACCESS_KEY_ID &&
    process.env.AWS_SECRET_ACCESS_KEY &&
    process.env.S3_BUCKET_NAME
  );
}

// ---------------------------------------------------------------------------
// Mode A: Manus Forge proxy (dev / preview)
// ---------------------------------------------------------------------------

function getForgeConfig(): { baseUrl: string; apiKey: string } {
  const baseUrl = ENV.forgeApiUrl;
  const apiKey = ENV.forgeApiKey;
  if (!baseUrl || !apiKey) {
    throw new Error(
      "Storage proxy credentials missing: set BUILT_IN_FORGE_API_URL and BUILT_IN_FORGE_API_KEY"
    );
  }
  return { baseUrl: baseUrl.replace(/\/+$/, ""), apiKey };
}

function ensureTrailingSlash(value: string): string {
  return value.endsWith("/") ? value : `${value}/`;
}

function buildAuthHeaders(apiKey: string): HeadersInit {
  return { Authorization: `Bearer ${apiKey}` };
}

function toFormData(
  data: Buffer | Uint8Array | string,
  contentType: string,
  fileName: string
): FormData {
  const blob =
    typeof data === "string"
      ? new Blob([data], { type: contentType })
      : new Blob([data as any], { type: contentType });
  const form = new FormData();
  form.append("file", blob, fileName || "file");
  return form;
}

async function forgePut(
  relKey: string,
  data: Buffer | Uint8Array | string,
  contentType: string
): Promise<{ key: string; url: string }> {
  const { baseUrl, apiKey } = getForgeConfig();
  const key = normalizeKey(relKey);

  const uploadUrl = new URL("v1/storage/upload", ensureTrailingSlash(baseUrl));
  uploadUrl.searchParams.set("path", key);

  const formData = toFormData(data, contentType, key.split("/").pop() ?? key);

  const response = await fetch(uploadUrl, {
    method: "POST",
    headers: buildAuthHeaders(apiKey),
    body: formData,
  });

  if (!response.ok) {
    const message = await response.text().catch(() => response.statusText);
    throw new Error(
      `Storage upload failed (${response.status} ${response.statusText}): ${message}`
    );
  }

  const url = (await response.json()).url;
  return { key, url };
}

async function forgeGet(relKey: string): Promise<{ key: string; url: string }> {
  const { baseUrl, apiKey } = getForgeConfig();
  const key = normalizeKey(relKey);

  const downloadApiUrl = new URL(
    "v1/storage/downloadUrl",
    ensureTrailingSlash(baseUrl)
  );
  downloadApiUrl.searchParams.set("path", key);

  const response = await fetch(downloadApiUrl, {
    method: "GET",
    headers: buildAuthHeaders(apiKey),
  });

  if (!response.ok) {
    const message = await response.text().catch(() => response.statusText);
    throw new Error(
      `Storage get URL failed (${response.status} ${response.statusText}): ${message}`
    );
  }

  const url = (await response.json()).url;
  return { key, url };
}

// ---------------------------------------------------------------------------
// Mode B: Direct AWS S3 (production / Cloud Run)
// ---------------------------------------------------------------------------

async function awsPut(
  relKey: string,
  data: Buffer | Uint8Array | string,
  contentType: string
): Promise<{ key: string; url: string }> {
  // Dynamic import so @aws-sdk packages are only loaded when AWS is configured
  const { S3Client, PutObjectCommand } = await import("@aws-sdk/client-s3");

  const region = process.env.AWS_REGION!;
  const bucket = process.env.S3_BUCKET_NAME!;
  const key = normalizeKey(relKey);

  const client = new S3Client({
    region,
    credentials: {
      accessKeyId: process.env.AWS_ACCESS_KEY_ID!,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
    },
  });

  const body: Buffer =
    typeof data === "string"
      ? Buffer.from(data, "utf-8")
      : Buffer.from(data as Uint8Array);

  await client.send(
    new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      Body: body,
      ContentType: contentType,
    })
  );

  const url = `https://${bucket}.s3.${region}.amazonaws.com/${key}`;
  return { key, url };
}

async function awsGet(
  relKey: string,
  expiresIn: number
): Promise<{ key: string; url: string }> {
  const { S3Client, GetObjectCommand } = await import("@aws-sdk/client-s3");
  const { getSignedUrl } = await import("@aws-sdk/s3-request-presigner");

  const region = process.env.AWS_REGION!;
  const bucket = process.env.S3_BUCKET_NAME!;
  const key = normalizeKey(relKey);

  const client = new S3Client({
    region,
    credentials: {
      accessKeyId: process.env.AWS_ACCESS_KEY_ID!,
      secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
    },
  });

  const url = await getSignedUrl(
    client,
    new GetObjectCommand({ Bucket: bucket, Key: key }),
    { expiresIn }
  );

  return { key, url };
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------

/**
 * Upload bytes to storage and return the object URL.
 *
 * @param relKey       Relative storage key, e.g. "receipts/user-123/photo.png"
 * @param data         File content as Buffer, Uint8Array, or string
 * @param contentType  MIME type, defaults to "application/octet-stream"
 * @returns            { key, url }
 */
export async function storagePut(
  relKey: string,
  data: Buffer | Uint8Array | string,
  contentType = "application/octet-stream"
): Promise<{ key: string; url: string }> {
  if (isAwsConfigured()) {
    return awsPut(relKey, data, contentType);
  }
  return forgePut(relKey, data, contentType);
}

/**
 * Get a download URL for a stored object.
 *
 * @param relKey      Relative storage key
 * @param expiresIn   URL lifetime in seconds (default: 1 hour). Only used in AWS mode.
 * @returns           { key, url }
 */
export async function storageGet(
  relKey: string,
  expiresIn = 3600
): Promise<{ key: string; url: string }> {
  if (isAwsConfigured()) {
    return awsGet(relKey, expiresIn);
  }
  return forgeGet(relKey);
}
