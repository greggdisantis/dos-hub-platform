/**
 * DOS Hub — Shared PDF Render Function
 *
 * Single entry point for all HTML-to-PDF generation.
 * All modules call this — no module should touch Puppeteer directly.
 *
 * Usage:
 *   import { renderToPdf } from './render';
 *   const html = buildSomeHtml(data);
 *   const pdfBuffer = await renderToPdf(html);
 */
import { getBrowser } from './engine';

export interface RenderToPdfOptions {
  /** Page format — defaults to 'Letter' (8.5 × 11 in) */
  format?: 'Letter' | 'A4';
  /** Print background colors and images — defaults to true */
  printBackground?: boolean;
  /** Page margins in CSS units — defaults to reasonable print margins */
  margin?: {
    top?: string;
    right?: string;
    bottom?: string;
    left?: string;
  };
}

const DEFAULT_OPTIONS: Required<RenderToPdfOptions> = {
  format: 'Letter',
  printBackground: true,
  margin: {
    top: '0.5in',
    right: '0.6in',
    bottom: '0.6in',
    left: '0.6in',
  },
};

/**
 * Render an HTML string to a PDF buffer using the shared Puppeteer engine.
 *
 * The HTML should be a complete document (including <html>, <head>, <style>).
 * The shared base.css should be embedded in the HTML by the module template.
 */
export async function renderToPdf(
  html: string,
  options?: RenderToPdfOptions,
): Promise<Buffer> {
  const opts = { ...DEFAULT_OPTIONS, ...options };
  const margin = { ...DEFAULT_OPTIONS.margin, ...opts.margin };

  const browser = await getBrowser();
  const page = await browser.newPage();

  try {
    // Set content and wait for any web fonts / images to load
    await page.setContent(html, { waitUntil: 'networkidle0' });

    // Generate PDF
    const pdfUint8 = await page.pdf({
      format: opts.format,
      printBackground: opts.printBackground,
      margin,
      // Prefer CSS @page rules for headers/footers over Puppeteer templates
      displayHeaderFooter: false,
    });

    // Convert Uint8Array to Buffer for Node.js compatibility
    return Buffer.from(pdfUint8);
  } finally {
    await page.close();
  }
}
