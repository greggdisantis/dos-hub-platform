/**
 * Tests for the Puppeteer-based CMR PDF export pipeline
 *
 * Validates:
 * - buildCmrHtml produces valid HTML with all required sections
 * - getCmrPdfFilename formats correctly
 * - renderToPdf produces a valid PDF buffer
 * - base.css loads without error
 */
import { describe, it, expect, afterAll } from 'vitest';
import { buildCmrHtml, getCmrPdfFilename } from './modules/cmr';
import { renderToPdf } from './render';
import { closeBrowser } from './engine';
import type { CmrPdfData } from './types';

const sampleData: CmrPdfData = {
  report: {
    id: 999,
    clientName: 'Test Client',
    consultantName: 'Jane Doe',
    appointmentDate: '2026-03-03',
    appointmentType: 'in-person',
    address: '123 Main St, Dallas, TX 75201',
    clientType: 'residential',
    leadSources: ['in-home', 'referral'],
    status: 'submitted',
    dealStatus: 'proposal-presented',
    closeTimeline: '31-60',
    lastConversationSummary: 'Discussed options for outdoor pergola.',
    purchaseConfidencePct: 72,
    originalPcPct: 55,
    estimatedContractValue: 85000,
    decisionMakers: 'Husband and Wife',
    mainMotivation: 'Outdoor entertaining',
    mainHesitation: 'Budget concerns',
    financingDiscussed: 1,
    financingReaction: 'interested',
    valueCommunicated: ['lifetime-warranty', 'custom-design'],
    clientResponse: 'strong-alignment',
    objectionNotes: 'Competitor quote was lower.',
    nextActions: ['Send revised proposal', 'Schedule follow-up'],
    leadQuality: 'excellent',
    expectationAlignment: 'yes',
    budgetAlignment: 'slightly-below',
  },
  actionItems: [],
  generatedBy: {
    firstName: 'Jane',
    lastName: 'Doe',
    email: 'jane@distinctiveos.com',
  },
};

afterAll(async () => {
  await closeBrowser();
});

describe('buildCmrHtml', () => {
  it('returns a complete HTML document', () => {
    const html = buildCmrHtml(sampleData);
    expect(html).toContain('<!DOCTYPE html>');
    expect(html).toContain('</html>');
  });

  it('includes the company name in the header', () => {
    const html = buildCmrHtml(sampleData);
    expect(html).toContain('Distinctive Outdoor Structures');
  });

  it('includes the report title', () => {
    const html = buildCmrHtml(sampleData);
    expect(html).toContain('Client Meeting Report');
  });

  it('includes the PC% badge when purchaseConfidencePct is set', () => {
    const html = buildCmrHtml(sampleData);
    expect(html).toContain('72% PC');
    expect(html).toContain('dos-badge');
  });

  it('omits the PC% badge div when purchaseConfidencePct is undefined', () => {
    const noPcData = {
      ...sampleData,
      report: { ...sampleData.report, purchaseConfidencePct: undefined },
    };
    const html = buildCmrHtml(noPcData);
    // The badge div should not appear (CSS class definition in base.css is fine)
    expect(html).not.toContain('% PC</div>');
  });

  it('includes the client name in the client card', () => {
    const html = buildCmrHtml(sampleData);
    expect(html).toContain('Test Client');
  });

  it('includes all 6 section headers', () => {
    const html = buildCmrHtml(sampleData);
    expect(html).toContain('CLIENT INFORMATION');
    expect(html).toContain('DEAL STATUS');
    expect(html).toContain('PURCHASE CONFIDENCE');
    expect(html).toContain('VALUE COMMUNICATED');
    expect(html).toContain('OBJECTIONS');
    expect(html).toContain('NEXT STEPS');
    expect(html).toContain('MARKETING FEEDBACK');
  });

  it('formats estimated value with commas and no decimals', () => {
    const html = buildCmrHtml(sampleData);
    expect(html).toContain('$85,000');
  });

  it('formats appointment date correctly', () => {
    const html = buildCmrHtml(sampleData);
    expect(html).toContain('Mar 3, 2026');
  });

  it('includes the footer with generated date', () => {
    const html = buildCmrHtml(sampleData);
    expect(html).toContain('dos-footer');
    expect(html).toContain('Generated');
  });

  it('embeds the shared base.css', () => {
    const html = buildCmrHtml(sampleData);
    expect(html).toContain('--dos-navy');
    expect(html).toContain('dos-section-header');
  });

  it('renders next actions as bullet points', () => {
    const html = buildCmrHtml(sampleData);
    expect(html).toContain('Send revised proposal');
    expect(html).toContain('Schedule follow-up');
  });
});

describe('getCmrPdfFilename', () => {
  it('formats filename as ClientName_MM-DD-YYYY.pdf', () => {
    const filename = getCmrPdfFilename('Anil Murthy', '2026-03-03');
    expect(filename).toBe('Anil_Murthy_03-03-2026.pdf');
  });

  it('handles missing appointment date by using current date', () => {
    const filename = getCmrPdfFilename('John Smith');
    expect(filename).toMatch(/^John_Smith_\d{2}-\d{2}-\d{4}\.pdf$/);
  });

  it('sanitizes special characters from client name', () => {
    const filename = getCmrPdfFilename("O'Brien & Sons", '2026-01-15');
    expect(filename).toBe('OBrien_Sons_01-15-2026.pdf');
  });

  it('replaces multiple spaces with single underscore', () => {
    const filename = getCmrPdfFilename('First  Middle  Last', '2026-06-01');
    expect(filename).toBe('First_Middle_Last_06-01-2026.pdf');
  });
});

describe('renderToPdf', () => {
  it('produces a valid PDF buffer from HTML', async () => {
    const html = buildCmrHtml(sampleData);
    const pdfBuffer = await renderToPdf(html);

    expect(pdfBuffer).toBeInstanceOf(Buffer);
    expect(pdfBuffer.length).toBeGreaterThan(1000);

    // Check PDF magic bytes
    const magic = pdfBuffer.subarray(0, 5).toString('ascii');
    expect(magic).toBe('%PDF-');
  }, 30000); // 30s timeout for Puppeteer
});
