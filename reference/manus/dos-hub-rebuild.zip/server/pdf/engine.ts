/**
 * DOS Hub — Shared PDF Export Engine
 *
 * Puppeteer singleton that launches Chromium once per server process
 * and reuses the browser instance across all PDF render requests.
 *
 * Usage:
 *   import { getBrowser } from './engine';
 *   const browser = await getBrowser();
 *   const page = await browser.newPage();
 */
import puppeteer, { type Browser } from 'puppeteer-core';
import { existsSync } from 'node:fs';

/**
 * Chromium candidate paths in priority order.
 *
 * ONLY real ELF binaries are listed — shell wrapper scripts are excluded
 * because Puppeteer requires an executable binary, not a shell launcher.
 *
 * Priority:
 *   1. CHROMIUM_PATH env var (operator override — highest priority)
 *   2. /usr/lib/chromium/chromium        — Debian Bookworm real binary (Cloud Run / node:22-slim)
 *   3. /usr/lib/chromium-browser/chromium-browser — Ubuntu Jammy real binary (Manus sandbox)
 *   4. /usr/bin/google-chrome-stable     — Google Chrome stable (some Cloud Run images)
 *   5. /usr/bin/google-chrome            — Google Chrome fallback
 *   6. /snap/bin/chromium                — Snap install fallback
 *
 * Intentionally excluded (shell wrappers — not valid Puppeteer executablePath):
 *   /usr/bin/chromium          — shell wrapper on Debian Bookworm
 *   /usr/bin/chromium-browser  — shell wrapper on Ubuntu Jammy
 */
const CHROMIUM_CANDIDATES = [
  process.env.CHROMIUM_PATH,
  '/usr/lib/chromium/chromium',                     // Debian Bookworm real binary (Cloud Run / node:22-slim)
  '/usr/lib/chromium-browser/chromium-browser',     // Ubuntu Jammy real binary (Manus sandbox)
  '/usr/bin/google-chrome-stable',
  '/usr/bin/google-chrome',
  '/snap/bin/chromium',
].filter(Boolean) as string[];

const CHROMIUM_PATH =
  CHROMIUM_CANDIDATES.find((p) => existsSync(p)) ??
  '/usr/lib/chromium/chromium'; // last-resort default — will fail with a clear path in logs

// Diagnostic: log resolved path and whether the binary exists at module load time
console.log('[PDF] CHROMIUM_PATH =', CHROMIUM_PATH);
console.log('[PDF] exists =', existsSync(CHROMIUM_PATH));

const LAUNCH_ARGS = [
  '--no-sandbox',
  '--disable-setuid-sandbox',
  '--disable-dev-shm-usage',
  '--disable-gpu',
  '--disable-extensions',
  '--font-render-hinting=none',
];

let browserInstance: Browser | null = null;
let launching: Promise<Browser> | null = null;

/**
 * Return a shared Chromium browser instance.
 * Lazily launches on first call; reuses on subsequent calls.
 * If the browser has been closed or disconnected, re-launches automatically.
 */
export async function getBrowser(): Promise<Browser> {
  if (browserInstance && browserInstance.connected) {
    return browserInstance;
  }

  // Prevent concurrent launch attempts
  if (launching) {
    return launching;
  }

  // Diagnostic: log the path used at launch time
  console.log('[PDF] launching puppeteer with', CHROMIUM_PATH);

  launching = puppeteer.launch({
    executablePath: CHROMIUM_PATH,
    headless: true,
    args: LAUNCH_ARGS,
  });

  try {
    browserInstance = await launching;
    return browserInstance;
  } finally {
    launching = null;
  }
}

/**
 * Gracefully close the browser (call on server shutdown if desired).
 */
export async function closeBrowser(): Promise<void> {
  if (browserInstance) {
    await browserInstance.close().catch(() => {});
    browserInstance = null;
  }
}
