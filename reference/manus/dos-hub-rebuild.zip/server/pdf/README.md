# DOS Hub — Shared PDF Export System

Puppeteer-based HTML-to-PDF rendering engine used by all DOS Hub modules.

## Architecture

Each module provides an **HTML template builder** that returns a complete HTML document string. The shared engine renders it to a PDF buffer using Chromium (via Puppeteer). No module touches Puppeteer directly.

```
Router → buildModuleHtml(data) → renderToPdf(html) → Buffer
```

## File Structure

```
server/pdf/
├── engine.ts          Puppeteer singleton (launches Chromium once, reuses)
├── render.ts          renderToPdf(html, options?) → Buffer
├── base.css           Shared print stylesheet (brand colors, sections, rows)
├── types.ts           TypeScript interfaces for all module data shapes
├── README.md          This file
└── modules/
    └── cmr.ts         CMR HTML template builder + filename helper
```

## Adding a New Module

1. Create `server/pdf/modules/<name>.ts`
2. Export a `build<Name>Html(data: <Name>PdfData): string` function
3. Use the CSS classes from `base.css` (embedded via `fs.readFileSync`)
4. In the export router, call `build<Name>Html(data)` then `renderToPdf(html)`

No Puppeteer setup, no new CSS framework, no page-break logic needed.

## Shared CSS Classes

| Class | Purpose |
|---|---|
| `.dos-header-band` | Full-width navy header band |
| `.dos-company-name` | Company name in header (16pt bold) |
| `.dos-report-title` | Report subtitle in header (10pt) |
| `.dos-badge` | Green pill badge (e.g. PC%) |
| `.dos-client-card` | Gray card with client name + meta line |
| `.dos-section` | Section wrapper (page-break-inside: avoid) |
| `.dos-section-header` | Navy ALL-CAPS section title bar |
| `.dos-row` | Two-column label/value data row |
| `.dos-label` | Left column (35%, gray text) |
| `.dos-value` | Right column (65%, bold dark text) |
| `.dos-footer` | Fixed footer at page bottom |

## Brand Tokens (CSS Variables)

```css
--dos-navy:       #1e3a5f
--dos-green:      #22c55e
--dos-gray-bg:    #f1f5f9
--dos-gray-label: #64748b
--dos-gray-line:  #e2e8f0
--dos-text:       #1a1a1a
```

## Filename Convention

All DOS Hub PDF filenames follow: `ClientName_MM-DD-YYYY.pdf` using the relevant date field (e.g. appointment date for CMR).

## Render Options

```ts
renderToPdf(html, {
  format: 'Letter',       // or 'A4'
  printBackground: true,
  margin: { top: '0.5in', right: '0.6in', bottom: '0.6in', left: '0.6in' },
});
```
