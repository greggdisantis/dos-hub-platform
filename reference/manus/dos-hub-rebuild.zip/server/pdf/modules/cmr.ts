/**
 * CMR PDF Export — HTML Template Builder
 *
 * Builds a complete HTML document string for the CMR report using the
 * shared DOS Hub PDF stylesheet (inlined). The HTML is then
 * rendered to PDF by the shared Puppeteer engine (render.ts).
 *
 * Layout matches the approved legacy-style report:
 *   - Full-width navy header band: company name left, PC% badge right
 *   - Client summary card: large name + date · consultant · estimated value
 *   - Section blocks: dark navy header bar (ALL-CAPS) + two-column label/value rows
 *   - Light gray footer on every page
 *
 * Filename format: ClientName_MM-DD-YYYY.pdf  (uses appointment date)
 */

import { CmrPdfData } from '../types';

// ── Shared stylesheet (inlined for production build compatibility) ────────────

const BASE_CSS = `/*
 * DOS Hub — Shared PDF Print Stylesheet
 *
 * Embedded into every PDF template via the module's buildHtml function.
 * Defines brand colors, typography, section headers, data rows,
 * page-break behavior, header band, client card, and footer.
 *
 * Modules add their own <style> block AFTER this for overrides.
 */

/* ── Reset ─────────────────────────────────────────────────────────── */

*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

/* ── Page Setup ────────────────────────────────────────────────────── */

@page {
  size: letter;
  margin: 0;
}

html, body {
  width: 8.5in;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto,
               'Helvetica Neue', Arial, sans-serif;
  font-size: 10pt;
  line-height: 1.4;
  color: #1a1a1a;
  background: #fff;
  -webkit-print-color-adjust: exact;
  print-color-adjust: exact;
}

/* ── Brand Tokens ──────────────────────────────────────────────────── */

:root {
  --dos-navy:       #1e3a5f;
  --dos-navy-light: #2a4d72;
  --dos-green:      #22c55e;
  --dos-green-dark: #16a34a;
  --dos-gray-bg:    #f1f5f9;
  --dos-gray-label: #64748b;
  --dos-gray-line:  #e2e8f0;
  --dos-white:      #ffffff;
  --dos-text:       #1a1a1a;
  --dos-text-light: #cbd5e1;
}

/* ── Page Content Wrapper ──────────────────────────────────────────── */

.dos-page {
  padding: 0 0.6in;
}

/* ── Header Band ───────────────────────────────────────────────────── */

.dos-header-band {
  background: var(--dos-navy);
  color: var(--dos-white);
  padding: 14px 0.6in;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.dos-header-left {
  display: flex;
  flex-direction: column;
}

.dos-company-name {
  font-size: 16pt;
  font-weight: 700;
  letter-spacing: 0.01em;
}

.dos-report-title {
  font-size: 10pt;
  font-weight: 400;
  color: var(--dos-text-light);
  margin-top: 2px;
}

/* ── Badge (e.g. PC%) ──────────────────────────────────────────────── */

.dos-badge {
  background: var(--dos-green);
  color: var(--dos-white);
  font-size: 13pt;
  font-weight: 700;
  padding: 6px 18px;
  border-radius: 6px;
  white-space: nowrap;
}

/* ── Client Card ───────────────────────────────────────────────────── */

.dos-client-card {
  background: var(--dos-gray-bg);
  border-left: 4px solid var(--dos-navy);
  padding: 14px 18px;
  margin: 18px 0 12px 0;
}

.dos-client-name {
  font-size: 16pt;
  font-weight: 700;
  color: var(--dos-text);
}

.dos-client-meta {
  font-size: 9pt;
  color: var(--dos-gray-label);
  margin-top: 4px;
}

.dos-client-meta .dos-sep {
  margin: 0 6px;
}

/* ── Section ───────────────────────────────────────────────────────── */

.dos-section {
  margin-top: 16px;
  page-break-inside: avoid;
}

.dos-section-header {
  background: var(--dos-navy);
  color: var(--dos-white);
  font-size: 9pt;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  padding: 7px 14px;
}

/* ── Data Rows (label / value) ─────────────────────────────────────── */

.dos-row {
  display: flex;
  border-bottom: 1px solid var(--dos-gray-line);
  padding: 7px 14px;
  page-break-inside: avoid;
}

.dos-row:last-child {
  border-bottom: none;
}

.dos-label {
  width: 35%;
  min-width: 35%;
  font-size: 9pt;
  color: var(--dos-gray-label);
}

.dos-value {
  width: 65%;
  font-size: 9pt;
  font-weight: 600;
  color: var(--dos-text);
  word-wrap: break-word;
  white-space: pre-wrap;
}

/* ── Footer ────────────────────────────────────────────────────────── */

.dos-footer {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  background: var(--dos-gray-bg);
  text-align: center;
  font-size: 7.5pt;
  color: var(--dos-gray-label);
  padding: 8px 0.6in;
}

/* ── Utility ───────────────────────────────────────────────────────── */

.dos-spacer {
  height: 8px;
}

.dos-page-break {
  page-break-before: always;
}

/* Ensure footer does not overlap content */
.dos-content {
  padding-bottom: 40px;
}`;

// ── Formatting helpers ───────────────────────────────────────────────────────

function esc(s: string): string {
  if (!s) return '';
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function fmtCurrency(val: string | number | null | undefined): string {
  if (val === null || val === undefined) return '—';
  const num = typeof val === 'string' ? parseFloat(val) : val;
  if (isNaN(num)) return '—';
  return `$${num.toLocaleString('en-US', { maximumFractionDigits: 0 })}`;
}

function fmtDate(dateInput: string | Date | null | undefined): string {
  if (!dateInput) return '—';
  let d: Date;
  if (dateInput instanceof Date) {
    d = dateInput;
  } else {
    // Parse as local noon to avoid timezone offset
    const [year, month, day] = dateInput.split('-');
    d = new Date(`${year}-${month}-${day}T12:00:00`);
  }
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function fmtDateFilename(dateInput: string | Date | null | undefined): string {
  if (!dateInput) {
    const now = new Date();
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const d = String(now.getDate()).padStart(2, '0');
    const y = now.getFullYear();
    return `${m}-${d}-${y}`;
  }
  let dateStr: string;
  if (dateInput instanceof Date) {
    const m = String(dateInput.getMonth() + 1).padStart(2, '0');
    const d = String(dateInput.getDate()).padStart(2, '0');
    const y = dateInput.getFullYear();
    dateStr = `${y}-${m}-${d}`;
  } else {
    dateStr = dateInput;
  }
  const [year, month, day] = dateStr.split('-');
  return `${month}-${day}-${year}`;
}

function fmtDealStatus(val: string | null | undefined): string {
  if (!val) return '—';
  const map: Record<string, string> = {
    'not-started': 'Not Started',
    'early-stage': 'Early Stage',
    'proposal-presented': 'Proposal Presented',
    'negotiation': 'Negotiation',
    'closed-won': 'Closed Won',
    'closed-lost': 'Closed Lost',
  };
  return map[val] || val;
}

function fmtCloseTimeline(val: string | null | undefined): string {
  if (!val) return '—';
  const map: Record<string, string> = {
    'immediate': 'Immediate',
    '1-7': '1–7 days',
    '8-14': '8–14 days',
    '15-30': '15–30 days',
    '31-60': '31–60 days',
    '60-plus': '60+ days',
  };
  return map[val] || val;
}

function fmtClientType(val: string | null | undefined): string {
  if (!val) return '—';
  const map: Record<string, string> = {
    'residential': 'Residential',
    'commercial': 'Commercial',
    'other': 'Other',
  };
  return map[val] || val;
}

function row(label: string, value: string): string {
  return `<div class="dos-row"><div class="dos-label">${esc(label)}</div><div class="dos-value">${esc(value)}</div></div>`;
}

function section(title: string, rows: [string, string][]): string {
  return `<div class="dos-section">
  <div class="dos-section-header">${esc(title)}</div>
  ${rows.map(([l, v]) => row(l, v)).join('\n  ')}
</div>`;
}

// ── Public API ───────────────────────────────────────────────────────────────

/**
 * Build a complete HTML document for the CMR report
 */
export function buildCmrHtml(data: CmrPdfData): string {
  const r = data.report;
  const footerParts: string[] = ['DOS Hub', 'Client Meeting Report'];
  if (r.clientName) footerParts.push(r.clientName);
  if (r.appointmentDate) footerParts.push(fmtDate(r.appointmentDate));
  const now = new Date();
  footerParts.push(`Generated ${(now.getMonth() + 1)}/${now.getDate()}/${now.getFullYear()}`);
  const footerText = footerParts.join('  ·  ');

  // Client card meta line
  const metaParts: string[] = [];
  if (r.appointmentDate) metaParts.push(fmtDate(r.appointmentDate));
  if (r.consultantName) metaParts.push(r.consultantName);
  const estVal = fmtCurrency(r.estimatedContractValue);
  if (estVal !== '—') metaParts.push(estVal);

  // PC badge
  const pcBadge = (r.purchaseConfidencePct !== undefined && r.purchaseConfidencePct !== null)
    ? `<div class="dos-badge">${r.purchaseConfidencePct}% PC</div>`
    : '';

  // Next steps — bullet list
  const nextStepsVal = (r.nextActions && r.nextActions.length > 0)
    ? r.nextActions.map(a => `• ${a}`).join('\n')
    : '—';

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>CMR — ${esc(r.clientName)}</title>
<style>
${BASE_CSS}
</style>
</head>
<body>

<!-- Header Band -->
<div class="dos-header-band">
  <div class="dos-header-left">
    <div class="dos-company-name">Distinctive Outdoor Structures</div>
    <div class="dos-report-title">Client Meeting Report</div>
  </div>
  ${pcBadge}
</div>

<div class="dos-page dos-content">

  <!-- Client Card -->
  <div class="dos-client-card">
    <div class="dos-client-name">${esc(r.clientName)}</div>
    <div class="dos-client-meta">${metaParts.join(' · ')}</div>
  </div>

  <!-- Section 1: CLIENT INFORMATION -->
  ${section('CLIENT INFORMATION', [
    ['Consultant',       r.consultantName || '—'],
    ['Appointment Date', fmtDate(r.appointmentDate)],
    ['Source',           (r.leadSources && r.leadSources.length > 0) ? r.leadSources.join(', ') : '—'],
    ['Address',          r.address || '—'],
    ['Client Type',      fmtClientType(r.clientType)],
  ])}

  <!-- Section 2: DEAL STATUS -->
  ${section('DEAL STATUS', [
    ['Status',               fmtDealStatus(r.dealStatus)],
    ['Close Timeline',       fmtCloseTimeline(r.closeTimeline)],
    ['Conversation Summary', r.lastConversationSummary || '—'],
  ])}

  <!-- Section 3: PURCHASE CONFIDENCE -->
  ${section('PURCHASE CONFIDENCE', [
    ['Current PC%',     r.purchaseConfidencePct !== undefined && r.purchaseConfidencePct !== null ? `${r.purchaseConfidencePct}%` : '—'],
    ['Original PC%',    r.originalPcPct !== undefined && r.originalPcPct !== null ? `${r.originalPcPct}%` : '—'],
    ['Estimated Value', fmtCurrency(r.estimatedContractValue)],
    ['Decision Makers', r.decisionMakers || '—'],
    ['Main Motivation', r.mainMotivation || '—'],
    ['Main Hesitation', r.mainHesitation || '—'],
  ])}

  <!-- Section 4: VALUE COMMUNICATED & OBJECTIONS -->
  ${section('VALUE COMMUNICATED &amp; OBJECTIONS', [
    ['Financing Discussed?', r.financingDiscussed ? 'Yes' : 'No'],
    ['Financing Reaction',   r.financingReaction ? (r.financingReaction.charAt(0).toUpperCase() + r.financingReaction.slice(1)) : '—'],
    ['Value Communicated',   (r.valueCommunicated && r.valueCommunicated.length > 0) ? r.valueCommunicated.join(', ') : '—'],
    ['Client Response',      r.clientResponse ? (r.clientResponse.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')) : '—'],
    ['Objection Notes',      r.objectionNotes || '—'],
  ])}

  <!-- Section 5: NEXT STEPS -->
  ${section('NEXT STEPS', [
    ['Actions', nextStepsVal],
  ])}

  <!-- Section 6: MARKETING FEEDBACK -->
  ${section('MARKETING FEEDBACK', [
    ['Lead Quality',          r.leadQuality ? (r.leadQuality.charAt(0).toUpperCase() + r.leadQuality.slice(1)) : '—'],
    ['Expectation Alignment', r.expectationAlignment ? (r.expectationAlignment === 'yes' ? 'Yes – Expectations aligned' : r.expectationAlignment.charAt(0).toUpperCase() + r.expectationAlignment.slice(1)) : '—'],
    ['Budget Alignment',      r.budgetAlignment ? (r.budgetAlignment.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')) : '—'],
  ])}

</div>

<!-- Footer (fixed to bottom of every page via CSS) -->
<div class="dos-footer">${esc(footerText)}</div>

</body>
</html>`;
}

/**
 * Generate filename for CMR PDF: ClientName_MM-DD-YYYY.pdf
 */
export function getCmrPdfFilename(clientName: string, appointmentDate: string | Date | null | undefined = null): string {
  // Sanitize client name: remove special chars, replace spaces with underscores
  const sanitized = clientName
    .replace(/[^a-zA-Z0-9\s-]/g, '')
    .replace(/\s+/g, '_');

  const dateStr = fmtDateFilename(appointmentDate || '');
  return `${sanitized}_${dateStr}.pdf`;
}
