/**
 * DOS Hub — Receipt PDF Template
 *
 * Builds the HTML string for a single receipt PDF.
 * Called by the receipts tRPC router's exportPdf procedure.
 * Uses the shared renderToPdf engine — no direct Puppeteer calls.
 */
import { readFileSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const baseCss = readFileSync(join(__dirname, "../base.css"), "utf-8");

export interface ReceiptPdfData {
  id: number;
  vendorName?: string | null;
  receiptDate?: string | Date | null;
  subtotal?: string | null;
  tax?: string | null;
  total?: string | null;
  description?: string | null;
  notes?: string | null;
  receiptType?: string | null;
  overheadCategory?: string | null;
  jobName?: string | null;
  poNumber?: string | null;
  status?: string | null;
  submittedByUserId?: number | null;
  submittedAt?: Date | null;
  financeNote?: string | null;
  voidReason?: string | null;
  lineItems?: Array<{ description?: string | null; amount?: string | null; sortOrder?: number | null }>;
  imageUrl?: string | null;
  exportedAt?: Date;
}

function fmt(val: any): string {
  if (val === null || val === undefined) return "—";
  return String(val);
}

function fmtDate(val: any): string {
  if (!val) return "—";
  try {
    return new Date(val).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  } catch {
    return String(val);
  }
}

function fmtCurrency(val: any): string {
  if (!val) return "—";
  const n = parseFloat(val);
  if (isNaN(n)) return val;
  return `$${n.toFixed(2)}`;
}

function row(label: string, value: string): string {
  return `
    <tr>
      <td class="label">${label}</td>
      <td class="value">${value}</td>
    </tr>`;
}

export function buildReceiptHtml(data: ReceiptPdfData): string {
  const exportedAt = (data.exportedAt ?? new Date()).toLocaleString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  const typeLabel =
    data.receiptType === "job_related"
      ? "Job Related"
      : data.receiptType === "overhead"
      ? "Overhead"
      : "—";

  const statusLabel = data.status ? data.status.charAt(0).toUpperCase() + data.status.slice(1) : "—";

  const lineItemsHtml =
    data.lineItems && data.lineItems.length > 0
      ? `
      <section>
        <h2 class="section-header">Line Items</h2>
        <table class="data-table">
          <thead>
            <tr>
              <th style="text-align:left;padding:6px 8px;border-bottom:1px solid #e5e7eb;">Description</th>
              <th style="text-align:right;padding:6px 8px;border-bottom:1px solid #e5e7eb;">Amount</th>
            </tr>
          </thead>
          <tbody>
            ${data.lineItems
              .sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0))
              .map(
                (li) => `
              <tr>
                <td style="padding:5px 8px;">${fmt(li.description)}</td>
                <td style="padding:5px 8px;text-align:right;">${fmt(li.amount)}</td>
              </tr>`
              )
              .join("")}
          </tbody>
        </table>
      </section>`
      : "";

  const imageHtml = data.imageUrl
    ? `
      <section>
        <h2 class="section-header">Receipt Image</h2>
        <div style="text-align:center;margin-top:8px;">
          <img src="${data.imageUrl}" alt="Receipt" style="max-width:100%;max-height:4in;object-fit:contain;border:1px solid #e5e7eb;border-radius:4px;" />
        </div>
      </section>`
    : "";

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Receipt #${data.id}</title>
  <style>
    ${baseCss}

    /* Receipt-specific overrides */
    .header-band {
      background: var(--brand-dark);
      color: #fff;
      padding: 18px 24px 14px;
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
    }
    .header-band .title { font-size: 18pt; font-weight: 700; letter-spacing: 0.02em; }
    .header-band .subtitle { font-size: 9pt; opacity: 0.75; margin-top: 2px; }
    .header-band .meta { text-align: right; font-size: 8.5pt; opacity: 0.85; }

    .body-content { padding: 20px 24px; }

    section { margin-bottom: 20px; }
    .section-header {
      font-size: 9pt;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: var(--brand-mid);
      border-bottom: 1.5px solid var(--brand-mid);
      padding-bottom: 4px;
      margin-bottom: 10px;
    }

    .data-table { width: 100%; border-collapse: collapse; }
    .data-table .label {
      width: 38%;
      font-size: 9pt;
      color: #6b7280;
      padding: 4px 0;
      vertical-align: top;
    }
    .data-table .value {
      font-size: 9.5pt;
      color: #111827;
      padding: 4px 0 4px 8px;
      vertical-align: top;
    }
    .total-row .label, .total-row .value {
      font-weight: 700;
      font-size: 10.5pt;
      color: #111827;
      border-top: 1.5px solid #e5e7eb;
      padding-top: 6px;
    }

    .status-badge {
      display: inline-block;
      padding: 2px 8px;
      border-radius: 12px;
      font-size: 8pt;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      background: #f3f4f6;
      color: #374151;
    }
    .status-badge.complete { background: #d1fae5; color: #065f46; }
    .status-badge.voided { background: #fee2e2; color: #991b1b; }
    .status-badge.submitted { background: #dbeafe; color: #1e40af; }
    .status-badge.entered { background: #ede9fe; color: #5b21b6; }

    .footer {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      padding: 8px 24px;
      font-size: 7.5pt;
      color: #9ca3af;
      border-top: 1px solid #e5e7eb;
      display: flex;
      justify-content: space-between;
    }
  </style>
</head>
<body>
  <!-- Header band -->
  <div class="header-band">
    <div>
      <div class="title">DOS Hub</div>
      <div class="subtitle">Receipt Capture</div>
    </div>
    <div class="meta">
      Receipt #${data.id}<br/>
      Exported: ${exportedAt}
    </div>
  </div>

  <div class="body-content">
    <!-- Status -->
    <section style="margin-bottom:12px;">
      <span class="status-badge ${data.status ?? ""}">${statusLabel}</span>
    </section>

    <!-- Receipt Details -->
    <section>
      <h2 class="section-header">Receipt Details</h2>
      <table class="data-table">
        ${row("Vendor", fmt(data.vendorName))}
        ${row("Date", fmtDate(data.receiptDate))}
        ${row("Type", typeLabel)}
        ${data.receiptType === "overhead" && data.overheadCategory ? row("Category", fmt(data.overheadCategory)) : ""}
        ${data.receiptType === "job_related" && data.jobName ? row("Job Name", fmt(data.jobName)) : ""}
        ${data.poNumber ? row("PO Number", fmt(data.poNumber)) : ""}
        ${data.description ? row("Description", fmt(data.description)) : ""}
      </table>
    </section>

    <!-- Amounts -->
    <section>
      <h2 class="section-header">Amounts</h2>
      <table class="data-table">
        ${row("Subtotal", fmtCurrency(data.subtotal))}
        ${row("Tax", fmtCurrency(data.tax))}
        <tr class="total-row">
          <td class="label">Total</td>
          <td class="value">${fmtCurrency(data.total)}</td>
        </tr>
      </table>
    </section>

    ${data.notes ? `
    <section>
      <h2 class="section-header">Notes</h2>
      <p style="font-size:9.5pt;color:#374151;">${fmt(data.notes)}</p>
    </section>` : ""}

    ${lineItemsHtml}

    <!-- Finance Info -->
    ${data.submittedAt || data.financeNote || data.voidReason ? `
    <section>
      <h2 class="section-header">Finance Information</h2>
      <table class="data-table">
        ${data.submittedAt ? row("Submitted", fmtDate(data.submittedAt)) : ""}
        ${data.financeNote ? row("Finance Note", fmt(data.financeNote)) : ""}
        ${data.voidReason ? row("Void Reason", fmt(data.voidReason)) : ""}
      </table>
    </section>` : ""}

    ${imageHtml}
  </div>

  <div class="footer">
    <span>DOS Hub — Receipt Capture</span>
    <span>Receipt #${data.id}</span>
  </div>
</body>
</html>`;
}
