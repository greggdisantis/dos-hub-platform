/**
 * DOS Hub — Screen Measurements PDF Template
 *
 * Builds the HTML string for a screen measurement record PDF.
 * Called by the screens tRPC router's exportPdf procedure.
 * Uses the shared renderToPdf engine — no direct Puppeteer calls.
 *
 * Layout:
 *   Page 1  — Header info (record, manufacturer, motor, install, date, status)
 *   Pages 2+ — One section per screen line (measurements + calculations + flags + notes)
 *   Footer  — Record number, generated timestamp, generated-by user name
 */
import { readFileSync } from "fs";
import { join, dirname } from "path";
import { fileURLToPath } from "url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const baseCss = readFileSync(join(__dirname, "../base.css"), "utf-8");

// ─── Data types ───────────────────────────────────────────────────────────────

export interface ScreenLinePdfData {
  id: number;
  screenLabel?: string | null;
  sortOrder?: number | null;
  // Raw measurements (stored in inches as decimal strings)
  ul?: string | null;
  ll?: string | null;
  ol?: string | null;
  ur?: string | null;
  lr?: string | null;
  orMeasurement?: string | null;
  t?: string | null;
  m?: string | null;
  b?: string | null;
  reverseMeasurements?: number | boolean | null;
  powerConnectionType?: string | null;
  powerConnectionOtherText?: string | null;
  // Calculation outputs (stored as decimal strings)
  upperSlope?: string | null;
  slopeDirection?: string | null;
  highSide?: string | null;
  lowSide?: string | null;
  leftHeight?: string | null;
  rightHeight?: string | null;
  tbDiff?: string | null;
  uChannelNeeded?: number | boolean | null;
  uChannelReason?: string | null;
  buildOutRequired?: number | boolean | null;
  buildOutType?: string | null;
  trackToTrack?: string | null;
  extendedHood?: number | boolean | null;
  bias?: string | null;
  orderableWidth?: string | null;
  orderableHeight?: string | null;
  leftSideMismatch?: number | boolean | null;
  rightSideMismatch?: number | boolean | null;
  calculationFlagsJson?: Array<{ code: string; severity: "info" | "warning" | "error"; message: string }> | null;
  notes?: string | null;
}

export interface ScreenMeasurementPdfData {
  recordNumber: string;
  status: string;
  manufacturerCode?: string | null;
  motorType?: string | null;
  remoteType?: string | null;
  installMount?: string | null;
  faceMountSides?: string | null;
  applyUChannelToAll?: number | boolean | null;
  calculationProfileCode?: string | null;
  measurementDate?: string | Date | null;
  siteNotes?: string | null;
  ownerName?: string | null;
  approvedByName?: string | null;
  approvedAt?: Date | null;
  lines: ScreenLinePdfData[];
  exportedByName?: string | null;
  exportedAt?: Date;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function esc(s: string | null | undefined): string {
  if (s === null || s === undefined) return "—";
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function fmtDate(val: any): string {
  if (!val) return "—";
  try {
    return new Date(val).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  } catch {
    return String(val);
  }
}

/**
 * Format a stored decimal inch value as fractional inches (e.g. 47.5 → 47 1/2").
 * Snaps to nearest 1/16".
 */
function fmtIn(val: string | number | null | undefined): string {
  if (val === null || val === undefined || val === "") return "—";
  const n = typeof val === "string" ? parseFloat(val) : val;
  if (isNaN(n)) return "—";
  const whole = Math.floor(n);
  const frac = n - whole;
  // Snap to nearest 1/16
  const sixteenths = Math.round(frac * 16);
  if (sixteenths === 0) return `${whole}"`;
  if (sixteenths === 16) return `${whole + 1}"`;
  const gcd = (a: number, b: number): number => (b === 0 ? a : gcd(b, a % b));
  const g = gcd(sixteenths, 16);
  return whole > 0
    ? `${whole} ${sixteenths / g}/${16 / g}"`
    : `${sixteenths / g}/${16 / g}"`;
}

function bool(val: number | boolean | null | undefined): string {
  if (val === null || val === undefined) return "—";
  return val ? "Yes" : "No";
}

function capitalize(s: string | null | undefined): string {
  if (!s) return "—";
  return s.charAt(0).toUpperCase() + s.slice(1).replace(/-/g, " ");
}

function statusBadgeClass(status: string): string {
  switch (status) {
    case "approved": return "badge-approved";
    case "submitted": return "badge-submitted";
    case "closed": return "badge-closed";
    case "cancelled": return "badge-cancelled";
    case "archived": return "badge-archived";
    default: return "badge-draft";
  }
}

function row(label: string, value: string): string {
  return `<div class="dos-row"><span class="dos-label">${label}</span><span class="dos-value">${value}</span></div>`;
}

function flagsHtml(flags: ScreenLinePdfData["calculationFlagsJson"]): string {
  if (!flags || flags.length === 0) return "";
  const items = flags
    .map((f) => {
      const cls = f.severity === "error" ? "flag-error" : f.severity === "warning" ? "flag-warn" : "flag-info";
      return `<div class="flag-item ${cls}"><span class="flag-code">${esc(f.code)}</span> ${esc(f.message)}</div>`;
    })
    .join("");
  return `
    <div class="dos-section">
      <div class="dos-section-header">Flags &amp; Warnings</div>
      <div class="flags-list">${items}</div>
    </div>`;
}

// ─── Per-screen section ───────────────────────────────────────────────────────

function buildLineSection(line: ScreenLinePdfData, index: number): string {
  const label = line.screenLabel ? esc(line.screenLabel) : `Screen ${index + 1}`;
  const reversed = line.reverseMeasurements ? " <span class='rev-badge'>Reversed</span>" : "";

  const powerLabel = line.powerConnectionType === "other"
    ? `Other — ${esc(line.powerConnectionOtherText)}`
    : capitalize(line.powerConnectionType);

  const slopeDir = esc(line.slopeDirection?.replace(/-/g, " ") ?? null);

  return `
  <div class="screen-section${index > 0 ? " dos-page-break" : ""}">
    <div class="screen-title-bar">
      <span class="screen-label">${label}</span>${reversed}
    </div>

    <!-- Raw Measurements -->
    <div class="dos-section">
      <div class="dos-section-header">Raw Measurements</div>
      <div class="meas-grid">
        <div class="meas-cell"><span class="meas-pt">UL</span><span class="meas-val">${fmtIn(line.ul)}</span></div>
        <div class="meas-cell"><span class="meas-pt">LL</span><span class="meas-val">${fmtIn(line.ll)}</span></div>
        <div class="meas-cell"><span class="meas-pt">OL</span><span class="meas-val">${fmtIn(line.ol)}</span></div>
        <div class="meas-cell"><span class="meas-pt">UR</span><span class="meas-val">${fmtIn(line.ur)}</span></div>
        <div class="meas-cell"><span class="meas-pt">LR</span><span class="meas-val">${fmtIn(line.lr)}</span></div>
        <div class="meas-cell"><span class="meas-pt">OR</span><span class="meas-val">${fmtIn(line.orMeasurement)}</span></div>
        <div class="meas-cell"><span class="meas-pt">T</span><span class="meas-val">${fmtIn(line.t)}</span></div>
        <div class="meas-cell"><span class="meas-pt">M</span><span class="meas-val">${fmtIn(line.m)}</span></div>
        <div class="meas-cell"><span class="meas-pt">B</span><span class="meas-val">${fmtIn(line.b)}</span></div>
      </div>
    </div>

    <!-- Slope Analysis -->
    <div class="dos-section">
      <div class="dos-section-header">Slope Analysis</div>
      ${row("Upper Slope", fmtIn(line.upperSlope))}
      ${row("Slope Direction", slopeDir)}
      ${row("Left Height", fmtIn(line.leftHeight))}
      ${row("Right Height", fmtIn(line.rightHeight))}
      ${row("T–B Difference", fmtIn(line.tbDiff))}
      ${row("Left Side Mismatch", bool(line.leftSideMismatch))}
      ${row("Right Side Mismatch", bool(line.rightSideMismatch))}
    </div>

    <!-- Ordering Outputs -->
    <div class="dos-section">
      <div class="dos-section-header">Ordering Outputs</div>
      ${row("U-Channel Needed", bool(line.uChannelNeeded))}
      ${line.uChannelReason ? row("U-Channel Reason", esc(line.uChannelReason)) : ""}
      ${row("Build-Out Required", bool(line.buildOutRequired))}
      ${line.buildOutType ? row("Build-Out Type", esc(line.buildOutType)) : ""}
      ${row("Track-to-Track", fmtIn(line.trackToTrack))}
      ${row("Extended Hood", bool(line.extendedHood))}
      ${row("Bias", fmtIn(line.bias))}
      ${row("Orderable Width", fmtIn(line.orderableWidth))}
      ${row("Orderable Height", fmtIn(line.orderableHeight))}
    </div>

    <!-- Power Connection -->
    <div class="dos-section">
      <div class="dos-section-header">Power Connection</div>
      ${row("Type", powerLabel)}
    </div>

    ${flagsHtml(line.calculationFlagsJson)}

    ${line.notes ? `
    <div class="dos-section">
      <div class="dos-section-header">Notes</div>
      <div class="dos-row"><span class="dos-value" style="width:100%;white-space:pre-wrap;">${esc(line.notes)}</span></div>
    </div>` : ""}
  </div>`;
}

// ─── Main builder ─────────────────────────────────────────────────────────────

export function buildScreenMeasurementHtml(data: ScreenMeasurementPdfData): string {
  const exportedAt = (data.exportedAt ?? new Date()).toLocaleString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

  const statusLabel = capitalize(data.status);
  const badgeCls = statusBadgeClass(data.status);

  const installLabel = data.installMount
    ? capitalize(data.installMount) +
      (data.installMount === "face-mount" && data.faceMountSides
        ? ` — ${capitalize(data.faceMountSides)}`
        : "")
    : "—";

  const sortedLines = [...data.lines].sort(
    (a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0)
  );

  const lineSections = sortedLines.length > 0
    ? sortedLines.map((line, i) => buildLineSection(line, i)).join("\n")
    : `<div class="dos-section"><div class="dos-row"><span class="dos-value">No screen lines recorded.</span></div></div>`;

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Screen Measurements — ${esc(data.recordNumber)}</title>
  <style>
    ${baseCss}

    /* ── Screen-specific styles ── */
    .dos-status-bar {
      padding: 8px 0.6in;
      background: var(--dos-gray-bg);
      border-bottom: 1px solid var(--dos-gray-line);
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .status-badge {
      display: inline-block;
      padding: 2px 10px;
      font-size: 8pt;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      border: 1px solid currentColor;
    }
    .badge-draft    { color: #374151; border-color: #9ca3af; }
    .badge-submitted { color: #1e40af; border-color: #93c5fd; background: #eff6ff; }
    .badge-approved { color: #065f46; border-color: #6ee7b7; background: #ecfdf5; }
    .badge-closed   { color: #4c1d95; border-color: #c4b5fd; background: #f5f3ff; }
    .badge-cancelled { color: #991b1b; border-color: #fca5a5; background: #fef2f2; }
    .badge-archived { color: #78350f; border-color: #fcd34d; background: #fffbeb; }

    .screen-section { margin-top: 0; }

    .screen-title-bar {
      background: var(--dos-navy-light, #2a4d72);
      color: #fff;
      font-size: 11pt;
      font-weight: 700;
      padding: 8px 0.6in;
      margin-bottom: 0;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .screen-label { letter-spacing: 0.02em; }
    .rev-badge {
      font-size: 7.5pt;
      font-weight: 600;
      background: #f59e0b;
      color: #1a1a1a;
      padding: 1px 6px;
      border-radius: 2px;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }

    /* 3-column measurement grid */
    .meas-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      border-bottom: 1px solid var(--dos-gray-line);
    }
    .meas-cell {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 8px 6px;
      border-right: 1px solid var(--dos-gray-line);
      border-bottom: 1px solid var(--dos-gray-line);
    }
    .meas-cell:nth-child(3n) { border-right: none; }
    .meas-pt {
      font-size: 7.5pt;
      font-weight: 700;
      color: var(--dos-gray-label);
      text-transform: uppercase;
      letter-spacing: 0.06em;
    }
    .meas-val {
      font-size: 11pt;
      font-weight: 700;
      color: var(--dos-text);
      margin-top: 2px;
    }

    /* Flags */
    .flags-list { padding: 8px 14px; }
    .flag-item {
      font-size: 8.5pt;
      padding: 4px 8px;
      margin-bottom: 4px;
      border-left: 3px solid currentColor;
    }
    .flag-code { font-weight: 700; margin-right: 6px; }
    .flag-error { color: #991b1b; background: #fef2f2; border-color: #ef4444; }
    .flag-warn  { color: #92400e; background: #fffbeb; border-color: #f59e0b; }
    .flag-info  { color: #1e40af; background: #eff6ff; border-color: #3b82f6; }

    /* Summary info card */
    .info-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0;
    }
    .info-grid .dos-row { border-right: 1px solid var(--dos-gray-line); }
    .info-grid .dos-row:nth-child(2n) { border-right: none; }
  </style>
</head>
<body>

  <!-- Header Band -->
  <div class="dos-header-band">
    <div class="dos-header-left">
      <span class="dos-company-name">DOS Hub</span>
      <span class="dos-report-title">Screen Measurements</span>
    </div>
    <div style="text-align:right;font-size:9pt;color:var(--dos-text-light);">
      <div style="font-size:13pt;font-weight:700;color:#fff;">${esc(data.recordNumber)}</div>
      <div style="margin-top:2px;">Exported: ${exportedAt}</div>
      ${data.exportedByName ? `<div>By: ${esc(data.exportedByName)}</div>` : ""}
    </div>
  </div>

  <!-- Status Bar -->
  <div class="dos-status-bar">
    <span class="status-badge ${badgeCls}">${statusLabel}</span>
    ${data.ownerName ? `<span style="font-size:8.5pt;color:var(--dos-gray-label);">Owner: <strong>${esc(data.ownerName)}</strong></span>` : ""}
    ${data.approvedByName ? `<span style="font-size:8.5pt;color:var(--dos-gray-label);">Approved by: <strong>${esc(data.approvedByName)}</strong></span>` : ""}
  </div>

  <!-- Record Info -->
  <div class="dos-page dos-content">
    <div class="dos-section">
      <div class="dos-section-header">Record Information</div>
      <div class="info-grid">
        ${row("Record Number", esc(data.recordNumber))}
        ${row("Status", statusLabel)}
        ${row("Manufacturer", esc(data.manufacturerCode))}
        ${row("Motor Type", esc(data.motorType))}
        ${row("Remote Type", esc(data.remoteType))}
        ${row("Install Mount", installLabel)}
        ${row("Apply U-Channel to All", bool(data.applyUChannelToAll))}
        ${row("Measurement Date", fmtDate(data.measurementDate))}
        ${row("Calculation Profile", esc(data.calculationProfileCode))}
        ${data.approvedAt ? row("Approved", fmtDate(data.approvedAt)) : ""}
      </div>
    </div>

    ${data.siteNotes ? `
    <div class="dos-section">
      <div class="dos-section-header">Site Notes</div>
      <div class="dos-row"><span class="dos-value" style="width:100%;white-space:pre-wrap;">${esc(data.siteNotes)}</span></div>
    </div>` : ""}

    <!-- Screen Lines -->
    <div style="margin-top:16px;">
      <div class="dos-section-header" style="background:var(--dos-navy);color:#fff;padding:7px 14px;font-size:9pt;font-weight:700;text-transform:uppercase;letter-spacing:0.06em;">
        Screen Lines (${sortedLines.length})
      </div>
    </div>

    ${lineSections}
  </div>

  <!-- Footer -->
  <div class="dos-footer">
    <span>DOS Hub — Screen Measurements &nbsp;|&nbsp; ${esc(data.recordNumber)}</span>
    <span>Generated ${exportedAt}${data.exportedByName ? ` by ${esc(data.exportedByName)}` : ""}</span>
  </div>

</body>
</html>`;
}
