/**
 * Shared PDF Export System - Type Definitions
 */

export interface PdfReportBuilderOptions {
  title: string;
  reportType: 'CMR' | 'Measurements' | 'Materials' | 'Receipt' | 'Checklist';
  metadata?: Record<string, unknown>;
}

export interface StandardHeaderOptions {
  companyName: string;
  reportTitle: string;
  reportType?: string;
  generatedBy: string;
  generatedAt: Date;
  projectName?: string;
  projectId?: number;
  customMetadata?: Record<string, string>;
}

export interface PdfSection {
  title: string;
  content: SectionContent[];
}

export type SectionContent =
  | TextContent
  | TableContent
  | ListContent
  | FormattedContent;

export interface TextContent {
  type: 'text';
  text: string;
  style?: TextStyle;
}

export interface TableContent {
  type: 'table';
  headers: string[];
  rows: (string | number)[][];
  style?: TableStyle;
}

export interface ListContent {
  type: 'list';
  items: string[];
  ordered?: boolean;
  style?: ListStyle;
}

export interface FormattedContent {
  type: 'formatted';
  html: string; // HTML content to be rendered
}

export interface TextStyle {
  fontSize?: number;
  bold?: boolean;
  italic?: boolean;
  color?: string;
  alignment?: 'left' | 'center' | 'right';
  marginTop?: number;
  marginBottom?: number;
}

export interface TableStyle {
  borderColor?: string;
  headerBackgroundColor?: string;
  headerTextColor?: string;
  alternateRowColor?: string;
  fontSize?: number;
}

export interface ListStyle {
  fontSize?: number;
  bulletType?: 'dot' | 'dash' | 'number';
  indentation?: number;
}

export interface PaginationOptions {
  pageHeight: number;
  pageWidth: number;
  marginTop: number;
  marginBottom: number;
  marginLeft: number;
  marginRight: number;
  headerHeight: number;
  footerHeight: number;
}

export interface PdfGenerationResult {
  buffer: Buffer;
  pageCount: number;
  generatedAt: Date;
}

export interface CmrPdfData {
  report: {
    id: number;
    clientName: string;
    consultantName?: string;
    appointmentDate?: Date;
    appointmentType?: string;
    address?: string;
    clientType?: string;
    leadSources?: string[];
    status: string;
    // Deal Status
    dealStatus?: string;
    closeTimeline?: string;
    lastConversationSummary?: string;
    // Purchase Confidence
    purchaseConfidencePct?: number;
    originalPcPct?: number;
    estimatedContractValue?: string | number | null;
    decisionMakers?: string;
    mainMotivation?: string;
    mainHesitation?: string;
    // Value & Objections
    financingDiscussed?: number;
    financingReaction?: string;
    valueCommunicated?: string[];
    clientResponse?: string;
    objectionNotes?: string;
    // Next Steps
    nextActions?: string[];
    // Marketing Feedback
    leadQuality?: string;
    expectationAlignment?: string;
    budgetAlignment?: string;
  };
  actionItems: Array<{
    description: string;
    assignedTo?: string;
    dueDate?: Date;
    completed: boolean;
  }>;
  dealAnalysis?: {
    dealStatus?: string;
    purchaseConfidence?: number;
    estimatedValue?: string;
  };
  project?: {
    id: number;
    name: string;
    clientName: string;
  };
  generatedBy: {
    firstName: string;
    lastName: string;
    email: string;
  };
}

export interface BrandingConfig {
  companyName: string;
  companyLogo?: string; // URL or base64
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  fontFamily: string;
}

export const DEFAULT_BRANDING: BrandingConfig = {
  companyName: 'Distinctive Outdoor Structures',
  primaryColor: '#1a3a52', // DOS Hub dark blue
  secondaryColor: '#2c5aa0', // DOS Hub medium blue
  accentColor: '#f59e0b', // DOS Hub accent orange
  fontFamily: 'Helvetica',
};

export const DEFAULT_PAGINATION: PaginationOptions = {
  pageHeight: 792, // 11 inches in points
  pageWidth: 612, // 8.5 inches in points
  marginTop: 72, // 1 inch
  marginBottom: 72, // 1 inch
  marginLeft: 54, // 0.75 inches
  marginRight: 54, // 0.75 inches
  headerHeight: 120, // 1.67 inches
  footerHeight: 36, // 0.5 inches
};
