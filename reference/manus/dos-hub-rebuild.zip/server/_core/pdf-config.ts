/**
 * Shared PDF Export Configuration
 * 
 * This module defines the standardized structure for all report-type modules.
 * Every report (CMR, Screen Measurements, Material Checklist, etc.) follows
 * this contract to ensure consistent PDF export, header formatting, and layout.
 */

/**
 * Standard report header that appears on all exported reports
 */
export interface ReportHeader {
  /** Company name/branding (e.g., "Distinctive Outdoor Structures") */
  companyName: string;
  /** Type of report (e.g., "CMR", "Screen Measurement", "Material Checklist") */
  reportType: string;
  /** When the report was created */
  createdDate: Date;
  /** User who created the report */
  createdBy: string;
  /** Project information (optional, module-specific) */
  projectInfo?: {
    projectName?: string;
    projectId?: string;
    clientName?: string;
  };
  /** Any additional identifying metadata */
  metadata?: Record<string, string | number | boolean>;
}

/**
 * Standard export request structure
 */
export interface ExportRequest {
  /** Type of report: 'cmr', 'screen', 'material', 'precon', 'receipt', 'aquaclean' */
  reportType: 'cmr' | 'screen' | 'material' | 'precon' | 'receipt' | 'aquaclean';
  /** ID of the specific report to export */
  reportId: number;
  /** User ID requesting the export (for access control) */
  userId: number;
  /** User role for permission checking */
  userRole: string;
}

/**
 * Standard export response
 */
export interface ExportResponse {
  success: boolean;
  pdfUrl?: string;
  error?: string;
}

/**
 * Template configuration for each report type
 * Defines how data maps to PDF template and styling
 */
export const REPORT_TEMPLATES: Record<string, {
  name: string;
  displayName: string;
  templateFile: string;
  cssFile: string;
  sections: string[];
}> = {
  cmr: {
    name: 'cmr',
    displayName: 'Client Meeting Report',
    templateFile: 'cmr.html',
    cssFile: 'report-styles.css',
    sections: ['header', 'meeting-info', 'attendees', 'notes', 'action-items', 'footer'],
  },
  screen: {
    name: 'screen',
    displayName: 'Screen Measurement',
    templateFile: 'screen.html',
    cssFile: 'report-styles.css',
    sections: ['header', 'project-info', 'measurements', 'materials', 'photos', 'footer'],
  },
  material: {
    name: 'material',
    displayName: 'Material Checklist',
    templateFile: 'material.html',
    cssFile: 'report-styles.css',
    sections: ['header', 'project-info', 'materials', 'delivery-status', 'footer'],
  },
  precon: {
    name: 'precon',
    displayName: 'Preconstruction Checklist',
    templateFile: 'precon.html',
    cssFile: 'report-styles.css',
    sections: ['header', 'project-info', 'checklist-items', 'completion-status', 'footer'],
  },
  receipt: {
    name: 'receipt',
    displayName: 'Receipt',
    templateFile: 'receipt.html',
    cssFile: 'report-styles.css',
    sections: ['header', 'receipt-info', 'line-items', 'summary', 'footer'],
  },
  aquaclean: {
    name: 'aquaclean',
    displayName: 'AquaClean Receipt',
    templateFile: 'aquaclean.html',
    cssFile: 'report-styles.css',
    sections: ['header', 'receipt-info', 'line-items', 'summary', 'footer'],
  },
};

/**
 * PDF styling constants for consistency across all reports
 */
export const PDF_STYLES = {
  // Page layout
  pageWidth: 8.5, // inches
  pageHeight: 11, // inches
  marginTop: 0.5,
  marginBottom: 0.5,
  marginLeft: 0.75,
  marginRight: 0.75,

  // Colors
  brandColor: '#1a472a', // DOS Hub brand green
  accentColor: '#4a90e2',
  textColor: '#333333',
  lightText: '#666666',
  borderColor: '#cccccc',
  backgroundColor: '#f9f9f9',

  // Typography
  fontFamily: '"Segoe UI", Tahoma, Geneva, Verdana, sans-serif',
  fontSize: {
    body: 11,
    small: 9,
    heading1: 18,
    heading2: 14,
    heading3: 12,
  },

  // Spacing
  sectionSpacing: 12, // points between sections
  lineHeight: 1.5,
  paragraphSpacing: 8,

  // Borders and dividers
  borderWidth: 1,
  borderStyle: 'solid',
};

/**
 * Pagination control constants
 * Used to prevent blank pages and orphaned content
 */
export const PAGINATION_RULES = {
  // CSS page-break rules
  avoidOrphans: 'page-break-inside: avoid;',
  avoidWidows: 'page-break-inside: avoid;',
  
  // Minimum content height to avoid blank pages
  minSectionHeight: 0.5, // inches
  
  // Maximum content per page before forced break
  maxContentPerPage: 10, // inches
};

/**
 * Standard company/branding information
 */
export const COMPANY_INFO = {
  name: 'Distinctive Outdoor Structures',
  shortName: 'DOS',
  tagline: 'Quality Construction & Installation',
};
