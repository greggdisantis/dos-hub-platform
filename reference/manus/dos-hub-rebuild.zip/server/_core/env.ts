export const ENV = {
  appId: process.env.VITE_APP_ID ?? "",
  // In development use JWT_SECRET_DEV (isolated dev secret).
  // In production use JWT_SECRET only.
  jwtSecret:
    process.env.NODE_ENV !== "production"
      ? (process.env.JWT_SECRET_DEV ?? process.env.JWT_SECRET ?? "")
      : (process.env.JWT_SECRET ?? ""),
  cookieSecret:
    process.env.NODE_ENV !== "production"
      ? (process.env.JWT_SECRET_DEV ?? process.env.JWT_SECRET ?? "")
      : (process.env.JWT_SECRET ?? ""),
  // In development use DATABASE_URL_DEV (isolated dev cluster) — NO fallback to DATABASE_URL.
  // Per Secret Management Policy: dev must never fall through to DATABASE_URL (which points to
  // the legacy gateway04 cluster). If DATABASE_URL_DEV is missing, the server will refuse to
  // connect rather than silently hitting the wrong cluster.
  // In production use DATABASE_URL (GCP Secret Manager → dos_hub_prod).
  databaseUrl:
    process.env.NODE_ENV !== "production"
      ? (process.env.DATABASE_URL_DEV ?? "")
      : (process.env.DATABASE_URL ?? ""),
  oAuthServerUrl: process.env.OAUTH_SERVER_URL ?? "",
  ownerOpenId: process.env.OWNER_OPEN_ID ?? "",
  isProduction: process.env.NODE_ENV === "production",
  forgeApiUrl: process.env.BUILT_IN_FORGE_API_URL ?? "",
  forgeApiKey: process.env.BUILT_IN_FORGE_API_KEY ?? "",
};
