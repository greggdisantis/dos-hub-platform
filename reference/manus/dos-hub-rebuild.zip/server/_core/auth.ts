import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { ForbiddenError } from "@shared/_core/errors";
import bcryptjs from "bcryptjs";
import { parse as parseCookieHeader } from "cookie";
import type { Request } from "express";
import { SignJWT, jwtVerify } from "jose";
import type { User } from "../../drizzle/schema";
import * as db from "../db";
import { ENV } from "./env";

export type SessionPayload = {
  userId: number;
  email: string;
};

/**
 * Hash a password using bcrypt
 */
export async function hashPassword(password: string): Promise<string> {
  const salt = await bcryptjs.genSalt(10);
  return bcryptjs.hash(password, salt);
}

/**
 * Compare a password with a bcrypt hash
 */
export async function verifyPassword(
  password: string,
  hash: string
): Promise<boolean> {
  return bcryptjs.compare(password, hash);
}

/**
 * Create a JWT session token
 */
export async function createSessionToken(
  userId: number,
  email: string,
  options: { expiresInMs?: number } = {}
): Promise<string> {
  const issuedAt = Date.now();
  const expiresInMs = options.expiresInMs ?? ONE_YEAR_MS;
  const expirationSeconds = Math.floor((issuedAt + expiresInMs) / 1000);
  const secretKey = new TextEncoder().encode(ENV.jwtSecret);

  return new SignJWT({
    userId,
    email,
  })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setExpirationTime(expirationSeconds)
    .sign(secretKey);
}

/**
 * Verify a JWT session token
 */
export async function verifySessionToken(
  token: string | undefined | null
): Promise<SessionPayload | null> {
  if (!token) {
    console.warn("[Auth] Missing session token");
    return null;
  }

  try {
    const secretKey = new TextEncoder().encode(ENV.jwtSecret);
    const { payload } = await jwtVerify(token, secretKey, {
      algorithms: ["HS256"],
    });

    const { userId, email } = payload as Record<string, unknown>;

    if (typeof userId !== "number" || typeof email !== "string") {
      console.warn("[Auth] Session payload missing required fields");
      return null;
    }

    return { userId, email };
  } catch (error) {
    console.warn("[Auth] Session verification failed", String(error));
    return null;
  }
}

/**
 * Parse cookies from request
 */
function parseCookies(cookieHeader: string | undefined): Map<string, string> {
  if (!cookieHeader) {
    return new Map<string, string>();
  }

  const parsed = parseCookieHeader(cookieHeader);
  return new Map(Object.entries(parsed));
}

/**
 * Authenticate a request using JWT from Authorization header or session cookie
 */
export async function authenticateRequest(req: Request): Promise<User> {
  // Try to get token from Authorization header first (Bearer token)
  const authHeader = req.headers.authorization;
  let token: string | null = null;

  if (authHeader && authHeader.startsWith("Bearer ")) {
    token = authHeader.slice(7);
  } else {
    // Fall back to session cookie
    const cookies = parseCookies(req.headers.cookie);
    token = cookies.get(COOKIE_NAME) || null;
  }

  if (!token) {
    throw ForbiddenError("No authentication token provided");
  }

  const session = await verifySessionToken(token);

  if (!session) {
    throw ForbiddenError("Invalid or expired session token");
  }

  const user = await db.getUserById(session.userId);

  if (!user) {
    throw ForbiddenError("User not found");
  }

  // Update last signed in
  await db.updateLastSignedIn(user.id);

  return user;
}
