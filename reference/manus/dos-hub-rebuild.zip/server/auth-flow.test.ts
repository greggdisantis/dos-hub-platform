import { describe, expect, it, beforeEach, vi } from "vitest";
import { appRouter } from "./routers";
import { COOKIE_NAME } from "../shared/const";
import type { TrpcContext } from "./_core/context";
import * as db from "./db";

// Mock database
vi.mock("./db", () => ({
  getUserByEmail: vi.fn(),
  createUser: vi.fn(),
  updateLastSignedIn: vi.fn(),
  getPendingUsers: vi.fn(),
  updateUserApproval: vi.fn(),
  deleteUser: vi.fn(),
}));

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(user?: AuthenticatedUser): { ctx: TrpcContext; clearedCookies: Array<{ name: string; options: Record<string, unknown> }>; setCookies: Array<{ name: string; value: string; options: Record<string, unknown> }> } {
  const clearedCookies: Array<{ name: string; options: Record<string, unknown> }> = [];
  const setCookies: Array<{ name: string; value: string; options: Record<string, unknown> }> = [];

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: (name: string, options: Record<string, unknown>) => {
        clearedCookies.push({ name, options });
      },
      cookie: (name: string, value: string, options: Record<string, unknown>) => {
        setCookies.push({ name, value, options });
      },
    } as unknown as TrpcContext["res"],
  };

  return { ctx, clearedCookies, setCookies };
}

describe("Authentication Flow", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("signup", () => {
    it("creates a new user with firstName and lastName", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      vi.mocked(db.getUserByEmail).mockResolvedValueOnce(undefined);
      vi.mocked(db.createUser).mockResolvedValueOnce();
      vi.mocked(db.getUserByEmail).mockResolvedValueOnce({
        id: 1,
        email: "test@example.com",
        firstName: "John",
        lastName: "Doe",
        passwordHash: "hashed",
        role: "pending",
        approved: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: null,
      });

      const result = await caller.auth.signup({
        email: "test@example.com",
        firstName: "John",
        lastName: "Doe",
        password: "Password123",
      });

      expect(result.success).toBe(true);
      expect(result.user.firstName).toBe("John");
      expect(result.user.lastName).toBe("Doe");
      expect(result.user.role).toBe("pending");
      expect(result.user.approved).toBe(false);
    });

    it("auto-approves and sets super-admin role for permanent super-admin emails", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      vi.mocked(db.getUserByEmail).mockResolvedValueOnce(undefined);
      vi.mocked(db.createUser).mockResolvedValueOnce();
      vi.mocked(db.getUserByEmail).mockResolvedValueOnce({
        id: 1,
        email: "Greggdisantis@gmail.com",
        firstName: "Gregg",
        lastName: "DiSantis",
        passwordHash: "hashed",
        role: "super-admin",
        approved: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: null,
      });

      const result = await caller.auth.signup({
        email: "Greggdisantis@gmail.com",
        firstName: "Gregg",
        lastName: "DiSantis",
        password: "Password123",
      });

      expect(result.success).toBe(true);
      expect(result.user.role).toBe("super-admin");
      expect(result.user.approved).toBe(true);
      expect(result.message).toContain("Super-admin account created and approved");
    });

    it("rejects duplicate email", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      vi.mocked(db.getUserByEmail).mockResolvedValueOnce({
        id: 1,
        email: "existing@example.com",
        firstName: "John",
        lastName: "Doe",
        passwordHash: "hashed",
        role: "pending",
        approved: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: null,
      });

      await expect(
        caller.auth.signup({
          email: "existing@example.com",
          firstName: "Jane",
          lastName: "Smith",
          password: "Password123",
        })
      ).rejects.toThrow("User with this email already exists");
    });

    it("validates password length", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.auth.signup({
          email: "test@example.com",
          firstName: "John",
          lastName: "Doe",
          password: "short",
        })
      ).rejects.toThrow("Password must be at least 8 characters");
    });

    it("validates email format", async () => {
      const { ctx } = createAuthContext();
      const caller = appRouter.createCaller(ctx);

      await expect(
        caller.auth.signup({
          email: "invalid-email",
          firstName: "John",
          lastName: "Doe",
          password: "Password123",
        })
      ).rejects.toThrow("Invalid email address");
    });
  });

  describe("admin.getPendingUsers", () => {
    it("returns pending users for super-admin", async () => {
      const superAdmin: AuthenticatedUser = {
        id: 1,
        email: "admin@example.com",
        firstName: "Admin",
        lastName: "User",
        passwordHash: "hashed",
        role: "super-admin",
        approved: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      };

      const { ctx } = createAuthContext(superAdmin);
      const caller = appRouter.createCaller(ctx);

      const pendingUsers = [
        {
          id: 2,
          email: "pending@example.com",
          firstName: "Pending",
          lastName: "User",
          passwordHash: "hashed",
          role: "pending",
          approved: 0,
          createdAt: new Date(),
          updatedAt: new Date(),
          lastSignedIn: null,
        },
      ];

      vi.mocked(db.getPendingUsers).mockResolvedValueOnce(pendingUsers);

      const result = await caller.admin.getPendingUsers();

      expect(result).toEqual(pendingUsers);
    });

    it("rejects access for non-super-admin users", async () => {
      const regularUser: AuthenticatedUser = {
        id: 1,
        email: "user@example.com",
        firstName: "Regular",
        lastName: "User",
        passwordHash: "hashed",
        role: "member",
        approved: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      };

      const { ctx } = createAuthContext(regularUser);
      const caller = appRouter.createCaller(ctx);

      await expect(caller.admin.getPendingUsers()).rejects.toThrow(
        "Only super-admins can access this"
      );
    });
  });

  describe("admin.approveUser", () => {
    it("approves a user when called by super-admin", async () => {
      const superAdmin: AuthenticatedUser = {
        id: 1,
        email: "admin@example.com",
        firstName: "Admin",
        lastName: "User",
        passwordHash: "hashed",
        role: "super-admin",
        approved: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      };

      const { ctx } = createAuthContext(superAdmin);
      const caller = appRouter.createCaller(ctx);

      vi.mocked(db.updateUserApproval).mockResolvedValueOnce();

      const result = await caller.admin.approveUser({ userId: 2 });

      expect(result.success).toBe(true);
      expect(result.message).toBe("User approved");
      expect(vi.mocked(db.updateUserApproval)).toHaveBeenCalledWith(2, true);
    });

    it("rejects approval from non-super-admin", async () => {
      const regularUser: AuthenticatedUser = {
        id: 1,
        email: "user@example.com",
        firstName: "Regular",
        lastName: "User",
        passwordHash: "hashed",
        role: "member",
        approved: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      };

      const { ctx } = createAuthContext(regularUser);
      const caller = appRouter.createCaller(ctx);

      await expect(caller.admin.approveUser({ userId: 2 })).rejects.toThrow(
        "Only super-admins can approve users"
      );
    });
  });

  describe("admin.rejectUser", () => {
    it("rejects a user when called by super-admin", async () => {
      const superAdmin: AuthenticatedUser = {
        id: 1,
        email: "admin@example.com",
        firstName: "Admin",
        lastName: "User",
        passwordHash: "hashed",
        role: "super-admin",
        approved: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      };

      const { ctx } = createAuthContext(superAdmin);
      const caller = appRouter.createCaller(ctx);

      vi.mocked(db.deleteUser).mockResolvedValueOnce();

      const result = await caller.admin.rejectUser({ userId: 2 });

      expect(result.success).toBe(true);
      expect(result.message).toBe("User rejected");
      expect(vi.mocked(db.deleteUser)).toHaveBeenCalledWith(2);
    });
  });
});
