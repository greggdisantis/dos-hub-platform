import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { createUser, createCMRReport, getCMRReportsByProject } from "./db";
import { hashPassword } from "./_core/auth";
import type { InsertCMRReport } from "../drizzle/schema";

describe("CMR Project Integration", () => {
  const testEmail = `cmr-project-test-${Date.now()}@test.com`;
  let testUserId: number | undefined;
  const createdCMRIds: number[] = [];

  afterAll(async () => {
    // Clean up all CMR records created during tests
    if (createdCMRIds.length > 0) {
      try {
        const { deleteCMRReport } = await import("./db");
        for (const id of createdCMRIds) {
          await deleteCMRReport(id);
        }
      } catch {
        // Ignore cleanup errors
      }
    }
    // Clean up test user
    if (testUserId) {
      try {
        const { deleteUser } = await import("./db");
        await deleteUser(testUserId);
      } catch {
        // Ignore cleanup errors
      }
    }
  });

  beforeAll(async () => {
    // Create a test user
    const passwordHash = await hashPassword("test-password-123");
    await createUser({
      email: testEmail,
      firstName: "CMR",
      lastName: "Tester",
      passwordHash,
      role: "member",
      approved: 1,
    });
    // Capture the user ID for cleanup
    const { getUserByEmail } = await import("./db");
    const user = await getUserByEmail(testEmail);
    testUserId = user?.id;
  });

  it("should create a CMR report with projectId", async () => {
    const projectId = 1;
    const cmrData: InsertCMRReport = {
      userId: 1,
      projectId,
      clientName: "Test Client",
      meetingDate: new Date(),
      attendees: ["John", "Jane"],
      notes: "Test meeting notes",
      actionItems: [
        {
          id: "1",
          description: "Follow up on proposal",
          assignedTo: "John",
          dueDate: new Date().toISOString(),
          completed: false,
        },
      ],
      dealStatus: "proposal-presented",
      purchaseConfidencePct: 75,
      estimatedContractValue: "50000",
      status: "draft",
    };

    const report = await createCMRReport(cmrData);
    if (report?.id) createdCMRIds.push(report.id);
    expect(report).toBeDefined();
    expect(report?.projectId).toBe(projectId);
    expect(report?.clientName).toBe("Test Client");
    expect(report?.status).toBe("draft");
  });

  it("should list CMR reports by project", async () => {
    const projectId = 1;
    // Create multiple CMR reports for the same project
    const cmrData1: InsertCMRReport = {
      userId: 1,
      projectId,
      clientName: "Client A",
      meetingDate: new Date(),
      attendees: ["Person 1"],
      notes: "First meeting",
      dealStatus: "working-on-design",
      purchaseConfidencePct: 50,
      estimatedContractValue: "25000",
      status: "draft",
    };

    const cmrData2: InsertCMRReport = {
      userId: 1,
      projectId,
      clientName: "Client B",
      meetingDate: new Date(),
      attendees: ["Person 2"],
      notes: "Second meeting",
      dealStatus: "proposal-presented",
      purchaseConfidencePct: 80,
      estimatedContractValue: "75000",
      status: "submitted",
    };

    const r1 = await createCMRReport(cmrData1);
    const r2 = await createCMRReport(cmrData2);
    if (r1?.id) createdCMRIds.push(r1.id);
    if (r2?.id) createdCMRIds.push(r2.id);

    // Fetch reports by project
    const reports = await getCMRReportsByProject(projectId);
    expect(reports).toBeDefined();
    expect(reports.length).toBeGreaterThanOrEqual(2);
    expect(reports.every((r) => r.projectId === projectId)).toBe(true);
  });

  it("should preserve CRM analytics fields during project linking", async () => {
    const projectId = 1;
    const cmrData: InsertCMRReport = {
      userId: 1,
      projectId,
      clientName: "Analytics Test Client",
      meetingDate: new Date(),
      attendees: ["Analyst"],
      notes: "Testing analytics preservation",
      dealStatus: "actively-considering",
      purchaseConfidencePct: 65,
      estimatedContractValue: "100000",
      status: "submitted",
    };

    const report = await createCMRReport(cmrData);
    if (report?.id) createdCMRIds.push(report.id);
    expect(report).toBeDefined();
    expect(report?.dealStatus).toBe("actively-considering");
    expect(report?.purchaseConfidencePct).toBe(65);
    // Database may format as decimal
    expect(String(report?.estimatedContractValue)).toMatch(/^100000/);
  });

  it("should support projectId parameter in CMR creation", async () => {
    // Test with projectId - the database will store it
    const cmrWithProject: InsertCMRReport = {
      userId: 1,
      projectId: 1,
      clientName: "With Project",
      meetingDate: new Date(),
      attendees: [],
      status: "draft",
    };

    const reportWithProject = await createCMRReport(cmrWithProject);
    if (reportWithProject?.id) createdCMRIds.push(reportWithProject.id);
    expect(reportWithProject).toBeDefined();
    expect(reportWithProject?.clientName).toBe("With Project");
    // projectId should be stored
    expect(reportWithProject?.projectId).toBeDefined();
  });

  it("should allow CMR reports without projectId (legacy records)", async () => {
    // Test without projectId - should still create the record
    const cmrWithoutProject: InsertCMRReport = {
      userId: 1,
      clientName: "Without Project",
      meetingDate: new Date(),
      attendees: [],
      status: "draft",
    };

    const reportWithoutProject = await createCMRReport(cmrWithoutProject);
    if (reportWithoutProject?.id) createdCMRIds.push(reportWithoutProject.id);
    expect(reportWithoutProject).toBeDefined();
    expect(reportWithoutProject?.clientName).toBe("Without Project");
    // Should be able to create CMR without projectId
  });
});
