/**
 * CMR Workflow Logic
 * Implements business rules for:
 * - originalPcPct locking on first submission
 * - outcome finality (sold/lost cannot revert to open)
 * - progress notes creation with timestamps
 * - required field validation
 * - conditional field validation
 */

import { getCMRReport, updateCMRReport } from "./db";
import { TRPCError } from "@trpc/server";

/**
 * Lock originalPcPct on first submission
 * When a CMR is submitted for the first time, set originalPcPct to the current purchaseConfidencePct
 * This value can never be changed after first submission
 */
export async function lockOriginalPcPctOnFirstSubmission(
  cmrId: number,
  currentPcPct: number
): Promise<void> {
  const cmr = await getCMRReport(cmrId);

  if (!cmr) {
    throw new TRPCError({
      code: "NOT_FOUND",
      message: "CMR not found",
    });
  }

  // Only lock on first submission (when status changes from draft to submitted)
  if (cmr.status === "draft" && cmr.originalPcPct === null) {
    await updateCMRReport(cmrId, { originalPcPct: currentPcPct });
  }
}

/**
 * Prevent outcome from reverting from sold/lost back to open
 * Once a CMR is marked as sold or lost, it cannot be changed back to open
 */
export async function validateOutcomeFinality(
  cmrId: number,
  newOutcome: "open" | "sold" | "lost"
): Promise<void> {
  const cmr = await getCMRReport(cmrId);

  if (!cmr) {
    throw new TRPCError({
      code: "NOT_FOUND",
      message: "CMR not found",
    });
  }

  // Check if trying to revert from sold/lost to open
  if (
    (cmr.outcome === "sold" || cmr.outcome === "lost") &&
    newOutcome === "open"
  ) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Cannot revert outcome from ${cmr.outcome} back to open`,
    });
  }
}

/**
 * Validate required fields based on CMR status and deal status
 */
export function validateRequiredFields(data: {
  clientName?: string;
  appointmentDate?: Date;
  appointmentType?: string;
  dealStatus?: string;
  purchaseConfidencePct?: number;
  pcNotes?: string;
}): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!data.clientName || data.clientName.trim().length === 0) {
    errors.push("Client name is required");
  }

  if (!data.appointmentDate) {
    errors.push("Appointment date is required");
  }

  if (!data.appointmentType) {
    errors.push("Appointment type is required");
  }

  if (!data.dealStatus) {
    errors.push("Deal status is required");
  }

  if (
    data.purchaseConfidencePct === undefined ||
    data.purchaseConfidencePct === null ||
    data.purchaseConfidencePct < 0 ||
    data.purchaseConfidencePct > 100
  ) {
    errors.push("Purchase confidence percentage must be between 0 and 100");
  }

  if (!data.pcNotes || data.pcNotes.trim().length === 0) {
    errors.push("PC notes are required");
  } else if (data.pcNotes.trim().length < 10) {
    errors.push("PC notes must be at least 10 characters");
  }

  return { valid: errors.length === 0, errors };
}

/**
 * Validate conditional field requirements
 */
export function validateConditionalFields(data: {
  appointmentType?: string;
  convertedToInPerson?: boolean;
  convertedDate?: Date;
  convertedType?: string;
  dealStatus?: string;
  lostReason?: string;
  leadSources?: string[];
  budgetAlignment?: string;
}): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  // If phone appointment converted to in-person, require conversion details
  if (
    data.appointmentType === "phone" &&
    data.convertedToInPerson === true
  ) {
    if (!data.convertedDate) {
      errors.push("Conversion date is required when phone call converted to in-person");
    }
    if (!data.convertedType) {
      errors.push("Conversion type is required when phone call converted to in-person");
    }
  }

  // If deal status is lost, require lost reason
  if (data.dealStatus === "lost" && !data.lostReason) {
    errors.push("Lost reason is required when deal status is 'lost'");
  }

  // If budget alignment exists, it must be valid
  if (
    data.budgetAlignment &&
    !["aligned", "below", "above", "unknown"].includes(data.budgetAlignment)
  ) {
    errors.push("Invalid budget alignment value");
  }

  return { valid: errors.length === 0, errors };
}

/**
 * Validate PC notes format (must contain at least 3 sentences)
 */
export function validatePcNotes(notes: string): { valid: boolean; error?: string } {
  if (!notes || notes.trim().length === 0) {
    return { valid: false, error: "PC notes cannot be empty" };
  }

  // Count sentences (periods, question marks, exclamation marks)
  const sentenceCount = (notes.match(/[.!?]/g) || []).length;
  if (sentenceCount < 3) {
    return { valid: false, error: "PC notes must contain at least 3 sentences" };
  }

  return { valid: true };
}
