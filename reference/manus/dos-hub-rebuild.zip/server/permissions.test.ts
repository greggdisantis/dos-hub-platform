/**
 * Tests for shared/permissions.ts
 * Verifies role checks, tag checks, module access, and backward compatibility.
 */
import { describe, it, expect } from "vitest";
import {
  hasRole,
  hasMinRole,
  isSuperAdmin,
  hasTag,
  hasAnyTag,
  hasAllTags,
  hasModuleAccess,
  hasFeatureAccess,
  hasRoleAndTag,
  getPermissionSummary,
  type PermissionUser,
} from "../shared/permissions";

// ─── Test fixtures ────────────────────────────────────────────────────────────

const superAdmin: PermissionUser = { role: "super-admin", userType: "internal", specialTags: [] };
const admin: PermissionUser = { role: "admin", userType: "internal", specialTags: [] };
const manager: PermissionUser = { role: "manager", userType: "internal", specialTags: [] };
const member: PermissionUser = { role: "member", userType: "internal", specialTags: [] };
const guest: PermissionUser = { role: "guest", userType: "internal", specialTags: [] };
const pending: PermissionUser = { role: "pending", userType: "internal", specialTags: [] };

// Old user with no specialTags field (backward compat)
const oldUser: PermissionUser = { role: "member", userType: "internal" };

// User with tags
const permitManager: PermissionUser = { role: "manager", userType: "internal", specialTags: ["Permit Dept"] };
const financeManager: PermissionUser = { role: "manager", userType: "internal", specialTags: ["Finance"] };
const multiTagUser: PermissionUser = { role: "member", userType: "internal", specialTags: ["Sales", "Engineering"] };

// ─── hasRole ─────────────────────────────────────────────────────────────────

describe("hasRole", () => {
  it("returns true for exact role match", () => {
    expect(hasRole(admin, "admin")).toBe(true);
    expect(hasRole(manager, "manager")).toBe(true);
  });

  it("returns false for non-matching role", () => {
    expect(hasRole(admin, "super-admin")).toBe(false);
    expect(hasRole(member, "admin")).toBe(false);
  });

  it("returns false for null/undefined user", () => {
    expect(hasRole(null, "admin")).toBe(false);
    expect(hasRole(undefined, "admin")).toBe(false);
  });
});

// ─── hasMinRole ───────────────────────────────────────────────────────────────

describe("hasMinRole", () => {
  it("super-admin passes all role checks", () => {
    expect(hasMinRole(superAdmin, "super-admin")).toBe(true);
    expect(hasMinRole(superAdmin, "admin")).toBe(true);
    expect(hasMinRole(superAdmin, "member")).toBe(true);
  });

  it("admin passes admin and below", () => {
    expect(hasMinRole(admin, "admin")).toBe(true);
    expect(hasMinRole(admin, "manager")).toBe(true);
    expect(hasMinRole(admin, "member")).toBe(true);
    expect(hasMinRole(admin, "super-admin")).toBe(false);
  });

  it("member only passes member and below", () => {
    expect(hasMinRole(member, "member")).toBe(true);
    expect(hasMinRole(member, "guest")).toBe(true);
    expect(hasMinRole(member, "manager")).toBe(false);
  });

  it("pending fails all meaningful checks", () => {
    expect(hasMinRole(pending, "member")).toBe(false);
    expect(hasMinRole(pending, "pending")).toBe(true);
  });
});

// ─── isSuperAdmin ─────────────────────────────────────────────────────────────

describe("isSuperAdmin", () => {
  it("returns true only for super-admin", () => {
    expect(isSuperAdmin(superAdmin)).toBe(true);
    expect(isSuperAdmin(admin)).toBe(false);
    expect(isSuperAdmin(null)).toBe(false);
  });
});

// ─── hasTag ───────────────────────────────────────────────────────────────────

describe("hasTag", () => {
  it("returns true when user has the tag", () => {
    expect(hasTag(permitManager, "Permit Dept")).toBe(true);
  });

  it("returns false when user does not have the tag", () => {
    expect(hasTag(manager, "Permit Dept")).toBe(false);
  });

  it("super-admin bypasses tag check", () => {
    expect(hasTag(superAdmin, "Permit Dept")).toBe(true);
    expect(hasTag(superAdmin, "Finance")).toBe(true);
  });

  it("old user with no specialTags field returns false (not super-admin)", () => {
    expect(hasTag(oldUser, "Permit Dept")).toBe(false);
  });

  it("returns false for null/undefined user", () => {
    expect(hasTag(null, "Permit Dept")).toBe(false);
  });
});

// ─── hasAnyTag ────────────────────────────────────────────────────────────────

describe("hasAnyTag", () => {
  it("returns true if user has at least one of the tags", () => {
    expect(hasAnyTag(multiTagUser, ["Sales", "Finance"])).toBe(true);
    expect(hasAnyTag(multiTagUser, ["Engineering", "HR"])).toBe(true);
  });

  it("returns false if user has none of the tags", () => {
    expect(hasAnyTag(multiTagUser, ["Finance", "HR"])).toBe(false);
  });

  it("super-admin bypasses", () => {
    expect(hasAnyTag(superAdmin, ["Finance"])).toBe(true);
  });
});

// ─── hasAllTags ───────────────────────────────────────────────────────────────

describe("hasAllTags", () => {
  it("returns true if user has all specified tags", () => {
    expect(hasAllTags(multiTagUser, ["Sales", "Engineering"])).toBe(true);
  });

  it("returns false if user is missing any tag", () => {
    expect(hasAllTags(multiTagUser, ["Sales", "Finance"])).toBe(false);
  });
});

// ─── hasModuleAccess ──────────────────────────────────────────────────────────

describe("hasModuleAccess", () => {
  it("super-admin accesses all modules", () => {
    expect(hasModuleAccess(superAdmin, "permits")).toBe(true);
    expect(hasModuleAccess(superAdmin, "user-management")).toBe(true);
    expect(hasModuleAccess(superAdmin, "finance")).toBe(true);
  });

  it("admin accesses all modules", () => {
    expect(hasModuleAccess(admin, "permits")).toBe(true);
    expect(hasModuleAccess(admin, "user-management")).toBe(true);
  });

  it("manager with Permit Dept tag accesses permits", () => {
    expect(hasModuleAccess(permitManager, "permits")).toBe(true);
  });

  it("member without tag cannot access permits", () => {
    expect(hasModuleAccess(member, "permits")).toBe(false);
  });

  it("member can access dashboard and projects", () => {
    expect(hasModuleAccess(member, "dashboard")).toBe(true);
    expect(hasModuleAccess(member, "projects")).toBe(true);
    expect(hasModuleAccess(member, "cmr")).toBe(true);
  });

  it("member with Finance tag can access finance module", () => {
    const finMember: PermissionUser = { role: "member", userType: "internal", specialTags: ["Finance"] };
    // Finance module requires minRole: manager OR Finance tag
    // member doesn't meet minRole but has the tag
    expect(hasModuleAccess(finMember, "finance")).toBe(true);
  });

  it("guest cannot access protected modules", () => {
    expect(hasModuleAccess(guest, "permits")).toBe(false);
    expect(hasModuleAccess(guest, "user-management")).toBe(false);
  });

  it("unknown module defaults to admin-only", () => {
    expect(hasModuleAccess(member, "nonexistent-module")).toBe(false);
    expect(hasModuleAccess(admin, "nonexistent-module")).toBe(true);
  });

  it("null user returns false", () => {
    expect(hasModuleAccess(null, "dashboard")).toBe(false);
  });
});

// ─── hasFeatureAccess ─────────────────────────────────────────────────────────

describe("hasFeatureAccess", () => {
  it("super-admin accesses all features", () => {
    expect(hasFeatureAccess(superAdmin, "cmr.approve")).toBe(true);
    expect(hasFeatureAccess(superAdmin, "finance.edit-commissions")).toBe(true);
  });

  it("manager can approve CMR", () => {
    expect(hasFeatureAccess(manager, "cmr.approve")).toBe(true);
  });

  it("member cannot approve CMR", () => {
    expect(hasFeatureAccess(member, "cmr.approve")).toBe(false);
  });

  it("permit dept member can submit permits", () => {
    const permitMember: PermissionUser = { role: "member", userType: "internal", specialTags: ["Permit Dept"] };
    expect(hasFeatureAccess(permitMember, "permits.submit")).toBe(true);
  });
});

// ─── hasRoleAndTag ────────────────────────────────────────────────────────────

describe("hasRoleAndTag", () => {
  it("returns true when user meets both role and tag", () => {
    expect(hasRoleAndTag(permitManager, "manager", "Permit Dept")).toBe(true);
  });

  it("returns false if only role matches", () => {
    expect(hasRoleAndTag(manager, "manager", "Permit Dept")).toBe(false);
  });

  it("returns false if only tag matches", () => {
    const memberWithTag: PermissionUser = { role: "member", specialTags: ["Permit Dept"] };
    expect(hasRoleAndTag(memberWithTag, "manager", "Permit Dept")).toBe(false);
  });

  it("super-admin bypasses", () => {
    expect(hasRoleAndTag(superAdmin, "manager", "Permit Dept")).toBe(true);
  });
});

// ─── Backward compatibility ───────────────────────────────────────────────────

describe("backward compatibility — old users with no specialTags", () => {
  it("old user with undefined specialTags does not crash", () => {
    expect(() => hasTag(oldUser, "Finance")).not.toThrow();
    expect(() => hasAnyTag(oldUser, ["Finance"])).not.toThrow();
    expect(() => hasModuleAccess(oldUser, "dashboard")).not.toThrow();
    expect(() => getPermissionSummary(oldUser)).not.toThrow();
  });

  it("old user still gets correct role-based access", () => {
    expect(hasModuleAccess(oldUser, "dashboard")).toBe(true);
    expect(hasModuleAccess(oldUser, "permits")).toBe(false);
  });

  it("getPermissionSummary returns empty tags for old user", () => {
    const summary = getPermissionSummary(oldUser);
    expect(summary.specialTags).toEqual([]);
    expect(summary.isSuperAdmin).toBe(false);
  });
});
