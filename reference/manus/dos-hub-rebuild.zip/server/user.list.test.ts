import { describe, it, expect, beforeAll } from "vitest";
import { appRouter } from "./routers";
import type { inferProcedureInput } from "@trpc/server";
import * as db from "./db";

describe("user.list", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeAll(() => {
    // Create a caller with a mock authenticated user context
    caller = appRouter.createCaller({
      user: {
        id: 1,
        email: "test@example.com",
        firstName: "Test",
        lastName: "User",
        role: "admin",
        userType: "internal",
        approved: 1,
        passwordChangeRequired: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: null,
      },
    });
  });

  it("should return a list of all users", async () => {
    const result = await caller.user.list();
    expect(Array.isArray(result)).toBe(true);
    
    // Each user should have id, email, firstName, lastName
    if (result.length > 0) {
      const user = result[0];
      expect(user).toHaveProperty("id");
      expect(user).toHaveProperty("email");
      expect(user).toHaveProperty("firstName");
      expect(user).toHaveProperty("lastName");
    }
  });

  it("should only return safe fields (not passwordHash)", async () => {
    const result = await caller.user.list();
    
    if (result.length > 0) {
      const user = result[0];
      expect(user).not.toHaveProperty("passwordHash");
      expect(user).not.toHaveProperty("role");
      expect(user).not.toHaveProperty("approved");
    }
  });
});
