import { drizzle } from "drizzle-orm/mysql2";
import { desc, eq } from "drizzle-orm";
import { InsertUser, users, cmrReports, InsertCMRReport } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
// In development this resolves to DATABASE_URL_DEV (isolated dev cluster).
// In production this resolves to DATABASE_URL (production cluster).
export async function getDb() {
  const url = ENV.databaseUrl;
  if (!_db && url) {
    try {
      _db = drizzle(url);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

/**
 * Create a new user with email and hashed password
 */
export async function createUser(data: {
  email: string;
  firstName: string;
  lastName: string;
  passwordHash: string;
  role?: "pending" | "guest" | "member" | "manager" | "admin" | "super-admin";
  approved?: number;
}): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  try {
    await db.insert(users).values({
      email: data.email,
      firstName: data.firstName,
      lastName: data.lastName,
      passwordHash: data.passwordHash,
      role: data.role || "pending", // New users start as pending by default
      approved: data.approved ?? 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    });
  } catch (error) {
    console.error("[Database] Failed to create user:", error);
    throw error;
  }
}

/**
 * Get user by email address
 */
export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  try {
    const result = await db
      .select()
      .from(users)
      .where(eq(users.email, email))
      .limit(1);

    return result.length > 0 ? result[0] : undefined;
  } catch (error) {
    console.error("[Database] Failed to get user by email:", error);
    throw error;
  }
}

/**
 * Get user by ID
 */
export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  try {
    const result = await db
      .select()
      .from(users)
      .where(eq(users.id, id))
      .limit(1);

    return result.length > 0 ? result[0] : undefined;
  } catch (error) {
    console.error("[Database] Failed to get user by ID:", error);
    throw error;
  }
}

/**
 * Update user's last signed in timestamp
 */
export async function updateLastSignedIn(userId: number): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  try {
    await db
      .update(users)
      .set({
        lastSignedIn: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));
  } catch (error) {
    console.error("[Database] Failed to update lastSignedIn:", error);
    throw error;
  }
}

/**
 * Update user profile (firstName, lastName)
 */
export async function updateUserProfile(
  userId: number,
  data: {
    firstName?: string;
    lastName?: string;
  }
): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  try {
    const updateData: Record<string, unknown> = {
      updatedAt: new Date(),
    };

    if (data.firstName !== undefined) {
      updateData.firstName = data.firstName;
    }
    if (data.lastName !== undefined) {
      updateData.lastName = data.lastName;
    }

    await db.update(users).set(updateData).where(eq(users.id, userId));
  } catch (error) {
    console.error("[Database] Failed to update user profile:", error);
    throw error;
  }
}

/**
 * Change user password and clear passwordChangeRequired flag
 */
export async function changePassword(
  userId: number,
  newPasswordHash: string
): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  try {
    await db
      .update(users)
      .set({
        passwordHash: newPasswordHash,
        passwordChangeRequired: 0,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));
  } catch (error) {
    console.error("[Database] Failed to change password:", error);
    throw error;
  }
}

/**
 * Update user profile (name, role, approved status)
 */
export async function updateUser(
  userId: number,
  data: {
    name?: string;
    role?: "pending" | "guest" | "member" | "manager" | "admin" | "super-admin";
    approved?: boolean;
  }
): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  try {
    const updateData: Record<string, unknown> = {
      updatedAt: new Date(),
    };

    if (data.name !== undefined) {
      updateData.name = data.name;
    }
    if (data.role !== undefined) {
      updateData.role = data.role;
    }
    if (data.approved !== undefined) {
      updateData.approved = data.approved ? 1 : 0;
    }

    await db.update(users).set(updateData).where(eq(users.id, userId));
  } catch (error) {
    console.error("[Database] Failed to update user:", error);
    throw error;
  }
}

/**
 * Get all pending users (awaiting admin approval)
 */
export async function getPendingUsers() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get pending users: database not available");
    return [];
  }

  try {
    const result = await db
      .select()
      .from(users)
      .where(eq(users.approved, 0));

    return result;
  } catch (error) {
    console.error("[Database] Failed to get pending users:", error);
    throw error;
  }
}

/**
 * Update user approval status
 */
export async function updateUserApproval(userId: number, approved: boolean): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  try {
    await db
      .update(users)
      .set({
        approved: approved ? 1 : 0,
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId));
  } catch (error) {
    console.error("[Database] Failed to update user approval:", error);
    throw error;
  }
}

/**
 * Delete a user (for rejecting pending signups)
 */
export async function deleteUser(userId: number): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  try {
    await db.delete(users).where(eq(users.id, userId));
  } catch (error) {
    console.error("[Database] Failed to delete user:", error);
    throw error;
  }
}


// CMR Report helpers
export async function createCMRReport(data: InsertCMRReport) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create CMR report: database not available");
    return undefined;
  }

  try {
    // Insert the record and get the newly created report
    await db.insert(cmrReports).values(data);
    // Query the most recently created report for this user
    const result = await db.select().from(cmrReports)
      .where(eq(cmrReports.userId, data.userId))
      .orderBy(desc(cmrReports.id))
      .limit(1);
    return result[0];
  } catch (error) {
    console.error("[Database] Failed to create CMR report:", error);
    throw error;
  }
}

export async function getCMRReport(id: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get CMR report: database not available");
    return undefined;
  }

  try {
    const result = await db.select().from(cmrReports).where(eq(cmrReports.id, id)).limit(1);
    return result[0];
  } catch (error) {
    console.error("[Database] Failed to get CMR report:", error);
    throw error;
  }
}

export async function getCMRReportsByUser(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get CMR reports: database not available");
    return [];
  }

  try {
    const result = await db.select().from(cmrReports).where(eq(cmrReports.userId, userId));
    return result;
  } catch (error) {
    console.error("[Database] Failed to get CMR reports:", error);
    throw error;
  }
}

export async function updateCMRReport(id: number, data: Partial<InsertCMRReport>) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update CMR report: database not available");
    return undefined;
  }

  try {
    await db.update(cmrReports).set(data).where(eq(cmrReports.id, id));
    const result = await db.select().from(cmrReports).where(eq(cmrReports.id, id)).limit(1);
    return result[0];
  } catch (error) {
    console.error("[Database] Failed to update CMR report:", error);
    throw error;
  }
}

export async function getCMRReportsByProject(projectId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get CMR reports: database not available");
    return [];
  }

  try {
    const result = await db.select().from(cmrReports).where(eq(cmrReports.projectId, projectId));
    return result;
  } catch (error) {
    console.error("[Database] Failed to get CMR reports by project:", error);
    throw error;
  }
}

export async function getAllCMRReports(filters?: {
  status?: "draft" | "submitted" | "approved";
  userId?: number;
  projectId?: number;
}) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get CMR reports: database not available");
    return [];
  }

  try {
    let query = db.select().from(cmrReports) as any;

    if (filters?.status) {
      query = query.where(eq(cmrReports.status, filters.status as any));
    }
    if (filters?.userId) {
      query = query.where(eq(cmrReports.userId, filters.userId));
    }
    if (filters?.projectId) {
      query = query.where(eq(cmrReports.projectId, filters.projectId));
    }

    const result = await query.orderBy(desc(cmrReports.createdAt));
    return result;
  } catch (error) {
    console.error("[Database] Failed to get all CMR reports:", error);
    throw error;
  }
}

export async function deleteCMRReport(id: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot delete CMR report: database not available");
    return false;
  }

  try {
    await db.delete(cmrReports).where(eq(cmrReports.id, id));
    return true;
  } catch (error) {
    console.error("[Database] Failed to delete CMR report:", error);
    throw error;
  }
}

/**
 * Get all users
 */
export async function getAllUsers() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get users: database not available");
    return [];
  }

  try {
    const result = await db.select().from(users);
    return result;
  } catch (error) {
    console.error("[Database] Failed to get users:", error);
    throw error;
  }
}

/**
 * Get all projects
 */
export async function getAllProjects() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get projects: database not available");
    return [];
  }

  try {
    const { projects } = await import("../drizzle/schema");
    const result = await db.select().from(projects);
    return result;
  } catch (error) {
    console.error("[Database] Failed to get projects:", error);
    throw error;
  }
}


/**
 * Update user management fields (role, userType, approved, passwordChangeRequired)
 */
export async function updateUserManagement(
  userId: number,
  data: {
    role?: "pending" | "guest" | "member" | "manager" | "admin" | "super-admin";
    userType?: "internal" | "dealer" | "sub-dealer" | "vendor" | "guest";
    approved?: boolean;
    passwordChangeRequired?: boolean;
    firstName?: string;
    lastName?: string;
    specialTags?: string[];
  }
): Promise<void> {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  try {
    const updateData: Record<string, unknown> = {
      updatedAt: new Date(),
    };

    if (data.role !== undefined) {
      updateData.role = data.role;
    }
    if (data.userType !== undefined) {
      updateData.userType = data.userType;
    }
    if (data.approved !== undefined) {
      updateData.approved = data.approved ? 1 : 0;
    }
    if (data.passwordChangeRequired !== undefined) {
      updateData.passwordChangeRequired = data.passwordChangeRequired ? 1 : 0;
    }
    if (data.firstName !== undefined) {
      updateData.firstName = data.firstName;
    }
    if (data.lastName !== undefined) {
      updateData.lastName = data.lastName;
    }
    if (data.specialTags !== undefined) {
      updateData.specialTags = data.specialTags;
    }

    await db.update(users).set(updateData).where(eq(users.id, userId));
  } catch (error) {
    console.error("[Database] Failed to update user management:", error);
    throw error;
  }
}

/**
 * Get all users with full details for admin management
 */
export async function getAllUsersForManagement() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get users: database not available");
    return [];
  }

  try {
    const result = await db
      .select({
        id: users.id,
        email: users.email,
        firstName: users.firstName,
        lastName: users.lastName,
        role: users.role,
        userType: users.userType,
        approved: users.approved,
        passwordChangeRequired: users.passwordChangeRequired,
        specialTags: users.specialTags,
        createdAt: users.createdAt,
        updatedAt: users.updatedAt,
        lastSignedIn: users.lastSignedIn,
      })
      .from(users)
      .orderBy(desc(users.createdAt));
    return result;
  } catch (error) {
    console.error("[Database] Failed to get users for management:", error);
    throw error;
  }
}
