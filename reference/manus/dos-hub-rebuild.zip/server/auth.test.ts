import { describe, expect, it, beforeEach, vi } from "vitest";
import {
  hashPassword,
  verifyPassword,
  createSessionToken,
  verifySessionToken,
} from "./_core/auth";

describe("Authentication System", () => {
  describe("Password Hashing", () => {
    it("should hash a password", async () => {
      const password = "TestPassword123!";
      const hash = await hashPassword(password);

      expect(hash).toBeDefined();
      expect(hash).not.toBe(password);
      expect(hash.length).toBeGreaterThan(20); // bcrypt hashes are long
    });

    it("should produce different hashes for the same password", async () => {
      const password = "TestPassword123!";
      const hash1 = await hashPassword(password);
      const hash2 = await hashPassword(password);

      expect(hash1).not.toBe(hash2); // Different salts produce different hashes
    });

    it("should verify a correct password", async () => {
      const password = "TestPassword123!";
      const hash = await hashPassword(password);
      const isValid = await verifyPassword(password, hash);

      expect(isValid).toBe(true);
    });

    it("should reject an incorrect password", async () => {
      const password = "TestPassword123!";
      const wrongPassword = "WrongPassword456!";
      const hash = await hashPassword(password);
      const isValid = await verifyPassword(wrongPassword, hash);

      expect(isValid).toBe(false);
    });
  });

  describe("Session Token Management", () => {
    it("should create a valid JWT session token", async () => {
      const userId = 1;
      const email = "test@example.com";
      const token = await createSessionToken(userId, email);

      expect(token).toBeDefined();
      expect(typeof token).toBe("string");
      expect(token.split(".").length).toBe(3); // JWT has 3 parts
    });

    it("should verify a valid session token", async () => {
      const userId = 1;
      const email = "test@example.com";
      const token = await createSessionToken(userId, email);
      const session = await verifySessionToken(token);

      expect(session).not.toBeNull();
      expect(session?.userId).toBe(userId);
      expect(session?.email).toBe(email);
    });

    it("should reject an invalid token", async () => {
      const invalidToken = "invalid.token.here";
      const session = await verifySessionToken(invalidToken);

      expect(session).toBeNull();
    });

    it("should reject a null token", async () => {
      const session = await verifySessionToken(null);

      expect(session).toBeNull();
    });

    it("should reject an undefined token", async () => {
      const session = await verifySessionToken(undefined);

      expect(session).toBeNull();
    });

    it("should respect token expiration", async () => {
      const userId = 1;
      const email = "test@example.com";
      // Create token with 1ms expiration (will expire immediately)
      const token = await createSessionToken(userId, email, {
        expiresInMs: 1,
      });

      // Wait a bit to ensure token is expired
      await new Promise(resolve => setTimeout(resolve, 10));

      const session = await verifySessionToken(token);

      expect(session).toBeNull();
    });
  });

  describe("Token Payload Validation", () => {
    it("should require userId in session payload", async () => {
      const token = await createSessionToken(123, "test@example.com");
      const session = await verifySessionToken(token);

      expect(session?.userId).toBe(123);
    });

    it("should require email in session payload", async () => {
      const token = await createSessionToken(1, "user@example.com");
      const session = await verifySessionToken(token);

      expect(session?.email).toBe("user@example.com");
    });
  });
});
