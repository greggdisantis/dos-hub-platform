import { describe, it, expect, beforeEach } from "vitest";
import {
  lockOriginalPcPctOnFirstSubmission,
  validateOutcomeFinality,
  addProgressNote,
  validateRequiredFields,
  validateConditionalFields,
  validatePcNotes,
} from "./cmr-workflow";
import { TRPCError } from "@trpc/server";

describe("CMR Workflow Logic", () => {
  describe("validateRequiredFields", () => {
    it("should pass validation with all required fields", () => {
      const result = validateRequiredFields({
        clientName: "John Doe",
        appointmentDate: new Date(),
        appointmentType: "in-home",
        dealStatus: "working-on-design",
        purchaseConfidencePct: 75,
        pcNotes: "This is a detailed note about the meeting and client feedback.",
      });

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it("should fail when clientName is missing", () => {
      const result = validateRequiredFields({
        appointmentDate: new Date(),
        appointmentType: "in-home",
        dealStatus: "working-on-design",
        purchaseConfidencePct: 75,
        pcNotes: "This is a detailed note about the meeting and client feedback.",
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain("Client name is required");
    });

    it("should fail when appointmentDate is missing", () => {
      const result = validateRequiredFields({
        clientName: "John Doe",
        appointmentType: "in-home",
        dealStatus: "working-on-design",
        purchaseConfidencePct: 75,
        pcNotes: "This is a detailed note about the meeting and client feedback.",
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain("Appointment date is required");
    });

    it("should fail when purchaseConfidencePct is out of range", () => {
      const result = validateRequiredFields({
        clientName: "John Doe",
        appointmentDate: new Date(),
        appointmentType: "in-home",
        dealStatus: "working-on-design",
        purchaseConfidencePct: 150,
        pcNotes: "This is a detailed note about the meeting and client feedback.",
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain(
        "Purchase confidence percentage must be between 0 and 100"
      );
    });

    it("should fail when pcNotes is too short", () => {
      const result = validateRequiredFields({
        clientName: "John Doe",
        appointmentDate: new Date(),
        appointmentType: "in-home",
        dealStatus: "working-on-design",
        purchaseConfidencePct: 75,
        pcNotes: "Short",
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain("PC notes must be at least 10 characters");
    });
  });

  describe("validateConditionalFields", () => {
    it("should require conversion details when phone call converted to in-person", () => {
      const result = validateConditionalFields({
        appointmentType: "phone",
        convertedToInPerson: true,
        convertedDate: undefined,
        convertedType: undefined,
        dealStatus: "working-on-design",
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain(
        "Conversion date is required when phone call converted to in-person"
      );
      expect(result.errors).toContain(
        "Conversion type is required when phone call converted to in-person"
      );
    });

    it("should require lost reason when deal status is lost", () => {
      const result = validateConditionalFields({
        dealStatus: "lost",
        lostReason: undefined,
      });

      expect(result.valid).toBe(false);
      expect(result.errors).toContain(
        "Lost reason is required when deal status is 'lost'"
      );
    });

    it("should pass when lost reason is provided for lost deal", () => {
      const result = validateConditionalFields({
        dealStatus: "lost",
        lostReason: "Client decided to go with competitor",
      });

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it("should pass when conversion details are provided", () => {
      const result = validateConditionalFields({
        appointmentType: "phone",
        convertedToInPerson: true,
        convertedDate: new Date(),
        convertedType: "in-home",
      });

      expect(result.valid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });
  });

  describe("validatePcNotes", () => {
    it("should pass with 3 or more sentences", () => {
      const result = validatePcNotes(
        "This is the first sentence. This is the second sentence. This is the third sentence."
      );

      expect(result.valid).toBe(true);
      expect(result.error).toBeUndefined();
    });

    it("should fail with fewer than 3 sentences", () => {
      const result = validatePcNotes("This is the first sentence. This is the second sentence");

      expect(result.valid).toBe(false);
      expect(result.error).toContain("must contain at least 3 sentences");
    });

    it("should fail when empty", () => {
      const result = validatePcNotes("");

      expect(result.valid).toBe(false);
      expect(result.error).toBe("PC notes cannot be empty");
    });

    it("should count question marks and exclamation marks as sentence endings", () => {
      const result = validatePcNotes(
        "Is this the first sentence? This is the second sentence! This is the third sentence."
      );

      expect(result.valid).toBe(true);
    });
  });
});
