/**
 * Motorized Screens — Workflow, Permissions, and Calculation Service
 *
 * Rules:
 * - Backend controls all validation, workflow transitions, and permission checks.
 * - UI only reflects backend state.
 * - Calculations are done here, never in the UI.
 * - Calculation outputs are stored on lines so old records are never affected by rule changes.
 */

import type { ScreenMeasurementHeader, ScreenMeasurementLine, ScreenCalculationProfile } from "../drizzle/schema";

// =============================================================================
// TYPES
// =============================================================================

export type ScreenStatus = "draft" | "submitted" | "approved" | "closed" | "cancelled" | "archived";
export type UserRole = "pending" | "guest" | "member" | "manager" | "admin" | "super-admin";

export interface WorkflowUser {
  id: number;
  role: UserRole;
}

export interface CalculationFlag {
  code: string;
  severity: "info" | "warning" | "error";
  message: string;
}

export interface CalculationResult {
  // Slope analysis
  upperSlope: number | null;
  slopeDirection: "left-high" | "right-high" | "level" | null;
  highSide: number | null;
  lowSide: number | null;
  // Height outputs
  leftHeight: number | null;
  rightHeight: number | null;
  // Top-to-bottom difference
  tbDiff: number | null;
  // U-channel
  uChannelNeeded: boolean;
  uChannelReason: string | null;
  // Build-out
  buildOutRequired: boolean;
  buildOutType: string | null;
  // Track and hood
  trackToTrack: number | null;
  extendedHood: boolean;
  extendedHoodValue: number | null;
  bias: number | null;
  // Final orderable dimensions
  orderableWidth: number | null;
  orderableHeight: number | null;
  // Mismatch flags
  leftSideMismatch: boolean;
  rightSideMismatch: boolean;
  // Structured flags (warnings, errors)
  calculationFlagsJson: CalculationFlag[];
}

// =============================================================================
// WORKFLOW — STATUS TRANSITIONS
// =============================================================================

/**
 * Allowed status transitions per the architecture spec.
 * Key = current status, Value = allowed next statuses.
 */
const ALLOWED_TRANSITIONS: Record<ScreenStatus, ScreenStatus[]> = {
  draft: ["submitted", "cancelled"],
  submitted: ["approved", "draft", "cancelled"],
  approved: ["closed", "draft"], // draft only for admin
  closed: ["archived"],
  cancelled: ["archived"],
  archived: [], // terminal
};

/**
 * Transitions that require admin or higher role.
 */
const ADMIN_ONLY_TRANSITIONS: Array<{ from: ScreenStatus; to: ScreenStatus }> = [
  { from: "approved", to: "draft" }, // Revert approved → draft is admin-only
];

export function isTransitionAllowed(
  from: ScreenStatus,
  to: ScreenStatus,
  user: WorkflowUser,
  ownerId: number
): { allowed: boolean; reason?: string } {
  const allowed = ALLOWED_TRANSITIONS[from] ?? [];

  if (!allowed.includes(to)) {
    return {
      allowed: false,
      reason: `Transition from '${from}' to '${to}' is not permitted.`,
    };
  }

  // Check admin-only transitions
  const isAdminOnly = ADMIN_ONLY_TRANSITIONS.some((t) => t.from === from && t.to === to);
  if (isAdminOnly) {
    const hasAdminRole = ["admin", "super-admin"].includes(user.role);
    if (!hasAdminRole) {
      return {
        allowed: false,
        reason: `Transition from '${from}' to '${to}' requires admin role.`,
      };
    }
  }

  return { allowed: true };
}

// =============================================================================
// PERMISSIONS
// =============================================================================

/**
 * Can the user view this record?
 * Members can view their own records.
 * Managers, admins, super-admins can view all records.
 */
export function canView(user: WorkflowUser, ownerId: number): boolean {
  if (["manager", "admin", "super-admin"].includes(user.role)) return true;
  return user.id === ownerId;
}

/**
 * Can the user edit the header fields?
 * Only allowed in Draft status.
 * Owner can edit their own draft; managers+ can edit any draft.
 */
export function canEditHeader(
  user: WorkflowUser,
  ownerId: number,
  status: ScreenStatus
): { allowed: boolean; reason?: string } {
  if (status !== "draft") {
    return { allowed: false, reason: "Header can only be edited in Draft status." };
  }
  if (["manager", "admin", "super-admin"].includes(user.role)) {
    return { allowed: true };
  }
  if (user.id === ownerId) {
    return { allowed: true };
  }
  return { allowed: false, reason: "You do not have permission to edit this record." };
}

/**
 * Can the user edit lines?
 * Lines are editable only in Draft status.
 * Same ownership rules as header.
 */
export function canEditLines(
  user: WorkflowUser,
  ownerId: number,
  status: ScreenStatus
): { allowed: boolean; reason?: string } {
  if (status !== "draft") {
    return { allowed: false, reason: "Lines can only be edited in Draft status." };
  }
  if (["manager", "admin", "super-admin"].includes(user.role)) {
    return { allowed: true };
  }
  if (user.id === ownerId) {
    return { allowed: true };
  }
  return { allowed: false, reason: "You do not have permission to edit lines on this record." };
}

/**
 * Can the user manage attachments?
 * Attachments are locked when status >= Approved.
 */
export function canManageAttachments(
  user: WorkflowUser,
  ownerId: number,
  status: ScreenStatus
): { allowed: boolean; reason?: string } {
  const lockedStatuses: ScreenStatus[] = ["approved", "closed", "cancelled", "archived"];
  if (lockedStatuses.includes(status)) {
    return { allowed: false, reason: "Attachments are locked once a record is Approved." };
  }
  if (["manager", "admin", "super-admin"].includes(user.role)) {
    return { allowed: true };
  }
  if (user.id === ownerId) {
    return { allowed: true };
  }
  return { allowed: false, reason: "You do not have permission to manage attachments on this record." };
}

/**
 * Can the user approve a submitted record?
 * Requires manager or higher.
 */
export function canApprove(user: WorkflowUser): boolean {
  return ["manager", "admin", "super-admin"].includes(user.role);
}

/**
 * Can the user delete a record?
 * Records with children (lines or attachments) must be archived instead.
 * Only admins can hard-delete, and only when no children exist.
 */
export function canDelete(user: WorkflowUser): boolean {
  return ["admin", "super-admin"].includes(user.role);
}

// =============================================================================
// CALCULATION ENGINE
// =============================================================================

type LineInput = Pick<
  ScreenMeasurementLine,
  | "ul" | "ll" | "ol"
  | "ur" | "lr" | "orMeasurement"
  | "t" | "m" | "b"
  | "reverseMeasurements"
  | "uChannelNeeded" | "uChannelReason"
  | "buildOutRequired" | "buildOutType"
>;

type HeaderInput = Pick<
  ScreenMeasurementHeader,
  "applyUChannelToAll" | "installMount" | "manufacturerCode"
>;

/**
 * ProfileRules
 *
 * All thresholds and tolerances used by calculateScreenLine must come from here.
 * Each field maps directly to a column or JSON sub-field in screen_calculation_profiles.
 * The defaults listed in the comments are the fallback values used when the profile
 * does not supply a value — they must never be changed here without a profile update.
 */
export interface ProfileRules {
  // ── U-channel ──────────────────────────────────────────────────────────────
  /** Slope (inches) above which a U-channel is required. Default: 0.25" */
  uChannelThreshold?: number | null;

  // ── Build-out ──────────────────────────────────────────────────────────────
  buildoutRulesJson?: {
    /** Height differential (inches) above which a build-out is required. Default: 0.5" */
    thresholdInches?: number;
  } | null;

  // ── Track ──────────────────────────────────────────────────────────────────
  trackRulesJson?: {
    /** Width added to each side for track-to-track calculation. Default: 1.75" */
    trackWidthInches?: number;
  } | null;

  // ── Extended hood ──────────────────────────────────────────────────────────
  extendedHoodRulesJson?: {
    /** Slope (inches) above which an extended hood is required. Default: 0.5" */
    slopeThresholdInches?: number;
  } | null;

  // ── Tolerances ─────────────────────────────────────────────────────────────
  toleranceRulesJson?: {
    /** Mismatch tolerance (inches) for left/right upper-lower comparison. Default: 0.25" */
    widthToleranceInches?: number;
    /** Height tolerance (inches) — reserved for future use. Default: 0.125" */
    heightToleranceInches?: number;
  } | null;

  // ── Slope warnings ─────────────────────────────────────────────────────────
  slopeRulesJson?: {
    /** Slope difference below this value is treated as level. Default: 0.0625" (1/16") */
    levelThresholdInches?: number;
    /** Slope above this value triggers a SLOPE_LARGE warning. Default: 1.0" */
    largeWarningThresholdInches?: number;
  } | null;

  // ── Top-to-bottom warnings ─────────────────────────────────────────────────
  tbRulesJson?: {
    /** TB difference above this value triggers a TB_DIFF_LARGE warning. Default: 0.5" */
    largeWarningThresholdInches?: number;
  } | null;

  // ── Bias warnings ──────────────────────────────────────────────────────────
  biasRulesJson?: {
    /** Bias above this value triggers a BIAS_LARGE warning. Default: 0.5" */
    largeWarningThresholdInches?: number;
  } | null;

  // ── Per-manufacturer U-channel threshold overrides ─────────────────────────
  /**
   * Keys are manufacturer codes (lowercase). Values are threshold inches.
   * Example: { "magnatrack": 0.375, "dos-screens": 1.5 }
   * When the header's manufacturerCode matches a key here, that value is used
   * instead of uChannelThreshold. Falls back to uChannelThreshold if no match.
   */
  manufacturerUChannelThresholdsJson?: Record<string, number> | null;
}

function toNum(val: string | number | null | undefined): number | null {
  if (val === null || val === undefined || val === "") return null;
  const n = typeof val === "string" ? parseFloat(val) : val;
  return isNaN(n) ? null : n;
}

/**
 * calculateScreenLine
 *
 * Core calculation engine. Called server-side only.
 * Takes raw measurements from a line, header settings, and the pinned calculation profile.
 * Returns all derived outputs and structured flags.
 *
 * Outputs are stored on the line record so historical records are never affected
 * when calculation rules change.
 */
export function calculateScreenLine(
  line: LineInput,
  header: HeaderInput,
  profile: ProfileRules
): CalculationResult {
  const flags: CalculationFlag[] = [];

  // ── Resolve all thresholds from profile (never hardcoded below this block) ──
  //
  // Each constant reads from the profile first.
  // The ?? fallback is the documented default for this profile version.
  // When the profile supplies a value, the fallback is never used.

  // U-channel threshold resolution (priority order):
  //   1. manufacturerUChannelThresholdsJson[manufacturerCode]  (profile, per-manufacturer)
  //   2. uChannelThreshold                                     (profile, generic)
  //   3. Hardcoded fallbacks below                             (code default, last resort)
  //
  // The hardcoded fallbacks are only reached when the profile row has no value at all.
  // Once the default-v1 row is seeded, these fallbacks are never used in production.
  const mfr = (header.manufacturerCode ?? "").toLowerCase();
  const mfrOverrides = profile.manufacturerUChannelThresholdsJson ?? null;
  const mfrSpecificThreshold = mfrOverrides && mfr ? (mfrOverrides[mfr] ?? null) : null;
  const hardcodedFallback =
    mfr === "magnatrack" ? 0.375 :
    mfr === "dos-screens" ? 1.5 :
    0.25;
  const uChannelThreshold =
    mfrSpecificThreshold ??
    toNum(profile.uChannelThreshold) ??
    hardcodedFallback;

  // Mismatch tolerance: abs((UL+LL) - OL) > tolerance flags a side mismatch
  const mismatchTolerance = profile.toleranceRulesJson?.widthToleranceInches ?? 0.125;

  // Large slope warning threshold
  const slopeLargeWarning = profile.slopeRulesJson?.largeWarningThresholdInches ?? 1.0;

  // Top-to-bottom large difference warning threshold
  const tbLargeWarning = profile.tbRulesJson?.largeWarningThresholdInches ?? 0.5;

  // ── 1. Normalize inputs ────────────────────────────────────────────────────
  // All raw measurements are stored as decimal inch strings; toNum() converts them.
  // snap16() rounds any computed output to the nearest 1/16".
  const snap16 = (v: number): number => Math.round(v * 16) / 16;

  // ── 2. Raw measurements ────────────────────────────────────────────────────
  const ul = toNum(line.ul);
  const ll = toNum(line.ll);
  const ol = toNum(line.ol);
  const ur = toNum(line.ur);
  const lr = toNum(line.lr);
  const or_ = toNum(line.orMeasurement);
  const t = toNum(line.t);
  const m = toNum(line.m);
  const b = toNum(line.b);

  // ── 2. Reverse measurements (swap for calculation only) ────────────────────
  // If reverse_measurements = true: UL↔UR, LL↔LR, OL↔OR
  const reversed = line.reverseMeasurements === 1;
  const leftUpper  = reversed ? ur  : ul;
  const leftLower  = reversed ? lr  : ll;
  const leftOuter  = reversed ? or_ : ol;
  const rightUpper = reversed ? ul  : ur;
  const rightLower = reversed ? ll  : lr;
  const rightOuter = reversed ? ol  : or_;

  // ── 3. Side mismatch ───────────────────────────────────────────────────────
  // left_side_mismatch  = abs((UL + LL) - OL) > tolerance
  // right_side_mismatch = abs((UR + LR) - OR) > tolerance
  let leftSideMismatch = false;
  let rightSideMismatch = false;

  if (leftUpper !== null && leftLower !== null && leftOuter !== null) {
    if (Math.abs((leftUpper + leftLower) - leftOuter) > mismatchTolerance) {
      leftSideMismatch = true;
      flags.push({
        code: "LEFT_MISMATCH",
        severity: "warning",
        message: `Left side mismatch: (UL ${leftUpper}" + LL ${leftLower}") vs OL ${leftOuter}" exceeds tolerance ${mismatchTolerance}".`,
      });
    }
  }

  if (rightUpper !== null && rightLower !== null && rightOuter !== null) {
    if (Math.abs((rightUpper + rightLower) - rightOuter) > mismatchTolerance) {
      rightSideMismatch = true;
      flags.push({
        code: "RIGHT_MISMATCH",
        severity: "warning",
        message: `Right side mismatch: (UR ${rightUpper}" + LR ${rightLower}") vs OR ${rightOuter}" exceeds tolerance ${mismatchTolerance}".`,
      });
    }
  }

  // ── 4. Upper slope ─────────────────────────────────────────────────────────
  // S = abs(UR - UL)  (using the post-reverse values)
  let upperSlope: number | null = null;
  if (leftUpper !== null && rightUpper !== null) {
    upperSlope = snap16(Math.abs(rightUpper - leftUpper));
  }

  // ── 5. Slope direction ─────────────────────────────────────────────────────
  let slopeDirection: "left-high" | "right-high" | "level" | null = null;
  let highSide: number | null = null;
  let lowSide: number | null = null;

  if (leftUpper !== null && rightUpper !== null) {
    if (leftUpper > rightUpper) {
      slopeDirection = "left-high";
      highSide = leftUpper;
      lowSide = rightUpper;
    } else if (rightUpper > leftUpper) {
      slopeDirection = "right-high";
      highSide = rightUpper;
      lowSide = leftUpper;
    } else {
      slopeDirection = "level";
      highSide = leftUpper;
      lowSide = leftUpper;
    }

    if (upperSlope !== null && upperSlope > slopeLargeWarning) {
      flags.push({
        code: "SLOPE_LARGE",
        severity: "warning",
        message: `Slope of ${upperSlope.toFixed(4)}" is unusually large (threshold: ${slopeLargeWarning}"). Verify measurements.`,
      });
    }
  }

  // ── 6 & 7. Left and right heights ──────────────────────────────────────────
  // S = upperSlope (already snapped)
  // level:      left_height = OL,       right_height = OR
  // left-high:  left_height = OL - S,   right_height = OR
  // right-high: left_height = OL,       right_height = OR - S
  // Clamp to >= 0
  let leftHeight: number | null = null;
  let rightHeight: number | null = null;

  if (leftOuter !== null && rightOuter !== null && upperSlope !== null && slopeDirection !== null) {
    if (slopeDirection === "level") {
      leftHeight  = snap16(Math.max(0, leftOuter));
      rightHeight = snap16(Math.max(0, rightOuter));
    } else if (slopeDirection === "left-high") {
      leftHeight  = snap16(Math.max(0, leftOuter - upperSlope));
      rightHeight = snap16(Math.max(0, rightOuter));
    } else {
      // right-high
      leftHeight  = snap16(Math.max(0, leftOuter));
      rightHeight = snap16(Math.max(0, rightOuter - upperSlope));
    }
  } else if (leftOuter !== null) {
    // Only left outer available — use it directly
    leftHeight = snap16(Math.max(0, leftOuter));
  } else if (rightOuter !== null) {
    rightHeight = snap16(Math.max(0, rightOuter));
  }

  // ── 8. T-B difference ──────────────────────────────────────────────────────
  let tbDiff: number | null = null;
  if (t !== null && b !== null) {
    tbDiff = snap16(Math.abs(t - b));
    if (tbDiff > tbLargeWarning) {
      flags.push({
        code: "TB_DIFF_LARGE",
        severity: "warning",
        message: `Top-to-bottom difference of ${tbDiff.toFixed(4)}" exceeds ${tbLargeWarning}". Check for bowing.`,
      });
    }
  }

  // ── 9. U-channel ───────────────────────────────────────────────────────────
  // Priority: manual line override → global header override → slope threshold
  //
  // Architecture note on applyUChannelToAll:
  // This flag is a header-level global override. When set, every line in the header
  // should have uChannelNeeded = true. However, calculateScreenLine operates on a
  // single line at a time and cannot iterate over sibling lines. The router
  // (recalculateLine) must therefore pass applyUChannelToAll = 1 on every line
  // when the header flag is set — which it already does via the header object.
  // No follow-up change is needed here; the architecture is correctly applied.
  let uChannelNeeded = false;
  let uChannelReason: string | null = null;

  if (line.uChannelNeeded === 1) {
    uChannelNeeded = true;
    uChannelReason = line.uChannelReason ?? "Manually set";
  } else if (header.applyUChannelToAll === 1) {
    uChannelNeeded = true;
    uChannelReason = "Applied to all screens (global setting)";
  } else if (upperSlope !== null && upperSlope > uChannelThreshold) {
    uChannelNeeded = true;
    uChannelReason = `Slope of ${upperSlope.toFixed(4)}" exceeds U-channel threshold of ${uChannelThreshold}" for ${header.manufacturerCode ?? "this manufacturer"}`;
  }

  // ── 10. Build-out ──────────────────────────────────────────────────────────
  // Driven by slope S (upperSlope):
  //   S < 7/16"          → none
  //   7/16" ≤ S ≤ 3/4"   → 1x2
  //   13/16" ≤ S ≤ 1.75" → 2x2
  //   S > 1.75"          → FLAG (requires manual review)
  // Manual override from line takes precedence.
  let buildOutRequired = false;
  let buildOutType: string | null = null;

  if (line.buildOutRequired === 1) {
    buildOutRequired = true;
    buildOutType = line.buildOutType ?? "Manual";
  } else if (upperSlope !== null) {
    const s = upperSlope;
    if (s > 1.75) {
      buildOutRequired = true;
      buildOutType = "FLAG — slope exceeds 1.75\", manual review required";
      flags.push({
        code: "BUILDOUT_SLOPE_EXCEEDS_MAX",
        severity: "error",
        message: `Slope of ${s.toFixed(4)}" exceeds 1.75". Build-out cannot be automatically determined. Manual review required.`,
      });
    } else if (s >= 0.8125) {
      // 13/16" = 0.8125
      buildOutRequired = true;
      buildOutType = "2x2";
      flags.push({
        code: "BUILDOUT_REQUIRED",
        severity: "warning",
        message: `Slope of ${s.toFixed(4)}" requires a 2x2 build-out.`,
      });
    } else if (s >= 0.4375) {
      // 7/16" = 0.4375
      buildOutRequired = true;
      buildOutType = "1x2";
      flags.push({
        code: "BUILDOUT_REQUIRED",
        severity: "warning",
        message: `Slope of ${s.toFixed(4)}" requires a 1x2 build-out.`,
      });
    }
    // else: s < 7/16" → no build-out
  }

  // ── 11. Track-to-track ─────────────────────────────────────────────────────
  // If U-channel: track_to_track = min(T - 1/8, M, B) - 1
  // Else:         track_to_track = T - 1/8
  let trackToTrack: number | null = null;
  const ONE_EIGHTH = 0.125;
  const ONE = 1.0;

  if (uChannelNeeded) {
    const candidates = [
      t !== null ? t - ONE_EIGHTH : null,
      m,
      b,
    ].filter((v): v is number => v !== null);
    if (candidates.length > 0) {
      trackToTrack = snap16(Math.min(...candidates) - ONE);
    }
  } else {
    if (t !== null) {
      trackToTrack = snap16(t - ONE_EIGHTH);
    }
  }

  // ── 12. Extended hood ──────────────────────────────────────────────────────
  // DOS Screens + undermount → none (extendedHood = false, value = null)
  // MagnaTrack + undermount + U-channel → T - 1/8
  // All others → M + 4.5
  //
  // extendedHood (boolean) = true when a non-zero hood extension is required.
  // The numeric value is stored in trackToTrack-adjacent logic; here we only
  // set the boolean flag and record the computed value for reference.
  let extendedHood = false;
  let extendedHoodValue: number | null = null;
  const isUndermount = header.installMount === "inside-mount";

  if (mfr === "dos-screens" && isUndermount) {
    extendedHood = false;
    extendedHoodValue = null;
  } else if (mfr === "magnatrack" && isUndermount && uChannelNeeded) {
    extendedHood = true;
    extendedHoodValue = t !== null ? snap16(t - ONE_EIGHTH) : null;
  } else {
    extendedHood = m !== null;
    extendedHoodValue = m !== null ? snap16(m + 4.5) : null;
  }

  // ── 13. Bias ───────────────────────────────────────────────────────────────
  // bias = S / 2  (half the upper slope)
  let bias: number | null = null;
  if (upperSlope !== null) {
    bias = snap16(upperSlope / 2);
  }

  // ── 14. Orderable dimensions ───────────────────────────────────────────────
  // orderable_width  = M
  // orderable_height = max(left_height, right_height)
  const orderableWidth: number | null = m !== null ? snap16(m) : null;

  let orderableHeight: number | null = null;
  if (leftHeight !== null && rightHeight !== null) {
    orderableHeight = snap16(Math.max(leftHeight, rightHeight));
  } else if (leftHeight !== null) {
    orderableHeight = snap16(leftHeight);
  } else if (rightHeight !== null) {
    orderableHeight = snap16(rightHeight);
  }

  // ── 15. Missing measurement warnings ──────────────────────────────────────
  if (t === null && m === null && b === null) {
    flags.push({
      code: "NO_WIDTH_MEASUREMENTS",
      severity: "error",
      message: "No width measurements (T/M/B) provided. Cannot calculate orderable width.",
    });
  }

  if (leftOuter === null && rightOuter === null) {
    flags.push({
      code: "NO_HEIGHT_MEASUREMENTS",
      severity: "error",
      message: "No outer height measurements (OL/OR) provided. Cannot calculate orderable height.",
    });
  }

  // ── Return ─────────────────────────────────────────────────────────────────
  return {
    upperSlope,
    slopeDirection,
    highSide,
    lowSide,
    leftHeight,
    rightHeight,
    tbDiff,
    uChannelNeeded,
    uChannelReason,
    buildOutRequired,
    buildOutType,
    trackToTrack,
    extendedHood,
    extendedHoodValue,
    bias,
    orderableWidth,
    orderableHeight,
    leftSideMismatch,
    rightSideMismatch,
    calculationFlagsJson: flags,
  };
}

// =============================================================================
// RECORD NUMBER GENERATOR
// =============================================================================

/**
 * Generate the next sequential record number in the format SM-XXXX.
 * Called by the create procedure before inserting the header.
 */
export function generateRecordNumber(lastNumber: string | null): string {
  if (!lastNumber) return "SM-0001";
  const match = lastNumber.match(/SM-(\d+)$/);
  if (!match) return "SM-0001";
  const next = parseInt(match[1], 10) + 1;
  return `SM-${String(next).padStart(4, "0")}`;
}
