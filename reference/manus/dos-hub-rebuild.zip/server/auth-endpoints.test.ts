import { describe, expect, it, beforeEach, vi } from "vitest";
import { appRouter } from "./routers";
import { COOKIE_NAME } from "../shared/const";
import * as auth from "./_core/auth";
import * as db from "./db";

// Mock modules
vi.mock("./_core/auth");
vi.mock("./db");

function createMockContext() {
  return {
    req: {
      protocol: "https",
      headers: {},
    },
    res: {
      cookie: vi.fn(),
      clearCookie: vi.fn(),
    },
    user: null,
  };
}

describe("Auth Endpoints", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("auth.signup", () => {
    it("should create a new user with firstName and lastName", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      // Mock: user doesn't exist
      vi.mocked(db.getUserByEmail).mockResolvedValueOnce(undefined);

      // Mock: create user succeeds
      vi.mocked(db.createUser).mockResolvedValueOnce();

      // Mock: get newly created user
      vi.mocked(db.getUserByEmail).mockResolvedValueOnce({
        id: 1,
        email: "test@example.com",
        firstName: "Test",
        lastName: "User",
        passwordHash: "hashed_password",
        role: "pending",
        approved: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: null,
      });

      // Mock: password hashing
      vi.mocked(auth.hashPassword).mockResolvedValueOnce("hashed_password");

      const result = await caller.auth.signup({
        email: "test@example.com",
        firstName: "Test",
        lastName: "User",
        password: "Password123",
      });

      expect(result.success).toBe(true);
      expect(result.user.email).toBe("test@example.com");
      expect(result.user.firstName).toBe("Test");
      expect(result.user.lastName).toBe("User");
      expect(result.user.role).toBe("pending");
      expect(result.user.approved).toBe(false);
    });

    it("should reject duplicate email", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      // Mock: user already exists
      vi.mocked(db.getUserByEmail).mockResolvedValueOnce({
        id: 1,
        email: "existing@example.com",
        firstName: "Existing",
        lastName: "User",
        passwordHash: "hashed_password",
        role: "pending",
        approved: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: null,
      });

      await expect(
        caller.auth.signup({
          email: "existing@example.com",
          firstName: "Test",
          lastName: "User",
          password: "Password123",
        })
      ).rejects.toThrow("User with this email already exists");
    });

    it("should auto-approve super-admin emails", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      // Mock: user doesn't exist
      vi.mocked(db.getUserByEmail).mockResolvedValueOnce(undefined);

      // Mock: create user succeeds
      vi.mocked(db.createUser).mockResolvedValueOnce();

      // Mock: get newly created super-admin user
      vi.mocked(db.getUserByEmail).mockResolvedValueOnce({
        id: 1,
        email: "Greggdisantis@gmail.com",
        firstName: "Gregg",
        lastName: "DiSantis",
        passwordHash: "hashed_password",
        role: "super-admin",
        approved: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: null,
      });

      // Mock: password hashing
      vi.mocked(auth.hashPassword).mockResolvedValueOnce("hashed_password");

      const result = await caller.auth.signup({
        email: "Greggdisantis@gmail.com",
        firstName: "Gregg",
        lastName: "DiSantis",
        password: "Password123",
      });

      expect(result.success).toBe(true);
      expect(result.user.role).toBe("super-admin");
      expect(result.user.approved).toBe(true);
      expect(result.message).toContain("Super-admin account created and approved");
    });
  });

  describe("auth.login", () => {
    it("should set session cookie on successful login", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      // Mock: user exists and is approved
      vi.mocked(db.getUserByEmail).mockResolvedValueOnce({
        id: 1,
        email: "test@example.com",
        firstName: "Test",
        lastName: "User",
        passwordHash: "hashed_password",
        role: "member",
        approved: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: null,
      });

      // Mock: password verification succeeds
      vi.mocked(auth.verifyPassword).mockResolvedValueOnce(true);

      // Mock: session token creation
      vi.mocked(auth.createSessionToken).mockResolvedValueOnce("mock_token");

      // Mock: update last signed in
      vi.mocked(db.updateLastSignedIn).mockResolvedValueOnce();

      const result = await caller.auth.login({
        email: "test@example.com",
        password: "Password123",
      });

      expect(result.success).toBe(true);
      expect(result.user.email).toBe("test@example.com");
      expect(result.user.firstName).toBe("Test");
      expect(result.user.lastName).toBe("User");
      expect(result.user.approved).toBe(true);

      // Verify cookie was set
      expect(ctx.res.cookie).toHaveBeenCalled();
    });

    it("should reject invalid credentials", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      // Mock: user exists
      vi.mocked(db.getUserByEmail).mockResolvedValueOnce({
        id: 1,
        email: "test@example.com",
        firstName: "Test",
        lastName: "User",
        passwordHash: "hashed_password",
        role: "member",
        approved: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: null,
      });

      // Mock: password verification fails
      vi.mocked(auth.verifyPassword).mockResolvedValueOnce(false);

      await expect(
        caller.auth.login({
          email: "test@example.com",
          password: "WrongPassword",
        })
      ).rejects.toThrow("Invalid email or password");
    });

    it("should reject if user is not approved", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      // Mock: user exists but not approved
      vi.mocked(db.getUserByEmail).mockResolvedValueOnce({
        id: 1,
        email: "test@example.com",
        firstName: "Test",
        lastName: "User",
        passwordHash: "hashed_password",
        role: "pending",
        approved: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: null,
      });

      // Mock: password verification succeeds
      vi.mocked(auth.verifyPassword).mockResolvedValueOnce(true);

      await expect(
        caller.auth.login({
          email: "test@example.com",
          password: "Password123",
        })
      ).rejects.toThrow("Your account is pending admin approval");
    });
  });

  describe("auth.logout", () => {
    it("should clear session cookie on logout", async () => {
      const ctx = createMockContext();
      const caller = appRouter.createCaller(ctx);

      const result = await caller.auth.logout();

      expect(result.success).toBe(true);
      expect(ctx.res.clearCookie).toHaveBeenCalledWith(
        COOKIE_NAME,
        expect.objectContaining({
          maxAge: -1,
        })
      );
    });
  });
});
