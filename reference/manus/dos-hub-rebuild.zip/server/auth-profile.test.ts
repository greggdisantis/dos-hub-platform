import { describe, it, expect, beforeEach, vi } from "vitest";
import { appRouter } from "./routers";
import * as auth from "./_core/auth";
import * as db from "./db";

// Mock modules
vi.mock("./_core/auth");
vi.mock("./db");

function createMockContext(user: any = null) {
  return {
    req: {
      protocol: "https",
      headers: {},
    },
    res: {
      cookie: vi.fn(),
      clearCookie: vi.fn(),
    },
    user,
  };
}

describe("Profile Completion Flow", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("auth.updateProfile", () => {
    it("should allow authenticated user to update profile with firstName and lastName", async () => {
      const ctx = createMockContext({
        id: 1,
        email: "test@example.com",
        firstName: "",
        lastName: "",
        role: "member",
        approved: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: null,
      });

      const caller = appRouter.createCaller(ctx);

      // Mock: update succeeds
      vi.mocked(db.updateUserProfile).mockResolvedValueOnce();

      // Mock: get updated user
      vi.mocked(db.getUserById).mockResolvedValueOnce({
        id: 1,
        email: "test@example.com",
        firstName: "John",
        lastName: "Doe",
        passwordHash: "hashed_password",
        role: "member",
        approved: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: null,
      });

      const result = await caller.auth.updateProfile({
        firstName: "John",
        lastName: "Doe",
      });

      expect(result.success).toBe(true);
      expect(result.user.firstName).toBe("John");
      expect(result.user.lastName).toBe("Doe");
      expect(vi.mocked(db.updateUserProfile)).toHaveBeenCalledWith(1, {
        firstName: "John",
        lastName: "Doe",
      });
    });

    it("should reject profile update with empty firstName", async () => {
      const ctx = createMockContext({
        id: 1,
        email: "test@example.com",
        firstName: "",
        lastName: "",
        role: "member",
        approved: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: null,
      });

      const caller = appRouter.createCaller(ctx);

      try {
        await caller.auth.updateProfile({
          firstName: "",
          lastName: "Doe",
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.message).toContain("First name is required");
      }
    });

    it("should reject profile update with empty lastName", async () => {
      const ctx = createMockContext({
        id: 1,
        email: "test@example.com",
        firstName: "",
        lastName: "",
        role: "member",
        approved: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: null,
      });

      const caller = appRouter.createCaller(ctx);

      try {
        await caller.auth.updateProfile({
          firstName: "John",
          lastName: "",
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.message).toContain("Last name is required");
      }
    });

    it("should reject profile update from unauthenticated user", async () => {
      const ctx = createMockContext(null);
      const caller = appRouter.createCaller(ctx);

      try {
        await caller.auth.updateProfile({
          firstName: "John",
          lastName: "Doe",
        });
        expect.fail("Should have thrown an error");
      } catch (error: any) {
        expect(error.code).toBe("UNAUTHORIZED");
      }
    });

    it("should trim whitespace from firstName and lastName", async () => {
      const ctx = createMockContext({
        id: 1,
        email: "test@example.com",
        firstName: "",
        lastName: "",
        role: "member",
        approved: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: null,
      });

      const caller = appRouter.createCaller(ctx);

      // Mock: update succeeds
      vi.mocked(db.updateUserProfile).mockResolvedValueOnce();

      // Mock: get updated user
      vi.mocked(db.getUserById).mockResolvedValueOnce({
        id: 1,
        email: "test@example.com",
        firstName: "Jane",
        lastName: "Smith",
        passwordHash: "hashed_password",
        role: "member",
        approved: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: null,
      });

      const result = await caller.auth.updateProfile({
        firstName: "  Jane  ",
        lastName: "  Smith  ",
      });

      expect(result.success).toBe(true);
      // Verify that trimmed values were passed to updateUserProfile
      expect(vi.mocked(db.updateUserProfile)).toHaveBeenCalledWith(1, {
        firstName: "Jane",
        lastName: "Smith",
      });
    });
  });
});
