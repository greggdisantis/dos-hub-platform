/**
 * db-connection.test.ts
 * Validates that DATABASE_URL_DEV connects successfully to dos_hub_dev on gateway01.
 * This test is intentionally skipped in CI environments where the DB is not reachable.
 */
import { describe, it, expect } from "vitest";
import { sql } from "drizzle-orm";
import { getDb } from "./db";

describe("DATABASE_URL_DEV connection", () => {
  it("should connect to dos_hub_dev and return a valid result", async () => {
    const db = await getDb();
    expect(db).not.toBeNull();
    // A lightweight read that requires a valid connection and correct credentials
    const result = await db!.execute(sql`SELECT 1 AS ok`);
    expect(result).toBeDefined();
  }, 15000);
});
