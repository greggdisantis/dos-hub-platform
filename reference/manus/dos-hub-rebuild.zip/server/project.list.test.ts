import { describe, it, expect, beforeAll } from "vitest";
import { appRouter } from "./routers";

describe("project.list", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;

  beforeAll(() => {
    // Create a caller with a mock authenticated user context
    caller = appRouter.createCaller({
      user: {
        id: 1,
        email: "test@example.com",
        firstName: "Test",
        lastName: "User",
        role: "admin",
        userType: "internal",
        approved: 1,
        passwordChangeRequired: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: null,
      },
    });
  });

  it("should return a list of all projects", async () => {
    const result = await caller.project.list();
    expect(Array.isArray(result)).toBe(true);
    
    // Each project should have id, name, clientName, projectStage
    if (result.length > 0) {
      const project = result[0];
      expect(project).toHaveProperty("id");
      expect(project).toHaveProperty("name");
      expect(project).toHaveProperty("clientName");
      expect(project).toHaveProperty("projectStage");
    }
  });

  it("should only return safe fields", async () => {
    const result = await caller.project.list();
    
    if (result.length > 0) {
      const project = result[0];
      expect(project).not.toHaveProperty("userId");
      expect(project).not.toHaveProperty("hubspotDealId");
      expect(project).not.toHaveProperty("serviceFusionJobId");
    }
  });
});
