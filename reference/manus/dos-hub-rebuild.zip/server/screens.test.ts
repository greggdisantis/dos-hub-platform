/**
 * Motorized Screens Module Tests
 * Tests cover:
 * - Workflow transitions (valid and invalid)
 * - Permission checks (owner, manager, admin)
 * - calculateScreenLine outputs
 */

import { describe, it, expect } from "vitest";
import {
  isTransitionAllowed,
  canView,
  canEditHeader,
  canEditLines,
  canApprove,
  canDelete,
  canManageAttachments,
  calculateScreenLine,
  type WorkflowUser,
  type ScreenStatus,
} from "./screen-workflow";

// ─── Test users ───────────────────────────────────────────────────────────────
const ownerUser: WorkflowUser = { id: 10, role: "member" };
const otherUser: WorkflowUser = { id: 20, role: "member" };
const managerUser: WorkflowUser = { id: 30, role: "manager" };
const adminUser: WorkflowUser = { id: 40, role: "admin" };
const superAdminUser: WorkflowUser = { id: 50, role: "super-admin" };
const OWNER_ID = 10;

// ─── Default profile for calculation tests ────────────────────────────────────
const defaultProfile = {
  uChannelThreshold: 0.25,
  buildoutRulesJson: { thresholdInches: 0.5 },
  trackRulesJson: { trackWidthInches: 1.75 },
  extendedHoodRulesJson: { slopeThresholdInches: 0.5 },
  toleranceRulesJson: { widthToleranceInches: 0.125, heightToleranceInches: 0.125 },
};

// ─── Workflow Transition Tests ─────────────────────────────────────────────────

describe("Screen Measurement Workflow — isTransitionAllowed", () => {
  it("allows draft → submitted (owner)", () => {
    const r = isTransitionAllowed("draft", "submitted", ownerUser, OWNER_ID);
    expect(r.allowed).toBe(true);
  });

  it("allows submitted → approved (manager)", () => {
    const r = isTransitionAllowed("submitted", "approved", managerUser, OWNER_ID);
    expect(r.allowed).toBe(true);
  });

  it("allows submitted → draft / reopen (owner)", () => {
    const r = isTransitionAllowed("submitted", "draft", ownerUser, OWNER_ID);
    expect(r.allowed).toBe(true);
  });

  it("allows approved → closed (manager)", () => {
    const r = isTransitionAllowed("approved", "closed", managerUser, OWNER_ID);
    expect(r.allowed).toBe(true);
  });

  it("allows draft → cancelled (owner)", () => {
    const r = isTransitionAllowed("draft", "cancelled", ownerUser, OWNER_ID);
    expect(r.allowed).toBe(true);
  });

  it("allows submitted → cancelled (owner)", () => {
    const r = isTransitionAllowed("submitted", "cancelled", ownerUser, OWNER_ID);
    expect(r.allowed).toBe(true);
  });

  it("blocks draft → approved (skip step)", () => {
    const r = isTransitionAllowed("draft", "approved", managerUser, OWNER_ID);
    expect(r.allowed).toBe(false);
  });

  it("blocks approved → draft for non-admin", () => {
    const r = isTransitionAllowed("approved", "draft", managerUser, OWNER_ID);
    expect(r.allowed).toBe(false);
  });

  it("allows approved → draft for admin", () => {
    const r = isTransitionAllowed("approved", "draft", adminUser, OWNER_ID);
    expect(r.allowed).toBe(true);
  });

  it("blocks closed → draft", () => {
    const r = isTransitionAllowed("closed", "draft", adminUser, OWNER_ID);
    expect(r.allowed).toBe(false);
  });

  it("blocks cancelled → any", () => {
    expect(isTransitionAllowed("cancelled", "draft", adminUser, OWNER_ID).allowed).toBe(false);
    expect(isTransitionAllowed("cancelled", "submitted", adminUser, OWNER_ID).allowed).toBe(false);
  });

  it("blocks archived → any", () => {
    expect(isTransitionAllowed("archived", "draft", adminUser, OWNER_ID).allowed).toBe(false);
    expect(isTransitionAllowed("archived", "submitted", adminUser, OWNER_ID).allowed).toBe(false);
  });

  it("returns a reason string when blocked", () => {
    const r = isTransitionAllowed("draft", "approved", ownerUser, OWNER_ID);
    expect(r.allowed).toBe(false);
    expect(typeof r.reason).toBe("string");
    expect(r.reason!.length).toBeGreaterThan(0);
  });
});

// ─── Permission Tests ──────────────────────────────────────────────────────────

describe("Screen Measurement Permissions — canView", () => {
  it("owner can view their own record", () => {
    expect(canView(ownerUser, OWNER_ID)).toBe(true);
  });

  it("other user cannot view someone else's record", () => {
    expect(canView(otherUser, OWNER_ID)).toBe(false);
  });

  it("manager can view any record", () => {
    expect(canView(managerUser, OWNER_ID)).toBe(true);
  });

  it("super-admin can view any record", () => {
    expect(canView(superAdminUser, OWNER_ID)).toBe(true);
  });
});

describe("Screen Measurement Permissions — canEditHeader", () => {
  it("owner can edit their own draft", () => {
    expect(canEditHeader(ownerUser, OWNER_ID, "draft").allowed).toBe(true);
  });

  it("other user cannot edit someone else's draft", () => {
    expect(canEditHeader(otherUser, OWNER_ID, "draft").allowed).toBe(false);
  });

  it("manager can edit any draft", () => {
    expect(canEditHeader(managerUser, OWNER_ID, "draft").allowed).toBe(true);
  });

  it("owner cannot edit submitted record", () => {
    expect(canEditHeader(ownerUser, OWNER_ID, "submitted").allowed).toBe(false);
  });

  it("manager can edit submitted record", () => {
    expect(canEditHeader(managerUser, OWNER_ID, "submitted").allowed).toBe(false); // locked at submitted
  });

  it("nobody can edit approved record except admin", () => {
    expect(canEditHeader(ownerUser, OWNER_ID, "approved").allowed).toBe(false);
    expect(canEditHeader(managerUser, OWNER_ID, "approved").allowed).toBe(false);
  });
});

describe("Screen Measurement Permissions — canEditLines", () => {
  it("owner can edit lines on draft", () => {
    expect(canEditLines(ownerUser, OWNER_ID, "draft").allowed).toBe(true);
  });

  it("other user cannot edit lines on someone else's draft", () => {
    expect(canEditLines(otherUser, OWNER_ID, "draft").allowed).toBe(false);
  });

  it("manager can edit lines on any draft", () => {
    expect(canEditLines(managerUser, OWNER_ID, "draft").allowed).toBe(true);
  });

  it("nobody can edit lines on submitted record", () => {
    expect(canEditLines(ownerUser, OWNER_ID, "submitted").allowed).toBe(false);
    expect(canEditLines(managerUser, OWNER_ID, "submitted").allowed).toBe(false);
  });
});

describe("Screen Measurement Permissions — canApprove", () => {
  it("manager can approve", () => {
    expect(canApprove(managerUser)).toBe(true);
  });

  it("admin can approve", () => {
    expect(canApprove(adminUser)).toBe(true);
  });

  it("owner cannot approve", () => {
    expect(canApprove(ownerUser)).toBe(false);
  });

  it("regular member cannot approve", () => {
    expect(canApprove(otherUser)).toBe(false);
  });
});

describe("Screen Measurement Permissions — canDelete", () => {
  it("admin can delete", () => {
    expect(canDelete(adminUser)).toBe(true);
  });

  it("super-admin can delete", () => {
    expect(canDelete(superAdminUser)).toBe(true);
  });

  it("manager cannot delete", () => {
    expect(canDelete(managerUser)).toBe(false);
  });

  it("owner cannot delete", () => {
    expect(canDelete(ownerUser)).toBe(false);
  });
});

describe("Screen Measurement Permissions — canManageAttachments", () => {
  it("owner can manage attachments on draft", () => {
    expect(canManageAttachments(ownerUser, OWNER_ID, "draft").allowed).toBe(true);
  });

  it("owner can manage attachments on submitted", () => {
    expect(canManageAttachments(ownerUser, OWNER_ID, "submitted").allowed).toBe(true);
  });

  it("attachments locked on approved", () => {
    expect(canManageAttachments(ownerUser, OWNER_ID, "approved").allowed).toBe(false);
    expect(canManageAttachments(managerUser, OWNER_ID, "approved").allowed).toBe(false);
  });

  it("other user cannot manage attachments on someone else's draft", () => {
    expect(canManageAttachments(otherUser, OWNER_ID, "draft").allowed).toBe(false);
  });
});

// ─── Calculation Tests ─────────────────────────────────────────────────────────

describe("calculateScreenLine — approved formulas", () => {
  // baseHeader now includes manufacturerCode (required by HeaderInput)
  const baseHeader = {
    applyUChannelToAll: 0 as 0 | 1,
    installMount: "face-mount" as const,
    manufacturerCode: "generic" as string | null,
  };

  // A perfectly square opening: all measurements equal, no slope.
  const squareLine = {
    ul: "84.000", ll: "84.000", ol: "168.000",   // OL = UL + LL = 168
    ur: "84.000", lr: "84.000", orMeasurement: "168.000",
    t: "60.000", m: "60.000", b: "60.000",
    reverseMeasurements: 0 as 0 | 1,
    uChannelNeeded: 0 as 0 | 1, uChannelReason: null,
    buildOutRequired: 0 as 0 | 1, buildOutType: null,
  };

  // ── Rule 1: snap to nearest 1/16" ─────────────────────────────────────────
  it("snaps outputs to nearest 1/16\"", () => {
    // OL = 84.1, OR = 84.0 → slope = 0.1 → snapped = 0.125 (2/16)
    const line = {
      ...squareLine,
      ul: "84.1", ll: "84.1", ol: "168.2",
      ur: "84.0", lr: "84.0", orMeasurement: "168.0",
    };
    const result = calculateScreenLine(line, baseHeader, defaultProfile);
    // upperSlope = abs(84.0 - 84.1) = 0.1 → snap16 → 0.125
    expect(result.upperSlope).toBe(0.125);
  });

  // ── Rule 2: reverse measurements ─────────────────────────────────────────
  it("swaps left/right when reverseMeasurements = 1", () => {
    // Left-high in normal orientation: UL=90, UR=84
    const normalLine = {
      ...squareLine,
      ul: "90.000", ll: "90.000", ol: "180.000",
      ur: "84.000", lr: "84.000", orMeasurement: "168.000",
    };
    const reversedLine = { ...normalLine, reverseMeasurements: 1 as 0 | 1 };
    const normal  = calculateScreenLine(normalLine,  baseHeader, defaultProfile);
    const reversed = calculateScreenLine(reversedLine, baseHeader, defaultProfile);
    // After reversal the roles swap: what was right-upper (84) becomes left-upper
    expect(normal.slopeDirection).toBe("left-high");
    expect(reversed.slopeDirection).toBe("right-high");
  });

  // ── Rule 3: side mismatch ─────────────────────────────────────────────────
  it("flags left side mismatch when abs((UL+LL) - OL) > tolerance", () => {
    // UL=84, LL=84, OL=168 → diff = 0 → no mismatch
    const noMismatch = calculateScreenLine(squareLine, baseHeader, defaultProfile);
    expect(noMismatch.leftSideMismatch).toBe(false);

    // UL=84, LL=84, OL=170 → diff = 2 → mismatch
    const mismatchLine = { ...squareLine, ol: "170.000" };
    const withMismatch = calculateScreenLine(mismatchLine, baseHeader, defaultProfile);
    expect(withMismatch.leftSideMismatch).toBe(true);
    expect(withMismatch.calculationFlagsJson.some(f => f.code === "LEFT_MISMATCH")).toBe(true);
  });

  it("flags right side mismatch when abs((UR+LR) - OR) > tolerance", () => {
    const mismatchLine = { ...squareLine, orMeasurement: "170.000" };
    const result = calculateScreenLine(mismatchLine, baseHeader, defaultProfile);
    expect(result.rightSideMismatch).toBe(true);
    expect(result.calculationFlagsJson.some(f => f.code === "RIGHT_MISMATCH")).toBe(true);
  });

  // ── Rule 4 & 5: upper slope and direction ─────────────────────────────────
  it("calculates S = abs(UR - UL) and direction = left-high when UL > UR", () => {
    const line = {
      ...squareLine,
      ul: "90.000", ll: "90.000", ol: "180.000",
      ur: "84.000", lr: "84.000", orMeasurement: "168.000",
    };
    const result = calculateScreenLine(line, baseHeader, defaultProfile);
    expect(result.upperSlope).toBe(6.0);
    expect(result.slopeDirection).toBe("left-high");
  });

  it("direction = right-high when UR > UL", () => {
    const line = {
      ...squareLine,
      ul: "84.000", ll: "84.000", ol: "168.000",
      ur: "90.000", lr: "90.000", orMeasurement: "180.000",
    };
    const result = calculateScreenLine(line, baseHeader, defaultProfile);
    expect(result.slopeDirection).toBe("right-high");
  });

  it("direction = level when UL === UR", () => {
    const result = calculateScreenLine(squareLine, baseHeader, defaultProfile);
    expect(result.slopeDirection).toBe("level");
    expect(result.upperSlope).toBe(0);
  });

  // ── Rules 6 & 7: left and right heights ───────────────────────────────────
  it("level: left_height = OL, right_height = OR", () => {
    // squareLine: OL=168, OR=168, slope=0 → level
    const result = calculateScreenLine(squareLine, baseHeader, defaultProfile);
    expect(result.leftHeight).toBe(168.0);
    expect(result.rightHeight).toBe(168.0);
  });

  it("left-high: left_height = OL - S, right_height = OR", () => {
    // UL=90, UR=84 → S=6; OL=180, OR=168
    // left_height = 180 - 6 = 174; right_height = 168
    const line = {
      ...squareLine,
      ul: "90.000", ll: "90.000", ol: "180.000",
      ur: "84.000", lr: "84.000", orMeasurement: "168.000",
    };
    const result = calculateScreenLine(line, baseHeader, defaultProfile);
    expect(result.leftHeight).toBe(174.0);
    expect(result.rightHeight).toBe(168.0);
  });

  it("right-high: left_height = OL, right_height = OR - S", () => {
    // UL=84, UR=90 → S=6; OL=168, OR=180
    // left_height = 168; right_height = 180 - 6 = 174
    const line = {
      ...squareLine,
      ul: "84.000", ll: "84.000", ol: "168.000",
      ur: "90.000", lr: "90.000", orMeasurement: "180.000",
    };
    const result = calculateScreenLine(line, baseHeader, defaultProfile);
    expect(result.leftHeight).toBe(168.0);
    expect(result.rightHeight).toBe(174.0);
  });

  it("clamps heights to >= 0", () => {
    // OL=2, OR=2, UL=10, UR=0 → S=10; left-high → left_height = 2-10 = -8 → clamped to 0
    const line = {
      ...squareLine,
      ul: "10.000", ll: "10.000", ol: "2.000",
      ur: "0.000",  lr: "0.000",  orMeasurement: "2.000",
    };
    const result = calculateScreenLine(line, baseHeader, defaultProfile);
    expect(result.leftHeight).toBe(0);
    expect(result.rightHeight).toBeGreaterThanOrEqual(0);
  });

  // ── Rule 8: T-B difference ────────────────────────────────────────────────
  it("tbDiff = abs(T - B)", () => {
    const line = { ...squareLine, t: "62.000", b: "60.000" };
    const result = calculateScreenLine(line, baseHeader, defaultProfile);
    expect(result.tbDiff).toBe(2.0);
  });

  // ── Rule 9: U-channel ─────────────────────────────────────────────────────
  it("marks uChannelNeeded when applyUChannelToAll is set on header", () => {
    const h = { ...baseHeader, applyUChannelToAll: 1 as 0 | 1 };
    expect(calculateScreenLine(squareLine, h, defaultProfile).uChannelNeeded).toBe(true);
  });

  it("marks uChannelNeeded when slope exceeds generic threshold (0.25)", () => {
    // S = abs(84.5 - 84.0) = 0.5 > 0.25
    const line = {
      ...squareLine,
      ul: "84.5", ll: "84.5", ol: "169.0",
      ur: "84.0", lr: "84.0", orMeasurement: "168.0",
    };
    const result = calculateScreenLine(line, baseHeader, defaultProfile);
    expect(result.uChannelNeeded).toBe(true);
  });

  it("uses MagnaTrack threshold (0.375) when manufacturerCode = magnatrack", () => {
    const h = { ...baseHeader, manufacturerCode: "magnatrack" };
    // S = 0.3125 (5/16") — below MagnaTrack threshold (0.375) but above generic (0.25)
    const line = {
      ...squareLine,
      ul: "84.3125", ll: "84.3125", ol: "168.625",
      ur: "84.0000", lr: "84.0000", orMeasurement: "168.000",
    };
    // Use a profile WITH manufacturerUChannelThresholdsJson so the per-manufacturer
    // override is read from the profile (not from hardcoded code fallbacks).
    const profileWithMfrMap = {
      ...defaultProfile,
      uChannelThreshold: undefined,   // no generic threshold
      manufacturerUChannelThresholdsJson: { "magnatrack": 0.375, "generic": 0.25 },
    };
    const generic = calculateScreenLine(line, baseHeader, profileWithMfrMap);
    const magna   = calculateScreenLine(line, h, profileWithMfrMap);
    // Generic (0.25 threshold from map): 0.3125 > 0.25 → needs U-channel
    expect(generic.uChannelNeeded).toBe(true);
    // MagnaTrack (0.375 threshold from map): 0.3125 < 0.375 → no U-channel from slope
    expect(magna.uChannelNeeded).toBe(false);
  });

  // ── Rule 10: build-out ────────────────────────────────────────────────────
  it("no build-out when slope < 7/16\"", () => {
    // S = 0.25 < 0.4375
    const line = {
      ...squareLine,
      ul: "84.25", ll: "84.25", ol: "168.5",
      ur: "84.00", lr: "84.00", orMeasurement: "168.0",
    };
    const result = calculateScreenLine(line, baseHeader, defaultProfile);
    expect(result.buildOutRequired).toBe(false);
    expect(result.buildOutType).toBeNull();
  });

  it("1x2 build-out when 7/16 <= slope <= 3/4\"", () => {
    // S = 0.5 (8/16") — between 7/16 and 3/4
    const line = {
      ...squareLine,
      ul: "84.5", ll: "84.5", ol: "169.0",
      ur: "84.0", lr: "84.0", orMeasurement: "168.0",
    };
    const result = calculateScreenLine(line, { ...baseHeader, applyUChannelToAll: 1 as 0 | 1 }, defaultProfile);
    expect(result.buildOutRequired).toBe(true);
    expect(result.buildOutType).toBe("1x2");
  });

  it("2x2 build-out when 13/16 <= slope <= 1.75\"", () => {
    // S = 1.0 — between 13/16 (0.8125) and 1.75
    const line = {
      ...squareLine,
      ul: "85.0", ll: "85.0", ol: "170.0",
      ur: "84.0", lr: "84.0", orMeasurement: "168.0",
    };
    const result = calculateScreenLine(line, { ...baseHeader, applyUChannelToAll: 1 as 0 | 1 }, defaultProfile);
    expect(result.buildOutRequired).toBe(true);
    expect(result.buildOutType).toBe("2x2");
  });

  it("FLAG build-out when slope > 1.75\"", () => {
    // S = 2.0 > 1.75
    const line = {
      ...squareLine,
      ul: "86.0", ll: "86.0", ol: "172.0",
      ur: "84.0", lr: "84.0", orMeasurement: "168.0",
    };
    const result = calculateScreenLine(line, { ...baseHeader, applyUChannelToAll: 1 as 0 | 1 }, defaultProfile);
    expect(result.buildOutRequired).toBe(true);
    expect(result.calculationFlagsJson.some(f => f.code === "BUILDOUT_SLOPE_EXCEEDS_MAX")).toBe(true);
  });

  // ── Rule 11: track-to-track ───────────────────────────────────────────────
  it("track_to_track = T - 1/8 when no U-channel", () => {
    // squareLine: T=60, no U-channel → 60 - 0.125 = 59.875
    const result = calculateScreenLine(squareLine, baseHeader, defaultProfile);
    expect(result.trackToTrack).toBe(59.875);
  });

  it("track_to_track = min(T-1/8, M, B) - 1 when U-channel required", () => {
    // T=60, M=60, B=60 → min(59.875, 60, 60) - 1 = 58.875
    const h = { ...baseHeader, applyUChannelToAll: 1 as 0 | 1 };
    const result = calculateScreenLine(squareLine, h, defaultProfile);
    expect(result.trackToTrack).toBe(58.875);
  });

  // ── Rule 12: extended hood ────────────────────────────────────────────────
  it("no extended hood for DOS Screens + inside-mount", () => {
    const h = { ...baseHeader, manufacturerCode: "dos-screens", installMount: "inside-mount" as const };
    const result = calculateScreenLine(squareLine, h, defaultProfile);
    expect(result.extendedHood).toBe(false);
  });

  it("extended hood = T - 1/8 for MagnaTrack + inside-mount + U-channel", () => {
    const h = {
      ...baseHeader,
      manufacturerCode: "magnatrack",
      installMount: "inside-mount" as const,
      applyUChannelToAll: 1 as 0 | 1,
    };
    // T=60 → T - 1/8 = 59.875
    const result = calculateScreenLine(squareLine, h, defaultProfile);
    expect(result.extendedHood).toBe(true);
  });

  it("default extended hood = M + 4.5 for all other cases", () => {
    // M=60 → 60 + 4.5 = 64.5
    const result = calculateScreenLine(squareLine, baseHeader, defaultProfile);
    // extendedHood boolean is true because M is present
    expect(result.extendedHood).toBe(true);
  });

  // ── Rule 13: bias ─────────────────────────────────────────────────────────
  it("bias = S / 2", () => {
    // UL=90, UR=84 → S=6 → bias = 3
    const line = {
      ...squareLine,
      ul: "90.000", ll: "90.000", ol: "180.000",
      ur: "84.000", lr: "84.000", orMeasurement: "168.000",
    };
    const result = calculateScreenLine(line, baseHeader, defaultProfile);
    expect(result.bias).toBe(3.0);
  });

  it("bias = 0 when level", () => {
    const result = calculateScreenLine(squareLine, baseHeader, defaultProfile);
    expect(result.bias).toBe(0);
  });

  // ── Rule 14: orderable dimensions ─────────────────────────────────────────
  it("orderable_width = M", () => {
    // M=60 → orderableWidth=60
    const result = calculateScreenLine(squareLine, baseHeader, defaultProfile);
    expect(result.orderableWidth).toBe(60.0);
  });

  it("orderable_height = max(left_height, right_height)", () => {
    // level: left=168, right=168 → max=168
    const result = calculateScreenLine(squareLine, baseHeader, defaultProfile);
    expect(result.orderableHeight).toBe(168.0);
  });

  it("orderable_height uses max (not min) for sloped opening", () => {
    // left-high: left_height=174, right_height=168 → max=174
    const line = {
      ...squareLine,
      ul: "90.000", ll: "90.000", ol: "180.000",
      ur: "84.000", lr: "84.000", orMeasurement: "168.000",
    };
    const result = calculateScreenLine(line, baseHeader, defaultProfile);
    expect(result.orderableHeight).toBe(174.0);
  });

  // ── Rule 15: structured flags ─────────────────────────────────────────────
  it("flags have correct shape { code, severity, message }", () => {
    const line = {
      ...squareLine,
      ul: "86.0", ll: "86.0", ol: "172.0",
      ur: "84.0", lr: "84.0", orMeasurement: "168.0",
    };
    const result = calculateScreenLine(line, { ...baseHeader, applyUChannelToAll: 1 as 0 | 1 }, defaultProfile);
    for (const flag of result.calculationFlagsJson) {
      expect(flag).toHaveProperty("code");
      expect(flag).toHaveProperty("severity");
      expect(flag).toHaveProperty("message");
      expect(["info", "warning", "error"]).toContain(flag.severity);
    }
  });

  it("SLOPE_LARGE flag fires when slope exceeds 1.0\"", () => {
    const line = {
      ...squareLine,
      ul: "85.5", ll: "85.5", ol: "171.0",
      ur: "84.0", lr: "84.0", orMeasurement: "168.0",
    };
    const result = calculateScreenLine(line, { ...baseHeader, applyUChannelToAll: 1 as 0 | 1 }, defaultProfile);
    expect(result.calculationFlagsJson.some(f => f.code === "SLOPE_LARGE")).toBe(true);
  });

  // ── Null / missing measurement guards ─────────────────────────────────────
  it("returns null orderable dimensions when all measurements are null", () => {
    const nullLine = {
      ul: null, ll: null, ol: null,
      ur: null, lr: null, orMeasurement: null,
      t: null, m: null, b: null,
      reverseMeasurements: 0 as 0 | 1,
      uChannelNeeded: 0 as 0 | 1, uChannelReason: null,
      buildOutRequired: 0 as 0 | 1, buildOutType: null,
    };
    const result = calculateScreenLine(nullLine, baseHeader, defaultProfile);
    expect(result.orderableWidth).toBeNull();
    expect(result.orderableHeight).toBeNull();
  });

  it("NO_HEIGHT_MEASUREMENTS error when OL and OR are both null", () => {
    const line = {
      ...squareLine,
      ol: null, orMeasurement: null,
      ul: null, ll: null, ur: null, lr: null,
    };
    const result = calculateScreenLine(line, baseHeader, defaultProfile);
    expect(result.calculationFlagsJson.some(f => f.code === "NO_HEIGHT_MEASUREMENTS")).toBe(true);
  });
});
