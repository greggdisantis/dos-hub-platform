/**
 * DOS: Receipt Capture — Database Query Helpers
 * Spec: DOS_Receipt_Capture_Module_Spec_v3_ARCHITECTURE_LEVEL.docx
 *
 * All queries target the shared DB connection (dev: dos_hub_dev, prod: dos_hub_prod).
 * Do NOT hardcode connection strings or bypass the shared getDb() helper.
 */
import { and, desc, eq, gte, lte, or, like, inArray, sql } from "drizzle-orm";
import { getDb } from "./db";
import {
  receiptSubmissions,
  receiptLineItems,
  receiptStatusHistory,
  receiptAnalysisSnapshots,
  users,
  type ReceiptSubmission,
  type InsertReceiptSubmission,
} from "../drizzle/schema";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------
export type ReceiptStatus = "draft" | "submitted" | "entered" | "complete" | "voided";
export type ReceiptType = "job_related" | "overhead";

export interface ReceiptWithSubmitter extends ReceiptSubmission {
  submitterFirstName: string | null;
  submitterLastName: string | null;
  submitterEmail: string;
}

export interface ReceiptListFilters {
  status?: ReceiptStatus | ReceiptStatus[];
  submittedByUserId?: number;
  receiptType?: ReceiptType;
  dateFrom?: Date;
  dateTo?: Date;
  search?: string;
  limit?: number;
  offset?: number;
}

// ---------------------------------------------------------------------------
// Read helpers
// ---------------------------------------------------------------------------

/**
 * Get a single receipt by ID with submitter info
 */
export async function getReceiptById(id: number): Promise<ReceiptWithSubmitter | null> {
  const db = await getDb();
  if (!db) return null;
  const rows = await db
    .select({
      id: receiptSubmissions.id,
      submittedByUserId: receiptSubmissions.submittedByUserId,
      submittedAt: receiptSubmissions.submittedAt,
      vendorName: receiptSubmissions.vendorName,
      receiptDate: receiptSubmissions.receiptDate,
      subtotal: receiptSubmissions.subtotal,
      tax: receiptSubmissions.tax,
      total: receiptSubmissions.total,
      description: receiptSubmissions.description,
      notes: receiptSubmissions.notes,
      receiptType: receiptSubmissions.receiptType,
      overheadCategory: receiptSubmissions.overheadCategory,
      jobName: receiptSubmissions.jobName,
      poNumber: receiptSubmissions.poNumber,
      originalImageKey: receiptSubmissions.originalImageKey,
      pdfKey: receiptSubmissions.pdfKey,
      status: receiptSubmissions.status,
      enteredByUserId: receiptSubmissions.enteredByUserId,
      enteredAt: receiptSubmissions.enteredAt,
      completedByUserId: receiptSubmissions.completedByUserId,
      completedAt: receiptSubmissions.completedAt,
      financeNote: receiptSubmissions.financeNote,
      createdAt: receiptSubmissions.createdAt,
      updatedAt: receiptSubmissions.updatedAt,
      submitterFirstName: users.firstName,
      submitterLastName: users.lastName,
      submitterEmail: users.email,
    })
    .from(receiptSubmissions)
    .leftJoin(users, eq(receiptSubmissions.submittedByUserId, users.id))
    .where(eq(receiptSubmissions.id, id))
    .limit(1);
  if (!rows.length) return null;
  return rows[0] as ReceiptWithSubmitter;
}

/**
 * List receipts with optional filters
 */
export async function listReceipts(filters: ReceiptListFilters = {}) {
  const db = await getDb();
  if (!db) return { rows: [], total: 0 };

  const conditions = [];

  if (filters.status) {
    if (Array.isArray(filters.status)) {
      conditions.push(inArray(receiptSubmissions.status, filters.status));
    } else {
      conditions.push(eq(receiptSubmissions.status, filters.status));
    }
  }
  if (filters.submittedByUserId) {
    conditions.push(eq(receiptSubmissions.submittedByUserId, filters.submittedByUserId));
  }
  if (filters.receiptType) {
    conditions.push(eq(receiptSubmissions.receiptType, filters.receiptType));
  }
  if (filters.dateFrom) {
    const df = filters.dateFrom.toISOString().split("T")[0];
    conditions.push(sql`${receiptSubmissions.receiptDate} >= ${df}`);
  }
  if (filters.dateTo) {
    const dt = filters.dateTo.toISOString().split("T")[0];
    conditions.push(sql`${receiptSubmissions.receiptDate} <= ${dt}`);
  }
  if (filters.search) {
    const term = `%${filters.search}%`;
    conditions.push(
      or(
        like(receiptSubmissions.vendorName, term),
        like(receiptSubmissions.jobName, term),
        like(receiptSubmissions.description, term),
        like(receiptSubmissions.poNumber, term)
      )
    );
  }

  const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

  const rows = await db
    .select({
      id: receiptSubmissions.id,
      submittedByUserId: receiptSubmissions.submittedByUserId,
      submittedAt: receiptSubmissions.submittedAt,
      vendorName: receiptSubmissions.vendorName,
      receiptDate: receiptSubmissions.receiptDate,
      subtotal: receiptSubmissions.subtotal,
      tax: receiptSubmissions.tax,
      total: receiptSubmissions.total,
      description: receiptSubmissions.description,
      receiptType: receiptSubmissions.receiptType,
      overheadCategory: receiptSubmissions.overheadCategory,
      jobName: receiptSubmissions.jobName,
      poNumber: receiptSubmissions.poNumber,
      originalImageKey: receiptSubmissions.originalImageKey,
      status: receiptSubmissions.status,
      financeNote: receiptSubmissions.financeNote,
      createdAt: receiptSubmissions.createdAt,
      updatedAt: receiptSubmissions.updatedAt,
      submitterFirstName: users.firstName,
      submitterLastName: users.lastName,
      submitterEmail: users.email,
    })
    .from(receiptSubmissions)
    .leftJoin(users, eq(receiptSubmissions.submittedByUserId, users.id))
    .where(whereClause)
    .orderBy(desc(receiptSubmissions.createdAt))
    .limit(filters.limit ?? 100)
    .offset(filters.offset ?? 0);

  return { rows, total: rows.length };
}

/**
 * Get line items for a receipt
 */
export async function getReceiptLineItems(receiptId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(receiptLineItems)
    .where(eq(receiptLineItems.receiptId, receiptId))
    .orderBy(receiptLineItems.sortOrder);
}

/**
 * Get status history for a receipt
 */
export async function getReceiptStatusHistory(receiptId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select({
      id: receiptStatusHistory.id,
      receiptId: receiptStatusHistory.receiptId,
      fromStatus: receiptStatusHistory.fromStatus,
      toStatus: receiptStatusHistory.toStatus,
      changedByUserId: receiptStatusHistory.changedByUserId,
      note: receiptStatusHistory.note,
      createdAt: receiptStatusHistory.createdAt,
      updatedAt: receiptStatusHistory.updatedAt,
      changerFirstName: users.firstName,
      changerLastName: users.lastName,
    })
    .from(receiptStatusHistory)
    .leftJoin(users, eq(receiptStatusHistory.changedByUserId, users.id))
    .where(eq(receiptStatusHistory.receiptId, receiptId))
    .orderBy(desc(receiptStatusHistory.createdAt));
}

/**
 * Get analytics summary for the analytics screen
 */
export async function getReceiptAnalytics(filters: { dateFrom?: Date; dateTo?: Date } = {}) {
  const db = await getDb();
  if (!db) return null;

  const conditions = [];
  if (filters.dateFrom) {
    const df2 = filters.dateFrom.toISOString().split("T")[0];
    conditions.push(sql`${receiptSubmissions.receiptDate} >= ${df2}`);
  }
  if (filters.dateTo) {
    const dt2 = filters.dateTo.toISOString().split("T")[0];
    conditions.push(sql`${receiptSubmissions.receiptDate} <= ${dt2}`);
  }

  const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

  const rows = await db
    .select({
      status: receiptSubmissions.status,      receiptType: receiptSubmissions.receiptType,
      total: receiptSubmissions.total,
      overheadCategory: receiptSubmissions.overheadCategory,
    })
    .from(receiptSubmissions)
    .where(whereClause);

  const summary = {
    totalCount: rows.length,
    totalAmount: 0,
    byStatus: {} as Record<string, { count: number; amount: number }>,
    byType: {} as Record<string, { count: number; amount: number }>,
    byOverheadCategory: {} as Record<string, { count: number; amount: number }>,
  };

  for (const row of rows) {
    const amt = parseFloat(row.total ?? "0") || 0;
    summary.totalAmount += amt;

    const s = row.status ?? "unknown";
    if (!summary.byStatus[s]) summary.byStatus[s] = { count: 0, amount: 0 };
    summary.byStatus[s].count++;
    summary.byStatus[s].amount += amt;

    const t = row.receiptType ?? "unknown";
    if (!summary.byType[t]) summary.byType[t] = { count: 0, amount: 0 };
    summary.byType[t].count++;
    summary.byType[t].amount += amt;

    if (row.receiptType === "overhead" && row.overheadCategory) {
      const c = row.overheadCategory;
      if (!summary.byOverheadCategory[c]) summary.byOverheadCategory[c] = { count: 0, amount: 0 };
      summary.byOverheadCategory[c].count++;
      summary.byOverheadCategory[c].amount += amt;
    }
  }

  return summary;
}

// ---------------------------------------------------------------------------
// Write helpers
// ---------------------------------------------------------------------------

/**
 * Create a new receipt in draft status
 */
export async function createReceipt(data: Omit<InsertReceiptSubmission, "status" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(receiptSubmissions).values({
    ...data,
    status: "draft",
  });
  const insertId = (result as any)[0]?.insertId ?? (result as any).insertId;
  return insertId as number;
}

/**
 * Update receipt fields
 */
export async function updateReceipt(
  id: number,
  data: Partial<Omit<InsertReceiptSubmission, "id" | "createdAt" | "updatedAt">>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(receiptSubmissions).set(data).where(eq(receiptSubmissions.id, id));
}

/**
 * Transition receipt status and record history
 */
export async function transitionReceiptStatus(
  receiptId: number,
  fromStatus: string,
  toStatus: ReceiptStatus,
  changedByUserId: number,
  note?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const now = new Date();
  const updateData: Partial<InsertReceiptSubmission> = { status: toStatus };

  if (toStatus === "submitted") updateData.submittedAt = now;
  if (toStatus === "entered") {
    updateData.enteredByUserId = changedByUserId;
    updateData.enteredAt = now;
  }
  if (toStatus === "complete") {
    updateData.completedByUserId = changedByUserId;
    updateData.completedAt = now;
  }

  await db.update(receiptSubmissions).set(updateData).where(eq(receiptSubmissions.id, receiptId));
  await db.insert(receiptStatusHistory).values({
    receiptId,
    fromStatus,
    toStatus,
    changedByUserId,
    note: note ?? null,
  });
}

/**
 * Upsert line items for a receipt (replace all)
 */
export async function replaceReceiptLineItems(
  receiptId: number,
  items: Array<{ description?: string; amount?: string; sortOrder?: number }>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(receiptLineItems).where(eq(receiptLineItems.receiptId, receiptId));
  if (items.length === 0) return;
  await db.insert(receiptLineItems).values(
    items.map((item, idx) => ({
      receiptId,
      description: item.description ?? null,
      amount: item.amount ?? null,
      sortOrder: item.sortOrder ?? idx,
    }))
  );
}

/**
 * Save LLM analysis snapshot
 */
export async function saveAnalysisSnapshot(data: {
  receiptId: number;
  rawResponse: string;
  extractedVendor?: string;
  extractedDate?: string;
  extractedSubtotal?: string;
  extractedTax?: string;
  extractedTotal?: string;
  confidence?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(receiptAnalysisSnapshots).values({
    receiptId: data.receiptId,
    rawResponse: data.rawResponse,
    extractedVendor: data.extractedVendor ?? null,
    extractedDate: data.extractedDate ? new Date(data.extractedDate) : null,
    extractedSubtotal: data.extractedSubtotal ?? null,
    extractedTax: data.extractedTax ?? null,
    extractedTotal: data.extractedTotal ?? null,
    confidence: data.confidence ?? null,
  });
}
