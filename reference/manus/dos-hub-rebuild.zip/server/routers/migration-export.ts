/**
 * TEMPORARY: Migration data export router.
 * Used ONLY for the controlled data promotion from dev to production.
 * DELETE THIS FILE after migration is complete.
 * All procedures are read-only — no writes.
 */
import { publicProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { sql } from "drizzle-orm";

export const migrationExportRouter = router({
  getSourceData: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new Error("DB not available");

    const countResult = await db.execute(sql`
      SELECT
        (SELECT COUNT(*) FROM users) AS users,
        (SELECT COUNT(*) FROM projects) AS projects,
        (SELECT COUNT(*) FROM cmr_reports) AS cmr_reports
    `);
    const countRow = (countResult as unknown as any[])[0] as Record<string, unknown>;

    let cmrLineItemsInfo: { exists: boolean; count: number } = { exists: false, count: 0 };
    try {
      const liResult = await db.execute(sql`SELECT COUNT(*) AS cnt FROM cmr_line_items`);
      const liRow = (liResult as unknown as any[])[0] as Record<string, unknown>;
      cmrLineItemsInfo = { exists: true, count: Number(liRow?.cnt ?? 0) };
    } catch {
      cmrLineItemsInfo = { exists: false, count: 0 };
    }

    const userResult = await db.execute(sql`
      SELECT id, email, firstName, lastName, role, approved, userType,
             passwordHash, passwordChangeRequired, specialTags,
             createdAt, updatedAt, lastSignedIn
      FROM users ORDER BY id
    `);

    const projectResult = await db.execute(sql`
      SELECT id, userId, name, description, externalSourceType,
             hubspotDealId, hubspotContactId, serviceFusionJobId,
             serviceFusionCustomerId, projectStage, createdAt, updatedAt, clientName
      FROM projects ORDER BY id
    `);

    const cmrResult = await db.execute(sql`
      SELECT id, userId, projectId, clientName, status, createdAt
      FROM cmr_reports ORDER BY id
    `);

    return {
      counts: {
        users: Number(countRow?.users ?? 0),
        projects: Number(countRow?.projects ?? 0),
        cmr_reports: Number(countRow?.cmr_reports ?? 0),
        cmr_line_items: cmrLineItemsInfo,
      },
      users: userResult as unknown as any[],
      projects: projectResult as unknown as any[],
      cmrSummary: cmrResult as unknown as any[],
    };
  }),
});
