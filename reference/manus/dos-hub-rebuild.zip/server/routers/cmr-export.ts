/**
 * CMR PDF Export Router
 * Handles PDF generation for CMR reports
 */

import { router, protectedProcedure } from '../_core/trpc';
import { z } from 'zod';
import { getCMRReport } from '../db';
import { buildCmrHtml, getCmrPdfFilename } from '../pdf/modules/cmr';
import { renderToPdf } from '../pdf/render';
import { TRPCError } from '@trpc/server';

export const cmrExportRouter = router({
  /**
   * Export a CMR report as PDF
   */
  exportPdf: protectedProcedure
    .input(z.object({ reportId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      try {
        // Get CMR report
        const report = await getCMRReport(input.reportId);

        if (!report) {
          throw new TRPCError({
            code: 'NOT_FOUND',
            message: 'CMR report not found',
          });
        }

        // Check permissions — owner, admin, super-admin, or manager can export
        const canExport =
          report.userId === ctx.user.id ||
          ['admin', 'super-admin', 'manager'].includes(ctx.user.role);
        if (!canExport) {
          throw new TRPCError({
            code: 'FORBIDDEN',
            message: 'You do not have permission to export this report',
          });
        }

        // Generate PDF — build HTML template then render via shared Puppeteer engine
        const cmrData = {
          report: {
            id: report.id,
            clientName: report.clientName,
            consultantName: report.consultantName ?? undefined,
            appointmentDate: report.appointmentDate ?? undefined,
            appointmentType: report.appointmentType ?? undefined,
            address: report.address ?? undefined,
            clientType: report.clientType ?? undefined,
            leadSources: (report.leadSources as string[] | null) ?? undefined,
            status: report.status,
            // Deal Status
            dealStatus: report.dealStatus ?? undefined,
            closeTimeline: report.closeTimeline ?? undefined,
            lastConversationSummary: report.lastConversationSummary ?? undefined,
            // Purchase Confidence
            purchaseConfidencePct: report.purchaseConfidencePct ?? undefined,
            originalPcPct: report.originalPcPct ?? undefined,
            estimatedContractValue: report.estimatedContractValue ?? undefined,
            decisionMakers: report.decisionMakers ?? undefined,
            mainMotivation: report.mainMotivation ?? undefined,
            mainHesitation: report.mainHesitation ?? undefined,
            // Value & Objections
            financingDiscussed: report.financingDiscussed ?? undefined,
            financingReaction: report.financingReaction ?? undefined,
            valueCommunicated: (report.valueCommunicated as string[] | null) ?? undefined,
            clientResponse: report.clientResponse ?? undefined,
            objectionNotes: report.objectionNotes ?? undefined,
            // Next Steps
            nextActions: (report.nextActions as string[] | null) ?? undefined,
            // Marketing Feedback
            leadQuality: report.leadQuality ?? undefined,
            expectationAlignment: report.expectationAlignment ?? undefined,
            budgetAlignment: report.budgetAlignment ?? undefined,
          },
          actionItems: [],
          generatedBy: {
            firstName: ctx.user.firstName || 'User',
            lastName: ctx.user.lastName || '',
            email: ctx.user.email || '',
          },
        };
        const html = buildCmrHtml(cmrData);
        const pdfBuffer = await renderToPdf(html);

        // Filename: ClientName_MM-DD-YYYY.pdf using appointment date
        const filename = getCmrPdfFilename(
          report.clientName,
          report.appointmentDate ?? null,
        );

        // Return base64 encoded PDF for download
        return {
          success: true,
          pdfBase64: pdfBuffer.toString('base64'),
          filename,
        };
      } catch (error) {
        console.error('[CMR Export] Error generating PDF:', error);
        if (error instanceof TRPCError) throw error;
        const message = error instanceof Error ? error.message : String(error);
        throw new TRPCError({
          code: 'INTERNAL_SERVER_ERROR',
          message: `Failed to generate PDF: ${message}`,
        });
      }
    }),
});
