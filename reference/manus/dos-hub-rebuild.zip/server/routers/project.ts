import { router, protectedProcedure } from "../_core/trpc";
import * as db from "../db";

export const projectRouter = router({
  list: protectedProcedure.query(async () => {
    const projects = await db.getAllProjects();
    // Return only necessary fields for display
    return projects.map((project) => ({
      id: project.id,
      name: project.name,
      clientName: project.clientName,
      projectStage: project.projectStage,
    }));
  }),
});
