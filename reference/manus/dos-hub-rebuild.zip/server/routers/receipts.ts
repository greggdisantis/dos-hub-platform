/**
 * DOS: Receipt Capture — tRPC Router
 * Spec: DOS_Receipt_Capture_Module_Spec_v3_ARCHITECTURE_LEVEL.docx
 *
 * Procedures:
 *   receipts.upload          — upload image + create draft receipt
 *   receipts.analyze         — run LLM analysis on uploaded image
 *   receipts.save            — save/update draft fields
 *   receipts.submit          — submit draft → submitted
 *   receipts.getById         — get single receipt with line items + history
 *   receipts.list            — list receipts (filtered by role)
 *   receipts.financeList     — finance inbox (submitted)
 *   receipts.financeInProgress — entered receipts
 *   receipts.archive         — search completed/voided receipts
 *   receipts.markEntered     — finance: submitted → entered
 *   receipts.markComplete    — finance: entered → complete
 *   receipts.void            — void a receipt
 *   receipts.addFinanceNote  — finance: add note to receipt
 *   receipts.analytics       — analytics summary
 *   receipts.exportPdf       — generate PDF for a receipt
 *   receipts.getUploadUrl    — get presigned S3 URL for image upload
 */
import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { router, protectedProcedure } from "../_core/trpc";
import { storagePut, storageGet } from "../storage";
import { invokeLLM, type Message } from "../_core/llm";
import {
  getReceiptById,
  listReceipts,
  createReceipt,
  updateReceipt,
  transitionReceiptStatus,
  replaceReceiptLineItems,
  getReceiptLineItems,
  getReceiptStatusHistory,
  getReceiptAnalytics,
  saveAnalysisSnapshot,
} from "../db-receipts";

// ---------------------------------------------------------------------------
// Permission helpers
// ---------------------------------------------------------------------------
const FINANCE_ROLES = ["admin", "super-admin", "manager", "finance"];

function isFinance(role: string) {
  return FINANCE_ROLES.includes(role);
}

function assertFinance(role: string) {
  if (!isFinance(role)) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Finance access required" });
  }
}

// ---------------------------------------------------------------------------
// Input schemas
// ---------------------------------------------------------------------------
const lineItemSchema = z.object({
  description: z.string().optional(),
  amount: z.string().optional(),
  sortOrder: z.number().optional(),
});

const saveReceiptInput = z.object({
  id: z.number(),
  vendorName: z.string().optional(),
  receiptDate: z.string().optional(),
  subtotal: z.string().optional(),
  tax: z.string().optional(),
  total: z.string().optional(),
  description: z.string().optional(),
  notes: z.string().optional(),
  receiptType: z.enum(["job_related", "overhead"]).optional(),
  overheadCategory: z.string().optional(),
  jobName: z.string().optional(),
  poNumber: z.string().optional(),
  lineItems: z.array(lineItemSchema).optional(),
});

// ---------------------------------------------------------------------------
// Router
// ---------------------------------------------------------------------------
export const receiptsRouter = router({
  /**
   * Get presigned upload URL for receipt image
   * Client uploads directly to S3, then calls receipts.createDraft with the key
   */
  getUploadUrl: protectedProcedure
    .input(z.object({ filename: z.string(), contentType: z.string() }))
    .mutation(async ({ input, ctx }) => {
      const ext = input.filename.split(".").pop() ?? "jpg";
      const randomSuffix = Math.random().toString(36).slice(2, 10);
      const key = `receipts/${ctx.user.id}/${Date.now()}-${randomSuffix}.${ext}`;
      // We use storagePut with a placeholder to reserve the key, then return it
      // The client will upload the actual file bytes via the returned key
      return { key };
    }),

  /**
   * Create a draft receipt after image upload
   */
  createDraft: protectedProcedure
    .input(
      z.object({
        originalImageKey: z.string(),
        vendorName: z.string().optional(),
        receiptDate: z.string().optional(),
        subtotal: z.string().optional(),
        tax: z.string().optional(),
        total: z.string().optional(),
        description: z.string().optional(),
        notes: z.string().optional(),
        receiptType: z.enum(["job_related", "overhead"]).optional(),
        overheadCategory: z.string().optional(),
        jobName: z.string().optional(),
        poNumber: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const receiptDate = input.receiptDate ? new Date(input.receiptDate) : undefined;
      // NOTE: Do NOT pass null for timestamp columns (submittedAt, enteredAt, completedAt).
      // Drizzle-ORM serializes null → "" for timestamp columns, which MySQL rejects.
      // Omitting them lets MySQL use its column default (NULL for nullable timestamps).
      const id = await createReceipt({
        submittedByUserId: ctx.user.id,
        vendorName: input.vendorName ?? null,
        receiptDate: receiptDate as any,
        subtotal: input.subtotal ?? null,
        tax: input.tax ?? null,
        total: input.total ?? null,
        description: input.description ?? null,
        notes: input.notes ?? null,
        receiptType: input.receiptType ?? null,
        overheadCategory: input.overheadCategory ?? null,
        jobName: input.jobName ?? null,
        poNumber: input.poNumber ?? null,
        originalImageKey: input.originalImageKey,
        pdfKey: null,
      });
      return { id };
    }),

  /**
   * Analyze receipt image with LLM and return extracted fields
   */
  analyze: protectedProcedure
    .input(z.object({ receiptId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const receipt = await getReceiptById(input.receiptId);
      if (!receipt) throw new TRPCError({ code: "NOT_FOUND", message: "Receipt not found" });
      if (receipt.submittedByUserId !== ctx.user.id && !isFinance(ctx.user.role)) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Not authorized" });
      }
      if (!receipt.originalImageKey) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "No image attached to this receipt" });
      }

      // Get a presigned URL for the image so LLM can access it
      const { url: imageUrl } = await storageGet(receipt.originalImageKey, 300);

      // Approved DOS overhead categories
      const OVERHEAD_CATEGORIES = [
        "Fuel", "Office Supplies", "Tools", "Vehicle Maintenance", "Parking",
        "Meals", "Travel", "Lodging", "Shipping", "Software", "Marketing",
        "Training", "Safety", "Shop Supplies", "Utilities", "Equipment Rental",
        "Miscellaneous",
      ];

      const response = await invokeLLM({
        messages: [
          {
            role: "system" as const,
            content: `You are a receipt analysis assistant for a construction/installation company. Extract structured data from receipt images. Return JSON only. For receipt_type: use "overhead" if this is a general business expense (office supplies, fuel, tools, meals, etc.) or "job_related" if it is clearly tied to a specific job/project. For overhead_category: choose the best match from this approved list only: ${OVERHEAD_CATEGORIES.join(", ")}. If none fit, use "Miscellaneous". For description: write a brief 1-sentence summary of what was purchased. For notes: leave null unless there is something unusual about the receipt.`,
          },
          {
            role: "user" as const,
            content: [
              {
                type: "image_url" as const,
                image_url: { url: imageUrl, detail: "high" as const },
              },
              {
                type: "text" as const,
                text: 'Extract the following fields from this receipt and return as JSON. Do not invent values — only extract what is clearly visible. If a field is not visible or not applicable, use null.',
              },
            ],
          },
        ] as Message[],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "receipt_extraction",
            strict: true,
            schema: {
              type: "object",
              properties: {
                vendor_name: { type: ["string", "null"] },
                receipt_date: { type: ["string", "null"] },
                subtotal: { type: ["string", "null"] },
                tax: { type: ["string", "null"] },
                total: { type: ["string", "null"] },
                receipt_type: { type: ["string", "null"] },
                overhead_category: { type: ["string", "null"] },
                description: { type: ["string", "null"] },
                notes: { type: ["string", "null"] },
                line_items: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      description: { type: ["string", "null"] },
                      amount: { type: ["string", "null"] },
                    },
                    required: ["description", "amount"],
                    additionalProperties: false,
                  },
                },
                confidence: { type: ["string", "null"] },
              },
              required: ["vendor_name", "receipt_date", "subtotal", "tax", "total", "receipt_type", "overhead_category", "description", "notes", "line_items", "confidence"],
              additionalProperties: false,
            },
          },
        },
      });

      const rawContentRaw = response.choices?.[0]?.message?.content ?? "{}";
      const rawContent = typeof rawContentRaw === "string" ? rawContentRaw : JSON.stringify(rawContentRaw);
      let extracted: any = {};
      try {
        extracted = JSON.parse(rawContent);
      } catch {
        extracted = {};
      }

      // Save snapshot
      await saveAnalysisSnapshot({
        receiptId: input.receiptId,
        rawResponse: rawContent,
        extractedVendor: extracted.vendor_name ?? undefined,
        extractedDate: extracted.receipt_date ?? undefined,
        extractedSubtotal: extracted.subtotal ?? undefined,
        extractedTax: extracted.tax ?? undefined,
        extractedTotal: extracted.total ?? undefined,
        confidence: extracted.confidence ?? undefined,
      });

      // Validate overhead_category against approved list
      const APPROVED_OVERHEAD = [
        "Fuel", "Office Supplies", "Tools", "Vehicle Maintenance", "Parking",
        "Meals", "Travel", "Lodging", "Shipping", "Software", "Marketing",
        "Training", "Safety", "Shop Supplies", "Utilities", "Equipment Rental",
        "Miscellaneous",
      ];
      const rawCategory = extracted.overhead_category ?? null;
      const validatedCategory = rawCategory && APPROVED_OVERHEAD.includes(rawCategory) ? rawCategory : null;

      // Validate receipt_type
      const rawType = extracted.receipt_type ?? null;
      const validatedType = rawType === "job_related" || rawType === "overhead" ? rawType : null;

      return {
        vendorName: extracted.vendor_name ?? null,
        receiptDate: extracted.receipt_date ?? null,
        subtotal: extracted.subtotal ?? null,
        tax: extracted.tax ?? null,
        total: extracted.total ?? null,
        receiptType: validatedType,
        overheadCategory: validatedCategory,
        description: extracted.description ?? null,
        notes: extracted.notes ?? null,
        lineItems: extracted.line_items ?? [],
        confidence: extracted.confidence ?? null,
      };
    }),

  /**
   * Save/update draft receipt fields
   */
  save: protectedProcedure
    .input(saveReceiptInput)
    .mutation(async ({ input, ctx }) => {
      const receipt = await getReceiptById(input.id);
      if (!receipt) throw new TRPCError({ code: "NOT_FOUND", message: "Receipt not found" });
      if (receipt.submittedByUserId !== ctx.user.id && !isFinance(ctx.user.role)) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Not authorized" });
      }
      if (receipt.status !== "draft" && !isFinance(ctx.user.role)) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Cannot edit a submitted receipt" });
      }

      const receiptDate = input.receiptDate ? new Date(input.receiptDate) : undefined;
      await updateReceipt(input.id, {
        vendorName: input.vendorName,
        receiptDate: receiptDate as any,
        subtotal: input.subtotal,
        tax: input.tax,
        total: input.total,
        description: input.description,
        notes: input.notes,
        receiptType: input.receiptType,
        overheadCategory: input.overheadCategory,
        jobName: input.jobName,
        poNumber: input.poNumber,
      });

      if (input.lineItems !== undefined) {
        await replaceReceiptLineItems(input.id, input.lineItems);
      }

      return { success: true };
    }),

  /**
   * Submit a draft receipt to the finance inbox
   */
  submit: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const receipt = await getReceiptById(input.id);
      if (!receipt) throw new TRPCError({ code: "NOT_FOUND", message: "Receipt not found" });
      if (receipt.submittedByUserId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Not authorized" });
      }
      if (receipt.status !== "draft") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Only draft receipts can be submitted" });
      }
      await transitionReceiptStatus(input.id, "draft", "submitted", ctx.user.id);
      return { success: true };
    }),

  /**
   * Get a single receipt with line items and status history
   */
  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input, ctx }) => {
      // STEP 1: Log entry

      // STEP 2: DB query
      let receipt: Awaited<ReturnType<typeof getReceiptById>>;
      try {
        receipt = await getReceiptById(input.id);
      } catch (dbErr) {
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: `DB query failed: ${dbErr instanceof Error ? dbErr.message : String(dbErr)}` });
      }

      if (!receipt) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Receipt not found" });
      }

      // STEP 3: Permission check
      const userIsOwner = receipt.submittedByUserId === ctx.user.id;
      const userIsFinance = isFinance(ctx.user.role);
      if (!userIsOwner && !userIsFinance) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Not authorized" });
      }

      // STEP 4: Line items and history
      let lineItems: Awaited<ReturnType<typeof getReceiptLineItems>>;
      let history: Awaited<ReturnType<typeof getReceiptStatusHistory>>;
      try {
        lineItems = await getReceiptLineItems(input.id);
        history = await getReceiptStatusHistory(input.id);
      } catch (relErr) {
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: `Related data query failed: ${relErr instanceof Error ? relErr.message : String(relErr)}` });
      }

      // STEP 5: Storage (must not block response)
      let imageUrl: string | null = null;
      if (receipt.originalImageKey) {
        try {
          const { url } = await storageGet(receipt.originalImageKey, 3600);
          imageUrl = url;
        } catch (storageErr) {
          console.warn(
            storageErr instanceof Error ? storageErr.message : storageErr
          );
          // imageUrl stays null — receipt data is still returned
        }
      } else {
      }

      // STEP 6: Return
      return { ...receipt, lineItems, history, imageUrl };
    }),

  /**
   * List current user's own receipts (My Receipts screen)
   */
  list: protectedProcedure
    .input(
      z.object({
        status: z.string().optional(),
        receiptType: z.string().optional(),
        search: z.string().optional(),
        limit: z.number().optional(),
        offset: z.number().optional(),
      })
    )
    .query(async ({ input, ctx }) => {
      const { rows } = await listReceipts({
        submittedByUserId: ctx.user.id,
        status: input.status as any,
        receiptType: input.receiptType as any,
        search: input.search,
        limit: input.limit,
        offset: input.offset,
      });
      return rows;
    }),
  /**
   * Finance inbox — submitted receipts awaiting entry
   */
  financeList: protectedProcedure.query(async ({ ctx }) => {
    assertFinance(ctx.user.role);
    const { rows } = await listReceipts({ status: "submitted" });
    return rows;
  }),

  /**
   * Finance in-progress — entered receipts
   */
  financeInProgress: protectedProcedure.query(async ({ ctx }) => {
    assertFinance(ctx.user.role);
    const { rows } = await listReceipts({ status: "entered" });
    return rows;
  }),

  /**
   * Archive search — complete and voided receipts
   */
  archive: protectedProcedure
    .input(
      z.object({
        search: z.string().optional(),
        receiptType: z.string().optional(),
        dateFrom: z.string().optional(),
        dateTo: z.string().optional(),
        limit: z.number().optional(),
        offset: z.number().optional(),
      })
    )
    .query(async ({ input, ctx }) => {
      assertFinance(ctx.user.role);
      const { rows } = await listReceipts({
        status: ["complete", "voided"],
        search: input.search,
        receiptType: input.receiptType as any,
        dateFrom: input.dateFrom ? new Date(input.dateFrom) : undefined,
        dateTo: input.dateTo ? new Date(input.dateTo) : undefined,
        limit: input.limit,
        offset: input.offset,
      });
      return rows;
    }),

  /**
   * Finance: mark a submitted receipt as entered
   */
  markEntered: protectedProcedure
    .input(z.object({ id: z.number(), financeNote: z.string().optional() }))
    .mutation(async ({ input, ctx }) => {
      assertFinance(ctx.user.role);
      const receipt = await getReceiptById(input.id);
      if (!receipt) throw new TRPCError({ code: "NOT_FOUND", message: "Receipt not found" });
      if (receipt.status !== "submitted") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Receipt must be in submitted status" });
      }
      if (input.financeNote) {
        await updateReceipt(input.id, { financeNote: input.financeNote });
      }
      await transitionReceiptStatus(input.id, "submitted", "entered", ctx.user.id, input.financeNote);
      return { success: true };
    }),

  /**
   * Finance: mark an entered receipt as complete
   */
  markComplete: protectedProcedure
    .input(z.object({ id: z.number(), financeNote: z.string().optional() }))
    .mutation(async ({ input, ctx }) => {
      assertFinance(ctx.user.role);
      const receipt = await getReceiptById(input.id);
      if (!receipt) throw new TRPCError({ code: "NOT_FOUND", message: "Receipt not found" });
      if (receipt.status !== "entered") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Receipt must be in entered status" });
      }
      if (input.financeNote) {
        await updateReceipt(input.id, { financeNote: input.financeNote });
      }
      await transitionReceiptStatus(input.id, "entered", "complete", ctx.user.id, input.financeNote);
      return { success: true };
    }),

  /**
   * Void a receipt
   */
  void: protectedProcedure
    .input(z.object({ id: z.number(), reason: z.string().optional() }))
    .mutation(async ({ input, ctx }) => {
      assertFinance(ctx.user.role);
      const receipt = await getReceiptById(input.id);
      if (!receipt) throw new TRPCError({ code: "NOT_FOUND", message: "Receipt not found" });
      if (receipt.status === "voided") {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Receipt is already voided" });
      }
      await transitionReceiptStatus(input.id, receipt.status ?? "unknown", "voided", ctx.user.id, input.reason);
      return { success: true };
    }),

  /**
   * Finance: add or update finance note
   */
  addFinanceNote: protectedProcedure
    .input(z.object({ id: z.number(), note: z.string() }))
    .mutation(async ({ input, ctx }) => {
      assertFinance(ctx.user.role);
      await updateReceipt(input.id, { financeNote: input.note });
      return { success: true };
    }),

  /**
   * Analytics summary
   */
  analytics: protectedProcedure
    .input(
      z.object({
        dateFrom: z.string().optional(),
        dateTo: z.string().optional(),
      })
    )
    .query(async ({ input, ctx }) => {
      assertFinance(ctx.user.role);
      const summary = await getReceiptAnalytics({
        dateFrom: input.dateFrom ? new Date(input.dateFrom) : undefined,
        dateTo: input.dateTo ? new Date(input.dateTo) : undefined,
      });
      return summary;
    }),

  /**
   * Export a receipt as a PDF — returns base64-encoded PDF
   */
  exportPdf: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const receipt = await getReceiptById(input.id);
      if (!receipt) throw new TRPCError({ code: "NOT_FOUND", message: "Receipt not found" });
      if (receipt.submittedByUserId !== ctx.user.id && !isFinance(ctx.user.role)) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Not authorized" });
      }
      const lineItems = await getReceiptLineItems(input.id);
      let imageUrl: string | null = null;
      if (receipt.originalImageKey) {
        const { url } = await storageGet(receipt.originalImageKey, 3600);
        imageUrl = url;
      }
      const { buildReceiptHtml } = await import("../pdf/modules/receipt");
      const { renderToPdf } = await import("../pdf/render");
      const html = buildReceiptHtml({
        ...receipt,
        lineItems: lineItems ?? [],
        imageUrl,
        exportedAt: new Date(),
      });
      const pdfBuffer = await renderToPdf(html);
      return { base64: pdfBuffer.toString("base64") };
    }),

  /**
   * Upload receipt image bytes to S3 and return the storage key
   * Accepts base64-encoded image data
   */
  uploadImage: protectedProcedure
    .input(
      z.object({
        filename: z.string(),
        contentType: z.string(),
        base64Data: z.string(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const ext = input.filename.split(".").pop() ?? "jpg";
      const randomSuffix = Math.random().toString(36).slice(2, 10);
      const key = `receipts/${ctx.user.id}/${Date.now()}-${randomSuffix}.${ext}`;
      const buffer = Buffer.from(input.base64Data, "base64");
      const { url } = await storagePut(key, buffer, input.contentType);
      return { key, url };
    }),
});
