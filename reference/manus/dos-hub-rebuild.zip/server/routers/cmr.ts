import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import {
  createCMRReport,
  getCMRReport,
  getCMRReportsByUser,
  getCMRReportsByProject,
  getAllCMRReports,
  updateCMRReport,
  deleteCMRReport,
} from "../db";
import type { InsertCMRReport } from "../../drizzle/schema";
import { TRPCError } from "@trpc/server";

/**
 * CMR (Client Meeting Report) Router
 * Handles CRUD operations for CMR reports with draft/submit workflow
 */
export const cmrRouter = router({
  /**
   * List all CMR reports for the current user
   */
  list: protectedProcedure.query(async ({ ctx }) => {
    if (!ctx.user) {
      throw new TRPCError({ code: "UNAUTHORIZED" });
    }

    try {
      const reports = await getCMRReportsByUser(ctx.user.id);
      return reports || [];
    } catch (error) {
      console.error("[CMR] Failed to list reports:", error);
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Failed to list CMR reports",
      });
    }
  }),

  /**
   * List all CMR reports (role-based access)
   * super-admin, admin, manager: see all reports
   * member: see only their own reports
   */
  listAll: protectedProcedure
    .input(
      z.object({
        status: z.enum(["draft", "submitted", "approved"]).optional(),
        userId: z.number().optional(),
        projectId: z.number().optional(),
      })
    )
    .query(async ({ ctx, input }) => {
      if (!ctx.user) {
        throw new TRPCError({ code: "UNAUTHORIZED" });
      }

      try {
        // Check role-based access
        const canSeeAll = ["super-admin", "admin", "manager"].includes(
          ctx.user.role
        );

        if (!canSeeAll) {
          // Members can only see their own reports
          const reports = await getCMRReportsByUser(ctx.user.id);
          return reports || [];
        }

        // Admins/managers can see all reports with filters
        const reports = await getAllCMRReports({
          status: input.status,
          userId: input.userId,
          projectId: input.projectId,
        });
        return reports || [];
      } catch (error) {
        console.error("[CMR] Failed to list all reports:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to list CMR reports",
        });
      }
    }),

  /**
   * List all CMR reports for a specific project
   */
  listByProject: protectedProcedure
    .input(z.object({ projectId: z.number() }))
    .query(async ({ ctx, input }) => {
      if (!ctx.user) {
        throw new TRPCError({ code: "UNAUTHORIZED" });
      }

      try {
        const reports = await getCMRReportsByProject(input.projectId);
        return reports || [];
      } catch (error) {
        console.error("[CMR] Failed to list project reports:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to list CMR reports",
        });
      }
    }),

  /**
   * Get a single CMR report by ID
   */
  get: protectedProcedure
    .input(z.object({ reportId: z.number() }))
    .query(async ({ ctx, input }) => {
      if (!ctx.user) {
        throw new TRPCError({ code: "UNAUTHORIZED" });
      }

      try {
        const report = await getCMRReport(input.reportId);
        if (!report) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "CMR report not found",
          });
        }

        // Check permissions
        if (
          report.userId !== ctx.user.id &&
          !["admin", "super-admin"].includes(ctx.user.role)
        ) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "You do not have permission to view this report",
          });
        }

        return report;
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        console.error("[CMR] Failed to get report:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to get CMR report",
        });
      }
    }),

  /**
   * Create a new CMR report (starts as draft)
   */
  create: protectedProcedure
    .input(
      z.object({
        projectId: z.number().optional(),
        // Section 1: Appointment Details
        clientName: z.string().min(1, "Client name is required"),
        hubspotContactId: z.string().optional(),
        address: z.string().optional(),
        clientType: z.enum(["residential", "commercial"]).optional(),
        appointmentDate: z.string().transform((s) => {
          // Parse date string as local date (YYYY-MM-DD format)
          const [year, month, day] = s.split('-').map(Number);
          const date = new Date(year, month - 1, day);
          return date;
        }),
        appointmentType: z.enum(["in-home", "showroom", "phone"]).optional(),
        convertedToInPerson: z.boolean().optional(),
        convertedDate: z.string().optional(),
        convertedType: z.enum(["in-home", "showroom"]).optional(),
        leadSources: z.array(z.string()).optional(),
        leadSourceOther: z.string().optional(),
        referredClientName: z.string().optional(),
        contractorRefName: z.string().optional(),
        projectTypes: z.array(z.string()).optional(),
        projectTypeOther: z.string().optional(),
        // Section 2: Deal Status
        dealStatus: z
          .enum([
            "working-on-design",
            "proposal-presented",
            "actively-considering",
            "awaiting-financing",
            "waiting-on-design",
            "delayed",
            "lost",
            "other",
          ])
          .optional(),
        otherDealStatus: z.string().optional(),
        followUpDate: z.string().optional(),
        noFollowUpReason: z.string().optional(),
        proposalDate: z.string().optional(),
        lostReason: z.string().optional(),
        closeTimeline: z.enum(["0-30", "31-60", "61-90", "90plus"]).optional(),
        summaryOfLastConversation: z.string().optional(),
        decisionMakersInvolved: z.string().optional(),       // Section 3: Purchase Confidence
        purchaseConfidencePct: z.number().min(0).max(100).optional(),
        originalPcPct: z.number().min(0).max(100).optional(),
        estimatedContractValue: z.number().optional(),
        decisionMakers: z.string().optional(),
        mainMotivation: z.string().optional(),
        otherMainMotivation: z.string().optional(),
        mainHesitation: z.string().optional(),
        otherMainHesitation: z.string().optional(),
        pcNotes: z.string().optional(),
        // Section 4: Value & Objections
        financingDiscussed: z.boolean().optional(),
        financingReaction: z.enum(["interested", "needs-follow-up", "declined"]).optional(),
        valueCommunicated: z.array(z.string()).optional(),
        clientResponse: z.enum(["strong-alignment", "neutral", "price-focused", "comparing-online", "other"]).optional(),
        otherClientResponse: z.string().optional(),
        objections: z.array(z.string()).optional(),
        objectionOther: z.string().optional(),
        objectionNotes: z.string().optional(),
        // Section 5: Next Steps & Marketing
        nextActions: z.array(z.string()).optional(),
        otherNextAction: z.string().optional(),
        nextFollowUpDate: z.string().optional(),
        leadQuality: z.enum(["excellent", "good", "average", "poor"]).optional(),
        expectationAlignment: z.enum(["yes", "somewhat", "no"]).optional(),
        messagingReferenced: z.array(z.string()).optional(),
        messagingOther: z.string().optional(),
        budgetAlignment: z.enum(["aligned", "slightly-below", "significantly-below"]).optional(),
        marketingNotes: z.string().optional(),
        // Section 6: Progress Notes
        progressNotes: z.array(z.object({ id: z.string(), text: z.string(), createdAt: z.string() })).optional(),
        // NEW FIELDS
        estimatedValue: z.number().optional(),
        currentConfidencePct: z.number().min(0).max(100).optional(),
        updateNotes: z.array(z.object({ note: z.string(), createdAt: z.string(), createdBy: z.string() })).optional(),
        approvedStatus: z.enum(["draft", "submitted", "approved", "closed", "lost"]).optional(),
        closedAmount: z.number().optional(),
        closedDate: z.string().optional(),
        appointmentResult: z.enum(["pending", "sold", "not_sold", "follow_up", "cancelled"]).optional(),
        lastUpdatedBy: z.number().optional(),
        allowQuickEdit: z.boolean().optional(),
        // Status field for submit workflow
        status: z.enum(["draft", "submitted", "approved"]).optional(),
        // Meeting notes fields (prod-aligned)
        attendees: z.array(z.string()).optional(),
        notes: z.string().optional(),
        actionItems: z.array(z.object({
          id: z.string(),
          text: z.string(),
          assignee: z.string().optional(),
          dueDate: z.string().optional(),
        })).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) {
        throw new TRPCError({ code: "UNAUTHORIZED" });
      }

      try {
        const reportData: InsertCMRReport = {
          userId: ctx.user.id,
          projectId: input.projectId,
          clientName: input.clientName,
          hubspotContactId: input.hubspotContactId,
          address: input.address,
          clientType: input.clientType,
          appointmentDate: input.appointmentDate,
          appointmentType: input.appointmentType,
          convertedToInPerson: input.convertedToInPerson ? 1 : 0,
          convertedDate: input.convertedDate ? new Date(input.convertedDate) : undefined,
          convertedType: input.convertedType,
          leadSources: input.leadSources,
          leadSourceOther: input.leadSourceOther,
          referredClientName: input.referredClientName,
          contractorRefName: input.contractorRefName,
          projectTypes: input.projectTypes,
          projectTypeOther: input.projectTypeOther,
          dealStatus: input.dealStatus,
          otherDealStatus: input.otherDealStatus,
          followUpDate: input.followUpDate ? (() => {
          const [year, month, day] = input.followUpDate.split('-').map(Number);
          return new Date(year, month - 1, day);
        })() : undefined,
          noFollowUpReason: input.noFollowUpReason,
          proposalDate: input.proposalDate ? new Date(input.proposalDate) : undefined,
          lostReason: input.lostReason,
          closeTimeline: input.closeTimeline,
          lastConversationSummary: input.summaryOfLastConversation,
          purchaseConfidencePct: input.purchaseConfidencePct,
          originalPcPct: input.status === "submitted" && !input.originalPcPct ? input.purchaseConfidencePct : input.originalPcPct,
          estimatedContractValue: input.estimatedContractValue ? String(input.estimatedContractValue) : undefined,
          decisionMakers: input.decisionMakers || input.decisionMakersInvolved,
          mainMotivation: input.mainMotivation,
          otherMainMotivation: input.otherMainMotivation,
          mainHesitation: input.mainHesitation,
          otherMainHesitation: input.otherMainHesitation,
          pcNotes: input.pcNotes,
          financingDiscussed: input.financingDiscussed ? 1 : 0,
          financingReaction: input.financingReaction,
          valueCommunicated: input.valueCommunicated,
          clientResponse: input.clientResponse,
          objections: input.objections,
          objectionOther: input.objectionOther,
          objectionNotes: input.objectionNotes,
          otherClientResponse: input.otherClientResponse,
          nextActions: input.nextActions,
          otherNextAction: input.otherNextAction,
          nextFollowUpDate: input.nextFollowUpDate ? (() => {
          const [year, month, day] = input.nextFollowUpDate.split('-').map(Number);
          return new Date(year, month - 1, day);
        })() : undefined,
          leadQuality: input.leadQuality,
          expectationAlignment: input.expectationAlignment,
          messagingReferenced: input.messagingReferenced,
          messagingOther: input.messagingOther,
          budgetAlignment: input.budgetAlignment,
          marketingNotes: input.marketingNotes,
          progressNotes: input.progressNotes,
          estimatedValue: input.estimatedValue ? String(input.estimatedValue) : undefined,
          currentConfidencePct: input.currentConfidencePct,
          updateNotes: input.updateNotes,
          approvedStatus: input.approvedStatus || "draft",
          closedAmount: input.closedAmount ? String(input.closedAmount) : undefined,
          closedDate: input.closedDate ? new Date(input.closedDate) : undefined,
          appointmentResult: input.appointmentResult,
          lastUpdatedBy: input.lastUpdatedBy || ctx.user.id,
          allowQuickEdit: input.allowQuickEdit ? 1 : 1, // Default to 1 (true)
          status: input.status || "draft",
          // Meeting notes fields
          attendees: input.attendees,
          notes: input.notes,
          actionItems: input.actionItems,
        };
        const report = await createCMRReport(reportData);

        if (!report) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to create CMR report",
          });
        }

        return report;
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        console.error("[CMR] Failed to create report:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to create CMR report",
        });
      }
    }),

  /**
   * Update a CMR report
   */
  update: protectedProcedure
    .input(
      z.object({
        reportId: z.number(),
        clientName: z.string().optional(),
        appointmentDate: z.string().transform((s) => new Date(s)).optional(),
        appointmentType: z.string().optional(),
        dealStatus: z
          .enum([
            "working-on-design",
            "proposal-presented",
            "actively-considering",
            "awaiting-financing",
            "waiting-on-design",
            "delayed",
            "lost",
            "other",
          ])
          .optional(),
        purchaseConfidencePct: z.number().min(0).max(100).optional(),
        currentConfidencePct: z.number().min(0).max(100).optional(),
        pcNotes: z.string().optional(),
        estimatedContractValue: z.number().optional(),
        estimatedValue: z.number().optional(),
        closedAmount: z.number().optional(),
        closedDate: z.string().optional(),
        appointmentResult: z.enum(["pending", "sold", "not_sold", "follow_up", "cancelled"]).optional(),
        updateNotes: z.array(z.object({ note: z.string(), createdAt: z.string(), createdBy: z.string() })).optional(),
        approvedStatus: z.enum(["draft", "submitted", "approved", "closed", "lost"]).optional(),
        status: z.enum(["draft", "submitted", "approved"]).optional(),
        // Meeting notes fields (prod-aligned)
        attendees: z.array(z.string()).optional(),
        notes: z.string().optional(),
        actionItems: z.array(z.object({
          id: z.string(),
          text: z.string(),
          assignee: z.string().optional(),
          dueDate: z.string().optional(),
        })).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) {
        throw new TRPCError({ code: "UNAUTHORIZED" });
      }

      try {
        const report = await getCMRReport(input.reportId);
        if (!report) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "CMR report not found",
          });
        }

        // Check permissions
        if (
          report.userId !== ctx.user.id &&
          !["admin", "super-admin"].includes(ctx.user.role)
        ) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "You do not have permission to update this report",
          });
        }

        const updateData: Partial<InsertCMRReport> = {};
        if (input.clientName !== undefined)
          updateData.clientName = input.clientName;
        if (input.appointmentDate !== undefined)
          updateData.appointmentDate = input.appointmentDate;
        if (input.appointmentType !== undefined)
          updateData.appointmentType = input.appointmentType as "in-home" | "showroom" | "phone" | undefined;
        if (input.dealStatus !== undefined)
          updateData.dealStatus = input.dealStatus;
        if (input.purchaseConfidencePct !== undefined)
          updateData.purchaseConfidencePct = input.purchaseConfidencePct;
        if (input.currentConfidencePct !== undefined)
          updateData.currentConfidencePct = input.currentConfidencePct;
        if (input.pcNotes !== undefined) updateData.pcNotes = input.pcNotes;
        if (input.estimatedContractValue !== undefined)
          updateData.estimatedContractValue = String(input.estimatedContractValue);
        if (input.estimatedValue !== undefined)
          updateData.estimatedValue = String(input.estimatedValue);
        if (input.closedAmount !== undefined)
          updateData.closedAmount = String(input.closedAmount);
        if (input.closedDate !== undefined)
          updateData.closedDate = new Date(input.closedDate);
        if (input.appointmentResult !== undefined)
          updateData.appointmentResult = input.appointmentResult;
        if (input.updateNotes !== undefined)
          updateData.updateNotes = input.updateNotes;
        if (input.approvedStatus !== undefined)
          updateData.approvedStatus = input.approvedStatus;
        if (input.status !== undefined) updateData.status = input.status;
        // Meeting notes fields
        if (input.attendees !== undefined) updateData.attendees = input.attendees;
        if (input.notes !== undefined) updateData.notes = input.notes;
        if (input.actionItems !== undefined) updateData.actionItems = input.actionItems;

        const updatedReport = await updateCMRReport(input.reportId, updateData);
        return updatedReport;
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        console.error("[CMR] Failed to update report:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to update CMR report",
        });
      }
    }),

  /**
   * Add an update note to a CMR report (allowed even after submission)
   */
  addUpdateNote: protectedProcedure
    .input(
      z.object({
        reportId: z.number(),
        note: z.string().min(1, "Note text is required"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) {
        throw new TRPCError({ code: "UNAUTHORIZED" });
      }

      try {
        const report = await getCMRReport(input.reportId);
        if (!report) {
          throw new TRPCError({ code: "NOT_FOUND", message: "CMR report not found" });
        }

        // Anyone with access can add notes (even after submission)
        if (
          report.userId !== ctx.user.id &&
          !["admin", "super-admin", "manager"].includes(ctx.user.role)
        ) {
          throw new TRPCError({ code: "FORBIDDEN", message: "You do not have permission to add notes to this report" });
        }

        // Parse existing notes (safe for old records with no notes)
        let existingNotes: Array<{ note: string; createdAt: string; createdBy: string }> = [];
        if (report.updateNotes) {
          try {
            existingNotes = typeof report.updateNotes === 'string'
              ? JSON.parse(report.updateNotes)
              : (report.updateNotes as Array<{ note: string; createdAt: string; createdBy: string }>);
          } catch {
            existingNotes = [];
          }
        }

        // Prepend new note (newest first)
        const newNote = {
          note: input.note,
          createdAt: new Date().toISOString(),
          createdBy: `${ctx.user.firstName || ''} ${ctx.user.lastName || ''}`.trim() || ctx.user.email,
        };
        const updatedNotes = [newNote, ...existingNotes];

        const updatedReport = await updateCMRReport(input.reportId, {
          updateNotes: updatedNotes,
          lastUpdatedAt: new Date(),
          lastUpdatedBy: ctx.user.id,
        });
        return updatedReport;
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        console.error("[CMR] Failed to add update note:", error);
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to add update note" });
      }
    }),

  /**
   * Quick edit: update estimatedValue and/or currentConfidencePct from main list
   * Does NOT allow editing originalPcPct
   */
  quickEdit: protectedProcedure
    .input(
      z.object({
        reportId: z.number(),
        estimatedValue: z.number().optional(),
        currentConfidencePct: z.number().min(0).max(100).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) {
        throw new TRPCError({ code: "UNAUTHORIZED" });
      }

      try {
        const report = await getCMRReport(input.reportId);
        if (!report) {
          throw new TRPCError({ code: "NOT_FOUND", message: "CMR report not found" });
        }

        // Check permissions
        if (
          report.userId !== ctx.user.id &&
          !["admin", "super-admin", "manager"].includes(ctx.user.role)
        ) {
          throw new TRPCError({ code: "FORBIDDEN", message: "You do not have permission to edit this report" });
        }

        const updateData: Partial<InsertCMRReport> = {
          lastUpdatedAt: new Date(),
          lastUpdatedBy: ctx.user.id,
        };

        if (input.estimatedValue !== undefined) {
          updateData.estimatedValue = String(input.estimatedValue);
        }
        if (input.currentConfidencePct !== undefined) {
          // NEVER overwrite originalPcPct — only update currentConfidencePct
          updateData.currentConfidencePct = input.currentConfidencePct;
        }

        const updatedReport = await updateCMRReport(input.reportId, updateData);
        return updatedReport;
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        console.error("[CMR] Failed to quick edit report:", error);
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Failed to quick edit CMR report" });
      }
    }),

  /**
   * Delete a CMR report
   */
  delete: protectedProcedure
    .input(z.object({ reportId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) {
        throw new TRPCError({ code: "UNAUTHORIZED" });
      }

      try {
        const report = await getCMRReport(input.reportId);
        if (!report) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "CMR report not found",
          });
        }

        // Check permissions
        if (
          report.userId !== ctx.user.id &&
          !["admin", "super-admin"].includes(ctx.user.role)
        ) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "You do not have permission to delete this report",
          });
        }

        await deleteCMRReport(input.reportId);
        return { success: true };
      } catch (error) {
        if (error instanceof TRPCError) throw error;
        console.error("[CMR] Failed to delete report:", error);
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to delete CMR report",
        });
      }
    }),
});
