/**
 * Motorized Screens Router
 * Handles CRUD for headers, lines, attachments, workflow transitions,
 * reference data (manufacturers, motor types, remote types), and calculations.
 */

import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { protectedProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import {
  screenMeasurementHeaders,
  screenMeasurementLines,
  screenMeasurementAttachments,
  screenMeasurementLineAttachments,
  screenManufacturers,
  screenMotorTypes,
  screenRemoteTypes,
  screenInstallMounts,
  screenCalculationProfiles,
  users,
  type InsertScreenMeasurementHeader,
  type InsertScreenMeasurementLine,
  type ScreenMeasurementStatus,
} from "../../drizzle/schema";
import { eq, desc, and, or, sql } from "drizzle-orm";
import { storagePut, storageGet } from "../storage";
import {
  isTransitionAllowed,
  canView,
  canEditHeader,
  canEditLines,
  canManageAttachments,
  canApprove,
  canDelete,
  calculateScreenLine,
  generateRecordNumber,
  type WorkflowUser,
} from "../screen-workflow";

// ─── Zod schemas ──────────────────────────────────────────────────────────────

const headerCreateInput = z.object({
  projectId: z.number().nullable().optional(),
  cmrId: z.number().nullable().optional(),
  manufacturerCode: z.string().nullable().optional(),
  motorType: z.string().nullable().optional(),
  remoteType: z.string().nullable().optional(),
  installMount: z.enum(["face-mount", "inside-mount", "ceiling-mount", "other"]).nullable().optional(),
  faceMountSides: z.enum(["both", "left-only", "right-only", "none"]).nullable().optional(),
  applyUChannelToAll: z.boolean().optional(),
  calculationProfileCode: z.string().nullable().optional(),
  measurementDate: z.string().nullable().optional(),
  siteNotes: z.string().nullable().optional(),
});

const headerUpdateInput = headerCreateInput.extend({
  id: z.number(),
});

const lineUpsertInput = z.object({
  id: z.number().optional(),
  headerId: z.number(),
  screenLabel: z.string().nullable().optional(),
  sortOrder: z.number().optional(),
  ul: z.number().nullable().optional(),
  ll: z.number().nullable().optional(),
  ol: z.number().nullable().optional(),
  ur: z.number().nullable().optional(),
  lr: z.number().nullable().optional(),
  orMeasurement: z.number().nullable().optional(),
  t: z.number().nullable().optional(),
  m: z.number().nullable().optional(),
  b: z.number().nullable().optional(),
  reverseMeasurements: z.boolean().optional(),
  // Per-screen parity fields (dev-only extension)
  motorSide: z.string().nullable().optional(),
  remoteType: z.string().nullable().optional(),
  numberOfCuts: z.number().nullable().optional(),
  powerConnectionType: z.enum(["plugged", "hardwired", "other"]).nullable().optional(),
  powerConnectionOtherText: z.string().nullable().optional(),
  uChannelNeeded: z.boolean().optional(),
  uChannelReason: z.string().nullable().optional(),
  buildOutRequired: z.boolean().optional(),
  buildOutType: z.string().nullable().optional(),
  notes: z.string().nullable().optional(),
});

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getWorkflowUser(ctx: { user: { id: number; role: string } }): WorkflowUser {
  return { id: ctx.user.id, role: ctx.user.role as WorkflowUser["role"] };
}

function requireDb<T>(db: T | null): asserts db is T {
  if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Database unavailable." });
}

async function getHeaderOrThrow(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  id: number
) {
  const rows = await db
    .select()
    .from(screenMeasurementHeaders)
    .where(eq(screenMeasurementHeaders.id, id))
    .limit(1);
  if (!rows[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Screen measurement record not found." });
  return rows[0];
}

/**
 * recalculateLine
 *
 * Loads the pinned calculation profile using both code and version from the header,
 * then delegates to calculateScreenLine with the full profile rule set.
 *
 * Profile lookup order:
 *   1. Match by code AND version (the pinned version stored on the header at creation time).
 *   2. Fall back to code-only match if the pinned version no longer exists (e.g. profile was
 *      replaced without incrementing version — should not happen in normal operation).
 *   3. Fall back to an empty profile object, which causes calculateScreenLine to use its
 *      documented defaults for every threshold.
 *
 * The profile is intentionally NOT re-pinned here. Version pinning happens only in the
 * `create` procedure so that historical records are never affected by rule changes.
 */
async function recalculateLine(
  db: NonNullable<Awaited<ReturnType<typeof getDb>>>,
  line: Parameters<typeof calculateScreenLine>[0],
  header: typeof screenMeasurementHeaders.$inferSelect
) {
  const profileCode = header.calculationProfileCode ?? "default-v1";
  const profileVersion = header.calculationVersion ?? null;

  // Attempt to load the exact pinned version first.
  let profileRows: (typeof screenCalculationProfiles.$inferSelect)[] = [];
  if (profileVersion !== null) {
    profileRows = await db
      .select()
      .from(screenCalculationProfiles)
      .where(
        and(
          eq(screenCalculationProfiles.code, profileCode),
          eq(screenCalculationProfiles.version, profileVersion)
        )
      )
      .limit(1);
  }

  // Fall back to code-only if the pinned version was not found.
  if (profileRows.length === 0) {
    profileRows = await db
      .select()
      .from(screenCalculationProfiles)
      .where(eq(screenCalculationProfiles.code, profileCode))
      .limit(1);
  }

  const profile = profileRows[0] ?? {};

  // Cast each JSON column to its typed shape and pass the full rule set.
  // New fields (slopeRulesJson, tbRulesJson, biasRulesJson) are read from the profile
  // if present; calculateScreenLine falls back to documented defaults when they are absent.
  return calculateScreenLine(line, header, {
    uChannelThreshold: profile.uChannelThreshold
      ? parseFloat(String(profile.uChannelThreshold))
      : undefined,
    buildoutRulesJson: profile.buildoutRulesJson as
      | { thresholdInches?: number }
      | null,
    trackRulesJson: profile.trackRulesJson as
      | { trackWidthInches?: number }
      | null,
    extendedHoodRulesJson: profile.extendedHoodRulesJson as
      | { slopeThresholdInches?: number }
      | null,
    toleranceRulesJson: profile.toleranceRulesJson as
      | { widthToleranceInches?: number; heightToleranceInches?: number }
      | null,
    // Extended rule sets — stored in JSON columns not yet in the DB schema.
    // These are read via type assertion from the raw profile row if the column
    // is ever added; until then they resolve to undefined and the engine uses defaults.
    slopeRulesJson: (profile as Record<string, unknown>).slopeRulesJson as
      | { levelThresholdInches?: number; largeWarningThresholdInches?: number }
      | null
      | undefined,
    tbRulesJson: (profile as Record<string, unknown>).tbRulesJson as
      | { largeWarningThresholdInches?: number }
      | null
      | undefined,
    biasRulesJson: (profile as Record<string, unknown>).biasRulesJson as
      | { largeWarningThresholdInches?: number }
      | null
      | undefined,
    manufacturerUChannelThresholdsJson: (profile as Record<string, unknown>).manufacturerUChannelThresholdsJson as
      | Record<string, number>
      | null
      | undefined,
  });
}

// ─── Router ───────────────────────────────────────────────────────────────────

export const screensRouter = router({

  // ── Reference data ──────────────────────────────────────────────────────────

  getManufacturers: protectedProcedure.query(async () => {
    const db = await getDb();
    requireDb(db);
    return db.select().from(screenManufacturers).where(eq(screenManufacturers.active, 1));
  }),

  getMotorTypes: protectedProcedure
    .input(z.object({ manufacturerCode: z.string().optional() }))
    .query(async ({ input }) => {
      const db = await getDb();
      requireDb(db);
      const conditions = [eq(screenMotorTypes.active, 1)];
      if (input.manufacturerCode) conditions.push(eq(screenMotorTypes.manufacturerCode, input.manufacturerCode));
      return db.select().from(screenMotorTypes).where(and(...conditions));
    }),

  getRemoteTypes: protectedProcedure
    .input(z.object({ manufacturerCode: z.string().optional() }))
    .query(async ({ input }) => {
      const db = await getDb();
      requireDb(db);
      const conditions = [eq(screenRemoteTypes.active, 1)];
      if (input.manufacturerCode) conditions.push(eq(screenRemoteTypes.manufacturerCode, input.manufacturerCode));
      return db.select().from(screenRemoteTypes).where(and(...conditions));
    }),

  getInstallMounts: protectedProcedure.query(async () => {
    const db = await getDb();
    requireDb(db);
    return db
      .select()
      .from(screenInstallMounts)
      .orderBy(screenInstallMounts.sortOrder);
  }),

  // ── Header CRUD ─────────────────────────────────────────────────────────────

   list: protectedProcedure
    .input(z.object({
      view: z.enum(["my", "all"]).default("my"),
      status: z.enum(["draft", "submitted", "approved", "closed", "cancelled", "archived"]).optional(),
      manufacturerCode: z.string().optional(),
    }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      requireDb(db);
      const user = getWorkflowUser(ctx);
      const canSeeAll = ["manager", "admin", "super-admin"].includes(user.role);
      const conditions = [eq(screenMeasurementHeaders.archivedFlag, 0)];
      if (input.view === "my" || !canSeeAll) {
        conditions.push(eq(screenMeasurementHeaders.ownerId, user.id));
      }
      if (input.status) conditions.push(eq(screenMeasurementHeaders.status, input.status));
      if (input.manufacturerCode) conditions.push(eq(screenMeasurementHeaders.manufacturerCode, input.manufacturerCode));

      // Fetch headers with owner name (left join on users)
      const rows = await db
        .select({
          // All header columns
          id: screenMeasurementHeaders.id,
          recordNumber: screenMeasurementHeaders.recordNumber,
          ownerId: screenMeasurementHeaders.ownerId,
          projectId: screenMeasurementHeaders.projectId,
          cmrId: screenMeasurementHeaders.cmrId,
          status: screenMeasurementHeaders.status,
          manufacturerCode: screenMeasurementHeaders.manufacturerCode,
          motorType: screenMeasurementHeaders.motorType,
          remoteType: screenMeasurementHeaders.remoteType,
          installMount: screenMeasurementHeaders.installMount,
          faceMountSides: screenMeasurementHeaders.faceMountSides,
          applyUChannelToAll: screenMeasurementHeaders.applyUChannelToAll,
          calculationProfileCode: screenMeasurementHeaders.calculationProfileCode,
          calculationVersion: screenMeasurementHeaders.calculationVersion,
          measurementDate: screenMeasurementHeaders.measurementDate,
          siteNotes: screenMeasurementHeaders.siteNotes,
          approvedBy: screenMeasurementHeaders.approvedBy,
          approvedAt: screenMeasurementHeaders.approvedAt,
          createdBy: screenMeasurementHeaders.createdBy,
          updatedBy: screenMeasurementHeaders.updatedBy,
          archivedFlag: screenMeasurementHeaders.archivedFlag,
          createdAt: screenMeasurementHeaders.createdAt,
          updatedAt: screenMeasurementHeaders.updatedAt,
          // Resolved owner name
          ownerFirstName: users.firstName,
          ownerLastName: users.lastName,
        })
        .from(screenMeasurementHeaders)
        .leftJoin(users, eq(users.id, screenMeasurementHeaders.ownerId))
        .where(and(...conditions))
        .orderBy(desc(screenMeasurementHeaders.createdAt));

      // Fetch line counts for all returned header IDs in one query
      const headerIds = rows.map((r) => r.id);
      let lineCounts: Record<number, number> = {};
      if (headerIds.length > 0) {
        const countRows = await db
          .select({
            headerId: screenMeasurementLines.headerId,
            cnt: sql<number>`COUNT(*)`.as("cnt"),
          })
          .from(screenMeasurementLines)
          .where(
            headerIds.length === 1
              ? eq(screenMeasurementLines.headerId, headerIds[0])
              : sql`${screenMeasurementLines.headerId} IN (${sql.join(headerIds.map((id) => sql`${id}`), sql`, `)})`
          )
          .groupBy(screenMeasurementLines.headerId);
        for (const row of countRows) {
          lineCounts[row.headerId] = Number(row.cnt);
        }
      }

      return rows.map((r) => ({
        ...r,
        ownerName: [r.ownerFirstName, r.ownerLastName].filter(Boolean).join(" ") || null,
        lineCount: lineCounts[r.id] ?? 0,
      }));
    }),

  get: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      requireDb(db);
      const user = getWorkflowUser(ctx);
      const header = await getHeaderOrThrow(db, input.id);

      if (!canView(user, header.ownerId)) {
        throw new TRPCError({ code: "FORBIDDEN", message: "You do not have access to this record." });
      }

      const lines = await db
        .select()
        .from(screenMeasurementLines)
        .where(eq(screenMeasurementLines.headerId, input.id))
        .orderBy(screenMeasurementLines.sortOrder, screenMeasurementLines.id);

      const attachments = await db
        .select()
        .from(screenMeasurementAttachments)
        .where(eq(screenMeasurementAttachments.recordId, input.id));

      return { header, lines, attachments };
    }),

  create: protectedProcedure
    .input(headerCreateInput)
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      requireDb(db);
      const user = getWorkflowUser(ctx);

      // Generate record number from the last existing one
      const lastRows = await db
        .select({ recordNumber: screenMeasurementHeaders.recordNumber })
        .from(screenMeasurementHeaders)
        .orderBy(desc(screenMeasurementHeaders.id))
        .limit(1);
      const recordNumber = generateRecordNumber(lastRows[0]?.recordNumber ?? null);

      // Pin calculation profile version
      const profileCode = input.calculationProfileCode ?? "default-v1";
      const profileRows = await db
        .select({ version: screenCalculationProfiles.version })
        .from(screenCalculationProfiles)
        .where(eq(screenCalculationProfiles.code, profileCode))
        .limit(1);
      const profileVersion = profileRows[0]?.version ?? 1;

      const insertData: InsertScreenMeasurementHeader = {
        recordNumber,
        status: "draft",
        ownerId: user.id,
        projectId: input.projectId ?? null,
        cmrId: input.cmrId ?? null,
        manufacturerCode: input.manufacturerCode ?? null,
        motorType: input.motorType ?? null,
        remoteType: input.remoteType ?? null,
        installMount: input.installMount ?? null,
        faceMountSides: input.faceMountSides ?? null,
        applyUChannelToAll: input.applyUChannelToAll ? 1 : 0,
        calculationProfileCode: profileCode,
        calculationVersion: profileVersion,
        measurementDate: input.measurementDate ? new Date(input.measurementDate) : null,
        siteNotes: input.siteNotes ?? null,
        createdBy: user.id,
        updatedBy: user.id,
      };

      await db.insert(screenMeasurementHeaders).values(insertData);

      // Retrieve the newly created record by unique recordNumber
      const newRows = await db
        .select({ id: screenMeasurementHeaders.id })
        .from(screenMeasurementHeaders)
        .where(eq(screenMeasurementHeaders.recordNumber, recordNumber))
        .limit(1);

      return { id: newRows[0]?.id ?? 0, recordNumber };
    }),

  update: protectedProcedure
    .input(headerUpdateInput)
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      requireDb(db);
      const user = getWorkflowUser(ctx);
      const header = await getHeaderOrThrow(db, input.id);

      const check = canEditHeader(user, header.ownerId, header.status as ScreenMeasurementStatus);
      if (!check.allowed) throw new TRPCError({ code: "FORBIDDEN", message: check.reason });

      await db
        .update(screenMeasurementHeaders)
        .set({
          projectId: input.projectId ?? null,
          cmrId: input.cmrId ?? null,
          manufacturerCode: input.manufacturerCode ?? null,
          motorType: input.motorType ?? null,
          remoteType: input.remoteType ?? null,
          installMount: input.installMount ?? null,
          faceMountSides: input.faceMountSides ?? null,
          applyUChannelToAll: input.applyUChannelToAll ? 1 : 0,
          measurementDate: input.measurementDate ? new Date(input.measurementDate) : null,
          siteNotes: input.siteNotes ?? null,
          updatedBy: user.id,
        })
        .where(eq(screenMeasurementHeaders.id, input.id));

      return { success: true };
    }),

  transition: protectedProcedure
    .input(z.object({
      id: z.number(),
      to: z.enum(["draft", "submitted", "approved", "closed", "cancelled", "archived"]),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      requireDb(db);
      const user = getWorkflowUser(ctx);
      const header = await getHeaderOrThrow(db, input.id);

      const check = isTransitionAllowed(
        header.status as ScreenMeasurementStatus,
        input.to,
        user,
        header.ownerId
      );
      if (!check.allowed) throw new TRPCError({ code: "FORBIDDEN", message: check.reason });

      if (input.to === "approved" && !canApprove(user)) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Approving requires manager role or higher." });
      }

      const updateData: Partial<InsertScreenMeasurementHeader> = {
        status: input.to,
        updatedBy: user.id,
      };
      if (input.to === "approved") {
        updateData.approvedBy = user.id;
        updateData.approvedAt = new Date();
      }

      await db
        .update(screenMeasurementHeaders)
        .set(updateData)
        .where(eq(screenMeasurementHeaders.id, input.id));

      return { success: true, newStatus: input.to };
    }),

  archive: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      requireDb(db);
      const user = getWorkflowUser(ctx);
      const header = await getHeaderOrThrow(db, input.id);

      if (!canDelete(user) && user.id !== header.ownerId) {
        throw new TRPCError({ code: "FORBIDDEN", message: "You do not have permission to archive this record." });
      }

      await db
        .update(screenMeasurementHeaders)
        .set({ archivedFlag: 1, status: "archived", updatedBy: user.id })
        .where(eq(screenMeasurementHeaders.id, input.id));

      return { success: true };
    }),

  // ── Lines ───────────────────────────────────────────────────────────────────

  upsertLine: protectedProcedure
    .input(lineUpsertInput)
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      requireDb(db);
      const user = getWorkflowUser(ctx);
      const header = await getHeaderOrThrow(db, input.headerId);

      const check = canEditLines(user, header.ownerId, header.status as ScreenMeasurementStatus);
      if (!check.allowed) throw new TRPCError({ code: "FORBIDDEN", message: check.reason });

      const lineForCalc = {
        ul: input.ul ?? null,
        ll: input.ll ?? null,
        ol: input.ol ?? null,
        ur: input.ur ?? null,
        lr: input.lr ?? null,
        orMeasurement: input.orMeasurement ?? null,
        t: input.t ?? null,
        m: input.m ?? null,
        b: input.b ?? null,
        reverseMeasurements: input.reverseMeasurements ? 1 : 0,
        uChannelNeeded: input.uChannelNeeded ? 1 : 0,
        uChannelReason: input.uChannelReason ?? null,
        buildOutRequired: input.buildOutRequired ? 1 : 0,
        buildOutType: input.buildOutType ?? null,
      } as Parameters<typeof calculateScreenLine>[0];

      const calc = await recalculateLine(db, lineForCalc, header);

      const n = (v: number | null | undefined) => (v !== null && v !== undefined ? String(v) : null);

      const lineData: InsertScreenMeasurementLine = {
        headerId: input.headerId,
        screenLabel: input.screenLabel ?? null,
        sortOrder: input.sortOrder ?? 0,
        ul: n(input.ul),
        ll: n(input.ll),
        ol: n(input.ol),
        ur: n(input.ur),
        lr: n(input.lr),
        orMeasurement: n(input.orMeasurement),
        t: n(input.t),
        m: n(input.m),
        b: n(input.b),
        reverseMeasurements: input.reverseMeasurements ? 1 : 0,
        motorSide: input.motorSide ?? null,
        remoteType: input.remoteType ?? null,
        numberOfCuts: input.numberOfCuts ?? null,
        powerConnectionType: input.powerConnectionType ?? null,
        powerConnectionOtherText: input.powerConnectionOtherText ?? null,
        uChannelNeeded: input.uChannelNeeded ? 1 : 0,
        uChannelReason: input.uChannelReason ?? null,
        buildOutRequired: input.buildOutRequired ? 1 : 0,
        buildOutType: input.buildOutType ?? null,
        notes: input.notes ?? null,
        upperSlope: n(calc.upperSlope),
        slopeDirection: calc.slopeDirection ?? null,
        highSide: n(calc.highSide),
        lowSide: n(calc.lowSide),
        leftHeight: n(calc.leftHeight),
        rightHeight: n(calc.rightHeight),
        tbDiff: n(calc.tbDiff),
        trackToTrack: n(calc.trackToTrack),
        extendedHood: calc.extendedHood ? 1 : 0,
        bias: n(calc.bias),
        orderableWidth: n(calc.orderableWidth),
        orderableHeight: n(calc.orderableHeight),
        leftSideMismatch: calc.leftSideMismatch ? 1 : 0,
        rightSideMismatch: calc.rightSideMismatch ? 1 : 0,
        calculationFlagsJson: calc.calculationFlagsJson,
        createdBy: user.id,
        updatedBy: user.id,
      };

      if (input.id) {
        const { createdBy: _cb, ...updateData } = lineData;
        await db
          .update(screenMeasurementLines)
          .set(updateData)
          .where(eq(screenMeasurementLines.id, input.id));
        return { id: input.id, calc };
      } else {
        await db.insert(screenMeasurementLines).values(lineData);
        // Retrieve new line ID by headerId + sortOrder + createdAt ordering
        const newRows = await db
          .select({ id: screenMeasurementLines.id })
          .from(screenMeasurementLines)
          .where(eq(screenMeasurementLines.headerId, input.headerId))
          .orderBy(desc(screenMeasurementLines.id))
          .limit(1);
        return { id: newRows[0]?.id ?? 0, calc };
      }
    }),

  deleteLine: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      requireDb(db);
      const user = getWorkflowUser(ctx);

      const lineRows = await db
        .select()
        .from(screenMeasurementLines)
        .where(eq(screenMeasurementLines.id, input.id))
        .limit(1);
      if (!lineRows[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Line not found." });

      const header = await getHeaderOrThrow(db, lineRows[0].headerId);
      const check = canEditLines(user, header.ownerId, header.status as ScreenMeasurementStatus);
      if (!check.allowed) throw new TRPCError({ code: "FORBIDDEN", message: check.reason });

      await db
        .delete(screenMeasurementLineAttachments)
        .where(eq(screenMeasurementLineAttachments.lineId, input.id));
      await db
        .delete(screenMeasurementLines)
        .where(eq(screenMeasurementLines.id, input.id));

      return { success: true };
    }),

  getLines: protectedProcedure
    .input(z.object({ headerId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      requireDb(db);
      const user = getWorkflowUser(ctx);
      const header = await getHeaderOrThrow(db, input.headerId);

      if (!canView(user, header.ownerId)) throw new TRPCError({ code: "FORBIDDEN" });

      const lines = await db
        .select()
        .from(screenMeasurementLines)
        .where(eq(screenMeasurementLines.headerId, input.headerId))
        .orderBy(screenMeasurementLines.sortOrder, screenMeasurementLines.id);

      const lineIds = lines.map((l) => l.id);
      const lineAttachments = lineIds.length > 0
        ? await db
            .select()
            .from(screenMeasurementLineAttachments)
            .where(
              lineIds.length === 1
                ? eq(screenMeasurementLineAttachments.lineId, lineIds[0])
                : or(...lineIds.map((id) => eq(screenMeasurementLineAttachments.lineId, id)))
            )
            .orderBy(screenMeasurementLineAttachments.lineId, screenMeasurementLineAttachments.sortOrder)
        : [];

      return lines.map((line) => ({
        ...line,
        attachments: lineAttachments.filter((a) => a.lineId === line.id),
      }));
    }),

  // ── Attachments ─────────────────────────────────────────────────────────────

  addAttachment: protectedProcedure
    .input(z.object({ recordId: z.number(), fileId: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      requireDb(db);
      const user = getWorkflowUser(ctx);
      const header = await getHeaderOrThrow(db, input.recordId);

      const check = canManageAttachments(user, header.ownerId, header.status as ScreenMeasurementStatus);
      if (!check.allowed) throw new TRPCError({ code: "FORBIDDEN", message: check.reason });

      await db.insert(screenMeasurementAttachments).values({
        recordId: input.recordId,
        fileId: input.fileId,
        uploadedBy: user.id,
      });

      const newRows = await db
        .select({ id: screenMeasurementAttachments.id })
        .from(screenMeasurementAttachments)
        .where(and(
          eq(screenMeasurementAttachments.recordId, input.recordId),
          eq(screenMeasurementAttachments.fileId, input.fileId)
        ))
        .orderBy(desc(screenMeasurementAttachments.id))
        .limit(1);

      return { id: newRows[0]?.id ?? 0 };
    }),

  removeAttachment: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      requireDb(db);
      const user = getWorkflowUser(ctx);

      const rows = await db
        .select()
        .from(screenMeasurementAttachments)
        .where(eq(screenMeasurementAttachments.id, input.id))
        .limit(1);
      if (!rows[0]) throw new TRPCError({ code: "NOT_FOUND" });

      const header = await getHeaderOrThrow(db, rows[0].recordId);
      const check = canManageAttachments(user, header.ownerId, header.status as ScreenMeasurementStatus);
      if (!check.allowed) throw new TRPCError({ code: "FORBIDDEN", message: check.reason });

      await db
        .delete(screenMeasurementAttachments)
        .where(eq(screenMeasurementAttachments.id, input.id));

      return { success: true };
    }),

  addLineAttachment: protectedProcedure
    .input(z.object({
      lineId: z.number(),
      fileId: z.string(),
      caption: z.string().nullable().optional(),
      photoType: z.enum(["overview", "detail", "problem", "measurement", "other"]).nullable().optional(),
      sortOrder: z.number().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      requireDb(db);
      const user = getWorkflowUser(ctx);

      const lineRows = await db
        .select()
        .from(screenMeasurementLines)
        .where(eq(screenMeasurementLines.id, input.lineId))
        .limit(1);
      if (!lineRows[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Line not found." });

      const header = await getHeaderOrThrow(db, lineRows[0].headerId);
      const check = canManageAttachments(user, header.ownerId, header.status as ScreenMeasurementStatus);
      if (!check.allowed) throw new TRPCError({ code: "FORBIDDEN", message: check.reason });

      await db.insert(screenMeasurementLineAttachments).values({
        lineId: input.lineId,
        fileId: input.fileId,
        caption: input.caption ?? null,
        photoType: input.photoType ?? null,
        sortOrder: input.sortOrder ?? 0,
        uploadedBy: user.id,
      });

      const newRows = await db
        .select({ id: screenMeasurementLineAttachments.id })
        .from(screenMeasurementLineAttachments)
        .where(and(
          eq(screenMeasurementLineAttachments.lineId, input.lineId),
          eq(screenMeasurementLineAttachments.fileId, input.fileId)
        ))
        .orderBy(desc(screenMeasurementLineAttachments.id))
        .limit(1);

      return { id: newRows[0]?.id ?? 0 };
    }),

  removeLineAttachment: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      requireDb(db);
      const user = getWorkflowUser(ctx);

      const rows = await db
        .select()
        .from(screenMeasurementLineAttachments)
        .where(eq(screenMeasurementLineAttachments.id, input.id))
        .limit(1);
      if (!rows[0]) throw new TRPCError({ code: "NOT_FOUND" });

      const lineRows = await db
        .select()
        .from(screenMeasurementLines)
        .where(eq(screenMeasurementLines.id, rows[0].lineId))
        .limit(1);
      if (!lineRows[0]) throw new TRPCError({ code: "NOT_FOUND" });

      const header = await getHeaderOrThrow(db, lineRows[0].headerId);
      const check = canManageAttachments(user, header.ownerId, header.status as ScreenMeasurementStatus);
      if (!check.allowed) throw new TRPCError({ code: "FORBIDDEN", message: check.reason });

      await db
        .delete(screenMeasurementLineAttachments)
        .where(eq(screenMeasurementLineAttachments.id, input.id));

      return { success: true };
    }),

  /**
   * uploadLinePhoto — upload a photo for a specific screen line.
   * Accepts base64-encoded file data, uploads to S3, and returns the key + URL.
   * The caller must then call addLineAttachment with the returned key as fileId.
   */
  uploadLinePhoto: protectedProcedure
    .input(z.object({
      lineId: z.number(),
      filename: z.string(),
      contentType: z.string(),
      base64Data: z.string(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      requireDb(db);
      const user = getWorkflowUser(ctx);
      // Verify line exists and user can manage attachments
      const lineRows = await db
        .select()
        .from(screenMeasurementLines)
        .where(eq(screenMeasurementLines.id, input.lineId))
        .limit(1);
      if (!lineRows[0]) throw new TRPCError({ code: "NOT_FOUND", message: "Line not found." });
      const header = await getHeaderOrThrow(db, lineRows[0].headerId);
      const check = canManageAttachments(user, header.ownerId, header.status as ScreenMeasurementStatus);
      if (!check.allowed) throw new TRPCError({ code: "FORBIDDEN", message: check.reason });
      const ext = input.filename.split(".").pop() ?? "jpg";
      const randomSuffix = Math.random().toString(36).slice(2, 10);
      const key = `screen-photos/${user.id}/line-${input.lineId}/${Date.now()}-${randomSuffix}.${ext}`;
      const buffer = Buffer.from(input.base64Data, "base64");
      const { url } = await storagePut(key, buffer, input.contentType);
      return { key, url };
    }),

  /**
   * getLineAttachmentUrls — resolve S3 keys to viewable URLs for a set of line attachments.
   * Returns an array of { id, url } objects.
   */
  getLineAttachmentUrls: protectedProcedure
    .input(z.object({ lineId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      requireDb(db);
      const user = getWorkflowUser(ctx);
      const lineRows = await db
        .select()
        .from(screenMeasurementLines)
        .where(eq(screenMeasurementLines.id, input.lineId))
        .limit(1);
      if (!lineRows[0]) throw new TRPCError({ code: "NOT_FOUND" });
      const header = await getHeaderOrThrow(db, lineRows[0].headerId);
      if (!canView(user, header.ownerId)) throw new TRPCError({ code: "FORBIDDEN" });
      const attachments = await db
        .select()
        .from(screenMeasurementLineAttachments)
        .where(eq(screenMeasurementLineAttachments.lineId, input.lineId))
        .orderBy(screenMeasurementLineAttachments.sortOrder, screenMeasurementLineAttachments.id);
      const results = await Promise.all(
        attachments.map(async (a) => {
          const { url } = await storageGet(a.fileId);
          return { id: a.id, fileId: a.fileId, caption: a.caption, photoType: a.photoType, url };
        })
      );
      return results;
    }),

  /**
   * exportPdf — generate a PDF for a screen measurement record.
   * Loads the header + all lines, builds HTML via the screens PDF template,
   * renders via the shared Puppeteer engine, and returns a base64-encoded PDF.
   */
  exportPdf: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      requireDb(db);
      const user = getWorkflowUser(ctx);

      // Load header
      const header = await getHeaderOrThrow(db, input.id);
      if (!canView(user, header.ownerId)) {
        throw new TRPCError({ code: "FORBIDDEN", message: "You do not have access to this record." });
      }

      // Load all lines
      const lines = await db
        .select()
        .from(screenMeasurementLines)
        .where(eq(screenMeasurementLines.headerId, input.id))
        .orderBy(screenMeasurementLines.sortOrder, screenMeasurementLines.id);

      // Resolve owner name
      const { users } = await import("../../drizzle/schema");
      const ownerRows = await db
        .select({ firstName: users.firstName, lastName: users.lastName })
        .from(users)
        .where(eq(users.id, header.ownerId))
        .limit(1);
      const ownerName = ownerRows[0]
        ? [ownerRows[0].firstName, ownerRows[0].lastName].filter(Boolean).join(" ") || null
        : null;

      // Resolve approvedBy name
      let approvedByName: string | null = null;
      if (header.approvedBy) {
        const approverRows = await db
          .select({ firstName: users.firstName, lastName: users.lastName })
          .from(users)
          .where(eq(users.id, header.approvedBy))
          .limit(1);
        approvedByName = approverRows[0]
          ? [approverRows[0].firstName, approverRows[0].lastName].filter(Boolean).join(" ") || null
          : null;
      }

      // Resolve exporter name (current user)
      const exporterRows = await db
        .select({ firstName: users.firstName, lastName: users.lastName })
        .from(users)
        .where(eq(users.id, user.id))
        .limit(1);
      const exportedByName = exporterRows[0]
        ? [exporterRows[0].firstName, exporterRows[0].lastName].filter(Boolean).join(" ") || null
        : null;

      // Build HTML and render PDF
      const { buildScreenMeasurementHtml } = await import("../pdf/modules/screens");
      const { renderToPdf } = await import("../pdf/render");

      const html = buildScreenMeasurementHtml({
        recordNumber: header.recordNumber,
        status: header.status,
        manufacturerCode: header.manufacturerCode,
        motorType: header.motorType,
        remoteType: header.remoteType,
        installMount: header.installMount,
        faceMountSides: header.faceMountSides,
        applyUChannelToAll: header.applyUChannelToAll,
        calculationProfileCode: header.calculationProfileCode,
        measurementDate: header.measurementDate,
        siteNotes: header.siteNotes,
        ownerName,
        approvedByName,
        approvedAt: header.approvedAt ?? null,
        lines: lines.map((l) => ({
          id: l.id,
          screenLabel: l.screenLabel,
          sortOrder: l.sortOrder,
          ul: l.ul,
          ll: l.ll,
          ol: l.ol,
          ur: l.ur,
          lr: l.lr,
          orMeasurement: l.orMeasurement,
          t: l.t,
          m: l.m,
          b: l.b,
          reverseMeasurements: l.reverseMeasurements,
          powerConnectionType: l.powerConnectionType,
          powerConnectionOtherText: l.powerConnectionOtherText,
          upperSlope: l.upperSlope,
          slopeDirection: l.slopeDirection,
          highSide: l.highSide,
          lowSide: l.lowSide,
          leftHeight: l.leftHeight,
          rightHeight: l.rightHeight,
          tbDiff: l.tbDiff,
          uChannelNeeded: l.uChannelNeeded,
          uChannelReason: l.uChannelReason,
          buildOutRequired: l.buildOutRequired,
          buildOutType: l.buildOutType,
          trackToTrack: l.trackToTrack,
          extendedHood: l.extendedHood,
          bias: l.bias,
          orderableWidth: l.orderableWidth,
          orderableHeight: l.orderableHeight,
          leftSideMismatch: l.leftSideMismatch,
          rightSideMismatch: l.rightSideMismatch,
          calculationFlagsJson: l.calculationFlagsJson,
          notes: l.notes,
        })),
        exportedByName,
        exportedAt: new Date(),
      });

      const pdfBuffer = await renderToPdf(html);
      return { base64: pdfBuffer.toString("base64") };
    }),
});
