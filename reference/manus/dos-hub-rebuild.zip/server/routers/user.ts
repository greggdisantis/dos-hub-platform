import { router, protectedProcedure, adminProcedure } from "../_core/trpc";
import * as db from "../db";
import { z } from "zod";

export const userRouter = router({
  list: protectedProcedure.query(async () => {
    const users = await db.getAllUsers();
    // Return only necessary fields for display
    return users.map((user) => ({
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
    }));
  }),

  /**
   * Get all users with full details for admin management
   * Only accessible to admin and super-admin users
   */
  listForManagement: adminProcedure.query(async () => {
    return await db.getAllUsersForManagement();
  }),

  /**
   * Update user management fields (role, userType, approved, etc.)
   * Only accessible to admin and super-admin users
   */
  updateManagement: adminProcedure
    .input(
      z.object({
        userId: z.number().int().positive(),
        role: z
          .enum(["pending", "guest", "member", "manager", "admin", "super-admin"])
          .optional(),
        userType: z
          .enum(["internal", "dealer", "sub-dealer", "vendor", "guest"])
          .optional(),
        approved: z.boolean().optional(),
        passwordChangeRequired: z.boolean().optional(),
        firstName: z.string().min(1).max(100).optional(),
        lastName: z.string().min(1).max(100).optional(),
        specialTags: z.array(z.string()).optional(),
      })
    )
    .mutation(async ({ input }) => {
      await db.updateUserManagement(input.userId, {
        role: input.role,
        userType: input.userType,
        approved: input.approved,
        passwordChangeRequired: input.passwordChangeRequired,
        firstName: input.firstName,
        lastName: input.lastName,
        specialTags: input.specialTags,
      });

      return { success: true };
    }),
});
