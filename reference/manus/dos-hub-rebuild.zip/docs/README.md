# DOS Hub — Operational Documentation

This directory contains checkpoint notes and SOPs that form the operational source of truth for the DOS Hub platform. All documents in this directory are authoritative and must be followed for the procedures they describe.

---

## Documents

| File | Title | Status |
|---|---|---|
| `tidb-password-rotation-sop.md` | TiDB Password Rotation & Secret Sync Procedure | Active — mandatory |

---

## Rules

- Do not delete documents from this directory.
- When a procedure changes, update the existing document and note the revision date at the top.
- All new operational procedures must be added here before they are considered part of the source of truth.
