# CMR PDF Reference Style Analysis

## Reference File
`Anil_Murthy_03-04-2026_210001.pdf`

## Layout Structure (Page 1)

### Header Band (full-width, dark navy #1a3a52 or similar)
- Left: "Distinctive Outdoor Structures" — large bold white text
- Left sub: "Client Meeting Report" — smaller white text below company name
- Right: Circular/pill badge showing "80% PC" in green (#22c55e or similar) — purchase confidence

### Client Summary Card (light gray background, rounded slightly)
- Large bold client name: "Anil Murthy"
- Subtitle row: "Mar 3, 2026 · Senior DiSantis · $85,000"
  (appointment date · consultant name · estimated value)

### Section Blocks (repeating pattern)
Each section has:
- Section header bar: dark navy background, white ALL-CAPS bold text (e.g. "CLIENT INFORMATION")
- Rows below: two-column layout
  - Left column (~35% width): label in gray, slightly smaller font
  - Right column (~65% width): value in dark text, normal weight
- Light horizontal dividers between rows
- No outer border on the section — just the header bar + rows

### Sections visible on page 1:
1. CLIENT INFORMATION
   - Consultant
   - Week Of
   - Source
   - Address
   - Client Type

2. DEAL STATUS
   - Status
   - Close Timeline
   - Conversation Summary

3. PURCHASE CONFIDENCE
   - Current PC%
   - Original PC%
   - Estimated Value
   - Decision Makers
   - Main Motivation
   - Main Hesitation

4. VALUE COMMUNICATED & OBJECTIONS
   - Financing Discussed?
   - Financing Reaction
   - Value Communicated
   - Client Response
   - Objection Notes

5. NEXT STEPS (empty section on page 1)

6. MARKETING FEEDBACK
   - Lead Quality
   - Expectation Alignment

### Page 2:
- Budget Alignment: Aligned
- (rest of page blank — content ended)
- Footer: light gray band at bottom

### Page 3 (header/footer only):
- Top center: "DOS Hub · Client Meeting Report · Anil Murthy · Mar 3, 2026 · Generated 3/4/2026"
- (This appears to be a continuation page with only footer/header metadata)

## Filename Format
`Anil_Murthy_03-04-2026_210001.pdf`
- Pattern: `{LastName}_{FirstName}_{MM-DD-YYYY}_{HHMMSS}.pdf`
- Or possibly: `{ClientName_underscored}_{date}_{time}.pdf`

## Key Design Rules to Implement

1. **Header band**: Full-width dark navy, company name + report type left, PC% badge right
2. **Client card**: Light gray background box with client name large + summary line
3. **Section header bars**: Dark navy full-width bars with white ALL-CAPS text (no rounded corners)
4. **Two-column rows**: Label (gray, ~35%) + Value (dark, ~65%), separated by thin lines
5. **No outer table borders** — just the header bar + internal row dividers
6. **Footer**: Light gray band at page bottom
7. **Page header on continuation pages**: Centered metadata line
8. **PC% badge**: Colored pill/circle in top-right of main header
9. **Font**: Sans-serif (appears to be a system font like Inter or similar)
10. **Colors**:
    - Navy: #1a3a52 (matches DOS Hub primary)
    - Label text: #6b7280 (gray)
    - Value text: #1f2937 (near-black)
    - Background: white
    - Section header: #1a3a52 with white text
    - Client card bg: #f3f4f6 (light gray)
    - PC% badge: green (#16a34a or similar)

## Filename Generation
Current: `CMR_{ClientName}_{YYYY-MM-DD}.pdf`
Target: `{ClientName_underscored}_{MM-DD-YYYY}_{HHMMSS}.pdf`
Example: `Anil_Murthy_03-04-2026_210001.pdf`
