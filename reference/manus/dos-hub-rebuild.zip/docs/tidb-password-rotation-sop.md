# DOS Hub — TiDB Password Rotation & Secret Sync Procedure

**Document type:** Internal SOP / Architecture Checkpoint Note  
**Cluster:** `gateway01.us-east-1.prod.aws.tidbcloud.com:4000`  
**User:** `4R5HJpcn2iDQSh6.root`  
**Last updated:** March 15, 2026  
**Trigger:** TiDB Cloud password reset on 2026-03-14 caused `ER_ACCESS_DENIED_ERROR` in Cloud Run due to stale `DATABASE_URL` in GCP Secret Manager.

---

## Purpose

Whenever the TiDB Cloud password for `4R5HJpcn2iDQSh6.root` is changed, four secrets across two environments must be updated in a specific order. Failing to update all four will cause either Cloud Run login failures, dev server connection errors, or silent schema diff failures. This document defines the mandatory procedure.

---

## Scope

| System | Secret | Environment |
|---|---|---|
| GCP Secret Manager → Cloud Run | `DATABASE_URL` | Production |
| Manus Secrets | `DATABASE_URL_DEV` | Development |
| Manus Secrets | `GATEWAY01_DEV_URL` | Development (scripts) |
| TiDB Cloud Console | Source of truth for new password | Both |

---

## Step 1 — Reset Password in TiDB Cloud

1. Log in to [TiDB Cloud Console](https://tidbcloud.com).
2. Navigate to the cluster: **gateway01.us-east-1.prod.aws.tidbcloud.com**.
3. Go to **Connect** → **Connection String**.
4. Select user `4R5HJpcn2iDQSh6.root`.
5. Click **Reset Password** and copy the new password immediately.
6. Construct the two connection strings before proceeding:

**Production string (dos_hub_prod):**
```
mysql://4R5HJpcn2iDQSh6.root:<NEW_PASSWORD>@gateway01.us-east-1.prod.aws.tidbcloud.com:4000/dos_hub_prod?ssl=%7B%22rejectUnauthorized%22%3Atrue%7D
```

**Dev string (dos_hub_dev):**
```
mysql://4R5HJpcn2iDQSh6.root:<NEW_PASSWORD>@gateway01.us-east-1.prod.aws.tidbcloud.com:4000/dos_hub_dev?ssl=%7B%22rejectUnauthorized%22%3Atrue%7D
```

> **Important:** Always use URL-encoded SSL parameter `ssl=%7B%22rejectUnauthorized%22%3Atrue%7D`. Do not use the raw JSON form `ssl={"rejectUnauthorized":true}` — it may be misinterpreted by some MySQL clients.

---

## Step 2 — Update GCP Secret Manager (Production)

From a terminal with `gcloud` authenticated to the correct GCP project:

```bash
echo -n "mysql://4R5HJpcn2iDQSh6.root:<NEW_PASSWORD>@gateway01.us-east-1.prod.aws.tidbcloud.com:4000/dos_hub_prod?ssl=%7B%22rejectUnauthorized%22%3Atrue%7D" | \
  gcloud secrets versions add DATABASE_URL \
    --data-file=- \
    --project="YOUR_GCP_PROJECT_ID"
```

> **Critical:** Always use `echo -n` — a trailing newline in the secret value causes a silent credential mismatch that is difficult to diagnose. Do not use `echo` without `-n`.

> **Do not rename the secret.** Add a new version to the existing `DATABASE_URL` secret. Cloud Run will pick up `DATABASE_URL:latest` on the next deploy.

---

## Step 3 — Redeploy Cloud Run to Pick Up Latest Secret

```bash
gcloud run services update YOUR_SERVICE_NAME \
  --region=us-east1 \
  --project="YOUR_GCP_PROJECT_ID" \
  --update-secrets=DATABASE_URL=DATABASE_URL:latest
```

Or redeploy using the existing image:

```bash
gcloud run deploy YOUR_SERVICE_NAME \
  --region=us-east1 \
  --project="YOUR_GCP_PROJECT_ID" \
  --image=$(gcloud run services describe YOUR_SERVICE_NAME \
    --region=us-east1 \
    --format='value(spec.template.spec.containers[0].image)') \
  --update-secrets=DATABASE_URL=DATABASE_URL:latest
```

**Verify:** After the new revision is serving, test login. Cloud Run logs should show no `ER_ACCESS_DENIED_ERROR`. The server startup log should read:

```
Server running on http://0.0.0.0:PORT/
```

---

## Step 4 — Update Dev-Side Secrets in Manus

Update both secrets in the Manus project secrets panel or via the `webdev_request_secrets` tool:

| Secret | Value |
|---|---|
| `DATABASE_URL_DEV` | `mysql://4R5HJpcn2iDQSh6.root:<NEW_PASSWORD>@gateway01.us-east-1.prod.aws.tidbcloud.com:4000/dos_hub_dev?ssl=%7B%22rejectUnauthorized%22%3Atrue%7D` |
| `GATEWAY01_DEV_URL` | Same as above — identical host, user, password, and database |

Both secrets must use:

- Cluster: `gateway01.us-east-1.prod.aws.tidbcloud.com:4000`
- User: `4R5HJpcn2iDQSh6.root`
- Password: the new password from Step 1
- Database: `dos_hub_dev`

---

## Step 5 — Restart Dev Server and Verify

1. Restart the dev server to pick up the new secret values.
2. Run the DB connection test:

```bash
pnpm test server/db-connection.test.ts --reporter=verbose
```

Expected output:

```
✓ DATABASE_URL_DEV connection > should connect to dos_hub_dev and return a valid result
Test Files  1 passed (1)
Tests       1 passed (1)
```

3. Confirm the dev server responds on port 3000:

```bash
curl -s -o /dev/null -w "HTTP: %{http_code}\n" http://localhost:3000/api/trpc/auth.me?batch=1
# Expected: HTTP: 200
```

---

## Step 6 — Verification Checklist

Complete all items before closing the rotation event.

| Check | Method | Expected |
|---|---|---|
| Production login works | Browser test against Cloud Run URL | Successful login |
| Cloud Run logs clean | `gcloud logging read` — no `ER_ACCESS_DENIED` | No errors |
| Dev DB connection works | `pnpm test server/db-connection.test.ts` | 1 passed |
| Dev server HTTP healthy | `curl localhost:3000/api/trpc/auth.me` | HTTP 200 |
| Schema unchanged | `npx tsc --noEmit` | 0 errors |
| No prod data changed | Implicit — this procedure makes no DB writes | N/A |
| No code changed | Implicit — this procedure changes secrets only | N/A |

---

## Step 7 — Rules

The following rules are mandatory and must never be violated during a password rotation event.

> **Never update `DATABASE_URL` in GCP without also updating `DATABASE_URL_DEV` and `GATEWAY01_DEV_URL` in Manus.** All three use the same gateway01 user and password. Updating only one will cause the others to silently fail.

> **Never update dev secrets without also updating the production `DATABASE_URL`.** Partial updates cause environment drift and are harder to diagnose than a complete outage.

> **Never rotate the TiDB password without immediately updating all four secrets** (GCP `DATABASE_URL`, Manus `DATABASE_URL_DEV`, Manus `GATEWAY01_DEV_URL`, and verifying Cloud Run is redeployed).

> **Always use `echo -n`** when writing secret values via the command line. A trailing newline is invisible but causes `ER_ACCESS_DENIED_ERROR`.

> **Always use the URL-encoded SSL parameter** `ssl=%7B%22rejectUnauthorized%22%3Atrue%7D` in all connection strings. The raw JSON form may be misinterpreted.

> **Never rename the `DATABASE_URL` secret** in GCP Secret Manager. Add a new version to the existing secret. Cloud Run must reference `DATABASE_URL:latest`.

---

## Incident Reference

**Date:** 2026-03-14  
**Symptom:** `ER_ACCESS_DENIED_ERROR` for user `4R5HJpcn2iDQSh6.root` from Cloud Run egress IP `34.34.225.15`  
**Root cause:** TiDB password was reset but `DATABASE_URL` in GCP Secret Manager was not updated. Cloud Run continued mounting the stale secret version.  
**Resolution:** Reset TiDB password → added new `DATABASE_URL` version in GCP → redeployed Cloud Run → updated `DATABASE_URL_DEV` and `GATEWAY01_DEV_URL` in Manus → restarted dev server → verified DB connection test passes.  
**Time to resolution:** Same session.
