# DOS Hub — CI/CD Setup Instructions

**Status:** Required one-time setup before the GitHub Actions pipeline will run.  
**Applies to:** `greggdisantis/dos-hub-editor-main` → `main` branch  
**Environment:** `dos-hub-production` GCP project  

---

## What the pipeline does

Every push to `main` automatically:

1. Runs the SOP pre-build safety checks (Chromium, patches order, Vite rules)
2. Builds the container image tagged with the git short SHA
3. Pushes it to Artifact Registry
4. Deploys a Cloud Run **candidate revision** with `--no-traffic --tag candidate`

**Production traffic is never shifted automatically.** Manual promotion remains required.

---

## One-time GCP setup (run in Cloud Shell)

### Step 1 — Create the deployer service account

```bash
gcloud iam service-accounts create dos-hub-deployer \
  --project dos-hub-production \
  --display-name "DOS Hub GitHub Actions Deployer"
```

### Step 2 — Grant required roles

```bash
SA="dos-hub-deployer@dos-hub-production.iam.gserviceaccount.com"

# Push images to Artifact Registry
gcloud projects add-iam-policy-binding dos-hub-production \
  --member="serviceAccount:${SA}" \
  --role="roles/artifactregistry.writer"

# Deploy Cloud Run revisions (no traffic shift permission)
gcloud projects add-iam-policy-binding dos-hub-production \
  --member="serviceAccount:${SA}" \
  --role="roles/run.developer"

# Allow the SA to act as the Cloud Run runtime SA
# Replace RUNTIME_SA with the SA that Cloud Run uses (check in Cloud Console → Cloud Run → dos-hub → Security)
gcloud iam service-accounts add-iam-policy-binding RUNTIME_SA@dos-hub-production.iam.gserviceaccount.com \
  --member="serviceAccount:${SA}" \
  --role="roles/iam.serviceAccountUser" \
  --project dos-hub-production
```

> **Note:** `roles/run.developer` allows deploying revisions but does NOT allow shifting traffic.
> Traffic shift requires `roles/run.admin`, which is intentionally NOT granted to this SA.
> This enforces the candidate-first rule at the IAM level.

### Step 3 — Create and download the JSON key

```bash
SA="dos-hub-deployer@dos-hub-production.iam.gserviceaccount.com"

gcloud iam service-accounts keys create dos-hub-deployer-key.json \
  --iam-account="${SA}" \
  --project dos-hub-production
```

Store the downloaded `dos-hub-deployer-key.json` securely. Do not commit it to GitHub.

---

## One-time GitHub setup

### Step 4 — Add the secret to the GitHub repo

1. Go to `https://github.com/greggdisantis/dos-hub-editor-main`
2. Click **Settings → Secrets and variables → Actions**
3. Click **New repository secret**
4. Name: `GCP_SA_KEY`
5. Value: paste the **entire contents** of `dos-hub-deployer-key.json`
6. Click **Add secret**

After this step, every push to `main` will trigger the pipeline.

---

## What remains manual after setup

| Step | Who does it | How |
|---|---|---|
| Test the candidate URL | You | Obtain URL from the "Deploy candidate revision" step output in the Actions run, or from Cloud Run console (select revision tagged `candidate`) |
| Check Cloud Run logs | You | `gcloud run services logs read dos-hub --project dos-hub-production --region us-east1 --limit 50` |
| Promote to production | You (explicit approval required) | `gcloud run services update-traffic dos-hub --project dos-hub-production --region us-east1 --to-latest` |
| Rollback if needed | You | `gcloud run services update-traffic dos-hub --project dos-hub-production --region us-east1 --to-revisions PREVIOUS_REVISION=100` |

---

## Rollback

The previous production revision is never deleted automatically. To roll back:

```bash
# List revisions to find the previous one
gcloud run revisions list \
  --service dos-hub \
  --project dos-hub-production \
  --region us-east1

# Shift 100% traffic back to a specific revision
gcloud run services update-traffic dos-hub \
  --project dos-hub-production \
  --region us-east1 \
  --to-revisions dos-hub-REVISION_NAME=100
```

---

## Candidate URL

After each pipeline run, the candidate URL is printed in the **"Deploy candidate revision"** step output. Do not rely on a hardcoded URL — always obtain it from:

1. The GitHub Actions run log ("Deploy candidate revision" step output), **or**
2. The Cloud Run console → select the revision tagged `candidate` → copy the URL from the revision detail page

The URL format is typically `https://candidate---dos-hub-<project-hash>-ue.a.run.app` but the exact value must be confirmed from the live output, not assumed.

---

## Protection summary

| Protection | Enforced by |
|---|---|
| No automatic production traffic shift | `--no-traffic` flag in workflow |
| No traffic shift even if SA is compromised | SA only has `roles/run.developer`, not `roles/run.admin` |
| No DB / secret / cluster changes | Workflow contains no such commands |
| Candidate must be tested before promotion | Manual step, outside automation |
| Rollback always possible | Previous revision retained in Cloud Run |
