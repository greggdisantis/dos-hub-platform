#!/usr/bin/env node
/**
 * Import CMR Records from JSON
 * 
 * This script imports 11 real CMR records from a JSON export with safe field mapping.
 * - Uses idempotent logic to prevent duplicates (checks clientName + appointmentDate)
 * - Preserves consultant attribution in metadata
 * - Transforms legacy field names to current schema
 * - Sets all imported records to "submitted" status
 * - Locks originalPcPct on import
 */

import mysql from 'mysql2/promise';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Load environment variables
const DB_HOST = process.env.DB_HOST || 'localhost';
const DB_USER = process.env.DB_USER || 'root';
const DB_PASSWORD = process.env.DB_PASSWORD || '';
const DB_NAME = process.env.DB_NAME || 'dos_hub';
const DEFAULT_USER_ID = process.env.DEFAULT_USER_ID || 1; // Fallback user ID

// Load JSON data
const jsonPath = '/tmp/cmr_data.json';
const jsonData = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));

console.log(`\n📋 CMR Import Starting...`);
console.log(`   Total records to import: ${jsonData.reports.length}`);
console.log(`   Metadata: ${JSON.stringify(jsonData.metadata)}\n`);

// Field mapping functions
function mapLeadSource(source) {
  if (!source) return [];
  return [source];
}

function mapProjectTypes(types) {
  if (!types) return [];
  if (Array.isArray(types)) return types;
  return [types];
}

function mapValueCommunicated(value) {
  if (!value) return [];
  if (Array.isArray(value)) return value;
  // Split by comma and trim
  return value.split(',').map(v => v.trim());
}

function mapObjections(objections) {
  if (!objections) return [];
  if (Array.isArray(objections)) return objections;
  // Split by comma and trim
  return objections.split(',').map(v => v.trim());
}

function mapNextActions(actions) {
  if (!actions) return [];
  if (Array.isArray(actions)) return actions;
  // Split by comma and trim
  return actions.split(',').map(v => v.trim());
}

function mapFinancingDiscussed(value) {
  if (typeof value === 'boolean') return value ? 1 : 0;
  if (value === 'Yes' || value === 'yes' || value === true) return 1;
  if (value === 'No' || value === 'no' || value === false) return 0;
  return 0;
}

function mapCloseTimeline(timeline) {
  if (!timeline) return null;
  if (timeline === '0-30 days') return '0-30';
  if (timeline === '31-60 days') return '31-60';
  if (timeline === '61-90 days') return '61-90';
  if (timeline === '90+ days' || timeline === '90plus') return '90plus';
  return timeline.toLowerCase().replace(' days', '').replace('plus', 'plus');
}

function mapDealStatus(status) {
  if (!status) return null;
  return status.replace('_', '-');
}

function mapClientResponse(response) {
  if (!response) return null;
  if (response === 'Strong Alignment') return 'strong-alignment';
  return response.toLowerCase().replace(' ', '-');
}

async function importRecords() {
  let connection;
  try {
    // Connect to database
    connection = await mysql.createConnection({
      host: DB_HOST,
      user: DB_USER,
      password: DB_PASSWORD,
      database: DB_NAME,
    });

    console.log('✅ Connected to database\n');

    let importedCount = 0;
    let skippedCount = 0;
    const importedIds = [];
    const errors = [];

    for (const record of jsonData.reports) {
      try {
        // Check if record already exists (idempotent logic)
        const [existing] = await connection.query(
          'SELECT id FROM cmr_reports WHERE clientName = ? AND appointmentDate = ?',
          [record.clientName, record.appointmentDate]
        );

        if (existing.length > 0) {
          console.log(`⏭️  SKIP: "${record.clientName}" (${record.appointmentDate}) - already exists`);
          skippedCount++;
          continue;
        }

        // Map fields from JSON to schema
        const importRecord = {
          userId: DEFAULT_USER_ID,
          clientName: record.clientName,
          address: record.address === '—' ? null : record.address,
          clientType: record.clientType?.toLowerCase() || null,
          appointmentDate: record.appointmentDate,
          appointmentType: record.appointmentType?.toLowerCase().replace(' ', '-') || null,
          leadSources: JSON.stringify(mapLeadSource(record.leadSource)),
          projectTypes: JSON.stringify(mapProjectTypes(record.projectTypes)),
          dealStatus: mapDealStatus(record.dealStatus),
          followUpDate: record.followUpDate === '—' ? null : record.followUpDate,
          closeTimeline: mapCloseTimeline(record.estimatedCloseTimeline),
          lastConversationSummary: record.summaryOfLastConversation === '—' ? null : record.summaryOfLastConversation,
          purchaseConfidencePct: record.purchaseConfidencePct,
          originalPcPct: record.purchaseConfidencePct, // Lock at import time
          estimatedContractValue: record.estimatedContractValue || null,
          decisionMakers: record.decisionMakersInvolved === '—' ? null : record.decisionMakersInvolved,
          mainMotivation: record.mainMotivation === '—' ? null : record.mainMotivation,
          mainHesitation: record.mainHesitation === '—' ? null : record.mainHesitation,
          pcNotes: record.pcNotes === '—' ? null : record.pcNotes,
          financingDiscussed: mapFinancingDiscussed(record.financingDiscussed),
          financingReaction: record.financingReaction?.toLowerCase().replace(' ', '-') || null,
          valueCommunicated: JSON.stringify(mapValueCommunicated(record.valueCommunicated)),
          clientResponse: mapClientResponse(record.clientResponse),
          objections: JSON.stringify(mapObjections(record.objections)),
          objectionNotes: record.objectionsNotes === '—' ? null : record.objectionsNotes,
          nextActions: JSON.stringify(mapNextActions(record.nextActions)),
          nextFollowUpDate: record.nextFollowUpDate === '—' ? null : record.nextFollowUpDate,
          outcome: record.outcome?.toLowerCase() || 'open',
          status: 'submitted', // All imported records are submitted
          approvedStatus: 'submitted',
          progressNotes: JSON.stringify([
            {
              id: `import-${Date.now()}`,
              text: `Imported from legacy CMR export. Original consultant: ${record.consultantName}`,
              createdAt: new Date().toISOString(),
            }
          ]),
        };

        // Insert record
        const [result] = await connection.query(
          `INSERT INTO cmr_reports (
            userId, clientName, address, clientType, appointmentDate, appointmentType,
            leadSources, projectTypes, dealStatus, followUpDate, closeTimeline,
            lastConversationSummary, purchaseConfidencePct, originalPcPct,
            estimatedContractValue, decisionMakers, mainMotivation, mainHesitation,
            pcNotes, financingDiscussed, financingReaction, valueCommunicated,
            clientResponse, objections, objectionNotes, nextActions, nextFollowUpDate,
            outcome, status, approvedStatus, progressNotes
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            importRecord.userId, importRecord.clientName, importRecord.address,
            importRecord.clientType, importRecord.appointmentDate, importRecord.appointmentType,
            importRecord.leadSources, importRecord.projectTypes, importRecord.dealStatus,
            importRecord.followUpDate, importRecord.closeTimeline,
            importRecord.lastConversationSummary, importRecord.purchaseConfidencePct,
            importRecord.originalPcPct, importRecord.estimatedContractValue,
            importRecord.decisionMakers, importRecord.mainMotivation, importRecord.mainHesitation,
            importRecord.pcNotes, importRecord.financingDiscussed, importRecord.financingReaction,
            importRecord.valueCommunicated, importRecord.clientResponse, importRecord.objections,
            importRecord.objectionNotes, importRecord.nextActions, importRecord.nextFollowUpDate,
            importRecord.outcome, importRecord.status, importRecord.approvedStatus,
            importRecord.progressNotes,
          ]
        );

        console.log(`✅ IMPORT: "${record.clientName}" (${record.appointmentDate}) - ID: ${result.insertId}`);
        importedCount++;
        importedIds.push(result.insertId);

      } catch (err) {
        const errorMsg = `❌ ERROR importing "${record.clientName}": ${err.message}`;
        console.log(errorMsg);
        errors.push(errorMsg);
      }
    }

    console.log(`\n📊 Import Summary:`);
    console.log(`   ✅ Imported: ${importedCount}`);
    console.log(`   ⏭️  Skipped: ${skippedCount}`);
    console.log(`   ❌ Errors: ${errors.length}`);
    console.log(`   📍 New IDs: ${importedIds.join(', ')}`);

    if (errors.length > 0) {
      console.log(`\n⚠️  Errors encountered:`);
      errors.forEach(err => console.log(`   ${err}`));
    }

    // Verify import
    const [allRecords] = await connection.query('SELECT COUNT(*) as count FROM cmr_reports');
    console.log(`\n📈 Total CMR records in database: ${allRecords[0].count}`);

    return { importedCount, skippedCount, errors, importedIds };

  } catch (err) {
    console.error('❌ Fatal error:', err.message);
    process.exit(1);
  } finally {
    if (connection) await connection.end();
  }
}

// Run import
importRecords().then(() => {
  console.log('\n✅ Import complete!\n');
  process.exit(0);
}).catch(err => {
  console.error('❌ Import failed:', err);
  process.exit(1);
});
